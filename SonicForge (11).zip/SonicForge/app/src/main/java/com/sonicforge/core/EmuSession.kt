package com.sonicforge.core

import android.content.Context
import android.media.*
import android.media.audiofx.LoudnessEnhancer
import com.sonicforge.data.Library
import com.sonicforge.ui.SegaCd
import com.sonicforge.data.Logger
import com.sonicforge.data.Rom
import com.sonicforge.data.SaveEvent
import com.sonicforge.data.Store
import com.sonicforge.input.Haptics
import java.io.File
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.locks.LockSupport
import kotlin.math.log10
import kotlin.math.min

/** Runs the emulator on its own thread: input -> retro_run -> audio -> pacing. Also SRAM, save states, rewind, cheats, RAM-watch events. */
class EmuSession(private val ctx: Context, val rom: Rom) {
    @Volatile var paused = false
    @Volatile var running = false
    @Volatile var inputMask = 0
    @Volatile var targetFps = 0.0   // 0 = native
    @Volatile var turbo = false
    @Volatile var rewinding = false
    private var rewindBroken = false
    @Volatile var measuredFps = 0
    var nativeFps = 60.0; var sampleRate = 44100; var aspect = 1.4f
    var onEvent: ((String) -> Unit)? = null
    var error: String = ""
    private var thread: Thread? = null
    private var track: AudioTrack? = null
    private var le: LoudnessEnhancer? = null
    private val cmds = ConcurrentLinkedQueue<() -> Unit>()
    private val ring = ArrayDeque<ByteArray>()
    private val saveDir = File(ctx.filesDir, "saves").apply { mkdirs() }
    private val srm get() = File(saveDir, "${rom.id}.srm")
    fun statePath(slot: Int) = File(saveDir, "${rom.id}.st$slot")
    private fun prevPath(slot: Int) = File(saveDir, "${rom.id}.st$slot.prev")
    fun hasPrev(slot: Int) = prevPath(slot).exists()
    fun hasState(slot: Int) = statePath(slot).exists()

    fun start(): Boolean {
        val si = Systems.byId(rom.sys)
        var core = File(ctx.applicationInfo.nativeLibraryDir, si.core ?: "libgpgx.so")
        if (rom.sys == "nds") { val c = com.sonicforge.ui.Ds.pickCore(ctx); if (c != null) { core = c; Logger.i("Emu", "DS core: ${c.name}") } }
        if (rom.sys == "scd" && SegaCd.useAltCore(rom)) { val alt = File(ctx.applicationInfo.nativeLibraryDir, "libpicodrive.so"); if (alt.exists()) { core = alt; Logger.i("Emu", "Sega CD: using the PicoDrive core for this game (Mode 1 / hacks)") } else Logger.w("Emu", "Sega CD: PicoDrive was asked for but is not in this build; using Genesis Plus GX") }
        if (!core.exists()) { error = "The ${si.label} core (${core.name}) is not included in this build." + if (si.core == "libgpgx.so") " Run fetch_core.sh / the GitHub workflow." else " It is an optional download that failed or does not exist for your CPU."; Logger.e("Emu", error); return false }
        val sys = File(ctx.filesDir, "system").apply { mkdirs() }
        val cd = rom.sys == "scd"
        if (cd && listOf("bios_CD_U.bin", "bios_CD_E.bin", "bios_CD_J.bin").none { File(sys, it).exists() }) {
            error = "Sega CD needs a BIOS file (bios_CD_U.bin / _E / _J). Add it in the LOCATIONS tab."; Logger.w("Emu", error); return false }
        if (cd) try { com.sonicforge.ui.SegaCd.healBram(ctx) } catch (_: Throwable) {}
        try { Emu.clearOptions(); if (rom.sys == "nds") com.sonicforge.ui.Ds.coreOptions(ctx).forEach { (k, v) -> Emu.setOption(k, v); Logger.i("Emu", "core option $k = $v") }; if (cd && Store.s("scdRegion_${rom.id}", "auto") == "auto") SegaCd.discRegion(ctx, rom)?.let { r -> Store.set("scdRegion_${rom.id}", when (r) { 'U' -> "ntsc-u"; 'E' -> "pal"; else -> "ntsc-j" }); Logger.i("Emu", "Sega CD region taken from the disc: $r") }
            if (cd) SegaCd.coreOptions(rom.id).forEach { (k, v) -> Emu.setOption(k, v); Logger.i("Emu", "core option $k = $v") } } catch (_: Throwable) {}
        Logger.i("Emu", "Launching project emu: core ${core.name} (${if (core.exists()) core.length() / 1024 else 0} KB) for ${rom.title}")
        if (!Emu.loadCore(core.path, sys.path, saveDir.path)) { error = "Could not load emulator core: " + Emu.lastError(); Logger.context = "${rom.title} | ${rom.sys} | ${si.label}"; Logger.e("Emu", error + " (" + core.name + ")"); return false }
        val gameFile = File(ctx.filesDir, "roms/${rom.file}")
        if (!gameFile.exists() || gameFile.length() == 0L) { error = "The game file is missing or empty. Import this game again (+ ADD GAME): it will be repaired."; Logger.context = "${rom.title} | ${rom.sys}"; Logger.e("Emu", "${rom.title}: file missing or empty: ${gameFile.path}"); return false }
        // disc images are opened by the core itself from the path; reading a 1 GB image into memory first froze the app (ANR) in Super
        val av = Emu.loadGame(gameFile.path, cd || rom.sys in setOf("dc", "sat", "psp", "ps2", "gc", "wii", "3ds"))
        if (av == null) { drainCoreLogs(); error = if (cd) "The core could not start this Sega CD image. Open the game page and use SEGA CD TOOLS: it checks the BIOS, the disc image and the region." else "The core rejected this ROM."; Logger.e("Emu", "${rom.title}: $error"); return false }
        Logger.context = "${rom.title} | ${rom.sys} | " + Emu.coreInfo()
        nativeFps = av[0]; sampleRate = av[1].toInt(); aspect = av[4].toFloat()
        Logger.i("Emu", "loaded ${rom.title} (${rom.sys}) ${av[2].toInt()}x${av[3].toInt()} @ ${"%.2f".format(nativeFps)} fps, audio $sampleRate Hz")
        if (srm.exists()) Emu.setSram(srm.readBytes())
        Emu.setPadType(if (Store.b("sixButton", false)) 257 else 1)
        applyCheats()
        val minBuf = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
        track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(sampleRate).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build())
            .setBufferSizeInBytes(maxOf(minBuf, sampleRate / 8 * 4)).setTransferMode(AudioTrack.MODE_STREAM)
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY).build()
        le = try { LoudnessEnhancer(track!!.audioSessionId) } catch (_: Exception) { null }
        applyVolume(); track?.play()
        running = true
        thread = Thread(::loop, "emu").also { it.priority = Thread.MAX_PRIORITY; it.start() }
        return true
    }

    /** 0..200 %: up to 100 % is plain volume, above that Android's loudness enhancer adds gain */
    /** copies the core's own console lines (e.g. "Unable to open CD BIOS") into the logger */
    private fun drainCoreLogs() { try { Emu.popLogs().lines().filter { it.isNotBlank() }.forEach { l -> val lv = l.substringBefore('|').toIntOrNull() ?: 1; Logger.core(lv, l.substringAfter('|').trim()) } } catch (_: Throwable) {} }
    fun applyVolume() {
        val v = Store.i("volGame", 100) / 100f
        track?.setVolume(min(1f, v))
        try { le?.setTargetGain(if (v > 1f) (2000 * log10(v.toDouble())).toInt() else 0); le?.enabled = v > 1f } catch (_: Exception) {}
    }
    fun post(c: () -> Unit) { cmds.add(c) }

    fun applyCheats() {
        val r = Library.roms.firstOrNull { it.id == rom.id } ?: rom
        val codes = if (!Store.b("cheats_${rom.id}", true)) emptyList()
                    else r.cheats.lines().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") }.map { it.substringAfter('=', it).trim() }
        post { Emu.setCheats(codes.toTypedArray()) }
    }

    private fun loop() {
        val buf = ShortArray(8192)
        var next = System.nanoTime(); var frames = 0L; var cnt = 0; var t0 = next
        val stateSize = Emu.serializeSize()
        val prof = Watch.byId(rom.profile, rom.rings, rom.lives)
        val watcher = prof?.let { Watcher(it) }
        val rules = VibRules.effective(rom)
        val hasRam = prof != null || rules.isNotEmpty()
        val gm = Store.s("hapAudio_${rom.id}", ""); val gl = AudioHaptics.mode()
        // "full" = the sound decides (games without a memory map), "assist" = memory map first, sound only adds explosions, "off" = no sound haptics
        val audioMode = when { rom.sys == "flash" || gm == "off" -> "off"; gm == "on" -> "full"; gl == "off" -> "off"; gl == "always" -> "full"; rom.sys in setOf("scd", "sat", "dc", "ps2", "psp") -> "off"; hasRam -> if (Store.b("audioAssist", true)) "assist" else "off"; else -> "full" }   // disc systems: the CD music fooled the sound detector (random buzzing); switch it on per game in VIBRATION if wanted
        var lastRamEv = 0L
        val audioH = if (audioMode == "off") null else AudioHaptics(audioMode == "assist", { System.currentTimeMillis() - lastRamEv < 260 }) { ev -> Logger.d("Event", "audio " + ev); HapDebug.add("sound", ev, "loud burst in the audio, mode $audioMode"); onEvent?.invoke(ev) }
        Logger.i("Game", "vibration source for ${rom.title}: " + (if (prof != null) "memory map (${rom.profile})" else "") + (if (rules.isNotEmpty()) " rules(${rules.size})" else "") + (if (!hasRam) " none" else "") + " + sound: $audioMode" + " + preset: " + (Haptics.gamePreset(rom.id).takeIf { it > 0 }?.toString() ?: "global"))
        HapDebug.reset(); HapDebug.header = "${rom.title} | ${rom.sys} | id ${rom.id} | map: ${rom.profile.ifEmpty { "none" }} | rules: ${rules.size} | sound: $audioMode | RAM: ${if (hasRam) "readable" else "NOT readable"}"
        val ruleW = rules.takeIf { it.isNotEmpty() }?.let { RuleWatcher(it, rom.sys in VibRules.swapped) }
        while (running) {
            while (true) { cmds.poll()?.invoke() ?: break }
            if (paused) { track?.pause(); Thread.sleep(25); next = System.nanoTime(); t0 = next; cnt = 0; continue }
            if (track?.playState != AudioTrack.PLAYSTATE_PLAYING) track?.play()
            val memCap = (Store.i("rewindMb", 128).coerceIn(32, 512) * 1024L * 1024 / stateSize.coerceAtLeast(1)).toInt()   // rewind history may use at most ~64 MB (a DS state is 6.5 MB: it ran the phone out of memory)
            val rewindOn = Store.b("rewind", true) && stateSize > 0 && memCap >= 12 && !rewindBroken
            var spd = if (targetFps > 0) targetFps / nativeFps else 1.0
            val unlimited = targetFps < 0
            if (rewinding && rewindOn && ring.isNotEmpty()) {
                Emu.unserialize(ring.removeLast()); Emu.run(); Emu.getAudio(buf)
            } else {
                Emu.setInput(inputMask); Emu.run()
                val n = Emu.getAudio(buf)
                if (n > 0) { track?.write(buf, 0, n, AudioTrack.WRITE_NON_BLOCKING); audioH?.feed(buf, n) }
                val rwStep = if (stateSize > 1_500_000) 6 else 3   // big states (discs, DS): snapshot less often so the history reaches further back
                if (rewindOn && frames % rwStep == 0L) {
                    try {
                        val a = if (ring.size >= minOf((Store.i("rewindSec", 12) * nativeFps / rwStep).toInt().coerceIn(12, 1500), memCap)) ring.removeFirst() else ByteArray(stateSize)
                        if (Emu.serialize(a)) ring.addLast(a)
                    } catch (_: OutOfMemoryError) { ring.clear(); rewindBroken = true; Logger.notice("Rewind switched off for this game: not enough memory", false) }
                }
                if (turbo) spd *= Store.i("ffMult", 2).toDouble()
            }
            frames++; cnt++
            if (tilt > 0) tiltStep(frames) else tiltPrev = 0
            if (frames % 60L == 0L) emuLog(frames)
            if (ruleW != null && frames % 2 == 0L) ruleW.poll({ s, l -> if (s >= 0x02000000) Emu.readMapped(s, l) else Emu.readRam(s, l) }) { ev -> lastRamEv = System.currentTimeMillis(); Logger.d("Event", "rule " + ev); HapDebug.add("rule", ev, ruleW.lastWhy); onEvent?.invoke(ev) }
            if (watcher != null && frames % 2 == 0L) watcher.poll({ s, l -> Emu.readRam(s, l) }) { ev -> lastRamEv = System.currentTimeMillis(); Logger.d("Event", ev); HapDebug.add("ram-map", ev, "memory profile ${rom.profile}"); onEvent?.invoke(ev) }
            val now = System.nanoTime()
            if (now - t0 >= 1_000_000_000L) { measuredFps = cnt; cnt = 0; t0 = now; drainCoreLogs() }
            if (unlimited) { next = System.nanoTime(); continue }
            next += (1e9 / (nativeFps * spd)).toLong()
            val sleep = next - System.nanoTime()
            if (sleep > 0) LockSupport.parkNanos(sleep) else if (sleep < -100_000_000L) next = System.nanoTime()
        }
    }

    fun saveSram(quiet: Boolean = true) {
        post {
            val d = Emu.getSram()
            if (d != null) {
                val ok = try { srm.writeBytes(d); srm.length() == d.size.toLong() } catch (e: Exception) { false }
                if (!quiet) Store.events.tryEmit(SaveEvent("Game save written", ok))
            }
        }
    }
    fun saveState(slot: Int) = post {
        val n = Emu.serializeSize(); val a = ByteArray(n)
        try { if (statePath(slot).exists()) statePath(slot).copyTo(prevPath(slot), true) } catch (_: Exception) {}   // keep the previous save in case this one was a mistake
        val ok = n > 0 && Emu.serialize(a) && try { statePath(slot).writeBytes(a); statePath(slot).length() == n.toLong() } catch (e: Exception) { false }
        Store.events.tryEmit(SaveEvent("State $slot saved (previous one kept)", ok))
    }
    fun loadState(slot: Int) = post {
        val f = statePath(slot)
        val ok = f.exists() && Emu.unserialize(f.readBytes()); ring.clear()
        Store.events.tryEmit(SaveEvent(if (f.exists()) "State $slot loaded" else "State $slot is empty", ok))
    }
    fun restorePrevious(slot: Int) = post {
        val p = prevPath(slot)
        val ok = p.exists() && try { p.copyTo(statePath(slot), true); Emu.unserialize(statePath(slot).readBytes()) } catch (_: Exception) { false }
        Store.events.tryEmit(SaveEvent("Previous save of slot $slot restored", ok))
    }
    /** "Cartridge tilt": randomly corrupts a few bytes of work RAM for glitchy chaos (experimental) */
    @Volatile var tilt = 0
    private var tiltPrev = 0; private var tiltHits = 0L
    private val tiltCfg = arrayOf(intArrayOf(40, 1), intArrayOf(40, 1), intArrayOf(20, 2), intArrayOf(13, 3), intArrayOf(8, 4), intArrayOf(4, 8), intArrayOf(2, 16))
    /** Tilt modes 1-6: how often and how many bytes of work RAM are scrambled. Crash-safe keeps away from the stack and system variables (the last mode ignores it). */
    private fun tiltStep(frames: Long) {
        val lv = tilt.coerceIn(1, 6)
        if (tiltPrev == 0) saveState(9)   // a safe point is stored when tilting starts
        tiltPrev = lv
        val c = tiltCfg[lv]; if (frames % c[0] != 0L) return
        val safe = Store.b("tiltSafe", true) && lv < 6
        repeat(c[1]) {
            val addr = kotlin.random.Random.nextInt(if (safe) 0x0100 else 0, if (safe) 0xF800 else 0x10000)
            val v = if (lv >= 5 && kotlin.random.Random.nextInt(4) == 0) 0xFF else kotlin.random.Random.nextInt(256)
            Emu.writeRam(addr, v); tiltHits++
        }
    }
    fun markSafe() { saveState(9) }
    fun restoreSafe() { loadState(9) }
    fun stateTime(slot: Int): Long = statePath(slot).lastModified()
    private fun emuLog(frames: Long) {
        if (!Store.b("logEmu", false)) return; if (Store.b("logEmuTilt", false) && tilt == 0) return
        Logger.emu("fps=$measuredFps frames=$frames tilt=$tilt hits=$tiltHits paused=$paused turbo=$turbo")
    }
    fun reset() = post { Emu.reset(); ring.clear() }

    fun stop() {
        if (!running) return
        running = false
        thread?.join(1000)
        val s = Emu.getSram()
        if (s != null) try { srm.writeBytes(s) } catch (_: Exception) {}
        try { le?.release() } catch (_: Exception) {}
        track?.stop(); track?.release()
        Emu.unload()
        Logger.i("Emu", "stopped ${rom.title}")
    }
}
