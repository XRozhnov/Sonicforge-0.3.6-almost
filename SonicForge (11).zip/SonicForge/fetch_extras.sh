#!/usr/bin/env bash
# Optional build-time download of the Ruffle (Flash) web player into app/src/main/assets/ruffle.
# Two sources are tried: the GitHub release "web-selfhosted" zip, then the npm package @ruffle-rs/ruffle.
# If both fail the build still continues; the app then says that Ruffle is not included in this build.
D=app/src/main/assets/ruffle; rm -rf "$D"; mkdir -p "$D"
AUTH=(); [ -n "$GH_TOKEN" ] && AUTH=(-H "Authorization: Bearer $GH_TOKEN")
ok=0
URL=$(curl -fsSL "${AUTH[@]}" "https://api.github.com/repos/ruffle-rs/ruffle/releases?per_page=8" | python3 -c "
import sys, json
for r in json.load(sys.stdin):
    for a in r.get('assets', []):
        n = a.get('name', '')
        if 'web-selfhosted' in n and n.endswith('.zip'):
            print(a['browser_download_url']); sys.exit(0)
" 2>/dev/null)
if [ -n "$URL" ] && curl -fsSL "$URL" -o /tmp/ruffle.zip && unzip -qo /tmp/ruffle.zip -d "$D" && [ -f "$D/ruffle.js" ]; then
  echo "OK   ruffle from GitHub release: $URL"; ok=1
fi
if [ $ok -eq 0 ]; then
  rm -rf "$D"; mkdir -p "$D"
  if (cd /tmp && rm -rf rpk && mkdir rpk && cd rpk && npm pack @ruffle-rs/ruffle >/dev/null 2>&1 && tar xzf ./*.tgz && cp -r package/* "$OLDPWD/../$D/" 2>/dev/null); then :; fi
  # the line above runs in /tmp, so copy again with absolute paths to be safe
  ABS="$(pwd)/$D"
  if [ ! -f "$ABS/ruffle.js" ] && [ -d /tmp/rpk/package ]; then cp -r /tmp/rpk/package/* "$ABS/"; fi
  [ -f "$ABS/ruffle.js" ] && { echo "OK   ruffle from npm"; ok=1; }
fi
if [ $ok -eq 1 ]; then ls "$D" | head -20; else echo "MISS ruffle: Flash support will be disabled in this build"; rm -rf "$D"; mkdir -p "$D"; touch "$D/.empty"; fi
# a second, OLDER Ruffle build (the previous release) as a choice in the Flash settings: if the newest one misbehaves on a phone the older one may not
D2=app/src/main/assets/ruffle_old; rm -rf "$D2"; mkdir -p "$D2"
URL2=$(curl -fsSL "${AUTH[@]}" "https://api.github.com/repos/ruffle-rs/ruffle/releases?per_page=60" | python3 -c "
import sys, json
n = 0
for r in json.load(sys.stdin):
    for a in r.get('assets', []):
        nm = a.get('name', '')
        if 'web-selfhosted' in nm and nm.endswith('.zip'):
            n += 1
            if n == 12: print(a['browser_download_url']); sys.exit(0)
" 2>/dev/null)
if [ -n "$URL2" ] && curl -fsSL "$URL2" -o /tmp/ruffle_old.zip && unzip -qo /tmp/ruffle_old.zip -d "$D2" && [ -f "$D2/ruffle.js" ]; then echo "OK   older ruffle: $URL2"; else echo "MISS older ruffle (optional)"; rm -rf "$D2"; mkdir -p "$D2"; touch "$D2/.empty"; fi
exit 0
