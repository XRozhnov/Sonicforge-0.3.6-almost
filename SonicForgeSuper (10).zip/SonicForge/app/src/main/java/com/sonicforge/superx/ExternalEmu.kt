package com.sonicforge.superx

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import com.sonicforge.data.Logger
import com.sonicforge.data.Store

/** Finds the installed emulator app for a system and starts the game in it. Every step is written to the log so the ENGINE LOG panel can show it. */
object ExternalEmu {
    fun installed(ctx: Context, pkg: String): Boolean = try { ctx.packageManager.getPackageInfo(pkg, 0); true } catch (_: Exception) { false }
    /** the app chosen by hand for this system, else the first known one that is installed */
    fun chosen(ctx: Context, s: SSys): Emu? {
        val own = Store.s("superApp_" + s.id)
        if (own.isNotEmpty() && installed(ctx, own)) return Emu(own, own)
        return s.emus.firstOrNull { installed(ctx, it.pkg) }
    }
    /** all launcher apps on the phone, for picking an emulator by hand (needs the broad MAIN/LAUNCHER query from the manifest) */
    fun launcherApps(ctx: Context): List<Emu> {
        val pm = ctx.packageManager
        return pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0).map { Emu(it.activityInfo.packageName, it.loadLabel(pm).toString()) }.distinctBy { it.pkg }.sortedBy { it.name.lowercase() }
    }
    fun launch(ctx: Context, g: SGame) {
        val s = SuperSystems.byId(g.sys)
        Logger.i("Super", "Launching project emu for ${s.label}...")
        val emu = chosen(ctx, s)
        if (emu == null) {
            Logger.w("Super", "no emulator app found for ${s.label}. Known: " + (s.emus.joinToString { it.name }.ifEmpty { "none exist" }))
            Toast.makeText(ctx, if (s.emus.isEmpty()) com.sonicforge.ui.I18n.tr("No Android emulator exists for this system. Pick an app by hand if you have one.") else com.sonicforge.ui.I18n.tr("Install the emulator first (or pick another app).") + " " + s.emus.first().name, Toast.LENGTH_LONG).show(); return
        }
        Logger.i("Super", "emulator: ${emu.name} (${emu.pkg})")
        Logger.i("Super", "Starting game “${g.title}” normally...")
        val uri = Uri.parse(g.uri)
        val fl = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK
        val main = ctx.packageManager.getLaunchIntentForPackage(emu.pkg)
        // several ways, tried in turn, because emulators differ: VIEW with a type, VIEW with another type, VIEW without a type, and finally the emulator's own start screen asked to open the file
        val tries = listOf(
            "VIEW + octet-stream" to Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/octet-stream").setPackage(emu.pkg).addFlags(fl),
            "VIEW + any type" to Intent(Intent.ACTION_VIEW).setDataAndType(uri, "*/*").setPackage(emu.pkg).addFlags(fl),
            "VIEW without a type" to Intent(Intent.ACTION_VIEW).setData(uri).setPackage(emu.pkg).addFlags(fl),
        ) + (if (main?.component != null) listOf("the emulator's start screen asked to open the file" to Intent(Intent.ACTION_VIEW).setComponent(main.component).setData(uri).addFlags(fl)) else emptyList())
        for ((how, it) in tries) {
            try { ctx.startActivity(it); Logger.i("Super", "handed the file to ${emu.name}: $how (read permission granted)"); return }
            catch (e: ActivityNotFoundException) { Logger.w("Super", "${emu.name}: '$how' not accepted (no handler)") }
            catch (e: SecurityException) { Logger.w("Super", "${emu.name} was refused the file ($how): ${e.message}") }
            catch (e: Exception) { Logger.w("Super", "${emu.name}: '$how' failed: ${e.message}") }
        }
        Logger.w("Super", "${emu.name} does not accept a file directly (no VIEW handler)")
        if (main != null) { Logger.i("Super", "opening ${emu.name} itself; add the game inside it (the file is the one you linked)"); Toast.makeText(ctx, "${emu.name}: " + com.sonicforge.ui.I18n.tr("opened. Add the game inside it:") + " ${g.title}", Toast.LENGTH_LONG).show(); ctx.startActivity(main.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        else Logger.e("Super", "${emu.name} has no launcher activity")
    }
}
