package com.sonicforge.ui

import androidx.compose.foundation.*
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonicforge.core.Systems
import com.sonicforge.data.Library
import com.sonicforge.data.Rom
import com.sonicforge.data.Store
import kotlinx.coroutines.delay

/**
 * Launcher interface styles. NORMAL is the look the app always had and is never changed. MANIA and TILES are two extra looks for variety:
 * MANIA = yellow stripes, slanted black buttons and blue banners (like the Sonic Mania menus);
 * TILES = dark blue tiles, big game cards, pill tabs and a button-hint bar (like Steam's Big Picture / Steam Deck).
 * They only restyle the launcher (never the game screen). Their names can be changed, and the quick-switch button can be hidden.
 */
object UiMode {
    val ids = listOf("normal", "mania", "tiles", "jolt", "itch", "coast", "blur", "rival", "meadow")
    /** true while a game is open: the game screen always keeps your normal skin */
    var inGame by mutableStateOf(false)
    fun id(): String { if (inGame && !Store.b("themeInGame", true)) return "normal"; val s = Store.s("uiMode", "normal"); return if (s in ids) s else "normal" }
    fun defName(id: String) = when (id) { "mania" -> "Mania"; "tiles" -> "Tiles"; "jolt" -> "Game Jolt"; "itch" -> "itch"; "coast" -> "Neon Coast"; "blur" -> "Blue Blur"; "rival" -> "Dark Rival"; "meadow" -> "Meadow Day"; else -> "Normal" }
    fun name(id: String) = Store.s("uiName_$id", defName(id))
    fun cycle() { Store.set("uiMode", ids[(ids.indexOf(id()) + 1) % ids.size]) }
    fun apply(b: Skin): Skin = when (id()) {
        "mania" -> b.copy(bgTop = Color(0xFF0B2A6B), bgBot = Color(0xFF081A44), accent = Color(0xFFFFD21F), c2 = Color(0xFF1E88E5), text = Color.White, dark = true,
            border = "solid", bdColor = Color.Black, bdWidth = 3, radius = 0, deco = "none")
        "tiles" -> b.copy(bgTop = Color(0xFF1B2838), bgBot = Color(0xFF0E141B), accent = Color(0xFF1A9FFF), c2 = Color(0xFF66C0F4), text = Color.White, dark = true,
            border = "solid", bdColor = Color(0x33FFFFFF), bdWidth = 1, radius = 14, deco = "none")
        "jolt" -> b.copy(bgTop = Color(0xFF1B1B1F), bgBot = Color(0xFF101013), accent = Color(0xFFCCFF00), c2 = Color(0xFF2F7F6F), text = Color.White, dark = true,
            border = "solid", bdColor = Color(0x44CCFF00), bdWidth = 1, radius = 10, deco = "none")
        "itch" -> b.copy(bgTop = Color(0xFF262626), bgBot = Color(0xFF171717), accent = Color(0xFFFA5C5C), c2 = Color(0xFFFF8A80), text = Color.White, dark = true,
            border = "solid", bdColor = Color(0x33FFFFFF), bdWidth = 1, radius = 4, deco = "none")
        "coast" -> b.copy(bgTop = Color(0xFF2B0F54), bgBot = Color(0xFF14082B), accent = Color(0xFFFF4F9A), c2 = Color(0xFFFFA23D), text = Color.White, dark = true,
            border = "solid", bdColor = Color(0x99FF4F9A), bdWidth = 2, radius = 12, deco = "none")
        "blur" -> b.copy(bgTop = Color(0xFF0A3D91), bgBot = Color(0xFF021B4D), accent = Color(0xFF29B6F6), c2 = Color(0xFFFFD600), text = Color.White, dark = true,
            border = "double", bdColor = Color(0xFF29B6F6), bdWidth = 3, radius = 12, deco = "none")
        "rival" -> b.copy(bgTop = Color(0xFF0B0B0F), bgBot = Color(0xFF260505), accent = Color(0xFFE53935), c2 = Color(0xFFFFC107), text = Color.White, dark = true,
            border = "solid", bdColor = Color(0xFFE53935), bdWidth = 3, radius = 2, deco = "none")
        "meadow" -> b.copy(bgTop = Color(0xFF4A90E2), bgBot = Color(0xFF2E7D32), accent = Color(0xFFE53935), c2 = Color(0xFFFFD54F), text = Color.White, dark = true,
            border = "solid", bdColor = Color.White, bdWidth = 4, radius = 16, deco = "none")
        else -> b
    }
}

/** slanted parallelogram used by the Mania style */
val ManiaShape = GenericShape { size, _ ->
    val k = size.height * .32f
    moveTo(k, 0f); lineTo(size.width, 0f); lineTo(size.width - k, size.height); lineTo(0f, size.height); close()
}

/** cut-corner shape (top-left and bottom-right corners chopped) used by the Game Jolt theme */
val ChamferShape = GenericShape { size, _ ->
    val k = minOf(size.height * .38f, 14f)
    moveTo(k, 0f); lineTo(size.width, 0f); lineTo(size.width, size.height - k); lineTo(size.width - k, size.height); lineTo(0f, size.height); lineTo(0f, k); close()
}

/** Game Jolt theme: dark with lime diagonal stripes, a dot grid and big pixel gamepad-ish blocks. Drawn in code. */
@Composable
fun JoltBackdrop() {
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width; val h = size.height; val u = minOf(w, h) / 14f
        drawRect(Brush.verticalGradient(listOf(Color(0xFF1B1B1F), Color(0xFF0B0B0D))))
        for (i in -3..14) { val x = i * u * 2.2f; drawPath(Path().apply { moveTo(x, 0f); lineTo(x + u * .7f, 0f); lineTo(x + u * .7f - h * .6f, h); lineTo(x - h * .6f, h); close() }, Color(0xFFCCFF00).copy(alpha = if (i % 3 == 0) .10f else .04f)) }
        var gy = u; while (gy < h) { var gx = u; while (gx < w) { drawCircle(Color(0xFFCCFF00).copy(alpha = .10f), 2.2f, Offset(gx, gy)); gx += u }; gy += u }
        // big chamfered frames in the corners
        val fr = Path().apply { moveTo(w * .62f, h * .08f); lineTo(w - u * .5f, h * .08f); lineTo(w - u * .5f, h * .30f); lineTo(w * .62f + u, h * .30f); close() }
        drawPath(fr, Color(0xFFCCFF00).copy(alpha = .35f), style = Stroke(4f))
        drawPath(Path().apply { moveTo(u * .5f, h * .78f); lineTo(w * .36f, h * .78f); lineTo(w * .36f - u, h * .94f); lineTo(u * .5f, h * .94f); close() }, Color(0xFF2F7F6F).copy(alpha = .55f))
        drawCircle(Color(0xFFCCFF00).copy(alpha = .16f), u * 3f, Offset(w * .9f, h * .72f), style = Stroke(u * .5f))
        drawRect(Color(0xFFCCFF00).copy(alpha = .8f), Offset(0f, h - 5f), Size(w, 5f))
    }
}

/** itch theme: charcoal with coral pixel blobs, ordered-dither dots and chunky stars, like indie pixel art. */
@Composable
fun ItchBackdrop() {
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width; val h = size.height; val u = minOf(w, h) / 20f
        drawRect(Brush.verticalGradient(listOf(Color(0xFF2B2B2B), Color(0xFF151515))))
        val blobs = listOf(Triple(.15f, .2f, 5f), Triple(.85f, .35f, 7f), Triple(.3f, .8f, 6f), Triple(.7f, .9f, 4f))
        blobs.forEachIndexed { i, (x, y, r) -> drawCircle(Color(0xFFFA5C5C).copy(alpha = .10f + i * .02f), u * r, Offset(w * x, h * y)); drawCircle(Color(0xFFFA5C5C).copy(alpha = .20f), u * r, Offset(w * x, h * y), style = Stroke(u * .25f)) }
        // dither: checkerboard of small squares fading downwards
        var yy = 0; var gy = 0f
        while (gy < h * .5f) { var gx = if (yy % 2 == 0) 0f else u * .5f; while (gx < w) { drawRect(Color.White.copy(alpha = .05f * (1f - gy / (h * .5f))), Offset(gx, gy), Size(u * .22f, u * .22f)); gx += u }; gy += u * .5f; yy++ }
        // pixel stars
        for (i in 0..9) { val x = w * ((i * 37 % 100) / 100f); val y = h * ((i * 53 % 100) / 100f); val s = u * (.3f + (i % 3) * .15f)
            drawRect(Color(0xFFFF8A80).copy(alpha = .6f), Offset(x - s / 2f, y - s * 1.5f), Size(s, s * 3f)); drawRect(Color(0xFFFF8A80).copy(alpha = .6f), Offset(x - s * 1.5f, y - s / 2f), Size(s * 3f, s)) }
    }
}

@Composable
fun ManiaBackdrop() {
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width; val h = size.height
        drawRect(Color(0xFFF7C800))
        drawCircle(Color(0xFFEF8A00), w * .42f, Offset(w * .66f, h * .55f), style = Stroke(w * .08f))
        val red = Path().apply { moveTo(0f, h * .38f); lineTo(w * .46f, 0f); lineTo(w * .64f, 0f); lineTo(0f, h * .68f); close() }
        drawPath(red, Color(0xFFE53935))
        val blue = Path().apply { moveTo(w * .46f, h); lineTo(w, h * .3f); lineTo(w, h * .58f); lineTo(w * .74f, h); close() }
        drawPath(blue, Color(0xFF1E88E5))
        val white = Path().apply { moveTo(w * .2f, h); lineTo(w * .56f, h * .62f); lineTo(w * .6f, h * .62f); lineTo(w * .26f, h); close() }
        drawPath(white, Color.White.copy(.75f))
        drawCircle(Color(0xFF26C6DA), w * .05f, Offset(w * .88f, h * .16f))
    }
}

/** an original sunset-and-neon poster scene (Neon Coast): gradient sky, big sun, sea lines and palm silhouettes. All drawn in code, no outside art. */
@Composable
fun CoastBackdrop() {
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width; val h = size.height; val hor = h * .68f
        drawRect(Brush.verticalGradient(listOf(Color(0xFF1B0A3C), Color(0xFF7A1F7A), Color(0xFFFF4F9A), Color(0xFFFFA23D)), 0f, hor))
        val r = minOf(w, h) * .26f; val c = Offset(w * .5f, hor - r * .35f)
        drawCircle(Brush.verticalGradient(listOf(Color(0xFFFFF176), Color(0xFFFF6E9C)), c.y - r, c.y + r), r, c)
        drawRect(Color(0xFF14082B), Offset(0f, hor), Size(w, h - hor))
        for (i in 1..7) drawRect(Color(0xFFFF4F9A).copy(alpha = .5f / i), Offset(w * (.5f - .38f / i), hor + i * (h - hor) / 8f), Size(w * .76f / i, 3f))
        fun palm(x: Float, base: Float, hgt: Float, lean: Float) {
            val top = Offset(x + lean, base - hgt)
            drawPath(Path().apply { moveTo(x, base); quadraticBezierTo(x + lean * .2f, base - hgt * .6f, top.x, top.y) }, Color(0xFF0B0418), style = Stroke(hgt * .035f + 3f))
            for (k in -3..3) { val ang = (k * 28f - 90f) * Math.PI.toFloat() / 180f; val len = hgt * .32f
                val e = Offset(top.x + kotlin.math.cos(ang) * len, top.y + kotlin.math.sin(ang) * len * .55f + len * .35f * kotlin.math.abs(k) / 3f)
                drawLine(Color(0xFF0B0418), top, e, strokeWidth = hgt * .03f + 2f) }
        }
        for (i in -10..10) drawLine(Color(0xFFFF4F9A).copy(alpha = .30f), Offset(w * .5f + i * w * .03f, hor), Offset(w * .5f + i * w * .30f, h), 2f)
        for (i in 0..14) { val a = (i * i * 7 % 100) / 100f; drawCircle(Color.White.copy(alpha = .35f + a * .4f), 1.5f + a * 2f, Offset(w * ((i * 61 % 100) / 100f), hor * (((i * 29) % 100) / 100f) * .6f)) }
        palm(w * .08f, h * .96f, h * .62f, w * .05f); palm(w * .16f, h, h * .42f, -w * .03f); palm(w * .93f, h * .97f, h * .58f, -w * .05f)
    }
}

/** the backdrop of the active theme (when you have not put your own background picture on it) */
@Composable
fun ThemeBackdrop(mode: String) {
    if (Store.s(styKey("bg", mode)).isNotEmpty()) return
    when (mode) { "jolt" -> JoltBackdrop(); "itch" -> ItchBackdrop(); "mania" -> ManiaBackdrop(); "coast" -> CoastBackdrop(); "blur" -> BlurBackdrop(); "rival" -> RivalBackdrop(); "meadow" -> MeadowBackdrop() }
}

@Composable
fun BlurBackdrop() {
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width; val h = size.height
        drawRect(Brush.linearGradient(listOf(Color(0xFF021B4D), Color(0xFF0A3D91), Color(0xFF29B6F6)), Offset(0f, h), Offset(w, 0f)))
        for (i in 0..13) { val y = h * (i / 13f); drawLine(Color.White.copy(alpha = .08f + (i % 3) * .05f), Offset(-20f, y + h * .25f), Offset(w + 20f, y - h * .25f), strokeWidth = 2f + (i % 4) * 2f) }
        drawCircle(Color(0xFFFFD600).copy(alpha = .85f), minOf(w, h) * .2f, Offset(w * .86f, h * .2f), style = Stroke(minOf(w, h) * .035f))
        drawCircle(Color(0xFFFFD600).copy(alpha = .35f), minOf(w, h) * .12f, Offset(w * .1f, h * .82f), style = Stroke(minOf(w, h) * .02f))
    }
}

@Composable
fun RivalBackdrop() {
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width; val h = size.height
        drawRect(Brush.verticalGradient(listOf(Color(0xFF0B0B0F), Color(0xFF260505))))
        for (i in -2..9) { val x = w * (i / 7f); drawPath(Path().apply { moveTo(x, 0f); lineTo(x + w * .09f, 0f); lineTo(x + w * .09f - h * .5f, h); lineTo(x - h * .5f, h); close() }, Color(0xFFE53935).copy(alpha = if (i % 2 == 0) .30f else .12f)) }
        drawRect(Color(0xFFFFC107).copy(alpha = .7f), Offset(0f, h * .93f), Size(w, 4f))
    }
}

@Composable
fun MeadowBackdrop() {
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width; val h = size.height; val u = minOf(w, h) / 12f
        drawRect(Brush.verticalGradient(listOf(Color(0xFF3F86E0), Color(0xFF9CD3FF)), 0f, h * .8f))
        // smiling clouds
        for (i in 0..3) { val cx = w * (.1f + i * .27f); val cy = h * (.10f + (i % 2) * .09f)
            drawOval(Color.White.copy(alpha = .92f), Offset(cx - u * 1.3f, cy - u * .6f), Size(u * 2.6f, u * 1.2f)); drawOval(Color.White.copy(alpha = .92f), Offset(cx - u * .8f, cy - u), Size(u * 1.6f, u * 1.2f))
            drawCircle(Color(0xFF37474F), u * .08f, Offset(cx - u * .25f, cy - u * .1f)); drawCircle(Color(0xFF37474F), u * .08f, Offset(cx + u * .25f, cy - u * .1f)) }
        // far hills with eyes
        fun hill(cx: Float, base: Float, r: Float, col: Color) {
            drawCircle(col, r, Offset(cx, base))
            val ey = base - r * .55f
            drawOval(Color(0xFF1B2A1B), Offset(cx - r * .28f, ey - r * .16f), Size(r * .12f, r * .3f)); drawOval(Color(0xFF1B2A1B), Offset(cx + r * .16f, ey - r * .16f), Size(r * .12f, r * .3f))
            drawCircle(Color.White, r * .03f, Offset(cx - r * .23f, ey - r * .08f)); drawCircle(Color.White, r * .03f, Offset(cx + r * .21f, ey - r * .08f))
        }
        val ground = h * .86f
        hill(w * .22f, ground + u * .5f, h * .30f, Color(0xFF7BCB6B)); hill(w * .78f, ground + u * .6f, h * .36f, Color(0xFF66BB6A))
        hill(w * .52f, ground + u, h * .22f, Color(0xFF8BD67A))
        // ground made of bricks
        drawRect(Color(0xFF8D5524), Offset(0f, ground), Size(w, h - ground))
        var row = 0; var y = ground
        while (y < h) { val bh = u * .7f; var x = if (row % 2 == 0) 0f else -u * .8f
            while (x < w) { drawRect(Color(0xFFB5703A), Offset(x + 2f, y + 2f), Size(u * 1.6f - 4f, bh - 4f)); x += u * 1.6f }
            y += bh; row++ }
        drawRect(Color(0xFF43A047), Offset(0f, ground - u * .22f), Size(w, u * .3f))
        // pipes
        fun pipe(x: Float, hgt: Float) { val pw = u * 1.5f; val top = ground - hgt
            drawRect(Color(0xFF2E9E43), Offset(x, top), Size(pw, hgt)); drawRect(Color(0xFF1B6E2D), Offset(x, top), Size(pw, hgt), style = Stroke(3f))
            drawRect(Color(0xFF3CB85A), Offset(x - u * .15f, top), Size(pw + u * .3f, u * .55f)); drawRect(Color(0xFF1B6E2D), Offset(x - u * .15f, top), Size(pw + u * .3f, u * .55f), style = Stroke(3f))
            drawRect(Color.White.copy(alpha = .25f), Offset(x + pw * .15f, top + u * .6f), Size(pw * .12f, hgt - u * .7f)) }
        pipe(w * .06f, u * 2.2f); pipe(w * .86f, u * 3.1f)
        // plant growing out of a pipe (petals + spots)
        run { val px = w * .86f + u * .75f; val py = ground - u * 3.1f
            drawRect(Color(0xFF2E9E43), Offset(px - u * .12f, py - u * 1.0f), Size(u * .24f, u * 1.0f))
            drawCircle(Color(0xFFE53935), u * .62f, Offset(px, py - u * 1.35f)); for (k in 0..3) drawCircle(Color.White, u * .12f, Offset(px - u * .3f + k * u * .2f, py - u * (1.15f + (k % 2) * .5f)))
            drawOval(Color.White, Offset(px - u * .45f, py - u * 1.25f), Size(u * .9f, u * .22f)) }
        // flowers
        for (i in 0..5) { val fx = w * (.2f + i * .11f); val fy = ground - u * .15f
            drawRect(Color(0xFF2E7D32), Offset(fx, fy - u * .5f), Size(3f, u * .5f))
            for (k in 0..4) { val ang = k * 72f * Math.PI.toFloat() / 180f; drawCircle(if (i % 2 == 0) Color(0xFFFFEB3B) else Color(0xFFFF80AB), u * .13f, Offset(fx + kotlin.math.cos(ang) * u * .2f, fy - u * .55f + kotlin.math.sin(ang) * u * .2f)) }
            drawCircle(Color(0xFFFF6F00), u * .1f, Offset(fx, fy - u * .55f)) }
        // floating blocks: a row of bricks and "?" blocks, with coins
        val by = h * .40f; val bs = u * 1.1f
        val paint = android.graphics.Paint().apply { color = android.graphics.Color.rgb(120, 70, 0); textSize = bs * .7f; isFakeBoldText = true; textAlign = android.graphics.Paint.Align.CENTER }
        for (i in 0..4) { val x = w * .52f + i * bs
            if (i % 2 == 1) { drawRect(Color(0xFFFFC107), Offset(x, by), Size(bs, bs)); drawRect(Color(0xFF8D5A00), Offset(x, by), Size(bs, bs), style = Stroke(3f)); drawContext.canvas.nativeCanvas.drawText("?", x + bs / 2f, by + bs * .72f, paint) }
            else { drawRect(Color(0xFFC0723A), Offset(x, by), Size(bs, bs)); drawRect(Color(0xFF6D3A12), Offset(x, by), Size(bs, bs), style = Stroke(3f)); drawLine(Color(0xFF6D3A12), Offset(x, by + bs / 2f), Offset(x + bs, by + bs / 2f), 3f); drawLine(Color(0xFF6D3A12), Offset(x + bs / 2f, by), Offset(x + bs / 2f, by + bs / 2f), 3f) } }
        for (i in 0..2) { val cx = w * .56f + i * bs * 1.6f; val cy = by - bs * (.9f + (i % 2) * .4f)
            drawOval(Color(0xFFFFD600), Offset(cx - u * .22f, cy - u * .34f), Size(u * .44f, u * .68f)); drawOval(Color(0xFFFFA000), Offset(cx - u * .22f, cy - u * .34f), Size(u * .44f, u * .68f), style = Stroke(3f)) }
    }
}

@Composable
fun UiSwitchButton() {
    if (Store.b("uiSwitchBtn", true)) Btn("◐ " + UiMode.name(UiMode.id())) { UiMode.cycle() }
}

private val NAV = listOf("games" to "GAMES", "super" to "⚗ SUPER", "mini" to "MINI-GAMES", "music" to "MUSIC", "draw" to "DRAW", "media" to "MEDIA", "custom" to "CUSTOMIZE", "locations" to "LOCATIONS", "settings" to "SETTINGS", "help" to "HELP")

@Composable
fun NavBar(mode: String, tab: String, onTab: (String) -> Unit) {
    val skin = Skins.current()
    when (mode) {
        "tiles" -> {
            var clock by remember { mutableStateOf("") }
            LaunchedEffect(Store.b("clock24", false)) { while (true) { clock = java.text.SimpleDateFormat(if (Store.b("clock24", false)) "HH:mm" else "h:mm a", java.util.Locale.getDefault()).format(java.util.Date()); delay(20000) } }
            Row(Modifier.fillMaxWidth().background(Color(0xFF0B1118)).padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    NAV.forEach { (k, n) -> TabPill((if (k == "settings") "⚙ " else "") + I18n.tr(n), tab == k, null) { onTab(k) } }
                }
                Text(clock, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 10.dp))
            }
        }
        "mania" -> Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("SONICFORGE", color = skin.accent, fontWeight = FontWeight.Black, letterSpacing = 2.sp, modifier = Modifier.clip(ManiaShape).background(Color.Black).padding(start = 22.dp, end = 26.dp, top = 6.dp, bottom = 6.dp))
            UiSwitchButton()
            NAV.forEach { (k, n) -> Btn((if (k == "settings") "⚙ " else "") + I18n.tr(n), selected = tab == k) { onTab(k) } }
        }
        else -> Row(Modifier.fillMaxWidth().background(Color.Black.copy(.35f)).horizontalScroll(rememberScrollState()).padding(8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("SONICFORGE", color = skin.accent, fontWeight = FontWeight.Black, letterSpacing = 3.sp, modifier = Modifier.padding(end = 8.dp))
            UiSwitchButton()
            NAV.forEach { (k, n) -> Btn((if (k == "settings") "⚙ " else "") + I18n.tr(n), selected = tab == k) { onTab(k) } }
        }
    }
}

@Composable
private fun TabPill(text: String, selected: Boolean, badge: Int?, onClick: () -> Unit) {
    val skin = Skins.current()
    Row(Modifier.clip(RoundedCornerShape(24.dp)).background(if (selected) Color(0xFF2A3A4C) else Color.Transparent).forgeClick { onClick() }.padding(horizontal = 16.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text, color = if (selected) Color.White else Color(0xFFB8C7D6), fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1)
        if (badge != null) Text(badge.toString(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.padding(start = 8.dp).clip(CircleShape).background(skin.accent).padding(horizontal = 8.dp, vertical = 2.dp))
    }
}

@Composable
private fun GameTile(r: Rom, w: androidx.compose.ui.unit.Dp, h: androidx.compose.ui.unit.Dp, onMenu: () -> Unit = {}, onClick: () -> Unit) {
    var foc by remember { mutableStateOf(false) }
    val bg = rememberBitmap(r.bg)
    val hue = ((r.title.hashCode() and 0x7fffffff) % 360).toFloat()
    val shape = RoundedCornerShape(8.dp)
    Box(Modifier.size(w, h).onFocusChanged { foc = it.isFocused }.clip(shape).background(Brush.verticalGradient(listOf(Color.hsv(hue, .55f, .55f), Color.hsv(hue, .6f, .22f)))).forgeClick { onClick() }) {
        if (bg != null) Image(bg, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000)))))
        val logo = if (Store.b("cardLogo", true)) rememberBitmap(r.logo) else null
        if (logo != null) Image(logo, null, Modifier.align(Alignment.BottomStart).padding(8.dp).fillMaxWidth().height(h * .3f), contentScale = ContentScale.Fit, alignment = Alignment.BottomStart)
        else if (Store.b("cardTitle", true)) Text(r.title, color = Color.White, fontWeight = FontWeight.Black, fontSize = 15.sp, maxLines = 3, modifier = Modifier.align(Alignment.BottomStart).padding(10.dp))
        if (Store.b("cardSys", true)) Text(Systems.byId(r.sys).label, color = Color(0xCCFFFFFF), fontSize = 10.sp, maxLines = 1, modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).clip(RoundedCornerShape(6.dp)).background(Color(0x99000000)).padding(horizontal = 5.dp, vertical = 1.dp))
        if (com.sonicforge.data.Recents.isHidden(r)) Text("🙈", fontSize = 12.sp, modifier = Modifier.align(Alignment.BottomEnd).padding(6.dp).clip(RoundedCornerShape(6.dp)).background(Color(0x99000000)).padding(horizontal = 4.dp))   // hidden from Recent games
        Text("⋯", color = Color.White, fontWeight = FontWeight.Black, fontSize = 18.sp, modifier = Modifier.align(Alignment.TopStart).padding(4.dp).clip(RoundedCornerShape(8.dp)).background(Color(0x99000000)).clickable { onMenu() }.padding(horizontal = 9.dp, vertical = 0.dp))   // always opens the game menu (vibration, Sega CD tools, art)
        if (foc) Box(Modifier.fillMaxSize().border(3.dp, Color.White, shape))
    }
}

/** the small game menu that opens when you tap a tile (SETTINGS ▸ SCREEN ▸ "Tapping a tile" can switch it to start the game at once) */
@Composable
private fun TileMenu(r: Rom, close: () -> Unit, onPlay: (Rom) -> Unit) {
    val ctx = LocalContext.current
    var cdT by remember { mutableStateOf(false) }; var hapT by remember { mutableStateOf(false) }; var dsT by remember { mutableStateOf(false) }; var sysT by remember { mutableStateOf(false) }
    var editT by remember { mutableStateOf(false) }; var delT by remember { mutableStateOf(false) }
    if (editT) EditDialog(r) { editT = false; close() }
    if (delT) ConfirmDialog("Remove ${r.title}?", "Removes the game from the library and deletes its copy inside the app.", "Your original file and your save states are not touched.", yes = "REMOVE", onYes = { Library.remove(r); delT = false; close() }, onNo = { delT = false })
    if (cdT) SegaCdToolsDialog(r) { cdT = false }
    if (hapT) GameHapticsDialog(r) { hapT = false }
    if (dsT) DsScreensDialog { dsT = false }
    if (sysT) SystemFilesDialog(r.sys) { sysT = false }
    androidx.compose.material3.AlertDialog(onDismissRequest = close, containerColor = Color(0xFF0D1520),
        confirmButton = { androidx.compose.material3.TextButton(close) { Text("Close") } },
        title = { Text(r.title, color = Color.White) },
        text = { Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Btn("▶  PLAY", Modifier.fillMaxWidth(), selected = true) { close(); onPlay(r) }
            var rtick by remember { mutableStateOf(0) }; val rt = rtick
            if (com.sonicforge.data.Recents.isHidden(r) && rt >= 0) Text("🙈 Hidden from Recent games" + (if (com.sonicforge.data.Recents.catHidden(r)) " (the whole console is hidden: SETTINGS ▸ Recent games)" else ""), color = Color(0xFFFFB74D), fontSize = 12.sp)
            if (com.sonicforge.data.Recents.ids().contains(r.id) && rt >= 0) Btn("✕ REMOVE FROM RECENT (comes back when you play it again)", Modifier.fillMaxWidth()) { com.sonicforge.data.Recents.remove(r.id); rtick++ }
            Btn(if (com.sonicforge.data.Recents.gameHidden(r)) "👁 SHOW THIS GAME IN RECENT AGAIN" else "🙈 NEVER SHOW THIS GAME IN RECENT", Modifier.fillMaxWidth()) { com.sonicforge.data.Recents.setGameHidden(r, !com.sonicforge.data.Recents.gameHidden(r)); rtick++ }
            if (r.sys != "bor") Btn("📳 VIBRATION (preset / source)", Modifier.fillMaxWidth()) { hapT = true }
            if (r.sys == "scd") Btn("💿 SEGA CD TOOLS (auto-fix, region, RAM)", Modifier.fillMaxWidth()) { cdT = true }
            if (r.sys == "nds") Btn("🖥 DS SCREENS", Modifier.fillMaxWidth()) { dsT = true }
            Btn("📂 SYSTEM FILES (BIOS)", Modifier.fillMaxWidth()) { sysT = true }
            Btn("✎ EDIT (title, description, cheats, group)", Modifier.fillMaxWidth()) { editT = true }
            Btn("🩹 PATCH", Modifier.fillMaxWidth()) { Picker.pick { u -> u.firstOrNull()?.let { Library.applyPatch(ctx, r, it) } }; close() }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { Btn("▲ MOVE UP", Modifier.weight(1f)) { Library.move(r.id, -1) }; Btn("▼ MOVE DOWN", Modifier.weight(1f)) { Library.move(r.id, 1) } }
            Btn("🖼 CHANGE BACKGROUND", Modifier.fillMaxWidth()) { Picker.pick(arrayOf("image/*")) { u -> u.firstOrNull()?.let { Library.setArt(ctx, r, it, false) } }; close() }
            Btn("🏷 CHANGE LOGO", Modifier.fillMaxWidth()) { Picker.pick(arrayOf("image/*")) { u -> u.firstOrNull()?.let { Library.setArt(ctx, r, it, true) } }; close() }
            Btn("RESET ART", Modifier.fillMaxWidth()) { r.bg?.let { java.io.File(it).delete() }; r.logo?.let { java.io.File(it).delete() }; Library.update(r.copy(bg = null, logo = null)); close() }
            Btn("🗑 REMOVE", Modifier.fillMaxWidth(), color = Color(0xFFE53935)) { delT = true }
            Text(Systems.byId(r.sys).label + " · " + r.desc, color = Color(0xE6FFFFFF), fontSize = 11.sp, maxLines = 4)
        } })
}

/** Games tab in the TILES style: big "recent game", filter pills with counters, and a grid of game cards. Tap a card to play. */
@Composable
fun TilesGames(onPlay: (Rom) -> Unit) {
    val skin = Skins.current(); val ctx = LocalContext.current
    var menuRom by remember { mutableStateOf<Rom?>(null) }
    val open: (Rom) -> Unit = { r -> if (Store.s("tileOpen", "menu") == "play") onPlay(r) else menuRom = r }
    menuRom?.let { r -> TileMenu(r, { menuRom = null }, onPlay) }
    var tab by remember { mutableStateOf("all") }
    val all = Library.roms
    val roms = all.filter { tab == "all" || Systems.tabOf(it.sys) == tab }
    val last = all.firstOrNull { it.id == Store.s("lastGame") }?.takeIf { !com.sonicforge.data.Recents.isHidden(it) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 10.dp)) {
        if (all.isEmpty()) {
            Text("No games yet", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("Add your ROMs (.bin .md .gen .smd .sms .gg, or a .zip / .rar / .7z) and they appear here as tiles.", color = Color(0xCCFFFFFF), modifier = Modifier.padding(vertical = 8.dp))
            Btn("+ ADD GAME") { Picker.pick { Library.importUris(ctx, it) } }
            return@Column
        }
        Text("Recent games", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        val recents = com.sonicforge.data.Recents.list(all).take(10)
        if (recents.isEmpty()) Text("Nothing yet: every game you start (any console, Flash too) appears here. Remove one with ⋯ ▸ REMOVE FROM RECENT, or keep consoles out of it in SETTINGS.", color = Color(0xCCFFFFFF), fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.Bottom) {
            recents.forEachIndexed { i, r -> if (i == 0) GameTile(r, 330.dp, 190.dp, { menuRom = r }) { open(r) } else GameTile(r, 130.dp, 190.dp, { menuRom = r }) { open(r) } }
        }
        if (last != null) Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 10.dp)) {
            Box(Modifier.size(52.dp).background(Color(0xFF4CAF50)).forgeClick("launch") { onPlay(last) }, Alignment.Center) { Text("▶", color = Color.White, fontSize = 24.sp) }
            Column(Modifier.padding(start = 12.dp)) { Text(last.title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1); Text(Systems.byId(last.sys).label.uppercase(), color = Color(0xFF69F0AE), fontSize = 12.sp, fontWeight = FontWeight.Bold) }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TabPill("ALL", tab == "all", all.size) { tab = "all" }
            listOf("md" to "MEGA DRIVE", "scd" to "SEGA CD", "x32" to "32X", "gba" to "GAME BOY", "nes" to "NES", "snes" to "SNES", "nds" to "DS", "bor" to "OPENBOR", "flash" to "FLASH").forEach { (k, n) ->
                val c = all.count { Systems.tabOf(it.sys) == k }; if (c > 0) TabPill(n, tab == k, c) { tab = k } }
        }
        Text("From your library", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp, bottom = 8.dp))
        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val n = (maxWidth / 146.dp).toInt().coerceAtLeast(2)
            val items: List<Rom?> = roms + listOf<Rom?>(null)
            Column {
                items.chunked(n).forEach { row ->
                    Row(Modifier.padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        row.forEach { r ->
                            if (r != null) GameTile(r, 134.dp, 180.dp, { menuRom = r }) { open(r) }
                            else Box(Modifier.size(134.dp, 180.dp).clip(RoundedCornerShape(8.dp)).border(2.dp, skin.accent, RoundedCornerShape(8.dp)).forgeClick { Picker.pick { Library.importUris(ctx, it) } }, Alignment.Center) {
                                Text("+ ADD GAME", color = skin.accent, fontWeight = FontWeight.Black, textAlign = TextAlign.Center) }
                        }
                    }
                }
            }
        }
    }
}

/** the bottom bar of the TILES style: style switch on the left, OPTIONS and SELECT hints on the right (like Steam's button hints) */
@Composable
fun TilesHintBar(onTab: (String) -> Unit) {
    val pad = com.sonicforge.input.Pads.devices.firstOrNull()
    val showPad = pad != null || Store.b("tilesPadHints", false)   // the A / B circles only make sense with a gamepad; on touch they are just clutter
    // a scrolling row never squeezes its children, so a label can no longer wrap letter by letter ("B A C K")
    Row(Modifier.fillMaxWidth().background(Color(0xFF05080C)).horizontalScroll(androidx.compose.foundation.rememberScrollState()).padding(horizontal = 14.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
        if (Store.b("uiSwitchBtn", true))
            Text("◐ " + UiMode.name(UiMode.id()).uppercase() + " ▸ STYLE", color = Color.Black, fontWeight = FontWeight.Black, fontSize = 13.sp, maxLines = 1, modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(Color.White).forgeClick { UiMode.cycle() }.padding(horizontal = 14.dp, vertical = 6.dp))
        Text("≡ OPTIONS", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, modifier = Modifier.forgeClick { onTab("settings") }.padding(8.dp))
        if (showPad) {
            val st = pad?.style ?: com.sonicforge.input.PadStyle.XBOX
            val confirm = com.sonicforge.input.Profiles.btnLabel(st, android.view.KeyEvent.KEYCODE_BUTTON_A)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(confirm, color = Color.Black, fontWeight = FontWeight.Black, maxLines = 1, modifier = Modifier.clip(CircleShape).background(Color.White).padding(horizontal = 9.dp, vertical = 4.dp))
                Text("SELECT", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, modifier = Modifier.padding(start = 6.dp))
            }
        }
        val back = if (showPad) com.sonicforge.input.Profiles.btnLabel(pad?.style ?: com.sonicforge.input.PadStyle.XBOX, android.view.KeyEvent.KEYCODE_BUTTON_B) else "◀"
        Row(Modifier.forgeClick { onTab("games") }, verticalAlignment = Alignment.CenterVertically) {   // tappable now: goes back to the games list
            Text(back, color = Color.Black, fontWeight = FontWeight.Black, maxLines = 1, modifier = Modifier.clip(CircleShape).background(Color(0xFFB8C7D6)).padding(horizontal = 9.dp, vertical = 4.dp))
            Text("BACK", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, modifier = Modifier.padding(start = 6.dp))
        }
    }
}

/** SETTINGS ▸ SCREEN & LOOK: choose the style, rename the styles, hide the quick-switch button */
@Composable
fun UiModePicker() {
    val cur = UiMode.id()
    H("Launcher theme")
    Text("STYLE or THEME? A STYLE is what you build in CUSTOMIZE: skin colours, frames, particles and your own pictures. A THEME is a ready-made launcher look that changes the layout and how buttons are drawn (Normal, Mania, Tiles, Game Jolt, itch, Neon Coast). A theme sits on top of your style: Normal shows your style exactly as before, the other themes bring their own colours, and your own pictures (below) work on every theme.", color = Color(0xFFFFE082), fontSize = 12.sp)
    Text("NORMAL is the look you already know and it is never removed. The other themes are extra looks for variety. They restyle the launcher and, if the switch below is on, the menus inside games and emulators too.", color = Color(0xCCFFFFFF), fontSize = 11.sp)
    val about = mapOf("normal" to "Your skins, particles and frames, exactly as before.",
        "mania" to "Yellow stripes, slanted black buttons and blue banners, like the Sonic Mania menus.",
        "tiles" to "Dark blue tiles, big game cards, pill tabs and a button-hint bar, like Steam Big Picture / Steam Deck. Buttons in the hint bar copy your connected controller.",
        "blur" to "Speed-blue gradient with white speed streaks and a golden ring: a fast, bright look inspired by anniversary-style blue-hedgehog art. Original design.",
        "rival" to "Black and crimson with sharp slanted stripes and gold accents: a dark rival look. Original design.",
        "meadow" to "Bright sky, rolling green hills and yellow question-style blocks, with a red accent: a cheerful platformer-world look. Original design, no characters.",
        "coast" to "Sunset gradient, big neon sun and palm silhouettes, poster-like pink and orange. An original design, not taken from any game.",
        "itch" to "Near-black pages with a coral-red accent and square game cards, inspired by the colours of indie game sites (an original palette, not a logo).",
        "jolt" to "Dark grey with a neon-lime accent, rounded cards, inspired by the Game Jolt site colours (an original palette, not its logo).")
    UiMode.ids.forEach { id ->
        Column(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(10.dp)).background(Color.Black.copy(.3f)).padding(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Btn(UiMode.name(id), selected = cur == id) { Store.set("uiMode", id) }
                Text(about[id] ?: "", color = Color(0xE6FFFFFF), fontSize = 11.sp, modifier = Modifier.weight(1f).padding(start = 8.dp))
            }
            OutlinedTextField(Store.s("uiName_$id", ""), { Store.set("uiName_$id", it.take(20)) }, singleLine = true, label = { Text("Name (empty = " + UiMode.defName(id) + ")") }, modifier = Modifier.fillMaxWidth().padding(top = 4.dp))
        }
    }
    H("Game cards")
    SChips("Tapping a game tile (tiles style)", "tileOpen", "menu", listOf("menu" to "Open game menu", "play" to "Start the game at once"))
    SToggle("Show the game title on cards", "cardTitle", true, "Off = no title text on cards and in the hero picture when the game has no logo.")
    SToggle("Show the system label on cards", "cardSys", true, "The little MEGA DRIVE / GAME BOY badge in the corner.")
    SToggle("Show the game logo", "cardLogo", true, "Off = logos you added are hidden on cards and in the hero picture; the title is shown instead.")
    SToggle("Use the theme inside games and emulators", "themeInGame", true, "On = the pause menu, buttons and background inside a game follow the chosen theme and change with it. Off = games and emulators always keep your normal style.")
    SToggle("24-hour clock (no AM / PM)", "clock24", false, "Changes the clock in the top bar of the card themes.")
    SToggle("Show the quick-switch button", "uiSwitchBtn", true, "A button in the top bar (and the bottom bar in the tiles style) that cycles Normal → Mania → Tiles with one tap. Hide it here; you can always still choose the style on this page.")
    SeasonalSettings()
    StyleImagesEditor()
}

// ---- your own pictures for every style: background, foreground and a character / object, each with opacity and blur ----
private fun styKey(layer: String, mode: String) = "sty_${layer}_" + (if (Store.b("styShared", false)) "all" else mode)

private val LAYERS = listOf("bg", "bo", "gr", "ch", "fg")
private val SFX = listOf("", "_a", "_blur", "_fit", "_scale", "_x", "_y", "_pos", "_front")
private val XFORM = listOf("_a", "_blur", "_fit", "_scale", "_x", "_y", "_pos", "_front")

/** the file starts like a GIF or an animated-capable WebP */
private fun looksAnimated(path: String): Boolean = try {
    java.io.File(path).inputStream().use { i -> val h = ByteArray(12); val n = i.read(h); n >= 12 && ((h[0] == 'G'.code.toByte() && h[1] == 'I'.code.toByte() && h[2] == 'F'.code.toByte()) || (h[0] == 'R'.code.toByte() && h[8] == 'W'.code.toByte() && h[9] == 'E'.code.toByte())) }
} catch (_: Exception) { false }

/** shows a GIF / animated WebP moving (Android 9+); on older Android, or if decoding fails, the first frame is shown. Any other image is drawn normally. */
@Composable
fun AnyPicture(path: String, modifier: Modifier, scale: ContentScale = ContentScale.Fit, alignment: Alignment = Alignment.Center) {
    val anim = remember(path) { android.os.Build.VERSION.SDK_INT >= 28 && looksAnimated(path) }
    if (anim) {
        val st = when {
            scale == ContentScale.Crop -> android.widget.ImageView.ScaleType.CENTER_CROP
            scale == ContentScale.FillBounds -> android.widget.ImageView.ScaleType.FIT_XY
            scale == ContentScale.None -> android.widget.ImageView.ScaleType.CENTER
            alignment == Alignment.BottomCenter || alignment == Alignment.BottomEnd || alignment == Alignment.BottomStart -> android.widget.ImageView.ScaleType.FIT_END
            alignment == Alignment.TopCenter || alignment == Alignment.TopStart || alignment == Alignment.TopEnd -> android.widget.ImageView.ScaleType.FIT_START
            else -> android.widget.ImageView.ScaleType.FIT_CENTER }
        androidx.compose.ui.viewinterop.AndroidView(factory = { c -> android.widget.ImageView(c).apply {
            scaleType = st
            try { val d = android.graphics.ImageDecoder.decodeDrawable(android.graphics.ImageDecoder.createSource(java.io.File(path))); setImageDrawable(d)
                (d as? android.graphics.drawable.AnimatedImageDrawable)?.let { it.repeatCount = android.graphics.drawable.AnimatedImageDrawable.REPEAT_INFINITE; it.start() } } catch (_: Throwable) {}
        } }, modifier = modifier)
    } else {
        val bmp = rememberBitmap(path) ?: return
        Image(bmp, null, modifier, contentScale = scale, alignment = alignment)
    }
}

/**
 * draws one picture layer of the current theme. By DEFAULT every layer sits BEHIND the menus (on every tab). A layer can optionally be put IN FRONT (it may cover content; it never catches touches).
 * `front` = null draws regardless; true / false draws only layers set to that position.
 */
@Composable
fun StyleLayer(layer: String, mode: String, front: Boolean? = null) {
    val k = styKey(layer, mode)
    val path = Store.s(k).ifEmpty { null } ?: return
    if (front != null && front != Store.b(k + "_front", false)) return
    val a = Store.i(k + "_a", 100) / 100f
    val bl = Store.i(if (Store.b("styBlurAll", false)) "sty_blur_all" else k + "_blur", 0)
    val fitSel = Store.s(k + "_fit", "auto")
    val cs = when (fitSel) { "crop" -> ContentScale.Crop; "fit" -> ContentScale.Fit; "stretch" -> ContentScale.FillBounds; "width" -> ContentScale.FillWidth; "original" -> ContentScale.None
        else -> when (layer) { "bg" -> ContentScale.Crop; "ch", "bo" -> ContentScale.Fit; "gr" -> ContentScale.FillWidth; else -> ContentScale.FillBounds } }
    val al = when (Store.s(k + "_pos", "default")) { "center" -> Alignment.Center; "bottom" -> Alignment.BottomCenter; "top" -> Alignment.TopCenter; "left" -> Alignment.CenterStart; "right" -> Alignment.CenterEnd
        else -> when (layer) { "ch" -> Alignment.BottomEnd; "bo", "gr" -> Alignment.BottomCenter; else -> Alignment.Center } }
    val sc = Store.i(k + "_scale", 100) / 100f; val dx = (Store.i(k + "_x", 100) - 100) / 100f; val dy = (Store.i(k + "_y", 100) - 100) / 100f
    val m = Modifier.fillMaxSize().then(if (bl > 0) Modifier.blur(bl.dp) else Modifier).alpha(a)
        .graphicsLayer { scaleX = sc; scaleY = sc; translationX = dx * size.width / 2f; translationY = dy * size.height / 2f }
        .then(if (layer == "ch" && fitSel == "auto") Modifier.padding(24.dp) else Modifier)
    AnyPicture(path, m, cs, al)
}

private fun snapLayers(cur: String): Map<String, String> { val m = HashMap<String, String>(); for (l in LAYERS) for (x in SFX) { val key = styKey(l, cur) + x; m[key] = Store.s(key) }; return m }
private object StyHist { val stack = ArrayList<Map<String, String>>(); var last: Map<String, String>? = null; var skip = false; var mode = ""; var n by mutableIntStateOf(0) }

@Composable
fun StyleImagesEditor() {
    val ctx = LocalContext.current
    val cur = Store.s("styEdit", UiMode.id()).let { if (it in UiMode.ids) it else "normal" }
    val now = snapLayers(cur)
    LaunchedEffect(now, cur) {   // history for UNDO STEP: remember the state before each change
        if (StyHist.mode != cur) { StyHist.stack.clear(); StyHist.last = null; StyHist.mode = cur }
        val l = StyHist.last
        if (l != null && l != now && !StyHist.skip) { StyHist.stack.add(l); if (StyHist.stack.size > 40) StyHist.stack.removeAt(0) }
        StyHist.n = StyHist.stack.size; StyHist.skip = false; StyHist.last = now
    }
    H("Your own pictures for the themes")
    Text("Add your own picture (PNG keeps transparency; GIF and animated WebP move on Android 9+, on older phones you see the first frame). By default every picture sits BEHIND the menus on all tabs. You can move a layer IN FRONT, but then it may cover content.", color = Color(0xE6FFFFFF), fontSize = 11.sp)
    Text("Note: pictures belong to the theme you pick below. Another theme shows its own pictures (or none), unless you turn on the same-pictures switch.", color = Color(0xFFFFCC80), fontSize = 11.sp)
    SChips("Theme to edit", "styEdit", cur, UiMode.ids.map { it to UiMode.name(it) })
    SToggle("Same pictures in every theme", "styShared", false, "On = one set of pictures for all themes. Off = each theme keeps its own set.")
    SToggle("One blur amount for all pictures", "styBlurAll", false)
    if (Store.b("styBlurAll", false)) SSlider("Blur (all pictures)", "sty_blur_all", 0, 25, "")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Btn(if (StyHist.n == 0) "↶ UNDO STEP (nothing)" else "↶ UNDO STEP (${StyHist.n})") {
            if (StyHist.stack.isNotEmpty()) { val prev = StyHist.stack.removeAt(StyHist.stack.size - 1); StyHist.skip = true; StyHist.n = StyHist.stack.size; prev.forEach { (kk, v) -> Store.set(kk, v) } } }
    }
    listOf("bg" to "1 · Background: sky", "bo" to "2 · Background objects: e.g. palms in front of the sky", "gr" to "3 · Ground: a strip at the bottom", "ch" to "4 · Character / object", "fg" to "5 · Foreground: leaves, frame, dust").forEach { (layer, label) ->
        val k = styKey(layer, cur)
        Column(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(10.dp)).background(Color.Black.copy(.3f)).padding(8.dp)) {
            Text(label, color = Color.White, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Btn("CHOOSE PICTURE") { Picker.pick(arrayOf("image/*")) { u -> u.firstOrNull()?.let { uri ->
                    val f = java.io.File(Library.art, "$k-${System.currentTimeMillis()}.img")
                    try { ctx.contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { i.copyTo(it) } }; Store.set(k, f.path) } catch (_: Exception) {} } } }
                Btn("CLEAR") { Store.set(k, "") }
            }
            if (Store.s(k).isNotEmpty()) {
                SChips("Position", k + "_front", "0", listOf("0" to "Behind the menus (default)", "1" to "In front (may cover content)"))
                if (Store.b(k + "_front", false)) Text("In front: the picture is drawn over menus and buttons, so it can hide things. It never blocks touches.", color = Color(0xFFFFCC80), fontSize = 11.sp)
                SChips("How it fills the screen", k + "_fit", "auto", listOf("auto" to "Automatic", "crop" to "Fill, cut the edges", "fit" to "Fit inside (no cutting)", "width" to "Fit the width", "stretch" to "Stretch", "original" to "Original size"))
                SChips("Where it sits", k + "_pos", "default", listOf("default" to "Automatic", "center" to "Centre", "bottom" to "Bottom", "top" to "Top", "left" to "Left", "right" to "Right"))
                SSlider("Size", k + "_scale", 100, 300, "%")
                SSlider("Move left / right (100 = centre)", k + "_x", 100, 200, "")
                SSlider("Move up / down (100 = centre)", k + "_y", 100, 200, "")
                SSlider("Opacity", k + "_a", 100)
                if (!Store.b("styBlurAll", false)) SSlider("Blur", k + "_blur", 0, 25, "")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Btn("RESET FIT") { for (x in listOf("_fit", "_scale", "_x", "_y", "_pos")) Store.set(k + x, "") }
                    Btn("APPLY TO ALL THEMES") { for (md in UiMode.ids) if (md != cur) for (x in XFORM) Store.set(styKey(layer, md) + x, Store.s(k + x)) }
                    Btn("APPLY TO ALL LAYERS") { for (l2 in LAYERS) if (l2 != layer) for (x in XFORM) Store.set(styKey(l2, cur) + x, Store.s(k + x)) }
                }
                Text("APPLY copies this layer's fit, size, position, opacity, blur and front/behind choice (not the picture itself). UNDO STEP above takes back the last change in this theme.", color = Color(0x99FFFFFF), fontSize = 10.sp)
            }
        }
    }
    Text("Blur needs Android 12 or newer; on older phones the picture is shown sharp.", color = Color(0xE6FFFFFF), fontSize = 11.sp)
}
