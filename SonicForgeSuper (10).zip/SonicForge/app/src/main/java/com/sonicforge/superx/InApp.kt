package com.sonicforge.superx

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.sonicforge.GameActivity
import com.sonicforge.core.Systems
import com.sonicforge.data.Library
import com.sonicforge.data.Logger
import com.sonicforge.data.Rom
import java.io.File
import kotlin.concurrent.thread

/** Runs a Super game INSIDE SonicForge with an open-source libretro core (software rendering, so slower than the external app). Experimental. */
object InApp {
    fun coreOf(ctx: Context, sys: String): File? { val n = Systems.all.firstOrNull { it.id == sys }?.core ?: return null; return File(ctx.applicationInfo.nativeLibraryDir, n).takeIf { it.exists() } }
    fun available(ctx: Context, sys: String) = coreOf(ctx, sys) != null
    private fun toast(ctx: Context, t: String) { android.os.Handler(android.os.Looper.getMainLooper()).post { android.widget.Toast.makeText(ctx, t, android.widget.Toast.LENGTH_LONG).show() } }
    var busy = androidx.compose.runtime.mutableStateOf("")
    fun play(ctx: Context, g: SGame) {
        if (busy.value.isNotEmpty()) return
        if (coreOf(ctx, g.sys) == null) { Logger.w("Super", "no libretro core for ${g.sys} in this build (the optional download failed or does not exist for this CPU)"); toast(ctx, "No built-in core for this console in this build. Use PLAY (external app)."); return }
        val low = g.uri.lowercase()
        if (g.sys == "dc" && (low.contains(".gdi") || g.title.lowercase().endsWith("gdi"))) { toast(ctx, "A .gdi needs its track files next to it, which cannot be copied here. Use PLAY (external app) or a .chd / .cdi."); Logger.w("Super", "INSIDE refused: .gdi sets cannot be copied as one file"); return }
        if (g.size > 2_000_000_000L) { toast(ctx, "This image is larger than 2 GB: use PLAY (external app)."); Logger.w("Super", "INSIDE refused: ${g.size / 1048576} MB is too big to copy"); return }
        Logger.i("Super", "Launching project emu inside the app: ${g.title}")
        val ext = g.title.let { SuperSystems.byId(g.sys).exts.first() }
        thread {
            try {
                val rid = "s_" + g.id; val name = "$rid.$ext"
                val out = File(Library.dir, name)
                if (!out.exists() || out.length() == 0L) {
                    busy.value = "copying " + g.title
                    Logger.i("Super", "copying the game into the app (big files take a while): ${g.size / 1048576} MB")
                    var done = 0L; var next = 100L shl 20
                    ctx.contentResolver.openInputStream(Uri.parse(g.uri))!!.use { i -> out.outputStream().use { o -> val b = ByteArray(1 shl 16); while (true) { val n = i.read(b); if (n <= 0) break; o.write(b, 0, n); done += n; if (done > next) { next += 100L shl 20; Logger.i("Super", "copied ${done shr 20} MB..."); busy.value = "copying ${done shr 20} MB" } } } }
                    Logger.i("Super", "copy done: ${out.length() shr 20} MB")
                }
                if (Library.roms.none { it.id == rid }) { Library.roms.add(Rom(rid, g.title, name, "Super game, runs inside the app (experimental).", sys = g.sys, profile = "off")); Library.save() }
                busy.value = ""
                toast(ctx, "Starting " + g.title + " inside the app...")
                Logger.i("Super", "Starting game ${g.title} normally...")
                ctx.startActivity(Intent(ctx, GameActivity::class.java).putExtra("rom", rid).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Throwable) { busy.value = ""; Logger.e("Super", "could not start inside the app", e); toast(ctx, "Could not start: " + (e.message ?: e.javaClass.simpleName)) }
        }
    }
}
