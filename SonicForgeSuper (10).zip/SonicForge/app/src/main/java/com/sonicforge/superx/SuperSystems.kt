package com.sonicforge.superx

/**
 * SONICFORGE SUPER (experiment). Everything in this package is the whole "Super" idea; delete the folder
 * (and the five hooks listed in SUPER_README.txt) and the normal app is back.
 * These systems are too heavy to run inside our own small libretro bridge, so SUPER hands the game to an
 * emulator app that is already installed on the phone (PPSSPP, Dolphin, Flycast, ...). Nothing here is verified on a phone.
 */
data class Emu(val pkg: String, val name: String)
data class SSys(val id: String, val label: String, val exts: Set<String>, val emus: List<Emu>, val note: String, val sonic: String)

object SuperSystems {
    val all = listOf(
        SSys("psp", "PlayStation Portable", setOf("iso", "cso", "pbp", "chd"), listOf(Emu("org.ppsspp.ppsspp", "PPSSPP"), Emu("org.ppsspp.ppssppgold", "PPSSPP Gold")), "Generally easy on modern phones.", "Sonic Rivals 1 and 2, Ultimate Genesis Collection"),
        SSys("wii", "Nintendo Wii", setOf("wbfs", "rvz", "iso", "gcz", "wad"), listOf(Emu("org.dolphinemu.dolphinemu", "Dolphin"), Emu("org.dolphinemu.mmjr", "Dolphin MMJR")), "Demanding: wants a strong phone.", "Sonic Colours, Secret Rings, Black Knight, Unleashed"),
        SSys("gc", "Nintendo GameCube", setOf("iso", "gcm", "rvz", "gcz", "ciso"), listOf(Emu("org.dolphinemu.dolphinemu", "Dolphin"), Emu("org.dolphinemu.mmjr", "Dolphin MMJR")), "Moderate to demanding. Same emulator as Wii.", "Sonic Adventure DX, Adventure 2 Battle, Heroes, Riders"),
        SSys("dc", "Sega Dreamcast", setOf("cdi", "gdi", "chd", "cue"), listOf(Emu("com.flycast.emulator", "Flycast")), "Good on most modern phones.", "Sonic Adventure 1 and 2, Shuffle"),
        SSys("sat", "Sega Saturn", setOf("cue", "chd", "iso", "mdf"), listOf(Emu("org.devmiyax.yabasanshioro2", "Yaba Sanshiro 2")), "Moderate; depends on the phone.", "Sonic Jam, Sonic R, 3D Blast"),
        SSys("3ds", "Nintendo 3DS", setOf("3ds", "cia", "cci", "cxi", "3dsx"), listOf(Emu("io.github.lime3ds.android", "Lime3DS"), Emu("org.azahar_emu.azahar", "Azahar"), Emu("org.citra.citra_emu", "Citra")), "Moderate to demanding. Emulator availability changes.", "Sonic Generations, Lost World, Boom"),
        SSys("ps2", "PlayStation 2", setOf("iso", "chd", "cso", "bin", "gz"), listOf(Emu("xyz.aethersx2.android", "AetherSX2 / NetherSX2")), "Demanding: powerful phone recommended.", "Heroes, Shadow, Riders, Unleashed, Mega Collection"),
    )
    /** locked on purpose: planned only for "SonicForge Hyper" */
    val hyper = listOf("PlayStation 3", "Xbox (original)", "Xbox 360")
    fun byId(id: String) = all.firstOrNull { it.id == id } ?: all[0]
    fun sysOfExt(ext: String): String? = all.firstOrNull { ext in it.exts }?.id
}
