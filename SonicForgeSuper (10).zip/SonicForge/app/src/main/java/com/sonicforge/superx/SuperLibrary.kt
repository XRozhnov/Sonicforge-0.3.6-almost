package com.sonicforge.superx

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.sonicforge.data.Logger
import com.sonicforge.data.Store
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class SGame(val id: String, val title: String, val sys: String, val uri: String, val size: Long)

/** Big disc images are NOT copied: only a link (URI) to the file is kept, in its own file, apart from the normal library. */
object SuperLibrary {
    val games = androidx.compose.runtime.mutableStateListOf<SGame>()
    private fun file(ctx: Context) = File(ctx.filesDir, "super_games.json")
    fun load(ctx: Context) {
        games.clear()
        try { val a = JSONArray(file(ctx).takeIf { it.exists() }?.readText() ?: "[]"); for (i in 0 until a.length()) a.getJSONObject(i).let { games.add(SGame(it.getString("id"), it.getString("title"), it.getString("sys"), it.getString("uri"), it.optLong("size"))) } } catch (e: Exception) { Logger.e("Super", "could not read the Super library", e) }
        Logger.i("Super", "library loaded: ${games.size} game(s)")
    }
    private fun save(ctx: Context) { try { val a = JSONArray(); games.forEach { a.put(JSONObject().put("id", it.id).put("title", it.title).put("sys", it.sys).put("uri", it.uri).put("size", it.size)) }; file(ctx).writeText(a.toString()) } catch (e: Exception) { Logger.e("Super", "could not save the Super library", e) } }
    fun add(ctx: Context, uris: List<Uri>, forceSys: String?) {
        var n = 0
        for (u in uris) {
            try { ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); Logger.d("Super", "kept permission for $u") } catch (e: Exception) { Logger.w("Super", "permission is only for this session (pick the file again after a restart): ${e.message}") }
            var name = "game"; var size = 0L
            try { ctx.contentResolver.query(u, null, null, null, null)?.use { c -> if (c.moveToFirst()) { val ni = c.getColumnIndex("_display_name"); val si = c.getColumnIndex("_size"); if (ni >= 0) name = c.getString(ni); if (si >= 0) size = c.getLong(si) } } } catch (_: Exception) {}
            val ext = name.substringAfterLast('.', "").lowercase()
            val sys = forceSys ?: SuperSystems.sysOfExt(ext)
            if (sys == null) { Logger.w("Super", "skipped $name: extension .$ext matches no Super system"); continue }
            if (games.any { it.uri == u.toString() }) { Logger.i("Super", "$name is already in the list"); continue }
            val title = name.substringBeforeLast('.').replace('_', ' ').trim()
            games.add(SGame(System.currentTimeMillis().toString() + n, title, sys, u.toString(), size)); n++
            Logger.i("Super", "added “$title” as ${SuperSystems.byId(sys).label} (${size / 1048576} MB, linked, not copied)")
        }
        save(ctx)
    }
    fun remove(ctx: Context, g: SGame) { games.remove(g); save(ctx); Logger.i("Super", "removed “${g.title}” from the list (the file itself is untouched)") }
}
