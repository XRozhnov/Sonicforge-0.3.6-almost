package com.sonicforge.superx

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonicforge.data.Logger
import com.sonicforge.data.Store
import com.sonicforge.ui.*
import kotlinx.coroutines.delay

/** the SUPER tab */
@Composable
fun SuperScreen() {
    val ctx = LocalContext.current; val skin = Skins.current()
    var sysId by remember { mutableStateOf(Store.s("superSys", "psp")) }
    var pickApp by remember { mutableStateOf(false) }; var del by remember { mutableStateOf<SGame?>(null) }
    LaunchedEffect(Unit) { SuperLibrary.load(ctx) }
    val s = SuperSystems.byId(sysId); val emu = ExternalEmu.chosen(ctx, s)
    val list = SuperLibrary.games.filter { it.sys == sysId }
    LazyColumn(Modifier.fillMaxSize().padding(10.dp)) {
      item { Column {
        Text("⚗ SONICFORGE SUPER · " + I18n.tr("EXPERIMENT"), color = skin.accent, fontWeight = FontWeight.Black, fontSize = 15.sp, letterSpacing = 1.sp)
        Text("Heavy consoles are opened in an emulator app you install yourself. Nothing here is verified on a phone yet. This build can be deleted without touching the normal SonicForge.", color = Color(0xCCFFFFFF), fontSize = 11.sp)
        SToggle("ENGINE LOG (show what the launcher and emulators are doing)", "engineLog", EngineLog.defaultOn, "A live strip: Launching project emu..., Starting game ... normally. 3 quick taps fold it, a long press closes it; this switch brings it back.")
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            SuperSystems.all.forEach { x -> Btn(x.label + " (" + SuperLibrary.games.count { it.sys == x.id } + ")", selected = sysId == x.id) { sysId = x.id; Store.set("superSys", x.id) } }
        }
        Text(s.note, color = Color.White, fontSize = 12.sp)
        Text(I18n.tr("Sonic games here:") + " " + s.sonic, color = Color(0xBBFFFFFF), fontSize = 11.sp)
        Text(if (emu != null) I18n.tr("Emulator:") + " ${emu.name} " + I18n.tr("is installed") + " ✔" else if (s.emus.isEmpty()) I18n.tr("Emulator: none exists for this system") else I18n.tr("Emulator: not installed. Look for") + " " + s.emus.joinToString(" / ") { it.name }, color = if (emu != null) Color(0xFF9BFF9B) else Color(0xFFFFCC80), fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        NeedsCard(sysId)
        Column(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(10.dp)).background(Color.Black.copy(.3f)).padding(8.dp)) {
            Text("HOW IT WORKS", color = skin.accent, fontWeight = FontWeight.Black, fontSize = 11.sp)
            Text("1. Install the emulator app for the console (the line above says which one). 2. Tap + ADD GAME and pick your game file (a disc image such as .iso .chd .cdi): it is only linked, nothing is copied. 3. Tap PLAY: the emulator app opens the game. If the emulator cannot take the file from here it opens on its own: add the game inside it once. INSIDE is experimental and only for small images; heavy consoles belong in PLAY.", color = Color(0xE6FFFFFF), fontSize = 11.sp)
        }
        if (InApp.busy.value.isNotEmpty()) Text("⏳ " + InApp.busy.value, color = Color(0xFFFFCC80), fontSize = 12.sp)
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Btn(I18n.tr("+ ADD GAME") + " · " + s.label) { SuperPicker.pick { SuperLibrary.add(ctx, it, sysId) } }
            Btn("CHOOSE EMULATOR APP") { pickApp = true }
            if (Store.s("superApp_" + sysId).isNotEmpty()) Btn("USE DEFAULT") { Store.set("superApp_" + sysId, ""); Logger.i("Super", "emulator for ${s.label} back to the default") }
        }
        Text(I18n.tr("Games are linked, not copied (discs are big). File endings:") + " " + s.exts.joinToString(" ") { ".$it" }, color = Color(0x99FFFFFF), fontSize = 10.sp)
      } }
            if (list.isEmpty()) item { Text(I18n.tr("No games here yet.") + " " + s.label, color = Color.White, modifier = Modifier.padding(8.dp)) }
            items(list, key = { it.id }) { g ->
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(10.dp)).background(Color.Black.copy(.35f)).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(g.title, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 2); Text("${g.size / 1048576} MB", color = Color(0x99FFFFFF), fontSize = 10.sp) }
                    Btn("▶ PLAY") { ExternalEmu.launch(ctx, g) }; if (InApp.available(ctx, g.sys)) { Spacer(Modifier.width(4.dp)); Btn("▶ INSIDE") { InApp.play(ctx, g) } }; Spacer(Modifier.width(4.dp)); Btn("✕") { del = g }
                }
            }
            item { Column(Modifier.padding(top = 12.dp)) {
                Text("🔒 SonicForge HYPER (later)", color = Color(0xFFFFCC80), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text(SuperSystems.hyper.joinToString(" · ") + " — " + I18n.tr("not practical on a phone today."), color = Color(0x99FFFFFF), fontSize = 11.sp) } }
    }
    del?.let { g -> ConfirmDialog(I18n.tr("Remove this game from the list?") + " " + g.title, I18n.tr("remove the link from this list"), I18n.tr("delete the game file or touch anything in your storage"), onYes = { SuperLibrary.remove(ctx, g); del = null }, onNo = { del = null }) }
    if (pickApp) androidx.compose.ui.window.Dialog(onDismissRequest = { pickApp = false }, properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
        val apps = remember { ExternalEmu.launcherApps(ctx) }
        Column(Modifier.fillMaxWidth(.92f).fillMaxHeight(.88f).clip(RoundedCornerShape(16.dp)).background(Color(0xFF14141C)).padding(12.dp)) {
            Text(I18n.tr("Choose the emulator app for") + " " + s.label, color = Color.White, fontWeight = FontWeight.Bold)
            LazyColumn { items(apps, key = { it.pkg }) { a -> Text(a.name + "\n" + a.pkg, color = Color.White, fontSize = 12.sp, modifier = Modifier.fillMaxWidth().forgeClick { Store.set("superApp_" + sysId, a.pkg); Logger.i("Super", "emulator for ${s.label} set to ${a.name}"); pickApp = false }.padding(8.dp)) } }
        }
    }
}

object SuperPicker { var pick: ((List<android.net.Uri>) -> Unit) -> Unit = {} }

