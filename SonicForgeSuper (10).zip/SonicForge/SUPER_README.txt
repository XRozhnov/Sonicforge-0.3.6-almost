SONICFORGE SUPER (experiment) - how to scrap it
================================================
This folder is a COPY of SonicForge 0.3.6_pre8 with a different application id (com.sonicforge.superx), name "SonicForge Super"
and version Super_0.1_exp1. It installs NEXT TO the normal app and never touches its data.
To scrap it: delete this folder / the GitHub branch, uninstall "SonicForge Super". The normal SonicForge is unaffected.

What is new (all of it in app/src/main/java/com/sonicforge/superx/ plus 6 small hooks):
- SUPER tab: PSP, Wii, GameCube, Wii U, Dreamcast, Saturn, 3DS, PS2 lists. Games are LINKED (not copied). PLAY opens the game in an emulator app you install
  (PPSSPP, Dolphin, Flycast, Yaba Sanshiro 2, Lime3DS/Azahar, AetherSX2/NetherSX2). Wii U: no Android emulator exists; list only.
- ENGINE LOG strip (toggle in SUPER tab): live lines such as "Launching project emu for ...", "Starting game ... normally...".
- PS3, Xbox, Xbox 360 are shown as locked: reserved for "SonicForge Hyper".
Hooks outside superx/: AndroidManifest.xml (label + package <queries>), build.gradle.kts (applicationId/version), MainActivity.kt (picker, SUPER tab case,
log strip, play log line), ui/UiModes.kt (NAV entry).
NOT written, NOT compiled, NOT tried on a phone. Honest limits: our own libretro bridge is software-rendered, so PSP/Wii/GC/DC/PS2 are NOT run inside the app.
Emulator intent handling (VIEW with a content URI) is a guess for each app; if an app refuses, SUPER opens the emulator itself and tells you to add the game there.
