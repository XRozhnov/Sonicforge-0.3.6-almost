#!/usr/bin/env bash
# Downloads libretro cores at BUILD time (the APK itself has no internet permission).
# Required: genesis_plus_gx (Mega Drive / Master System / Game Gear / Sega CD). Optional: picodrive (32X), mgba (GBA/GB), fceumm (NES), snes9x (SNES), melonds / desmume2015 (Nintendo DS, experimental). Optional failures are skipped.
fetch() {  # abi core libname required
  local abi=$1 core=$2 lib=$3 req=$4
  local d=app/src/main/jniLibs/$abi; mkdir -p $d
  if curl -fsSL "https://buildbot.libretro.com/nightly/android/latest/$abi/${core}_libretro_android.so.zip" -o /tmp/$core-$abi.zip && unzip -qo /tmp/$core-$abi.zip -d /tmp/$core-$abi && cp /tmp/$core-$abi/${core}_libretro_android.so $d/$lib; then
    echo "OK   $abi $core"
  else
    echo "MISS $abi $core"; rm -f $d/$lib
    if [ "$req" = "1" ]; then echo "required core missing: $core"; exit 1; fi
  fi
}
for ABI in arm64-v8a armeabi-v7a x86_64 x86; do
  REQ=1; case $ABI in x86*) REQ=0;; esac   # PC / Chromebook builds: a missing core must never stop the phone builds
  fetch $ABI genesis_plus_gx libgpgx.so $REQ
  fetch $ABI picodrive libpicodrive.so 0
  fetch $ABI mgba libmgba.so 0
  fetch $ABI fceumm libfceumm.so 0
  fetch $ABI snes9x libsnes9x.so 0
  fetch $ABI melonds libmelonds.so 0
  fetch $ABI desmume2015 libdesmume.so 0
  fetch $ABI desmume libdesmume_full.so 0      # full DeSmuME (interpreter on phones): another DS choice
  fetch $ABI melondsds libmelondsds.so 0       # the new melonDS DS core (JesseTG): another DS choice
  fetch $ABI ppsspp libppsspp.so 0      # SUPER: PSP
  fetch $ABI yabause libyabause.so 0    # SUPER: Saturn
  fetch $ABI flycast libflycast.so 0    # SUPER: Dreamcast
done
ls -la app/src/main/jniLibs/*/
