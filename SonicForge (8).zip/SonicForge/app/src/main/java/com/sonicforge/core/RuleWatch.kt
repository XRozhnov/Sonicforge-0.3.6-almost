package com.sonicforge.core

import com.sonicforge.data.Store
import org.json.JSONArray
import org.json.JSONObject

/**
 * User-made vibration rules for ANY game on ANY console (ROM hacks, other Sega games, NES, SNES, Game Boy ...).
 * A rule watches one number in the console's work RAM and fires one of the normal vibration events when it rises, falls, changes,
 * becomes a value or drops below a value. Addresses are offsets inside the console's system RAM (for the Mega Drive: $FFxxxx -> xxxx).
 */
data class VibRule(val label: String, val addr: Int, val size: Int, val trig: String, val value: Int, val event: String)

object VibRules {
    private fun key(id: String) = "vibRules_$id"
    fun load(id: String): List<VibRule> = try {
        val a = JSONArray(Store.s(key(id), "[]"))
        List(a.length()) { val o = a.getJSONObject(it); VibRule(o.optString("l"), o.optInt("a"), o.optInt("s", 1).coerceIn(1, 2), o.optString("t", "up"), o.optInt("v", 0), o.optString("e", "ring")) }
    } catch (_: Exception) { emptyList() }
    fun save(id: String, list: List<VibRule>) {
        val a = JSONArray(); list.forEach { a.put(JSONObject().put("l", it.label).put("a", it.addr).put("s", it.size).put("t", it.trig).put("v", it.value).put("e", it.event)) }
        Store.set(key(id), a.toString())
    }
    val swapped = setOf("md", "scd", "x32")   // 68000 RAM is stored word-swapped by the cores on little-endian phones

    class Suggest(val sys: String, val game: String, val rules: List<VibRule>)
    /** your own rules; when you have none, a matching starting point from the list below is used automatically (SETTINGS ▸ VIBRATION ▸ "Use suggested rules" turns that off) */
    fun effective(rom: com.sonicforge.data.Rom): List<VibRule> {
        val own = load(rom.id); if (own.isNotEmpty() || !Store.b("hapAutoRules", true)) return own
        return suggestionFor(rom)?.rules ?: own
    }
    /** which built-in list (if any) fits this game, judged by its title with the (region) and [hack] tags removed */
    fun suggestionFor(rom: com.sonicforge.data.Rom): Suggest? {
        val t = rom.title.lowercase().replace(Regex("\\(.*?\\)|\\[.*?]"), " ").replace(Regex("\\s+"), " ").trim()
        return when {
            rom.sys == "nes" && Regex("mario (bros\\.? ?)?3|smb ?3").containsMatchIn(t) -> suggestions[2]
            rom.sys == "nes" && Regex("super mario bros\\.?( |$)|mario bros\\.? ?(the )?lost|smb ?1").containsMatchIn(t) && !Regex("bros\\.? ?[23]").containsMatchIn(t) -> suggestions[0]
            rom.sys == "snes" && t.contains("mario world") && !t.contains("world 2") -> suggestions[1]
            else -> null
        }
    }
    /** starting points written from memory of public RAM maps: NOT verified on a device, so test them and edit the addresses if nothing happens */
    val suggestions = listOf(
        Suggest("nes", "Super Mario Bros. (NES)", listOf(
            VibRule("Coins", 0x075E, 1, "up", 0, "ring"), VibRule("Lives lost", 0x075A, 1, "down", 0, "death"), VibRule("Extra life", 0x075A, 1, "up", 0, "oneup"),
            VibRule("Hit: power-up lost", 0x0756, 1, "down", 0, "hurt"), VibRule("Power-up", 0x0756, 1, "up", 0, "shield"))),
        Suggest("snes", "Super Mario World (SNES)", listOf(
            VibRule("Coins", 0x0DBF, 1, "up", 0, "ring"), VibRule("Lives lost", 0x0DBE, 1, "down", 0, "death"), VibRule("Extra life", 0x0DBE, 1, "up", 0, "oneup"),
            VibRule("Hit: power-up lost", 0x0019, 1, "down", 0, "hurt"), VibRule("Power-up", 0x0019, 1, "up", 0, "shield"),
            VibRule("Death animation", 0x0071, 1, "eq", 9, "death"), VibRule("Yoshi mounted", 0x187A, 1, "up", 0, "spring"), VibRule("Star power", 0x1490, 1, "up", 0, "invinc"))),
        Suggest("nes", "Super Mario Bros. 3 (NES)", listOf(
            VibRule("Lives lost", 0x0736, 1, "down", 0, "death"), VibRule("Extra life", 0x0736, 1, "up", 0, "oneup"),
            VibRule("Hit (flashing starts)", 0x0552, 1, "up", 0, "hurt"), VibRule("Star power", 0x0553, 1, "up", 0, "invinc"),
            VibRule("Power-up", 0x00ED, 1, "up", 0, "shield")))
    )
}

class RuleWatcher(private val rules: List<VibRule>, private val swap: Boolean) {
    private val last = IntArray(rules.size) { -1 }
    fun poll(read: (Int, Int) -> ByteArray?, emit: (String) -> Unit) {
        rules.forEachIndexed { i, r ->
            val base = if (swap) r.addr and 1.inv() else r.addr
            val len = r.size + (r.addr - base) + (if (swap) 2 else 0)
            val d = read(base, len) ?: return@forEachIndexed
            var v = 0
            for (j in 0 until r.size) {
                val off = r.addr - base + j; val idx = if (swap) off xor 1 else off
                if (idx !in d.indices) return@forEachIndexed
                val b = d[idx].toInt() and 0xFF
                v = if (swap) (v shl 8) or b else v or (b shl (8 * j))
            }
            val p = last[i]; last[i] = v
            if (p < 0) return@forEachIndexed
            val fire = when (r.trig) { "up" -> v > p; "down" -> v < p; "change" -> v != p; "eq" -> v == r.value && p != r.value; "below" -> v < r.value && p >= r.value; else -> false }
            if (fire) emit(r.event)
        }
    }
}
