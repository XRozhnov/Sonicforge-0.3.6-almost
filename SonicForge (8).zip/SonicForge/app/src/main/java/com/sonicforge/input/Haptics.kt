package com.sonicforge.input

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import com.sonicforge.data.SaveEvent
import com.sonicforge.data.Store
import org.json.JSONObject

data class HEv(val id: String, val label: String, val defAmp: Int)

/**
 * Vibration. Two independent channels: the app (menus) and the emulator (touch buttons + in-game events).
 * Every game event has its own on/off switch and strength; templates (Quiet/Medium/Max) and 3 saved presets set them all at once;
 * a per-game switch and the global switch never erase your settings.
 */
object Haptics {
    val events = listOf(
        HEv("touch", "Touch buttons", 35), HEv("ring", "Ring collected", 25), HEv("hurt", "Ring loss / hit", 80), HEv("death", "Death", 100),
        HEv("jump", "Jump", 40), HEv("spin", "Spin dash", 60), HEv("spring", "Spring", 70), HEv("fly", "Tails flying", 30), HEv("drown", "Drowning countdown", 75),
        HEv("bite", "Enemy bite (steals a ring)", 70), HEv("drain", "Rings draining away", 45), HEv("oneup", "Extra life", 55), HEv("shield", "Shield picked up", 50),
        HEv("invinc", "Invincibility sparkles", 25), HEv("shoes", "Speed shoes", 45), HEv("fizz", "Fire shield doused", 50), HEv("zap", "Lightning shield zaps water", 80), HEv("step", "Footsteps (experimental)", 25),
        HEv("boom", "Explosion / monitor / enemy popped (from sound)", 60), HEv("splash", "Water splash (in / out)", 40), HEv("bubble", "Air bubble breathed", 35))
    @Volatile var currentGame = ""
    /** per-game preset: while a game runs, its chosen preset (1-9) answers evOn/evAmp instead of the global switches; your global settings are never touched */
    @Volatile private var overlay: Map<String, Pair<Boolean, Int>>? = null
    fun gamePreset(id: String): Int = Store.s("hapPreset_$id", "0").toIntOrNull() ?: 0
    fun setGamePreset(id: String, n: Int) { Store.set("hapPreset_$id", n.toString()); if (id == currentGame) overlay = presetMap(n) }
    fun enterGame(id: String) { currentGame = id; overlay = presetMap(gamePreset(id)) }
    fun leaveGame() { currentGame = ""; overlay = null }
    /** what a preset switches on and how strong, without applying it anywhere; null = "global" (0) or an empty slot */
    fun presetMap(n: Int): Map<String, Pair<Boolean, Int>>? {
        if (n <= 0) return null
        if (n <= 3) { val set = when (n) { 1 -> setOf("touch", "ring"); 2 -> setOf("touch", "ring", "hurt", "death", "jump", "spin", "spring", "fly", "drown"); else -> events.map { it.id }.toSet() - "step" }
            return events.associate { it.id to ((it.id in set) to it.defAmp) } }
        val t = Store.read("haptic_preset_$n.json") ?: return null
        return try { val o = JSONObject(t); val m = HashMap<String, Pair<Boolean, Int>>(); events.forEach { e -> o.optJSONObject(e.id)?.let { m[e.id] = it.optBoolean("on", true) to it.optInt("amp", e.defAmp) } }; m } catch (_: Exception) { null }
    }
    private var vib: Vibrator? = null
    private val last = HashMap<String, Long>()
    fun init(ctx: Context) {
        vib = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(VibratorManager::class.java)?.defaultVibrator
              else @Suppress("DEPRECATION") ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }
    fun appOn() = Store.b("hapAppOn", true)
    fun gameOn() = Store.b("hapGameOn", true) && Store.s("hapG_$currentGame", "1") != "0"
    fun evOn(id: String) = overlay?.get(id)?.first ?: Store.b("hapE_${id}_on", id != "step")
    fun evAmp(id: String) = overlay?.get(id)?.second ?: Store.i("hapE_${id}_amp", events.first { it.id == id }.defAmp)
    fun defAmp(id: String): Int = events.firstOrNull { it.id == id }?.let { it.defAmp } ?: 60

    /** where buzzes go: "phone" | "pad" (connected controllers) | "both" | "off". Menus (app) and the game have separate settings; a game can override its own. */
    fun routeApp() = Store.s("hapRouteApp", "phone")
    fun routeGame(): String = Store.s("hapRG_$currentGame").ifEmpty { Store.s("hapRouteGame", "phone") }
    data class HTarget(val id: String, val label: String, val vib: Vibrator?, val supported: Boolean, val amplitude: Boolean, val note: String)
    private fun padVib(id: Int): Vibrator? = try {
        val d = android.view.InputDevice.getDevice(id)
        if (d == null) null else if (Build.VERSION.SDK_INT >= 31) d.vibratorManager.defaultVibrator else @Suppress("DEPRECATION") d.vibrator
    } catch (_: Throwable) { null }
    /** phone + every connected controller, with what Android says about each (used by the test screen) */
    fun targets(): List<HTarget> {
        val l = ArrayList<HTarget>()
        val ph = vib; val phOk = ph?.hasVibrator() == true
        l.add(HTarget("phone", "This phone", ph, phOk, phOk && ph?.hasAmplitudeControl() == true, if (phOk) "" else "Android reports no vibration motor in this device."))
        Pads.devices.forEach { p ->
            val v = padVib(p.id); val ok = v?.hasVibrator() == true
            l.add(HTarget("pad${p.id}", p.name + " (" + p.style.label + ")", v, ok, ok && v?.hasAmplitudeControl() == true,
                if (ok) "" else "Android reports no rumble for this controller. Common with some Bluetooth pads, generic mode and PlayStation pads on certain phones; nothing the app can force."))
        }
        return l
    }
    private class Lvl(val mult: Float, val floor: Int, val dur: Float)
    /** strength presets: the phone's NORMAL is the old behaviour; a controller's NORMAL is stronger because rumble motors need a push to be felt */
    private fun lvl(pad: Boolean, name: String): Lvl = if (pad) when (name) {
        "low" -> Lvl(1.2f, 70, 1f); "high" -> Lvl(3f, 200, 1.4f); "max" -> Lvl(10f, 255, 1.8f); else -> Lvl(2.2f, 130, 1.15f)
    } else when (name) {
        "low" -> Lvl(.5f, 0, 1f); "high" -> Lvl(1.6f, 80, 1.3f); "max" -> Lvl(10f, 255, 1.6f); else -> Lvl(1f, 0, 1f)
    }
    private fun play(v: Vibrator, t: LongArray, s: IntArray, pad: Boolean, forceAmp: Boolean) {
        try {
            if (!v.hasVibrator()) return
            val lv = lvl(pad, Store.s(if (pad) "hapPadLevel" else "hapPhoneLevel", "normal"))
            val user = Store.i(if (pad) "hapPadScale" else "hapPhoneScale", 100) / 100f
            val floor = maxOf(lv.floor, if (pad) Store.i("hapPadMin", 0) else 0)
            val durUser = (if (pad) Store.i("hapPadDur", 100) else 100) / 100f
            val tt = LongArray(t.size) { i -> if (i % 2 == 1) (t[i] * lv.dur * durUser).toLong().coerceIn(1L, 3000L) else t[i] }
            val eff = if (v.hasAmplitudeControl() || forceAmp)
                VibrationEffect.createWaveform(tt, IntArray(s.size) { i -> if (s[i] <= 0) 0 else (s[i] * lv.mult * user).toInt().coerceIn(maxOf(floor, 1), 255) }, -1)
            else VibrationEffect.createWaveform(tt, -1)
            v.vibrate(eff)
        } catch (_: Exception) {}
    }
    private fun send(route: String, t: LongArray, s: IntArray) {
        if (route == "off") return
        if (route == "phone" || route == "both") vib?.let { play(it, t, s, false, true) }
        if (route == "pad" || route == "both") Pads.devices.forEach { p -> padVib(p.id)?.let { play(it, t, s, true, false) } }
    }
    /** test one device for ~0.6 s so you can tell which one really buzzes (uses that device's current strength settings) */
    fun testTarget(t: HTarget) { val v = t.vib ?: return; play(v, longArrayOf(0, 250, 120, 250), intArrayOf(0, 200, 0, 200), t.id != "phone", t.id == "phone") }

    private fun fire(id: String, a: Int, route: String = routeGame()) {
        if (route == "off" || a <= 0) return
        if (route == "phone" && (vib == null || vib?.hasVibrator() != true)) return
        val now = System.currentTimeMillis(); val gap = when (id) { "ring" -> 50; "fly" -> 220; "touch" -> 20; "bite" -> 35; "drain" -> 45; "step" -> 120; "invinc" -> 300; "boom" -> 130; "splash" -> 200; "bubble" -> 150; else -> 110 }
        if (now - (last[id] ?: 0) < gap) return; last[id] = now
        val amp = (a * 255 / 100).coerceIn(1, 255); val k = 0.6f + a / 100f * 0.8f
        fun ms(x: Int) = (x * k).toLong().coerceAtLeast(3)
        val (t, s) = when (id) {
            "hurt" -> longArrayOf(0, ms(35), 30, ms(55)) to intArrayOf(0, amp, 0, amp)
            "death" -> longArrayOf(0, ms(120), 60, ms(170)) to intArrayOf(0, amp, 0, amp)
            "spin" -> longArrayOf(0, ms(15), 25, ms(20), 25, ms(25), 25, ms(38)) to intArrayOf(0, amp / 3 + 1, 0, amp / 2 + 1, 0, amp * 3 / 4 + 1, 0, amp)
            "spring" -> longArrayOf(0, ms(12), 18, ms(26)) to intArrayOf(0, amp, 0, amp / 2 + 1)
            "drown" -> longArrayOf(0, ms(60), 70, ms(60)) to intArrayOf(0, amp, 0, amp)
            "bite" -> longArrayOf(0, ms(5), 12, ms(5)) to intArrayOf(0, amp, 0, amp)                  // two quick sharp ticks, like snapping teeth
            "drain" -> longArrayOf(0, ms(10), 8, ms(8)) to intArrayOf(0, amp, 0, amp / 2 + 1)       // a soft fading pulse per ring sucked away
            "oneup" -> longArrayOf(0, ms(15), 30, ms(15), 30, ms(25)) to intArrayOf(0, amp / 2 + 1, 0, amp * 3 / 4 + 1, 0, amp)   // rising jingle
            "shield" -> longArrayOf(0, ms(20), 30, ms(10)) to intArrayOf(0, amp, 0, amp / 2 + 1)
            "invinc" -> longArrayOf(0, 6, 40, 6, 40, 6, 40, 6) to intArrayOf(0, amp / 2 + 1, 0, amp / 2 + 1, 0, amp / 2 + 1, 0, amp / 2 + 1)   // soft sparkles
            "shoes" -> longArrayOf(0, ms(40)) to intArrayOf(0, amp)
            "fizz" -> longArrayOf(0, ms(40), 20, ms(30), 20, ms(20)) to intArrayOf(0, amp / 2 + 1, 0, amp / 3 + 1, 0, amp / 5 + 1)   // steam fading out
            "zap" -> longArrayOf(0, 8, 10, 8, 10, 8, 10, 20) to intArrayOf(0, amp, 0, amp, 0, amp, 0, amp)   // electric jitter
            "step" -> longArrayOf(0, ms(5)) to intArrayOf(0, amp * 2 / 3 + 1)
            "boom" -> longArrayOf(0, ms(45), 25, ms(30)) to intArrayOf(0, amp, 0, amp / 2 + 1)   // a thump with an aftershock
            "splash" -> longArrayOf(0, ms(12), 15, ms(20)) to intArrayOf(0, amp / 2 + 1, 0, amp / 3 + 1)
            "bubble" -> longArrayOf(0, ms(6), 18, ms(6)) to intArrayOf(0, amp / 2 + 1, 0, amp / 2 + 1)
            "ring", "touch", "ui" -> longArrayOf(0, ms(8)) to intArrayOf(0, amp)
            else -> longArrayOf(0, ms(14)) to intArrayOf(0, amp)
        }
        send(route, t, s)
    }

    fun ui() { if (appOn()) fire("ui", Store.i("hapApp", 35), routeApp()) }
    fun gameTouch() = game("touch")
    fun gameEvent(kind: String) = game(kind)
    fun game(ev: String) { if (!gameOn() || !evOn(ev)) return; fire(ev, evAmp(ev)) }
    fun test(ev: String) { if (ev == "ui") fire("ui", Store.i("hapApp", 35), routeApp()) else fire(ev, evAmp(ev)) }
    fun stopAll() { try { vib?.cancel() } catch (_: Exception) {}; Pads.devices.forEach { p -> try { padVib(p.id)?.cancel() } catch (_: Exception) {} } }

    fun template(name: String) {
        events.forEach { e -> Store.setI("hapE_${e.id}_amp", when (name) { "quiet" -> (e.defAmp / 2).coerceAtLeast(10); "max" -> (e.defAmp * 16 / 10).coerceAtMost(100); else -> e.defAmp }) }
        Store.setI("hapApp", when (name) { "quiet" -> 20; "max" -> 70; else -> 35 })
    }
    /** Presets 1-3 are built in (1 = rings + buttons only, 2 = classic set, 3 = everything but footsteps). 4-9 are yours (empty until you save). */
    fun builtin(n: Int) {
        val set = when (n) { 1 -> setOf("touch", "ring"); 2 -> setOf("touch", "ring", "hurt", "death", "jump", "spin", "spring", "fly", "drown"); else -> events.map { it.id }.toSet() - "step" }
        events.forEach { Store.setB("hapE_${it.id}_on", it.id in set); Store.setI("hapE_${it.id}_amp", it.defAmp) }
        Store.setI("hapApp", 35)
    }
    fun presetExists(n: Int) = n <= 3 || Store.read("haptic_preset_$n.json") != null
    fun savePreset(n: Int): Boolean {
        if (n <= 3) return false
        val o = JSONObject().put("app", Store.i("hapApp", 35)).put("rApp", routeApp()).put("rGame", Store.s("hapRouteGame", "phone")).put("padScale", Store.i("hapPadScale", 100)); events.forEach { o.put(it.id, JSONObject().put("on", evOn(it.id)).put("amp", evAmp(it.id))) }
        val ok = Store.writeVerified("haptic_preset_$n.json", o.toString()); Store.events.tryEmit(SaveEvent("Vibration preset $n saved", ok)); return ok
    }
    fun loadPreset(n: Int): Boolean {
        if (n <= 3) { builtin(n); Store.events.tryEmit(SaveEvent("Vibration preset $n applied", true)); return true }
        val t = Store.read("haptic_preset_$n.json")
        if (t == null) { Store.events.tryEmit(SaveEvent("Vibration preset $n is empty (yours to fill)", false)); return false }
        return try { val o = JSONObject(t); Store.setI("hapApp", o.optInt("app", 35)); Store.set("hapRouteApp", o.optString("rApp", "phone")); Store.set("hapRouteGame", o.optString("rGame", "phone")); Store.setI("hapPadScale", o.optInt("padScale", 100))
            events.forEach { e -> o.optJSONObject(e.id)?.let { Store.setB("hapE_${e.id}_on", it.optBoolean("on", true)); Store.setI("hapE_${e.id}_amp", it.optInt("amp", e.defAmp)) } }
            Store.events.tryEmit(SaveEvent("Vibration preset $n loaded", true)); true } catch (_: Exception) { false }
    }
}
