# CHECKLIST for update 0.3.6 (this is the list to tick; legend: 🆕 NEW in the latest batch (written, uncompiled) · 🛠 fixed after a real build error · ✅ code written (uncompiled) · 🟡 partly · ⬜ not started · 🔒 impossible/deferred with reason)
> **Reconciled on 2026-11-21: see `14_STATUS_0.3.6_RECONCILED.md` for the verified done / partial / not-done picture (sections below keep their history; some old ⬜ markers were updated).**
Version target: **0.3.6** (code 9). Previous failed build: 0.3.5 (DrawUi type mismatch, fixed ✅).

## A. Fix first (compile + bugs seen in screenshots)
- ✅ A1 DrawUi HueBar `size.height.toFloat()`
- 🟡 A2 (queue no longer closes; ⌖ icon still to do) Queue sheet must NOT close after choosing a song; small ⌖ jump icon in the queue
- ✅ A3 Favourites ♥ does not update (list, counts, heart state): make Playlists observable
- ✅ A4 Text colour: default text must follow the skin (storage page, Locations, DATA tab were black)
- ✅ A5 Locations buttons overflow (scroll the button rows)
- 🟡 A6 (hidden=no space, close, peek, tap title done; "turn off inside the player tab" still to do) Mini player: hidden state takes no space; CLOSE (not only minimise); "?" peek list = 2 previous + current + upcoming; tap title opens MUSIC tab, ☰ opens queue; switch to turn it off inside the player tab
- 🟡 A7 (Language translated; check the English "Languages" line) "Language" heading translated, "Languages" below always English
- ✅ A8 Reset button label: "Reset / restart the emulator (console)"
- ✅ A9 Pause music when headphones unplug (ACTION_AUDIO_BECOMING_NOISY)
- 🟡 A10 (labels done; layout with real A+B still to verify) SMS/GG: both buttons + Start/Pause; labels 1 / 2 (A + B) and PAUSE (SMS) / START (GG); the user says Start did not start games (real SMS: Start = Pause) → show both and explain; also verify the on-screen layout matches the real controller
- ⬜ A11 Game Gear rewind solid-colour bug and RESET after it
- 🟡 (open-in-Ruffle, keyboard symbols/backspace done; FPS lock, haptic options, hide language key still open; black screen unconfirmed) (open-in-Ruffle, keyboard symbols/backspace done; FPS lock, haptic options, hide language key still open; black screen unconfirmed) A12 Flash/Ruffle still broken: research more, add "open in the installed Ruffle app" option, FPS lock, haptic response options (gamepad / keyboard / both, intensity), keyboard: backspace + esc, ?123/ABC symbols page (switchable), hide-able language key (future languages)
- ⬜ A13 Customisation text/UI stays white after picking a background image; theme change does nothing (investigate Skins/Store keys)
- ⬜ A14 Vertical launcher orientation not fixed; the orientation switch changes nothing (explain or fix)

## B. Requested features in this update
### Emulator / game screen
- ⬜ Reset + UI on/off inside the mini menu next to the Classic switch (works in Classic too)
- ⬜ Split Classic: "Classic look" (no frame/UI chrome) vs "show controls"; third switch: mini-button panel expanded/minimised; switch to turn the mini panel off with confirmation (only BACK or closing the app leaves); explain every chip
- ⬜ D-pad lights only the pressed directions/combos (switchable to the whole pad); say where to change it
- ⬜ T indicator: hollow square "□T" when the console MAY still be affected after tilt is off (until a full close/reopen or a reset by the console button); hidden when not affected; setting to hide it
- ⬜ Alpha: separate alpha for controls and for symbols; "apply to buttons" switch; 6-button pad switch inside the mini menu
- ⬜ EMU counter / SCREEN counter: reset colour (different defaults) + explanation of the difference
- ⬜ Dead-zone map "always show" (only inside that settings tab)
- ⬜ Auto-rotate: disable, or auto-rotate with a confirmation button (drawn icon, not text), well placed
- ✅🆕 (swap + 8 ratios + system-bars chips) Resolution: "swap sides" (4:3 ↔ 3:4) with a description; extra ratios under "show more" (16:10, 8:5, 21:9/7:3 UWQHD 3440×1440, 5:3, 3:2, 5:4, 32:9, …); show/hide Android system bars switch there too
- ✅🆕 UI scale (like Minecraft) with a "keep these settings?" countdown (8 s) and test buttons that click + vibrate
- 🟡 (PAUSE button done; hide-mini-menu option and TV remote still open) (PAUSE button done; hide-mini-menu option and TV remote still open) Optional PAUSE button; hide mini menu option (BACK reopens); TV remote support (all 4 APK types)
- ⬜ Tilt: "glitch visuals only" switch (experimental), vibration-ignore switch while tilting, per-console tilt methods
- 🟡 (rewind length 4-20 s and a memory cap done; per-save-point history not done) (rewind length 4-20 s and a memory cap done; per-save-point history not done) Rewind: remember rewind history per save point
### Music
- ✅ Headphone buttons explanation (Eggman) 
- ⬜ Search bar (ignore case / exact phrase / symbols), sort by length (+ reversed), small ⌖ jump icon in queue
- 🟡 (REAL-TIME equalizer done; custom image, 2 more styles, tempo not done) (REAL-TIME equalizer done; custom image, 2 more styles, tempo not done) Equalizer: show over cover/custom image, 2 more styles, fix WAVE, tempo/speed setting + reset
- ⬜ Use original files in place (no copying): explain extra space; option for copy format (same format or .opus) and why; show the cloned folder in LOCATIONS
- ⬜ Import: confirm adding songs with the same name/metadata to ALL
- 🟡 (cover, seek, play/pause state fix done; hide-cover option not done) (cover, seek, play/pause state fix done; hide-cover option not done) Notification: like the user's examples (cover, seek bar), option to hide the cover
- ✅🆕 Share-to-launcher (Android share sheet) importing games / music (choose playlist) / comics / pictures / videos with per-type tabs and a chooser for ambiguous images
### Look and customisation
- ⬜ Replace the 10 new skins with more varied ones (falling green leaves on a gradient, Horror Hills, Angel Island, …), Soft White / Soft Black side by side at the end
- 🟡 (foreground layer, GIF in layers done; click-to-play GIF on buttons not done) (foreground layer, GIF in layers done; click-to-play GIF on buttons not done) Foreground image layer over the background (own opacity/brightness/size/position); GIF support with recommendations; click-to-play GIF on control buttons (experimental)
- ⬜ Picture preset slots: 9 per category (A launcher menu, B controls UI, C background/foreground/emulator BG, D falling image, E future) with “+”, name, description, colour, delete (min 3) with confirmation; recommended sizes for imports
- ⬜ Effect FPS settings + presets; particles fade in/out outside the screen edge
- ⬜ Controller pictures per model (Xbox 360, Xbox One/Series, DualShock 4, DualSense, Steam Controller 1/2, Switch Pro, custom) with bumpers/triggers; controller vibration on/off/only-controller + coloured test; reset circle for combos; detect several Bluetooth devices and say which are controllers
### Content / data
- 🟡 (cache clearing + free space done; charts not done) (cache clearing + free space done; charts not done) Per-category cache clearing; free-space info of the device; storage charts (Pro)
- ⬜ More guide slides (new features) and translations of guide, What's new, descriptions, Settings and Help into all 12 languages
- 🟡 (entries are labelled NEW/FIXED/IMPROVED/NOT DONE; no grouped UI) (entries are labelled NEW/FIXED/IMPROVED/NOT DONE; no grouped UI) What's new split: Added / Fixed / Improved
- ⬜ Console handbooks (every console, Flash, OpenBOR) with 3 depth levels; Sega CD walkthrough with in-app steps
- 🟡 (sound-driven haptics for every game + user RAM rules done; exact hazard events not done) (sound-driven haptics for every game + user RAM rules done; exact hazard events not done) Vibration: cutscene/hazard events (levers, boss flames, bridges, Hydrocity wall, Ice Cap avalanche, special-stage entry, wind, debris, icicles), 12 popular MD games incl. racers, Sonic on Game Boy; supported-games catalogue
- ⬜ Add-game category sheet (experimental) with advice for AUTOMATIC mode; supported lists
### New big modules (Pro / experimental)
- 🟡 (COPY mode with zoom/tap/manga/reorder done; READ IN PLACE, transitions, bookmarks not done) (COPY mode with zoom/tap/manga/reorder done; READ IN PLACE, transitions, bookmarks not done) COMICS, PICTURES, VIDEO with two modes: COPY into the app, or READ IN PLACE from the device (default: no caching); transitions (≥5), zoom with %, modes (L→R, manga R→L, vertical, webtoon), tap halves/swipe, overlay switch (on by default on TV)
- 🟡 (recorder + backing track + level display + live preview done; karaoke lyrics/timestamps, scene creator not done) (recorder + backing track + level display + live preview done; karaoke lyrics/timestamps, scene creator not done) Recorder + karaoke/timestamps, scene creator (Pro)

## C. Docs and delivery (must be done each batch)
- ✅ C1 this checklist, known facts, index
- 🟡 C2 (0.3.6 version + changelog written; docs sync pending) update What's new (0.3.6) + Russian rows, version 0.3.6 (code 9), zip, workflow `build.yml` path reminder

## D. Added later (still part of 0.3.6 unless moved) — ⬜ unless marked
- ✅ D1 Rewind ON by default
- 🟡 (shader scope this game/console/all done; removing the Settings shader option and moving the collation not done) (shader scope this game/console/all done; removing the Settings shader option and moving the collation not done) D2 Shader choice inside the in-game mini menu ("apply to this console" / "apply to all consoles"); remove the general shader option from Settings (they conflict); move the "controls collation" from the VIDEO tab to the CONTROLS tab
- ⬜ D3 Translate HELP (and Ask a helper) first into ru, uk, de, ja, zh, with more info; translate the tutorial / quick start / What's new into all 12 languages; much more tutorial text
- ✅ D4 Remove every mention of the user's headset model (WI-C100)
- ⬜ D5 Under "Pro mode": list what it currently adds
- ⬜ D6 6-button layouts: a corrected "6 buttons close" and a simple "6 buttons"
- ⬜ D7 Vibration for S3&K (abv./exp.) fixes; make footsteps actually work; OPTIONAL vibration log (what should trigger, when it ends, what happened) readable in LOGS so gameplay tests can drive fixes; advanced Sonic 1 & 2 profiles: explosions, wall/brick breaking (Knuckles/Sonic, Hydrocity cutscene bricks), monitor effects, invincibility sparkle while active, plain shield (feel on appear/break), water/fire/electric shield + break, speed shoes, jump, cutscenes, insta-shield whoosh, multi spin-dash revs; same for Sonic Advance and other consoles' Sonic games
- ⬜ D8 LOCATIONS buttons still off-screen in portrait and cannot be swiped (the 0.3.6 row scroll is untested): re-check
- ⬜ D9 Search for games, video, comics, pictures (not only music), with ignore-case / exact phrase
- ⬜ D10 Patch buttons (IPS/BPS): explain what they do, with a real example and file formats; if useless, write it down for the future
- 🟡 (Sega CD TOOLS + auto-fix done; load/eject disc controls not done) (Sega CD TOOLS + auto-fix done; load/eject disc controls not done) D11 Sega CD module: launch the Sega CD itself with disc controls (load / eject, can be hidden with a switch), a tutorial + tools to format/fix the RAM issue for Sonic CD (Memory Manager), BIOS pick
- ⬜ D12 Library pages: SMS / GG / MD must not appear under Game Boy pages; Game Boy pages: All, Game Boy, Game Boy Color, Game Boy Advance; an ALL CONSOLES page with search and a coloured tag per console/emulator, still able to launch
- 🟡 (NES, SNES, DS done as experimental; N64 not done) (NES, SNES, DS done as experimental; N64 not done) D13 NEW CONSOLES (skip DS): NES, SNES, Game Boy / Color / Advance (already GB/GBA via mGBA), Nintendo 64. Plan: libretro cores fetched at build time like the others: NES = fceumm (GPL) or nestopia, SNES = snes9x (non-commercial licence: note it), GB/GBC = gambatte (GPL), GBA = mgba (MPL), N64 = mupen64plus-next (needs OpenGL, heavy: experimental). Each needs a Systems entry, extension list, input mapping (SNES has 6 face/shoulder buttons: A B X Y L R), a factory touch layout, fetch_core.sh lines, tab chips, a handbook page. Android emulator reference list (for the handbooks): NES: NES.emu, John NESS, RetroArch; SNES: Snes9x EX+, John SNES, RetroArch; GB/GBC/GBA: Pizza Boy, My Boy!, My OldBoy!, RetroArch; DS: DraStic, melonDS (skipped); N64: M64Plus FZ.

## E. Added in the last messages
- ✅ E1 RP answers (who / how / where from + first appearance / hello) for the 9 helpers (English only; translate next). 💬 marks them
- 🟡 E2 Ask-a-helper UI strings translated for ru uk de ja zh (only the few buttons: ASK A HELPER, Ask by, LIST, TYPE, BOTH); the ANSWERS and all HELP topics are still English
- ✅ E3 "S3&K advanced (exp.)" renamed to "advanced (experimental)" + a BASIC vs ADVANCED description under the vibration-profile chooser
- 🟡 E4 Console handbook: only a SHORT HELP topic "Consoles in short". Still wanted: one illustrated page per console (console + controller + TV drawings, cables, how setup worked, region differences, history, competitors, sales, famous games, unique features, usage in this emulator), 3 depth levels, translated to all 12 languages, with a note on vibration support for phones and Bluetooth/USB controllers
- ⬜ E5 MEDIA TRIPLE (Comics / Pictures / Video) quality bar: file-format tag chips (like the gallery filter chips), Kotatsu-style reader (modes, zoom %, tap halves, swipe, long images, bookmarks, history, favourites, per-comic memory, local storage), YouTube-style video player with a library/storage of videos and a "what to watch" picker, a simple gallery photo editor (crop with grid + rotation ruler like the screenshot), a drawings catalogue with project thumbnails (Ibis-style), COPY mode and READ-IN-PLACE mode (default: no caching), search, sort (incl. length for video)

## F. Latest batch (Eggman, notification, books, vibration presets)
- ✅ F1 Eggman name history answers (Eggman vs Robotnik vs Egghead, meanings, first-game look and plan) + 3 more answers for every helper: favourite food, what you like to do/create, where you appeared after your first game (English only; hedged where unofficial: Shadow's coffee joke, pyjamas concept)
- 🟡 F2 Music notification: the line "▶ Playing / ⏸ Paused" is shown and ongoing follows playback (written blind, check on the phone); still wanted: obvious play/pause icon state, cover, seek bar
- ⬜ F3 CONSOLE GUIDE BOOKS: one book per console/emulator, pages you swipe/flip (Minecraft-book UX, manual-style visuals: console + controller + TV drawings, cables, history, competitors, sales, famous games, regional differences, how to set up/use, how it works in this app), switch book easily, ALL 12 languages
- ⬜ F4 Helper background pictures: extra image layer on top of the helper backdrop, behind texts/icons, own transparency slider with reset, applies to all characters, recommended resolution text, must fit inside the messenger-style outline
- ✅🆕 F5 HELP order: QUICK START first, ASK A HELPER second
- ⬜ F6 Vibration: 5 more event sets; 6 preset slots like controls (hollow circle = SAVE into the slot, rounded square = LOAD it; filled/coloured when loaded, counter turns white when selected); RESET sliders (not the preset); built-in "Classic" preset by default (changeable only by on/off switches and strength low/medium/high); CLEAR for presets 1–6

## G. Latest (economical mode: small safe batches)
- ✅ G1 More helper info: name/design origin and first-game story for Sonic, Tails, Knuckles, Amy, Shadow, Metal Sonic, Motobug, Buzz Bomber (hedged "reported" facts; English only, translate next)
- ✅🆕 G2 HELP order: QUICK START first, ASK A HELPER second (code location: HelpUi.kt chip row)
- ⬜ G3 Translate helper answers and HELP topics (ru, uk, de, ja, zh first)
- Work style from now on: small verified batches, checks after each (brackets, quotes, imports), research only when a fact is uncertain, update this file every batch.

## H. Controls UX + interface styles (batch, still 0.3.6) — all ✅ = written, NOT compiled
* ✅ Vibration route: Phone / Controller / Both / Off for menus and for the game, per-game override, controller strength, presets store the route. (`Haptics.kt`, `HapticsUi.kt`)
* ✅ TEST DEVICES: buzzes phone and each controller, shows Android's support info, remembers "I felt it / nothing". Unsupported devices are shown as unsupported (nothing is faked).
* ✅ On-screen buttons light up from a physical controller (not in Classic; switch `padFeedback`, idle look `padFeedbackIdle`). Touch overlay stays non-interactive in this mode.
* ✅ Controller setup (`ControlsUi.kt`): detection of Xbox/DS4/DualSense/Switch/Steam/generic (+ manual choice), diagram with live highlight and current layout, tap-to-assign on the picture, wizard action → press → recognised input → conflicts → optional second action → CONFIRM, per-row unassign/reset.
* ✅ Profiles (`Profiles.kt`): layers GAME → EMULATOR → GLOBAL → factory, sparse per layer, old pad_/kb_/combo_ keys read as GLOBAL base; templates (3 built in + yours: save/copy/rename/apply/delete); RESET LAYER / RESTORE FACTORY with confirm; source tag on every row; in-game menu has the same editor for the current game.
* ✅ New actions: diagonals, next/previous save slot, show/hide screen buttons, vibration on/off (+ existing save/load/menu/turbo/rewind).
* 🔒 Stated limits: two physical buttons as one chord (not supported), touchpad/gyro/lightbar/adaptive triggers/paddles (Android does not expose them for generic pads), exact photos of each model.
* ✅ Interface styles (`UiModes.kt`): NORMAL (unchanged) + MANIA + TILES, ◐ quick switch in the top bar (and bottom hint bar in TILES), hide switch: SETTINGS ▸ SCREEN & LOOK ▸ Interface style; names editable; game screen always keeps the normal skin (`UiMode.inGame`).
* ⬜ Next: compile feedback; translations of the new long texts; Mania/Tiles look for the in-game menu; focus order for controller navigation in TILES.

## I. Beta release prep (version name is now `0.3.6_beta`; the NEXT delivery after the checklist is finished is plain `0.3.6`)
* ✅ Tour (Guide.kt) expanded to 12 pages: richer welcome, language + look chooser page, controllers, vibration, beta thanks. ✅ HELP: new topics Control layers & profiles, Interface styles, About this beta; Controls and Vibration topics rewritten.
* ✅ Tour + HELP translated into all 12 languages (en es fr de pt-BR it ru uk ja zh ko hi tr) via `app/src/main/assets/i18n_long.json` (`LongI18n` in I18n.kt). Key = the exact English string; if you EDIT an English string in Guide.kt / HelpUi.kt that text silently falls back to English until its row in the JSON is updated. Helper answers (AssistantData.kt), What's new and the new settings screens' long texts are still English.
* ✅ What's new for 0.3.6 beta rewritten as NEW / IMPROVED / FIXED with only real changes.
* ⬜ After the user's test of the beta: fix reported bugs, finish remaining checklist items, then ship `0.3.6` (versionName without _beta, versionCode +1).


## J. Batch 3 (pre-release `0.3.6_pre`, code 10): all ✅ = written, NOT compiled, not tried on a phone
* ✅ Classic mode "show controls" (SETTINGS ▸ SCREEN, in-game menu) with own opacity — splits "classic look" from "show controls".
* ✅ Launcher focus ring + `padNav` (A/✕ press, B/○ back) toggles, explained in SETTINGS ▸ CONTROLS ▸ "Launcher with a controller".
* ✅ Vibration strength Low/Normal/High/Max for phone and for controller + fine tuning.
* ✅ Game-card toggles (title / system label / logo); tap on a tile opens a game menu (or plays at once: `tileOpen`).
* ✅ Themes: Normal, Mania, Tiles, Game Jolt, itch, Neon Coast. Explanation "styles vs themes" (Help topic, SETTINGS, CUSTOMIZE note). Theme also inside games (`themeInGame`, default on).
* ✅ Own PNG background / foreground / character per theme (opacity, blur, same-for-all switch). A background replaces the theme's built-in backdrop.
* ✅ Startup intro (picture or video + music + fade) — experimental, off by default (ui/Splash.kt).
* ✅ Three new mini-games with own names: Endless Hills, Sky Spring (tilt optional, hidden without sensor; buttons / drag / D-pad), Lane Sprint. No licensed names.
* ✅ Bugs: ♪ chip (hit area), queue strip duplicates, reorder arrows, picture under status bar in games, Mania landscape, library buttons overlap, contrast.
* ✅ A6 "turn off the player bar inside the player tab"; F5/G2 HELP order.
* ⬜ Translations: staged parts in the scratchpad (`tr2/*_partN.json`) for settings + What's new; merge into `assets/i18n_long.json` in the final build (strings still change).
* ⬜ NOT started in this batch: music/video/comics/photos tabs, recorder, Flash fix, new equalizers, share-to-launcher, per-button function dropdown + emulator labels, new consoles (D13), Sega CD module (D11), library pages (D12), console handbooks, vibration event sets, in-game UI toggles (D2…), UI scale, resolution list.

## K. pre2 / pre3 status (written, NOT compiled, NOT tested on a device)
* ✅ pre2: NES/SNES (experimental), themes Blue Blur / Dark Rival / Meadow Day, layers bg/objects/ground/character/foreground, optional seasonal overlay (off), 24h clock, music notification cover + seek, silent theme change.
* ✅ pre3: Flash fix attempt (URL-encoded rom name, CORS headers, on-page error text, OPEN IN RUFFLE APP via FileProvider, package rs.ruffle unverified), BY BUTTON list in controller setup, CONSOLE MANUALS (9 consoles, English).
* ⬜ Still open: Flash FPS lock / haptics options / keyboard symbols + hide language key; per-console native label preview + A/B swap for GB; rewind-seconds hint; manuals for Flash/OpenBOR + depth levels + illustrations beyond the pad drawing; media tabs (comics, video, pictures, notes, files); open-with chooser; recorder/karaoke; vibration sets (Mario family, footsteps, rings, shields, monitors, explosions preset); Sonic Advance rumble; tutorial last-slide intro offer; translations (all 12 languages) for new strings.

## L. pre4 batch (`0.3.6_pre4`, code 13): 🆕 = new in this batch, 🛠 = fix after the REAL build log of pre3. All written, NOT compiled by me.
* 🛠 L1 Build errors from the pre3 run: GameActivity used `WindowInsets.statusBarsIgnoringVisibility` (experimental layout API) -> `@OptIn(ExperimentalLayoutApi)` on the class. MiniGames called `androidx.compose.foundation.gestures.detectDragGestures(...)` fully qualified (an extension function cannot be called that way) -> import + plain call. Lesson: run `HANDOFF/tools/preflight.py <app/src/main/java>` before every zip (checks missing imports, qualified extension calls, experimental APIs without @OptIn).
* 🆕 L2 MEDIA tab (nav: MEDIA): PICTURES (grid + swipe viewer), COMICS (pages from images, natural sort, modes PAGES/SCROLL, left-to-right or manga right-to-left, remembers the page), VIDEO (copy in, player with controls), NOTES (text editor: new / edit / rename / save / share / import .txt), FILES (browser of the app's own media folder: folders, rename, delete, share / open with), RECORDER (voice recording to .m4a, play, share, delete; BACKING TRACK plays while you record = karaoke-style; the two are NOT mixed into one file; lyrics not done). Copy mode only; "read in place" still not done.
* 🆕 L3 "Open with SonicForge" / Share: pictures, video, audio, text arrive with a "Where should this go?" dialog (comics: new or existing comic / pictures / video / notes / recorder folder / files).
* 🆕 L4 Flash: keyboard backspace and a ?123 / ABC symbols page (punctuation, F1-F8, Home/End/PgUp/PgDn/Del); file name URL-encoded; OPEN IN RUFFLE APP; on-page error text. Still open: FPS lock (Ruffle cannot change a SWF's frame rate, needs research), haptic options, hide-able language key (there is no language key yet).
* 🆕 L5 BY BUTTON list in controller setup; CONSOLE MANUALS (9 consoles, English).
* 🆕 L6 BUILD_REPORT.txt is generated next to the APKs (version, which APK to install, cores, every compile error line, log tail) and the artifact is uploaded even if the build fails.
* 🆕 L7 Android TV: the launcher icon already appears on TV (leanback); touchscreen is optional. Remote navigation = existing focus frame + D-pad; still open: TV-specific layout pass and a test on a real TV. A 32-bit ARM APK exists (armeabi-v7a). x86 / x86_64: planned, not enabled (needs cores for those ABIs from the libretro build bot; kept off to keep the build stable).
* Still open after pre4: vibration sets (Mario family, footsteps, rings, shields, monitors, explosions preset; all need verified RAM addresses), Sonic Advance rumble, A/B swap for GB, rewind-seconds hint, tutorial last-slide intro offer, translations (12 languages) of all new strings, read-in-place media mode, comic CBZ import, video library extras, photo editor, UI scale, resolution list.

## M. pre5 batch (`0.3.6_pre5`, code 14): 🆕 = new, 🛠 = fix after your feedback. Written, NOT compiled by me.
* 🆕 M1 Sega CD TOOLS (game page, scd games): BIOS md5/size report, disc check (cue, track files, SEGADISCSYSTEM tag, region letter), region override (core option), backup RAM files list + delete. New bridge functions `setOption/clearOptions`. Core option names (`genesis_plus_gx_region_detect`, `genesis_plus_gx_bram`) are from memory: unverified.
* 🆕 M2 Layers behind the interface by default, front optional, fit/size/position/offset, APPLY TO ALL, UNDO STEP, GIF animation. (The third layer item in the last message was empty: ask the user.)
* 🆕 M3 Comics: pinch + double-tap zoom, tap edges (28 %) with on/off, manga scroll mode + width zoom, PAGES / ORDER dialog, comic order ▲▼, names Comic N counting up, REPLACE / ADD PAGES / BACK on a name clash, delete confirmation.
* 🆕 M4 Pictures: ZoomBox, rotate, flip, crop by sliders or ratio, save as copy, replace original (confirmed), share, copy, delete (confirmed). FILES ▸ txt ▸ OPEN IN EDITOR. NOTE: the NOTES editor was already directly editable in pre4; the "press edit first" behaviour the user saw was probably another app.
* 🆕 M5 Recorder level bar + waveform. 🆕 M6 Vibration RULES (any game, any console). 
* 🆕 M7 Nintendo DS (experimental): core melonds (fallback desmume2015), `.nds`, tab DS, pointer input in the bridge, DS SCREENS dialog (AUTO / SIDE BY SIDE / TOP-BOTTOM / TOP-BOTTOM + REAL GAP / TABLET). Core option names unverified; cores may not exist for the CPU; no 3DS.
* 🛠 M8 TILES bottom bar: no letter-by-letter wrap, BACK tappable, A/B circles only with a gamepad (or `tilesPadHints`).
* 🆕 M9 Theme art: Game Jolt, itch, Neon Coast (grid + stars), Dark Rival, Meadow Day (bricks, pipes, plant, hills with eyes, ? blocks, coins); button shapes per theme.
* 🛠 M10 Flash autoplay on + status line. Still unconfirmed on a phone.
* ⬜ After pre5: TV remote pass, x86, translations, Sonic RAM vibration events, GIF in every image picker (layers, covers via AnyPicture only; thumbnails still static), tablet layouts for the whole app.

## N. pre6 (`0.3.6_pre6`, code 15) 🆕 written, NOT compiled
* 🆕 N1 Rewind length 4/8/12/20 s (`rewindSec`; the old hint "4 seconds" was wrong, the code kept ~12 s). 🆕 N2 A/B swap (`abSwap`) for GB/GBA/NES/SNES/DS on-screen buttons (a hardware pad may bypass it: unverified). ⬜ Next: tutorial last-slide intro offer, in-game pause menu in Mania/Tiles, Flash FPS lock.

## O. pre7 (`0.3.6_pre7`, code 16) 🆕 written, NOT compiled
* 🛠 O1 Compile error fixed (nativeCanvas import, UiModes). 🛠 O2 DS out-of-memory crash (log: OutOfMemoryError at EmuSession rewind, 6.5 MB per state): rewind capped at 64 MB, off for DS. 🛠 O3 Music notification stuck on pause: MainActivity.onResume replaced `Music.onChange`; now also refreshes the service.
* 🆕 O4 Sound-driven haptics for every console (`AudioHaptics`, modes off/auto/always, sensitivity). Heuristic, cannot know what happened. 🆕 O5 Sega CD auto-fix + automatic region from disc. 🆕 O6 Live (Visualizer) equalizer in MUSIC and in the recorder preview, toggles. 🆕 O7 MEDIA favourites, sorting, date captions.
* 🆕 O8 Game screen: aspect swap, 8 extra ratios, system-bars chips, PAUSE button, shader scope. 🆕 O9 UI scale with 8 s confirm. 🆕 O10 Per-category cache clearing + free space. (D2 partly: shader scope done; the in-menu "remove general shader option" not done.)
* ⬜ Still open from this list: D12 library pages for GB (All/GB/GBC/GBA) and an ALL CONSOLES page, What's new split into Added/Fixed/Improved, D-pad lights only pressed directions, T indicator hollow square, separate alpha for symbols, search bars (games, music), music sort by length, vibration preset slots and logs, picture preset slots, helper background image, controller pictures per model, console handbooks/books, translations, TV, x86.

## P. pre8
- 🆕 Manuals redesigned (console art, callouts, SPECS, coloured bars, DS manual). Written, not compiled.
- 🆕 Library: ALL CONSOLES tab + search; Music: search, sort by length; counters colours + explanation.
- ⬜ Still open: GG rewind colours, D-pad lights, T indicator, alpha split, picture presets, vibration presets, tempo, per-search in video/comics/pictures.
- 🆕 Symbol transparency: linked to buttons by default (symLink) or separate slider (symAlpha), in game settings and Settings > touch opacity.
