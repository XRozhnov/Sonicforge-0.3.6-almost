# SonicForge: documents index (read in this order)
1. `00_INDEX.md` (this file); `10_NEW_CHAT_START_HERE.md` is the one-file briefing for a new chat
2. `09_KNOWN_FACTS.md`: facts, gotchas and environment (what is verified, what is not)
3. `08_CHECKLIST_0.3.6.md`: the CURRENT update checklist (separate from older ones). Tick things here first.
4. `07_BIG_PROMPT_FOR_NEW_CHAT.md`: the big hand-over prompt (paste it into a new chat together with SonicForge.zip). Section "REQUESTS SINCE 0.3.5" = the 0.3.6 asks in full wording.
5. `12_MASTER_BACKLOG_ALL_UNFINISHED_FROM_THE_START.md`: EVERY unfinished request since the first message (includes asks that were never in a version checklist, e.g. the voice recorder); `11_CHECKLIST_UP_TO_0.3.5.md`: the separate archive checklist for everything before 0.3.6; `03_CHECKLIST.md`: older cumulative notes
6. `01_PROJECT_CONTEXT.md`, `02_USER_REQUESTS_FULL_LOG.md`, `04_FILE_MAP_AND_ARCHITECTURE.md`, `05_RESEARCH_NOTES_VERIFIED_FACTS.md`, `06_KNOWN_ISSUES_AND_NEXT_STEPS.md`: early hand-over set (still valid, older)
7. `docs/NOT_ADDED_YET.md`, `docs/FUTURE_REFERENCES.md`, `docs/BUILD_GUIDE.md`, `docs/build-from-zip.yml` (the workflow: copy to repo root `.github/workflows/build.yml`)
8. `status.json`: machine-readable summary

Rules of the house: update ALL of these when you finish a batch; never claim "works" for code that was not compiled; every user-visible change also goes into the in-app What's new (Changelog in AboutUi.kt), the guide/help, and translations (RAW rows in I18n.kt).
