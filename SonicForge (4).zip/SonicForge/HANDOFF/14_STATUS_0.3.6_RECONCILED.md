# 0.3.6 STATUS, RECONCILED (2026-11-21, build line `0.3.6_pre7`, code 16)
Honest note: ✅ below means CODE WRITTEN. Nothing from pre2 to pre7 has been compiled by me, and the user has run no pre5+ build yet (the pre5 build failed on a missing import, fixed in pre7). Only 0.3.3/0.3.4/0.3.5-era features were ever confirmed on a phone. 🟡 = partly. ⬜ = not done. 🔒 = out of reach.

## DONE (code written)
Fixes: A1 A3 A4 A5 A8 A9 D1 D4 · DS rewind out-of-memory · music notification stuck on pause · pre3 build errors · pre5 build error (nativeCanvas).
Game screen: Classic "show controls" · UI scale with 8 s confirm · swap sides + 8 ratios + system-bars switch · optional PAUSE button · shader for game/console/all · A/B swap (Nintendo) · rewind length 4-20 s + memory cap.
Music: ♥ favourites, queue stays open, mini-player rules (A6), headphone-unplug pause, notification with cover/seek/state, REAL-TIME equalizer, hide player bar in tab.
Look: themes Mania, Tiles, Game Jolt, itch, Neon Coast, Blue Blur, Dark Rival, Meadow Day (all with art + button shapes) · layers behind the interface by default, fit/size/position, APPLY TO ALL, UNDO · GIF in layers/backgrounds (Android 9+) · seasonal overlay · intro splash · 24 h clock.
Controls: controller setup, BY BUTTON list, layered profiles, vibration route/strength, pad lights on-screen buttons, controller focus ring (launcher).
Consoles: NES, SNES, Nintendo DS (experimental: 3 arrangements + AUTO + TABLET + touch).
Media: pictures (zoom, rotate, crop, copy), comics (zoom, tap edges, manga/scroll, reorder, counting names, replace warning), video, notes, files, recorder (level display, backing track, live preview), favourites, sorting, dates, share-to-launcher.
Vibration: sound-driven haptics for any game · RAM rules for any game · Sega CD auto-fix · cache clearing + free space.
Help: manuals (9 consoles, English), helper answers, tutorial + HELP in 12 languages, HELP order (F5/G2).

## PARTIAL
A2 (⌖ jump icon in queue) · A7 (English "Languages" line to check) · A10 (SMS/GG layout vs real pad) · A12 Flash (open-in-Ruffle, keyboard, status line done; FPS lock + haptics options + hide language key not; black screen still unconfirmed) · D2 · D11 · D13 (no N64) · E2/E4 (helper answers and console handbook not translated/illustrated) · F2 · What's new split (labels only) · media READ-IN-PLACE · scene creator/karaoke · storage charts.

## NOT DONE
Game screen: A11 Game Gear rewind colour bug · D-pad lights only pressed directions · T indicator hollow square + hide setting · separate alpha for controls and symbols · EMU/SCREEN counter colours · dead-zone map always show · auto-rotate with confirm icon · hide-mini-menu option · tilt options (glitch-only, ignore vibration, per-console) · rewind per save point · Classic mini-panel switches.
Music: search bar · sort by length · ⌖ jump icon · tempo/speed · use original files in place · same-name import confirm · custom-image equalizer.
Look: more varied skins (leaves, Horror Hills, Angel Island...) · picture preset slots (9 per category) · effect FPS + presets · particles fade · controller pictures per model with bumpers/triggers · helper background picture (F4) · click-to-play GIF on buttons.
Content: console guide BOOKS (F3/E4) with 3 depth levels · Flash/OpenBOR manuals · Pro-mode list (D5) · 6-button layout fixes (D6) · IPS/BPS explanation with example (D10) · search in games/video/comics/pictures (D9) · library pages GB/GBC/GBA + ALL CONSOLES (D12) · add-game category sheet · more guide slides.
Vibration: S3&K fixes + footsteps + optional vibration log (D7) · 6 preset slots + 5 more event sets (F6) · exact cutscene/hazard events.
Everything else: translations of all new texts (do last) · D8 re-check LOCATIONS in portrait · D3/G3 translate helper answers + HELP.
🔒 / deferred on purpose: Android TV remote pass + real TV test · x86/x86_64 builds · Nintendo 3DS, N64 · touchpad/gyro/lightbar/adaptive triggers.

## Suggested order for the next batches
1) Verify pre7 on a phone (compile, Flash, DS, Sega CD). 2) Cheap UI items: D12 library pages, What's new grouping, D-pad lights, T indicator, alpha split, counters, search bars, sort by length. 3) Presets (F6 vibration slots, picture slots). 4) Big: console books, controller pictures, READ IN PLACE. 5) Translations. 6) TV / x86.
