package com.sonicforge.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.view.KeyEvent
import com.sonicforge.core.Systems
import com.sonicforge.data.Library
import com.sonicforge.data.SaveEvent
import com.sonicforge.data.Store
import com.sonicforge.input.Act
import com.sonicforge.input.Layer
import com.sonicforge.input.PadStyle
import com.sonicforge.input.Pads
import com.sonicforge.input.Profiles
import com.sonicforge.input.Template

private data class Slot(val code: Int, val x: Float, val y: Float, val kind: Int)   // kind: 0 round, 1 shoulder pill, 2 small pill, 3 stick
private val SLOTS = listOf(
    Slot(KeyEvent.KEYCODE_BUTTON_L2, .17f, .07f, 1), Slot(KeyEvent.KEYCODE_BUTTON_L1, .17f, .21f, 1),
    Slot(KeyEvent.KEYCODE_BUTTON_R2, .83f, .07f, 1), Slot(KeyEvent.KEYCODE_BUTTON_R1, .83f, .21f, 1),
    Slot(KeyEvent.KEYCODE_DPAD_UP, .24f, .36f, 0), Slot(KeyEvent.KEYCODE_DPAD_DOWN, .24f, .62f, 0),
    Slot(KeyEvent.KEYCODE_DPAD_LEFT, .15f, .49f, 0), Slot(KeyEvent.KEYCODE_DPAD_RIGHT, .33f, .49f, 0),
    Slot(KeyEvent.KEYCODE_BUTTON_Y, .80f, .35f, 0), Slot(KeyEvent.KEYCODE_BUTTON_A, .80f, .63f, 0),
    Slot(KeyEvent.KEYCODE_BUTTON_X, .72f, .49f, 0), Slot(KeyEvent.KEYCODE_BUTTON_B, .88f, .49f, 0),
    Slot(KeyEvent.KEYCODE_BUTTON_SELECT, .42f, .38f, 2), Slot(KeyEvent.KEYCODE_BUTTON_START, .58f, .38f, 2), Slot(KeyEvent.KEYCODE_BUTTON_MODE, .50f, .52f, 2),
    Slot(KeyEvent.KEYCODE_BUTTON_THUMBL, .38f, .75f, 3), Slot(KeyEvent.KEYCODE_BUTTON_THUMBR, .62f, .75f, 3))

private val MOVE = listOf(Act.UP, Act.DOWN, Act.LEFT, Act.RIGHT, Act.UPRIGHT, Act.UPLEFT, Act.DOWNRIGHT, Act.DOWNLEFT)
private val BUTTONS = listOf(Act.A, Act.B, Act.C, Act.X, Act.Y, Act.Z, Act.L, Act.R, Act.START, Act.MODE)
private val FUNCS = listOf(Act.SAVE, Act.LOAD, Act.MENU, Act.TURBO, Act.REWIND, Act.SLOTNEXT, Act.SLOTPREV, Act.UITOGGLE, Act.VIBTOGGLE)

private fun layerColor(id: String): Color = when {
    id.isEmpty() -> Color(0xFF9E9E9E); id == Profiles.GLOBAL -> Color(0xFF81C784); id.startsWith("e:") -> Color(0xFF4FC3F7); id.startsWith("r:") -> Color(0xFFFF8A65); else -> Color(0xFFBA68C8)
}

/** The controller picture: every button shows its real name for the detected family, what it does now, a live highlight while pressed, and can be tapped to re-assign. */
@Composable
private fun PadDiagram(style: PadStyle, bind: Map<Int, String>, held: Set<Int>, sel: Int, onTap: (Int) -> Unit) {
    val skin = Skins.current(); var sz by remember { mutableStateOf(IntSize.Zero) }
    val tap by rememberUpdatedState(onTap)
    Canvas(Modifier.fillMaxWidth().aspectRatio(1.75f).clip(RoundedCornerShape(16.dp)).background(Color(0xFF1B252C)).onSizeChanged { sz = it }
        .pointerInput(Unit) { detectTapGestures { p ->
            var best = -1; var bd = Float.MAX_VALUE
            for (s in SLOTS) { val dx = p.x - s.x * sz.width; val dy = p.y - s.y * sz.height; val d = dx * dx + dy * dy; if (d < bd) { bd = d; best = s.code } }
            val lim = sz.width * .09f; if (best != -1 && bd < lim * lim) tap(best) } }) {
        val w = size.width; val h = size.height; val u = w / 100f
        val body = Color(0xFF2B3A45)
        drawRoundRect(body, Offset(w * .07f, h * .16f), Size(w * .86f, h * .56f), CornerRadius(h * .2f))
        drawCircle(body, h * .21f, Offset(w * .2f, h * .74f)); drawCircle(body, h * .21f, Offset(w * .8f, h * .74f))
        val pl = android.graphics.Paint().apply { color = android.graphics.Color.WHITE; textAlign = android.graphics.Paint.Align.CENTER; isFakeBoldText = true; isAntiAlias = true; textSize = u * 2.7f }
        val pa = android.graphics.Paint().apply { color = android.graphics.Color.rgb(255, 213, 79); textAlign = android.graphics.Paint.Align.CENTER; isFakeBoldText = true; isAntiAlias = true; textSize = u * 2.2f }
        for (s in SLOTS) {
            val c = Offset(s.x * w, s.y * h); val isHeld = s.code in held; val isSel = s.code == sel; val act = bind[s.code]
            val fill = if (isHeld) skin.accent else if (act != null) Color(0xFF47657A) else Color(0xFF33424D)
            val line = if (isSel) Color.White else Color(0xCCFFFFFF)
            val st = Stroke(if (isSel) 5f else 2f)
            var ar = h * .07f
            when (s.kind) {
                1 -> { val tl = Offset(c.x - w * .07f, c.y - h * .045f); val sd = Size(w * .14f, h * .09f); drawRoundRect(fill, tl, sd, CornerRadius(h * .04f)); drawRoundRect(line, tl, sd, CornerRadius(h * .04f), style = st); ar = h * .045f }
                2 -> { val tl = Offset(c.x - w * .035f, c.y - h * .03f); val sd = Size(w * .07f, h * .06f); drawRoundRect(fill, tl, sd, CornerRadius(h * .03f)); drawRoundRect(line, tl, sd, CornerRadius(h * .03f), style = st); ar = h * .03f }
                3 -> { drawCircle(fill, h * .1f, c); drawCircle(line, h * .1f, c, style = st); ar = h * .1f }
                else -> { drawCircle(fill, h * .065f, c); drawCircle(line, h * .065f, c, style = st) }
            }
            val nc = drawContext.canvas.nativeCanvas
            pl.color = if (isHeld) android.graphics.Color.BLACK else android.graphics.Color.WHITE
            val name = Profiles.btnLabel(style, s.code); pl.textSize = if (name.length > 4) u * 1.9f else u * 2.7f
            nc.drawText(name, c.x, c.y + pl.textSize * .35f, pl)
            if (act != null) {
                if (s.kind == 1) { pa.textAlign = if (s.x < .5f) android.graphics.Paint.Align.RIGHT else android.graphics.Paint.Align.LEFT; nc.drawText(act, c.x + (if (s.x < .5f) -w * .08f else w * .08f), c.y + pa.textSize * .35f, pa) }
                else { pa.textAlign = android.graphics.Paint.Align.CENTER; nc.drawText(act, c.x, c.y + ar + pa.textSize * 1.05f, pa) }
            }
        }
    }
}

@Composable private fun Tag(id: String) {
    Text(Profiles.layerLabel(id).uppercase(), color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(layerColor(id)).padding(horizontal = 5.dp, vertical = 1.dp))
}

private class Cap(val code: Int, val device: String, val scan: Int, val fromPad: Boolean, val viaDiagram: Boolean)

/**
 * SETTINGS ▸ CONTROLS (also inside the in-game menu). One screen: detected controller, picture with the current layout, step-by-step re-binding,
 * the three priority layers (Game → Emulator → Global → Factory), named profiles, resets and vibration support.
 */
@Composable
fun ControllerSetup(game: com.sonicforge.data.Rom? = null) {
    val skin = Skins.current(); val confirm = rememberConfirm()
    @Suppress("UNUSED_VARIABLE") val tick = Profiles.tick
    var scope by remember { mutableStateOf(if (game != null) "r" else "g") }
    var emuSel by remember { mutableStateOf(game?.sys ?: "md") }
    var romSel by remember { mutableStateOf(game?.id ?: Library.roms.firstOrNull()?.id ?: "") }
    var tplSel by remember { mutableStateOf(Profiles.custom().firstOrNull()?.id ?: "") }
    var kb by remember { mutableStateOf(false) }
    var target by remember { mutableStateOf<Act?>(null) }
    var cap by remember { mutableStateOf<Cap?>(null) }
    var comboSel by remember { mutableStateOf<Act?>(null) }
    var unbindOthers by remember { mutableStateOf(true) }
    var hint by remember { mutableStateOf("") }
    var slotSel by remember { mutableIntStateOf(-1) }
    var renameId by remember { mutableStateOf("") }; var renameText by remember { mutableStateOf("") }
    DisposableEffect(Unit) { onDispose { Pads.captureEv = null } }

    val romObj = Library.roms.firstOrNull { it.id == romSel }
    val layerId = when (scope) { "e" -> Profiles.emuLayer(emuSel); "r" -> Profiles.gameLayer(romSel); "n" -> Profiles.tplLayer(tplSel); else -> Profiles.GLOBAL }
    val chain = when (scope) { "e" -> Profiles.chainFor(emuSel, ""); "r" -> Profiles.chainFor(romObj?.sys ?: "md", romSel); "n" -> listOf(layerId); else -> listOf(Profiles.GLOBAL) }
    val scopeOk = when (scope) { "r" -> romSel.isNotEmpty(); "n" -> tplSel.isNotEmpty(); else -> true }
    val dev = Pads.devices.firstOrNull()
    val styleSel = Store.s("padStyle", "auto")
    val style = if (styleSel == "auto") (dev?.style ?: PadStyle.GENERIC) else (try { PadStyle.valueOf(styleSel) } catch (_: Exception) { PadStyle.GENERIC })
    val held = Pads.held.toSet()

    fun cancel() { target = null; cap = null; hint = ""; Pads.captureEv = null }
    fun begin(a: Act) {
        cap = null; target = a; hint = ""; comboSel = Profiles.comboOf(a, chain)
        Pads.captureEv = { e ->
            if (!kb && !Profiles.isGamepad(e)) hint = "That press did not come from a gamepad (keyboard / touch ignored). Press a controller button."
            else { cap = Cap(e.keyCode, e.device?.name ?: "unknown device", e.scanCode, Profiles.isGamepad(e), false); hint = ""; Pads.captureEv = null }
        }
    }
    fun commit() {
        val a = target ?: return; val c = cap ?: return
        val l = Profiles.layer(layerId).copyOf(); val m = if (kb) l.kb else l.pad
        if (unbindOthers) Profiles.conflicts(c.code, kb, chain, a).forEach { m[it.name] = 0 }
        m[a.name] = c.code
        if (comboSel != Profiles.comboOf(a, chain)) l.combo[a.name] = comboSel?.name ?: "NONE"
        Profiles.save(layerId, l); Store.events.tryEmit(SaveEvent("Controls saved (" + Profiles.layerLabel(layerId) + ")", true)); cancel()
    }

    confirm.Host()
    H("Controller")
    if (Pads.devices.isEmpty()) Text("No controller detected. Connect one by USB or Bluetooth. Until then the picture shows a generic pad; pick the family below to preview its button names.", color = Color(0xCCFFFFFF), fontSize = 12.sp)
    Pads.devices.forEach { p ->
        Column(Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(10.dp)).background(Color.Black.copy(.35f)).padding(8.dp)) {
            Text("🎮 ${p.name}", color = Color.White, fontWeight = FontWeight.Bold)
            Text("Detected as ${p.style.label} · id ${p.id} · vendor 0x${p.vendor.toString(16)} product 0x${p.product.toString(16)}", color = Color(0xE6FFFFFF), fontSize = 11.sp)
            Text(if (!p.rumble) "Vibration: Android reports NO rumble for this controller" else "Vibration: supported" + (if (p.amplitude) " (adjustable strength)" else " (on/off only)") + if (p.motors > 1) ", ${p.motors} motors" else "",
                color = if (p.rumble) Color(0xFF69F0AE) else Color(0xFFFFAB91), fontSize = 11.sp)
        }
    }
    SChips("Controller family (names on the picture)", "padStyle", "auto", listOf("auto" to "AUTO" + (if (styleSel == "auto") " (" + style.label + ")" else ""), "XBOX" to "Xbox", "PS4" to "DualShock 4", "PS5" to "DualSense", "SWITCH" to "Switch Pro", "STEAM" to "Steam", "GENERIC" to "Generic"))
    Text("Detection reads the device name and USB vendor id, so it can be wrong for clones: just choose the family yourself.", color = Color(0xE6FFFFFF), fontSize = 11.sp)

    H("What am I editing?")
    Text("Priority: GAME → EMULATOR → GLOBAL → factory. A higher layer only overrides the buttons you changed in it; everything else is inherited. Editing one layer never changes another.", color = Color(0xCCFFFFFF), fontSize = 11.sp)
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Btn("GLOBAL", selected = scope == "g", color = layerColor(Profiles.GLOBAL)) { scope = "g"; cancel() }
        Btn("EMULATOR", selected = scope == "e", color = layerColor("e:")) { scope = "e"; cancel() }
        Btn("GAME", selected = scope == "r", color = layerColor("r:")) { scope = "r"; cancel() }
        Btn("MY PROFILE", selected = scope == "n", color = layerColor("n:")) { scope = "n"; cancel() }
    }
    when (scope) {
        "g" -> Text("GLOBAL: one layout for every game that has no emulator or game layer of its own.", color = Color(0xE6FFFFFF), fontSize = 11.sp)
        "e" -> {
            Text("EMULATOR: a layout for one system (for example only Game Boy, or only Mega Drive).", color = Color(0xE6FFFFFF), fontSize = 11.sp)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Systems.all.filter { it.id != "bor" && it.id != "flash" }.forEach { s -> Btn(s.label + if (Profiles.layer(Profiles.emuLayer(s.id)).isEmpty()) "" else " ●", selected = emuSel == s.id) { emuSel = s.id; cancel() } } }
        }
        "r" -> {
            Text("GAME: a layout only for this game; it overrides the emulator and global layers.", color = Color(0xE6FFFFFF), fontSize = 11.sp)
            if (game == null) { if (Library.roms.isEmpty()) Text("No games yet.", color = Color.White, fontSize = 12.sp) else
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Library.roms.forEach { r -> Btn(r.title + if (Profiles.layer(Profiles.gameLayer(r.id)).isEmpty()) "" else " ●", selected = romSel == r.id) { romSel = r.id; cancel() } } } }
            else Text("Game: ${game.title}", color = Color.White, fontWeight = FontWeight.Bold)
        }
        else -> {
            Text("MY PROFILE: edit one of your saved profiles. It changes nothing in a game until you APPLY it to a layer (see PROFILES below).", color = Color(0xE6FFFFFF), fontSize = 11.sp)
            val cs = Profiles.custom()
            if (cs.isEmpty()) Text("You have no profiles yet. Use PROFILES ▸ SAVE THIS LAYER AS A NEW PROFILE.", color = Color(0xFFFFCC80), fontSize = 12.sp)
            else Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) { cs.forEach { t -> Btn(t.name, selected = tplSel == t.id) { tplSel = t.id; cancel() } } }
        }
    }
    if (scopeOk) {
        // which layer decides what, shown as a chain with the number of buttons each layer changes
        val parts = chain.map { id -> val l = Profiles.layer(id); val n = if (id == Profiles.GLOBAL) Act.values().count { Store.settings["pad_" + it.name]?.toIntOrNull() != null } + l.pad.size + l.kb.size else l.pad.size + l.kb.size
            Profiles.layerLabel(id) + " (" + (if (n == 0) "no changes" else "$n changed") + ")" }
        Text("Active order here: " + parts.joinToString(" → ") + " → Factory", color = skin.accent, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
        Text("Editing now: " + Profiles.layerLabel(layerId).uppercase() + when (scope) { "e" -> " · " + Systems.byId(emuSel).label; "r" -> " · " + (romObj?.title ?: ""); "n" -> " · " + (Profiles.custom().firstOrNull { it.id == tplSel }?.name ?: ""); else -> "" },
            color = layerColor(layerId), fontWeight = FontWeight.Bold, fontSize = 13.sp)
        if (!kb) ByButtonList(layerId, chain, style, Systems.byId(if (scope == "r") (romObj?.sys ?: "md") else emuSel).label)

        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Btn("GAMEPAD", selected = !kb) { kb = false; cancel() }; Btn("KEYBOARD", selected = kb) { kb = true; cancel() } }
        SToggle(if (kb) "Keyboard control enabled" else "Gamepad control enabled", if (kb) "kbOn" else "padOn", true, "Turning this off never touches your layers or the touch layout.")

        // current layout, drawn on the controller
        val bind = HashMap<Int, String>()
        Act.values().forEach { a -> val c = Profiles.code(a, false, chain); if (c != 0) bind[c] = ((bind[c]?.let { "$it+" } ?: "") + Profiles.actShort(a)).let { t -> if (t.length > 14) t.take(13) + "…" else t } }
        if (!kb) {
            H("Your layout on the controller")
            Text("Tap a button on the picture to see what it does and give it another action. Pressing a real button lights it up.", color = Color(0xE6FFFFFF), fontSize = 11.sp)
            PadDiagram(style, bind, held, cap?.code ?: slotSel) { slotSel = if (slotSel == it) -1 else it; if (target != null && cap != null) cap = Cap(it, "picture", 0, true, true) }
            if (slotSel != -1) {
                val doing = Act.values().filter { Profiles.code(it, false, chain) == slotSel }
                Column(Modifier.fillMaxWidth().padding(vertical = 6.dp).clip(RoundedCornerShape(10.dp)).background(Color.Black.copy(.35f)).padding(8.dp)) {
                    Text("${Profiles.btnLabel(style, slotSel)}  (Android: ${Profiles.codeName(slotSel)}, code $slotSel)", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("Does now: " + (if (doing.isEmpty()) "nothing" else doing.joinToString(", ") { it.label }), color = Color(0xCCFFFFFF), fontSize = 12.sp)
                    Text("Give this button an action:", color = skin.accent, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        (MOVE + BUTTONS + FUNCS).forEach { a -> Btn(Profiles.actShort(a)) { target = a; cap = Cap(slotSel, "picture", 0, true, true); comboSel = Profiles.comboOf(a, chain); hint = "" } } }
                }
            }
        }

        // step-by-step wizard
        target?.let { a ->
            val c = cap
            Column(Modifier.fillMaxWidth().padding(vertical = 6.dp).clip(RoundedCornerShape(12.dp)).background(skin.accent.copy(.16f)).border(2.dp, skin.accent, RoundedCornerShape(12.dp)).padding(10.dp)) {
                Text("RE-BIND", color = skin.accent, fontWeight = FontWeight.Black, fontSize = 12.sp, letterSpacing = 2.sp)
                Text("① Action: ${a.label}", color = Color.White, fontWeight = FontWeight.Bold)
                if (c == null) {
                    Text("② Press the " + (if (kb) "key" else "controller button") + " now…", color = Color.White, modifier = Modifier.padding(top = 4.dp))
                    if (hint.isNotEmpty()) Text(hint, color = Color(0xFFFFAB91), fontSize = 11.sp)
                    Text("Nothing changes until you confirm in step ④.", color = Color(0xE6FFFFFF), fontSize = 11.sp)
                    Btn("CANCEL", Modifier.padding(top = 6.dp)) { cancel() }
                } else {
                    Text("② Recognised: " + (if (kb) Profiles.codeName(c.code) else Profiles.btnLabel(style, c.code)) + "   (Android name ${Profiles.codeName(c.code)}, code ${c.code}" + (if (c.scan != 0) ", scan ${c.scan}" else "") + ")", color = Color.White, modifier = Modifier.padding(top = 4.dp))
                    Text(if (c.viaDiagram) "Chosen on the picture." else "From: ${c.device}" + if (!c.fromPad && !kb) " (not a gamepad)" else "", color = Color(0xE6FFFFFF), fontSize = 11.sp)
                    val clash = Profiles.conflicts(c.code, kb, chain, a)
                    if (clash.isNotEmpty()) {
                        Text("⚠ Already used by: " + clash.joinToString(", ") { it.label }, color = Color(0xFFFFCC80), fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Btn("UNBIND THE OTHER", selected = unbindOthers) { unbindOthers = true }; Btn("KEEP BOTH", selected = !unbindOthers) { unbindOthers = false } }
                    }
                    Text("③ Also press together with (optional):", color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        Btn("none", selected = comboSel == null) { comboSel = null }
                        (MOVE.take(4) + BUTTONS.take(8)).filter { it != a }.forEach { x -> Btn("+ " + Profiles.actShort(x), selected = comboSel == x) { comboSel = x } } }
                    Text("④ Confirm to save it in the " + Profiles.layerLabel(layerId).uppercase() + " layer.", color = Color.White, modifier = Modifier.padding(top = 6.dp))
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Btn("✔ CONFIRM", selected = true) { commit() }
                        if (!c.viaDiagram) Btn("PRESS AGAIN") { begin(a) }
                        Btn("CANCEL") { cancel() } }
                }
            }
        }

        // action list
        @Composable fun row(a: Act) {
            val (code, src) = Profiles.resolve(a, kb, chain)
            val own = (if (kb) Profiles.layer(layerId).kb else Profiles.layer(layerId).pad).containsKey(a.name) || (layerId == Profiles.GLOBAL && Store.settings[(if (kb) "kb_" else "pad_") + a.name]?.toIntOrNull() != null)
            val cmb = Profiles.comboOf(a, chain)
            Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(a.label, color = Color.White, fontSize = 13.sp)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text((if (code == 0) "not assigned" else if (kb) Profiles.codeName(code) else Profiles.btnLabel(style, code)) + (if (cmb != null) "  + " + Profiles.actShort(cmb) else ""), color = if (code == 0) Color(0xCCFFFFFF) else skin.accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Tag(src) }
                }
                Btn("REBIND", selected = target == a) { slotSel = -1; begin(a) }
                Spacer(Modifier.width(4.dp)); Btn("∅") { val l = Profiles.layer(layerId).copyOf(); (if (kb) l.kb else l.pad)[a.name] = 0; Profiles.save(layerId, l) }
                if (own) { Spacer(Modifier.width(4.dp)); Btn("↺") { Profiles.resetAction(layerId, a, kb) } }
            }
        }
        H("Move"); MOVE.forEach { row(it) }
        Text("Diagonals are two directions at once. Handy for a button that should walk up-right, for example.", color = Color(0xE6FFFFFF), fontSize = 11.sp)
        H("Buttons"); BUTTONS.forEach { row(it) }
        H("Emulator functions"); FUNCS.forEach { row(it) }
        Text("∅ = unassign here (hides the inherited button).  ↺ = remove this layer's change so the layer below decides again.  The coloured tag tells which layer the button comes from.", color = Color(0xE6FFFFFF), fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))

        H("Resets")
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Btn("RESET THIS LAYER", color = Color(0xFFFFA726)) { confirm.ask("Reset the " + Profiles.layerLabel(layerId) + " layer?", "remove every change in this one layer, so the layers below decide again", "touch your other layers, your saved profiles or your touch layout") { Profiles.resetLayer(layerId); cancel() } }
            Btn("RESTORE FACTORY (ALL LAYERS)", color = Color(0xFFE53935)) { confirm.ask("Restore factory controls?", "clear the Global layer and every emulator and game layer", "delete your saved profiles or change the touch layout", force = true) {
                Profiles.restoreFactory(Library.roms.map { it.id }, Systems.all.map { it.id }); cancel() } }
        }
    } else Text("Pick something above to edit.", color = Color(0xFFFFCC80))

    H("Profiles (templates)")
    Text("A profile is a saved set of buttons. APPLY copies it into the layer you are editing (only the buttons it defines). Your profiles can be edited under MY PROFILE.", color = Color(0xCCFFFFFF), fontSize = 11.sp)
    (Profiles.builtins + Profiles.custom()).forEach { t ->
        Column(Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(10.dp)).background(Color.Black.copy(.3f)).padding(8.dp)) {
            Text(t.name + if (t.builtin) "  (built in)" else "", color = Color.White, fontWeight = FontWeight.Bold)
            Text(t.info, color = Color(0xE6FFFFFF), fontSize = 11.sp)
            if (renameId == t.id) Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(renameText, { renameText = it.take(24) }, singleLine = true, modifier = Modifier.weight(1f))
                Spacer(Modifier.width(6.dp)); Btn("SAVE") { Profiles.renameTemplate(t.id, renameText); renameId = "" } }
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                if (scopeOk && !(scope == "n" && layerId == Profiles.tplLayer(t.id))) Btn("APPLY TO " + Profiles.layerLabel(layerId).uppercase()) {
                    confirm.ask("Apply \"${t.name}\"?", "copy this profile's buttons into the " + Profiles.layerLabel(layerId) + " layer", "change any other layer") { Profiles.applyTemplate(t, layerId); Store.events.tryEmit(SaveEvent("Profile applied", true)) } }
                if (!t.builtin) {
                    Btn("EDIT") { scope = "n"; tplSel = t.id; cancel() }
                    Btn("COPY") { Profiles.createTemplate(t.name + " copy", Profiles.templateLayer(t)) }
                    Btn("RENAME") { renameId = t.id; renameText = t.name }
                    Btn("DELETE", color = Color(0xFFE53935)) { confirm.ask("Delete \"${t.name}\"?", "remove this saved profile", "change any layer that already used it") { Profiles.deleteTemplate(t.id); if (tplSel == t.id) tplSel = "" } }
                }
            }
        }
    }
    if (scopeOk) Btn("SAVE THIS LAYER AS A NEW PROFILE", Modifier.padding(top = 4.dp)) {
        val l = Layer(); Act.values().forEach { a -> val (c, s) = Profiles.resolve(a, false, chain); if (s.isNotEmpty()) l.pad[a.name] = c; val (k, ks) = Profiles.resolve(a, true, chain); if (ks.isNotEmpty()) l.kb[a.name] = k
            Profiles.comboOf(a, chain)?.let { l.combo[a.name] = it.name } }
        val t = Profiles.createTemplate("My profile " + (Profiles.custom().size + 1), l); tplSel = t.id; Store.events.tryEmit(SaveEvent("Profile saved: " + t.name, true)) }

    H("Controller options")
    if (!kb) SSlider("Analog stick dead-zone", "padDead", 35)
    SToggle("Hide touch controls while a controller is connected", "hideTouch", true, "Off = the touch buttons stay and can be used together with the controller.")
    SToggle("Show controller presses on the screen buttons", "padFeedback", true, "While a controller hides the touch controls, the on-screen buttons stay drawn and light up when you press the real ones. Not shown in Classic mode.")
    H("Launcher with a controller")
    SToggle("Highlight the selected item", "focusRing", true, "A white frame shows which button or card the controller is on in the launcher. Turn off if you do not want the frame.")
    SToggle("A / ✕ presses, B / ○ goes back", "padNav", true, "Lets a gamepad press the highlighted item and go back in the launcher menus.")
    SToggle("Keep idle screen buttons faintly visible", "padFeedbackIdle", true, "Off = the buttons only appear while a controller button is held.")

    H("What Android cannot do")
    Text("• Buttons are reported by position, not by label: the bottom button is always \"A\" to Android, shown here as ✕ on PlayStation pads and B on Switch pads.\n• Touchpad, gyro, light bar, adaptive triggers and rear paddles are not available to apps for ordinary gamepads, so they cannot be mapped.\n• Two physical buttons pressed together as ONE trigger (a chord) is not supported yet. Use the 'also press together with' step (one button = two actions) or a diagonal action instead.\n• The controller picture is a generic drawing re-labelled for the detected family, not a photo of your exact model.\n• Controller rumble depends on the phone, the connection and the pad; use VIBRATION ▸ TEST DEVICES to see what really buzzes.",
        color = Color(0xCCFFFFFF), fontSize = 11.sp)
}


/** Which console-native label each physical button gets, and a dropdown to pick another function for it. Works on the layer being edited. */
@Composable
private fun ByButtonList(layerId: String, chain: List<String>, style: PadStyle, sysLabel: String) {
    @Suppress("UNUSED_VARIABLE") val tick = Profiles.tick
    val skin = Skins.current()
    val buttons = listOf(KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_BUTTON_X, KeyEvent.KEYCODE_BUTTON_Y,
        KeyEvent.KEYCODE_BUTTON_L1, KeyEvent.KEYCODE_BUTTON_R1, KeyEvent.KEYCODE_BUTTON_L2, KeyEvent.KEYCODE_BUTTON_R2,
        KeyEvent.KEYCODE_BUTTON_THUMBL, KeyEvent.KEYCODE_BUTTON_THUMBR, KeyEvent.KEYCODE_BUTTON_SELECT, KeyEvent.KEYCODE_BUTTON_START, KeyEvent.KEYCODE_BUTTON_MODE,
        KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT)
    var open by remember { mutableStateOf<Int?>(null) }
    H("BY BUTTON (pick a function for each button)")
    Text("Each row is a physical button on your controller (named for your controller family). Tap a row to choose which console function it does. $sysLabel's own names are shown, for example R3 (click) → Mode Select. Picking a function moves it to this button and frees it from the old one. Changes go into the layer you are editing above.", color = Color(0xE6FFFFFF), fontSize = 11.sp)
    buttons.forEach { code ->
        val acts = Act.values().filter { Profiles.code(it, false, chain) == code }
        val label = Profiles.btnLabel(style, code)
        Column(Modifier.fillMaxWidth().padding(vertical = 2.dp).clip(RoundedCornerShape(10.dp)).background(Color.Black.copy(.3f))) {
            Row(Modifier.fillMaxWidth().clickable { open = if (open == code) null else code }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(label, color = skin.accent, fontWeight = FontWeight.Black, modifier = Modifier.width(86.dp))
                Text("→", color = Color.White)
                Text(if (acts.isEmpty()) "nothing" else acts.joinToString(" + ") { it.label }, color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(start = 8.dp).weight(1f))
                Text(if (open == code) "▲" else "▼", color = Color.White)
            }
            if (open == code) Column(Modifier.padding(start = 10.dp, end = 10.dp, bottom = 8.dp)) {
                Text("Choose what $label does:", color = Color(0xCCFFFFFF), fontSize = 11.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Btn("NOTHING") { val l = Profiles.layer(layerId).copyOf(); acts.forEach { l.pad[it.name] = 0 }; Profiles.save(layerId, l); open = null }
                }
                Act.values().filter { it.def != 0 || it.name in setOf("SLOTNEXT", "SLOTPREV", "UITOGGLE", "VIBTOGGLE") }.chunked(2).forEach { pair ->
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(vertical = 2.dp)) {
                        pair.forEach { a -> Btn(a.label, selected = a in acts) {
                            val l = Profiles.layer(layerId).copyOf()
                            Profiles.conflicts(code, false, chain, a).forEach { l.pad[it.name] = 0 }
                            l.pad[a.name] = code; Profiles.save(layerId, l); open = null } }
                    }
                }
            }
        }
    }
    Text("Not done yet here: the emulator's own labels per console (A/B swap for Game Boy family) and a rewind-seconds hint.", color = Color(0x99FFFFFF), fontSize = 10.sp)
}
