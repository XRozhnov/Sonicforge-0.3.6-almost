package com.sonicforge.ui

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonicforge.data.Logger
import com.sonicforge.data.Rom
import com.sonicforge.data.Store
import java.io.File
import java.security.MessageDigest

/** Sega CD helper: checks the BIOS files and the disc image, lets you force the region and manage backup RAM. Written, not compiled. */
object SegaCd {
    /** core options handed to Genesis Plus GX before the game starts (per game). Names are the core's own; unknown names are simply ignored by the core. */
    fun coreOptions(id: String): Map<String, String> {
        val m = LinkedHashMap<String, String>()
        val region = Store.s("scdRegion_$id", "auto"); if (region != "auto") m["genesis_plus_gx_region_detect"] = region
        val bram = Store.s("scdBram_$id", "per bios"); if (bram != "per bios") m["genesis_plus_gx_bram"] = bram
        return m
    }

    fun md5(f: File): String = try { val md = MessageDigest.getInstance("MD5"); f.inputStream().use { i -> val b = ByteArray(65536); while (true) { val n = i.read(b); if (n <= 0) break; md.update(b, 0, n) } }; md.digest().joinToString("") { "%02x".format(it) } } catch (_: Exception) { "?" }
    private val knownBios = mapOf("2efd74e3232ff260e371b99f84024f7f" to "US Sega CD v1.10", "e66fa1dc5820d254611fdcdba0662372" to "Mega-CD EU v1.00", "278a9397d192149e84e820ac621a8edd" to "Mega-CD JP v1.00")

    /** region letter (U / E / J) written in the disc's first sector, or null when it cannot be read */
    fun discRegion(ctx: Context, rom: Rom): Char? {
        try {
            var img = File(ctx.filesDir, "roms/${rom.file}"); if (!img.exists()) return null
            if (img.extension.lowercase() == "cue") { val n = Regex("FILE\\s+\"([^\"]+)\"", RegexOption.IGNORE_CASE).find(img.readText())?.groupValues?.get(1) ?: return null; img = File(img.parentFile, n.substringAfterLast('/').substringAfterLast('\\')) }
            if (!img.exists() || img.extension.lowercase() == "chd") return null
            val head = img.inputStream().use { i -> ByteArray(0x400).also { i.read(it) } }; val txt = String(head, Charsets.ISO_8859_1)
            val base = when { txt.startsWith("SEGADISCSYSTEM") -> 0; txt.regionMatches(16, "SEGADISCSYSTEM", 0, 14) -> 16; else -> return null }
            return txt.getOrNull(base + 0x1F0)?.takeIf { it in "UEJ" }
        } catch (_: Exception) { return null }
    }
    /** the one-tap repair: set the region from the disc, say which BIOS is missing, optionally wipe the backup RAM files. Returns a short report. */
    fun autoFix(ctx: Context, rom: Rom, wipeRam: Boolean): String {
        val out = StringBuilder()
        val r = discRegion(ctx, rom)
        if (r != null) {
            Store.set("scdRegion_${rom.id}", when (r) { 'U' -> "ntsc-u"; 'E' -> "pal"; else -> "ntsc-j" })
            out.append("Region set from the disc: $r. ")
            if (!File(ctx.filesDir, "system/bios_CD_$r.bin").exists()) out.append("But bios_CD_$r.bin is missing: add a $r BIOS in LOCATIONS. ")
        } else out.append("The disc did not state a region (or it is a .chd); region left on AUTO. ")
        if (wipeRam) { val l = brmFiles(ctx); l.forEach { it.delete() }; out.append("Deleted ${l.size} backup RAM file(s); fresh formatted ones are created at the start. ") }
        Logger.notice(out.toString().trim()); return out.toString().trim()
    }
    fun brmFiles(ctx: Context): List<File> = (File(ctx.filesDir, "saves").listFiles() ?: emptyArray()).filter { it.name.lowercase().endsWith(".brm") }.sortedBy { it.name }

    fun biosReport(ctx: Context): List<String> {
        val sys = File(ctx.filesDir, "system"); val out = mutableListOf<String>()
        for (r in listOf("U", "E", "J")) {
            val f = File(sys, "bios_CD_$r.bin")
            if (!f.exists()) { out += "bios_CD_$r.bin: missing"; continue }
            val k = knownBios[md5(f)]
            out += "bios_CD_$r.bin: ${f.length()} bytes, " + (k?.let { "matches a known good dump ($it)" } ?: "unknown dump (may still work; if the game never starts try another BIOS)")
        }
        return out
    }

    /** looks into the disc image: cue sheet, referenced files, sector size, the SEGADISCSYSTEM tag and the region letter */
    fun discReport(ctx: Context, rom: Rom): List<String> {
        val out = mutableListOf<String>()
        val main = File(ctx.filesDir, "roms/${rom.file}")
        if (!main.exists()) return listOf("The game file is missing. Import it again.")
        val ext = main.extension.lowercase(); var img: File = main
        if (ext == "cue") {
            val files = Regex("FILE\\s+\"([^\"]+)\"", RegexOption.IGNORE_CASE).findAll(main.readText()).map { it.groupValues[1] }.toList()
            if (files.isEmpty()) out += "The .cue lists no files."
            files.forEach { n -> val f = File(main.parentFile, n.substringAfterLast('/').substringAfterLast('\\')); out += (if (f.exists()) "track file OK: " + f.name + " (" + f.length() / 1024 + " KB)" else "MISSING track file: ${f.name} (the .cue points to it, the bin must have exactly this name)") }
            val first = files.firstOrNull()?.let { File(main.parentFile, it.substringAfterLast('/').substringAfterLast('\\')) }
            if (first == null || !first.exists()) return out
            img = first
        }
        if (ext == "chd") return out + "CHD: cannot be inspected here. If it only shows the player, convert it to bin/cue."
        val head = try { img.inputStream().use { i -> ByteArray(0x400).also { i.read(it) } } } catch (e: Exception) { return out + "Cannot read the image: ${e.message}" }
        val txt = String(head, Charsets.ISO_8859_1)
        val base = when { txt.startsWith("SEGADISCSYSTEM") -> 0; txt.regionMatches(16, "SEGADISCSYSTEM", 0, 14) -> 16; else -> -1 }
        if (base < 0) {
            out += "The first sector has no SEGADISCSYSTEM tag. A Sega CD BIOS cannot boot this image: it opens the CD player instead. Typical causes: a data track that is not first, a wrong dump, or a hack image that needs its own boot file."
        } else {
            out += "Sega CD boot tag found (sector size " + (if (base == 16) "2352 raw" else "2048") + ")."
            val region = txt.getOrNull(base + 0x1F0)
            out += "Header region letter: " + (if (region != null && region in "UEJ") region.toString() else "not stated") + ". " +
                when (region) { 'U' -> "Use the U BIOS."; 'E' -> "Use the E BIOS."; 'J' -> "Use the J BIOS."; else -> "Try the region chooser below." }
        }
        return out
    }
}

@Composable
fun SegaCdToolsDialog(rom: Rom, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    var askBrm by remember { mutableStateOf<File?>(null) }; var fix by remember { mutableStateOf(false) }; var fixMsg by remember { mutableStateOf("") }
    val bios = remember(tick) { SegaCd.biosReport(ctx) }
    val disc = remember(tick) { SegaCd.discReport(ctx, rom) }
    val brm = remember(tick) { SegaCd.brmFiles(ctx) }
    AlertDialog(onDismissRequest = onClose, containerColor = Color(0xFF0D0D14), titleContentColor = Color.White, textContentColor = Color.White,
        confirmButton = { TextButton(onClose) { Text("CLOSE") } },
        title = { Text("SEGA CD TOOLS") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Btn("⚡ AUTO-FIX (region from the disc + fresh backup RAM)", selected = true) { fix = true }
                Text("One tap: reads the region from the disc, sets it for this game, and deletes the backup RAM files so the BIOS finds fresh, formatted ones (this erases Sega CD saves kept in those files). Then start the game again.", fontSize = 11.sp, color = Color(0xFFFFE082))
                if (fixMsg.isNotEmpty()) Text(fixMsg, fontSize = 12.sp, color = Color(0xFFC5E1A5), modifier = Modifier.padding(top = 4.dp))
                H("What happens at the logo")
                Text("The Sega CD BIOS starts first. With a recognised disc it runs the game by itself. If you only see the CD player (the BIOS menu with the memory/RAM screens), the BIOS did not recognise the disc. Press START there once: some discs begin from that screen. If nothing starts, use the checks below.", fontSize = 12.sp, color = Color(0xDDFFFFFF))
                H("1. BIOS files")
                bios.forEach { Text("• $it", fontSize = 12.sp, color = if (it.contains("missing")) Color(0xFFFFAB91) else Color(0xFFC5E1A5)) }
                H("2. This disc image")
                disc.forEach { Text("• $it", fontSize = 12.sp, color = if (it.startsWith("MISSING") || it.contains("no SEGADISCSYSTEM")) Color(0xFFFFAB91) else Color(0xFFC5E1A5)) }
                H("3. Force the region (this game)")
                SChips("Region", "scdRegion_${rom.id}", "auto", listOf("auto" to "AUTO", "ntsc-u" to "USA", "pal" to "EUROPE", "ntsc-j" to "JAPAN"))
                Text("A Japanese disc with only the US BIOS (or the other way round) often ends in the player. Choose the region of the DISC, then start again. Takes effect the next time the game starts.", fontSize = 11.sp, color = Color(0xCCFFFFFF))
                H("4. Backup RAM (saves and the RAM message)")
                SChips("Backup RAM is kept", "scdBram_${rom.id}", "per bios", listOf("per bios" to "SHARED PER BIOS", "per game" to "SEPARATE PER GAME"))
                Text("If the BIOS complains that the RAM is not formatted or full, delete the file below: the core creates a fresh, formatted one at the next start. Deleting erases the saves kept in that file.", fontSize = 11.sp, color = Color(0xCCFFFFFF))
                if (brm.isEmpty()) Text("(no backup RAM files yet)", fontSize = 12.sp)
                brm.forEach { f -> Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) { Text(f.name + "  " + f.length() / 1024 + " KB", fontSize = 12.sp, modifier = Modifier.weight(1f)); Btn("DELETE", color = Color(0xFFE53935)) { askBrm = f } } }
                H("5. Still only the player?")
                Text("Send the log (SETTINGS ▸ LOGS): the core prints why the BIOS rejected the disc. Try the other BIOS dump in LOCATIONS, a plain .bin/.cue (not .chd), and make sure every track file named in the .cue sits next to it.", fontSize = 12.sp, color = Color(0xFFFFE082))
            }
        })
    if (fix) ConfirmDialog("Run the auto-fix?", "Sets the region from the disc and deletes the Sega CD backup RAM files.", "Your game files and save states are not touched.", onYes = { fixMsg = SegaCd.autoFix(ctx, rom, true); fix = false; tick++ }, onNo = { fix = false })
    askBrm?.let { f -> ConfirmDialog("Delete ${f.name}?", "Deletes this backup RAM file; a new formatted one is created at the next start.", "Your game files and save states are not touched.", onYes = { try { f.delete(); Logger.notice("Deleted ${f.name}") } catch (_: Exception) {}; askBrm = null; tick++ }, onNo = { askBrm = null }) }
}
