package com.sonicforge.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonicforge.data.Logger
import com.sonicforge.data.Store
import kotlinx.coroutines.delay
import java.io.File

/** Launcher UI scale (like Minecraft's GUI scale). A change must be confirmed within 8 seconds or it reverts. Written, not compiled. */
object UiScale {
    fun value() = (Store.i("uiScale", 100)).coerceIn(70, 150) / 100f
    @Composable
    fun Provide(content: @Composable () -> Unit) {
        val d = LocalDensity.current; val k = value()
        CompositionLocalProvider(LocalDensity provides Density(d.density * k, d.fontScale)) { content() }
    }
}

@Composable
fun UiScalePanel() {
    var pending by remember { mutableStateOf<Int?>(null) }; var prev by remember { mutableIntStateOf(100) }
    H("Interface size")
    Text("Makes the whole launcher bigger or smaller (not the game picture). After a change you have 8 seconds to keep it; if the screen becomes unreadable just wait and it goes back by itself.", color = Color(0xCCFFFFFF), fontSize = 12.sp)
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf(80, 90, 100, 110, 120, 135).forEach { v -> Btn("$v%", selected = Store.i("uiScale", 100) == v) { if (v != Store.i("uiScale", 100)) { prev = Store.i("uiScale", 100); Store.setI("uiScale", v); pending = prev; com.sonicforge.audio.Sfx.play("click"); com.sonicforge.input.Haptics.ui() } } }
    }
    pending?.let { old ->
        var left by remember { mutableIntStateOf(8) }
        LaunchedEffect(Unit) { while (left > 0) { delay(1000); left-- }; Store.setI("uiScale", old); pending = null }
        AlertDialog(onDismissRequest = { }, containerColor = Color(0xFF0D0D14), titleContentColor = Color.White, textContentColor = Color.White,
            title = { Text("Keep this size?") }, text = { Text("Going back to ${old}% in $left s.") },
            confirmButton = { TextButton({ pending = null }) { Text("KEEP") } },
            dismissButton = { TextButton({ Store.setI("uiScale", old); pending = null }) { Text("GO BACK") } })
    }
}

/** per-category cache clearing + free space on the device (SETTINGS ▸ DATA & PRIVACY) */
@Composable
fun StorageTools() {
    val ctx = LocalContext.current; var tick by remember { mutableIntStateOf(0) }; @Suppress("UNUSED_VARIABLE") val t = tick
    fun size(f: File): Long = if (f.isFile) f.length() else (f.listFiles()?.sumOf { size(it) } ?: 0L)
    fun mb(b: Long) = if (b < 1024 * 1024) "${b / 1024} KB" else "%.1f MB".format(b / 1048576.0)
    val free = try { ctx.filesDir.usableSpace } catch (_: Exception) { 0L }; val total = try { ctx.filesDir.totalSpace } catch (_: Exception) { 0L }
    H("Space and caches")
    Text("Device: ${mb(free)} free of ${mb(total)}.", color = Color.White, fontSize = 13.sp)
    val cats = listOf(
        Triple("Temporary files (cache)", ctx.cacheDir, "Safe to clear: rebuilt when needed."),
        Triple("Save states", File(ctx.filesDir, "saves"), "Erases your save states and battery saves. Not recoverable."),
        Triple("Pictures (covers, backgrounds)", com.sonicforge.data.Library.art, "Your own pictures; games fall back to the built-in look."),
        Triple("Media (comics, notes, video, recordings)", Media.root, "Everything you added in the MEDIA tab."))
    var ask by remember { mutableStateOf<Triple<String, File, String>?>(null) }
    val maxB = cats.maxOf { size(it.second) }.coerceAtLeast(1L)
    cats.forEach { c ->
        val b = size(c.second)
        Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
            Row(Modifier.fillMaxWidth()) { Text(c.first + ": " + mb(b), color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f)); Btn("CLEAR", color = Color(0xFFE53935)) { ask = c } }
            Box(Modifier.fillMaxWidth(b.toFloat() / maxB).height(6.dp).background(Color(0xFF4FC3F7), androidx.compose.foundation.shape.RoundedCornerShape(3.dp)))
        }
    }
    ask?.let { c -> ConfirmDialog("Clear ${c.first}?", c.third, "Your game files (ROMs) are not touched.", onYes = {
        try { c.second.listFiles()?.forEach { it.deleteRecursively() }; Logger.notice("Cleared ${c.first}") } catch (e: Exception) { Logger.notice("Could not clear: ${e.message}", false) }
        ask = null; tick++ }, onNo = { ask = null }) }
}
