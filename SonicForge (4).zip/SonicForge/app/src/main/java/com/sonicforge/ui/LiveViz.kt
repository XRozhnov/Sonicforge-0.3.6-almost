package com.sonicforge.ui

import android.media.audiofx.Visualizer
import androidx.compose.runtime.*
import com.sonicforge.data.Logger
import kotlinx.coroutines.delay
import kotlin.math.hypot
import kotlin.math.ln

/**
 * Real-time spectrum of what is actually playing (android.media.audiofx.Visualizer on a MediaPlayer's audio session).
 * Needs the microphone permission (Android treats it as capturing output); without it, or when the device refuses, the caller falls back to the animated look.
 * Written, not compiled, never tried on a device.
 */
@Composable
fun rememberLiveSpectrum(enabled: Boolean, sessionId: () -> Int, key: Any?, bands: Int = 28): FloatArray? {
    val mags = remember { FloatArray(bands) }
    var ok by remember { mutableStateOf(false) }
    LaunchedEffect(enabled, key) {
        ok = false
        if (!enabled) return@LaunchedEffect
        val id = sessionId(); if (id == 0) return@LaunchedEffect
        var v: Visualizer? = null
        try {
            v = Visualizer(id); v.captureSize = Visualizer.getCaptureSizeRange()[1].coerceAtMost(1024); v.enabled = true
            val fft = ByteArray(v.captureSize); ok = true
            while (true) {
                delay(33)
                v.getFft(fft)
                val n = fft.size / 2
                for (b in 0 until bands) {
                    // log-spaced bands from bin 1 to n-1
                    val lo = Math.pow((n - 1).toDouble(), b / bands.toDouble()).toInt().coerceAtLeast(1)
                    val hi = Math.pow((n - 1).toDouble(), (b + 1) / bands.toDouble()).toInt().coerceAtLeast(lo + 1).coerceAtMost(n - 1)
                    var m = 0f
                    for (k in lo..hi) { val re = fft[2 * k].toInt(); val im = fft[2 * k + 1].toInt(); m = maxOf(m, hypot(re.toFloat(), im.toFloat())) }
                    val target = (ln(1f + m) / ln(1f + 181f)).coerceIn(0f, 1f)          // 0..1, a byte pair is at most ~181
                    mags[b] = if (target > mags[b]) target else mags[b] * 0.82f          // fast attack, slow fall
                }
            }
        } catch (e: Throwable) { Logger.i("Viz", "live spectrum unavailable: $e"); ok = false }
        finally { try { v?.enabled = false; v?.release() } catch (_: Throwable) {} }
    }
    return if (ok) mags else null
}
