package com.sonicforge.ui

import android.content.Context
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.sp
import com.sonicforge.core.Emu
import com.sonicforge.data.Store

/**
 * Nintendo DS (experimental). The core draws both screens into ONE picture; we only choose how they are arranged and forward touches on the lower screen.
 * Layouts: side by side, top/bottom, top/bottom with the real gap between the screens, and AUTO (picks by orientation / tablet). Written, not compiled, never run on a device.
 */
object Ds {
    /** the core option names differ between melonDS and DeSmuME, both are sent; a core ignores the names it does not know */
    fun coreOptions(ctx: Context): Map<String, String> {
        val land = ctx.resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
        val wideDp = ctx.resources.configuration.smallestScreenWidthDp
        var mode = Store.s("dsLayout", "auto")
        if (mode == "auto") mode = if (land) (if (wideDp >= 600 || Store.b("dsLandSide", false)) "lr" else "tb") else "tb"
        if (mode == "tablet") mode = if (land) "lr" else "tbgap"
        val gap = if (mode == "lr") 0 else Store.i("dsGap", 0)   // default: the screens touch; the slider sets the gap in every stacked arrangement
        val m = LinkedHashMap<String, String>()
        val side = mode == "lr"
        m["melonds_screen_layout"] = if (side) "Left/Right" else "Top/Bottom"
        m["desmume_screens_layout"] = if (side) "left/right" else "top/bottom"
        m["melonds_jit_enable"] = if (Store.b("dsJit", false)) "enabled" else "disabled"   // the JIT needs executable memory: off is slower but draws on phones where the JIT leaves a white picture
        if (!side) { m["melonds_screen_gap"] = gap.toString(); m["desmume_screens_gap"] = ((gap + 2) / 5 * 5).toString() }
        return m
    }
}

/** landscape: the buttons are squeezed into the two side bands next to the picture (widthFrac = share of the screen width the picture takes), so nothing lies over the picture or the touch screen */
fun dsSideLayout(l: com.sonicforge.data.PadLayout, widthFrac: Float): com.sonicforge.data.PadLayout {
    val k = (1f - widthFrac).coerceIn(.2f, 1f)
    return l.copy(land = l.land.map { e -> e.copy(x = if (e.x < .5f) e.x * k else 1f - (1f - e.x) * k) })
}

/**
 * Stylus input for the lower screen. It listens in the INITIAL pass of the parent, so the full-screen button layer on top cannot swallow it
 * (a layer drawn above hides everything below it from touch): a finger that starts inside the picture and not on a button becomes the stylus.
 */
fun Modifier.dsStylus(active: Boolean, rect: () -> androidx.compose.ui.geometry.Rect?, onControl: (androidx.compose.ui.geometry.Offset) -> Boolean): Modifier =
    if (!active) this else this.pointerInput(Unit) {
        awaitPointerEventScope {
            var id: androidx.compose.ui.input.pointer.PointerId? = null
            fun send(p: androidx.compose.ui.geometry.Offset, r: androidx.compose.ui.geometry.Rect) {
                val fx = ((p.x - r.left) / r.width.coerceAtLeast(1f)).coerceIn(0f, 1f); val fy = ((p.y - r.top) / r.height.coerceAtLeast(1f)).coerceIn(0f, 1f)
                Emu.setPointer((fx * 65534f - 32767f).toInt(), (fy * 65534f - 32767f).toInt(), true)
            }
            while (true) {
                val ev = awaitPointerEvent(androidx.compose.ui.input.pointer.PointerEventPass.Initial)
                val r = rect() ?: continue
                val cur = id
                if (cur == null) {
                    val d = ev.changes.firstOrNull { it.pressed && !it.previousPressed && r.contains(it.position) && !onControl(it.position) }
                    if (d != null) { id = d.id; send(d.position, r) }
                } else {
                    val c = ev.changes.firstOrNull { it.id == cur }
                    if (c == null || !c.pressed) { Emu.setPointer(0, 0, false); id = null } else send(c.position, r)
                }
            }
        }
    }

/** transparent layer over the picture: a finger on it becomes a stylus touch (the core reads the lower screen only) */
@Composable
fun DsTouchPad() {
    Box(Modifier.fillMaxSize().pointerInput(Unit) {
        awaitEachGesture {
            val w = size.width.coerceAtLeast(1); val h = size.height.coerceAtLeast(1)
            fun send(x: Float, y: Float, down: Boolean) { Emu.setPointer(((x / w).coerceIn(0f, 1f) * 65534f - 32767f).toInt(), ((y / h).coerceIn(0f, 1f) * 65534f - 32767f).toInt(), down) }
            val d = awaitFirstDown(requireUnconsumed = false)
            send(d.position.x, d.position.y, true)
            do {
                val ev = awaitPointerEvent()
                val c = ev.changes.firstOrNull() ?: break
                send(c.position.x, c.position.y, c.pressed)
                c.consume()
            } while (ev.changes.any { it.pressed })
            Emu.setPointer(0, 0, false)
        }
    })
}

@Composable
fun DsScreensDialog(onClose: () -> Unit) {
    AlertDialog(onDismissRequest = onClose, containerColor = Color(0xFF0D0D14), titleContentColor = Color.White, textContentColor = Color.White,
        confirmButton = { TextButton(onClose) { Text("CLOSE") } }, title = { Text("DS SCREENS (experimental)") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("Takes effect the next time the game starts. The picture keeps the DS proportions, so turn the phone to match: SIDE BY SIDE is for landscape, TOP / BOTTOM for portrait.", fontSize = 12.sp, color = Color(0xDDFFFFFF))
                SChips("Arrangement", "dsLayout", "auto", listOf("auto" to "AUTO", "lr" to "SIDE BY SIDE", "tb" to "TOP / BOTTOM", "tbgap" to "TOP / BOTTOM + REAL GAP", "tablet" to "TABLET"))
                Text("AUTO: landscape = side by side, portrait = top / bottom. TABLET: landscape = side by side, portrait = top / bottom with the real gap, which fills a tall tablet screen better.", fontSize = 11.sp, color = Color(0xCCFFFFFF))
                SSlider("Gap between the screens", "dsGap", 0, 126, " px")
                Text("0 = the screens touch (default). A real DS has about 46 pixels of hinge. Used by every stacked arrangement; takes effect when the game starts.", fontSize = 11.sp, color = Color(0xCCFFFFFF))
                SToggle("Side by side in landscape on phones (AUTO)", "dsLandSide", false, "OFF (recommended): in landscape the two screens stay stacked in the middle and the buttons sit at the sides, so nothing covers the picture. ON: wide picture, the buttons lie over it.")
                SToggle("Landscape: buttons beside the picture (not over it)", "dsInset", true, "The on-screen buttons move into the two side bands, so they never cover the screens or the touch screen. Other consoles can use this too (SETTINGS ▸ CONTROLS).")
                SToggle("JIT recompiler (faster, may leave the picture WHITE)", "dsJit", false, "OFF (default) is slower but draws correctly on more phones. If your phone is fast enough, try ON. Takes effect when the game starts.")
                SToggle("Plain picture frame (no rounded corners, no border)", "dsPlain", true, "Like the classic mode: sharp edges, no margin. Takes effect when the game starts.")
                H("Touch")
                Text("Touch the lower screen with a finger: it acts as the stylus. The on-screen pad gives the D-pad and A B X Y L R START SELECT.", fontSize = 12.sp, color = Color(0xFFFFE082))
            }
        })
}

fun Modifier.androidx_onSize(f: (androidx.compose.ui.unit.IntSize) -> Unit): Modifier = this.onSizeChanged(f)
fun Modifier.androidx_onPos(f: (androidx.compose.ui.geometry.Rect) -> Unit): Modifier = this.onGloballyPositioned { f(it.boundsInRoot()) }
