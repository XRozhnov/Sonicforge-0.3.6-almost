package com.sonicforge.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonicforge.data.Logger
import com.sonicforge.data.Store

data class Release(val version: String, val name: String, val date: String, val items: List<String>)

object Changelog {
    val all = listOf(
        Release("0.3.6_pre11", "Vibration for every game (pre-release 11)", "Nov 2026", listOf(
            "🧪 BETA, written but not compiled or tried on a phone yet.",
            "🆕 NEW · VIBRATION per game: a 📳 VIBRATION button on every game page and in the TILES menu (⋯ on a tile, always available) chooses a preset for that game only and shows where its buzzes come from (touch buttons, memory map, sound). The ENGINE LOG now prints one line per game: which source is active.",
            "🆕 NEW · more vibration: explosions of monitors / enemies (from the game's sound, on top of the memory map), water splash in and out, air bubble. Sonic 3 / S&K / Heroes now use the advanced map by default (shields, fire / lightning / bubble); Mario NES / SNES use suggested memory rules automatically. Sound haptics give every other game (Advance, SNES, GB...) buzzes: SETTINGS ▸ VIBRATION.",
            "🛠 FIXED · Sega CD: the option name for the backup RAM was wrong (it never reached the core); now genesis_plus_gx_system_bram / cart_bram, with a new 'RAM cartridge' switch. Empty (all-zero) backup RAM files are moved aside before each start (for 'RAM cartridge is not initialized' in Sonic CD). SEGA CD TOOLS is reachable from the TILES menu.",
            "🆕 NEW · LOCATIONS ▸ Nintendo DS files: + ADD DS FILES installs bios7.bin / bios9.bin / firmware.bin (recognised by name). Optional: DS games start without them.",
            "🛠 FIXED · the build error in Haptics.kt (operator precedence) that stopped the previous upload from compiling.",
            "🛠 FIXED · ENGINE LOG: FOLD and CLOSE buttons (closing no longer flashes back); the in-game top bar's ▸ can no longer be undone by the same tap.",
            "🛠 FIXED · Nintendo DS: plain picture frame (no rounded corners / border, switchable), in landscape the screens stay stacked so buttons do not cover them (switchable).",
            "🛠 FIXED · Flash: if the movie does not start the screen now offers OPEN IN THE RUFFLE APP (your phone plays these files there).",
            "⚠ NOT DONE / UNCONFIRMED · DS white screen and the Flash black screen: the true cause is still unknown. Your last log came from a build without the new bridge lines, so install this one and send the ENGINE LOG again.",
        )),
        Release("0.3.6_pre10", "Core diagnostics (pre-release 10)", "Nov 2026", listOf(
            "🧪 BETA, written but not compiled or tried on a phone yet.",
            "🆕 NEW · ENGINE LOG has a COPY button; the emulator bridge now writes what the core does: every option name the core offers, refused hardware rendering, video size, and whether the picture is blank (white/black). This is for the DS white screen and the Sega CD problem.",
            "🛠 FIXED · SUPER tab scrolls as one page (buttons at the bottom were cut off); INSIDE shows messages when it cannot start.",
            "NOT DONE · DS white screen and Sonic CD RAM problem: not fixed, only made visible. Send the ENGINE LOG after trying them.",
        )),
        Release("0.3.6_pre9", "Engine log, Flash diagnostics, TV and x86 (pre-release 9)", "Nov 2026", listOf(
            "🧪 BETA, written but not compiled or tried on a phone yet.",
            "🆕 NEW · ENGINE LOG strip over the launcher, games and Flash: 3 taps fold it, a long press closes it, SETTINGS ▸ ABOUT or the logs window bring it back (off by default).",
            "🆕 NEW · Required-files cards (BIOS, keys, game format) on the game page for Sega CD, GBA, GB, NES and DS.",
            "🆕 NEW · x86_64 and x86 APKs (Chromebooks, PC emulators); Android TV first-start setup (bigger UI, remote navigation, no touch buttons).",
            "🛠 FIXED (not verified) · Flash page is served like a real site and each step goes to the engine log: ruffle.js, wasm, WebView version, movie start.",
            "🆕 NEW · Manuals and new texts translated into all 12 languages.",
            "NOT DONE · Sonic CD RAM error (send the engine log), Flash still unconfirmed.",
        )),
        Release("0.3.6_pre8", "Manuals with a console (pre-release 8)", "Nov 2026", listOf(
            "🧪 BETA, written but not compiled or tried on a phone yet.",
            "🆕 NEW · Manuals redesigned: each console is drawn in the app with numbered callouts and a legend, a SPECS box, coloured section bars with icons.",
            "🆕 NEW · Nintendo DS manual added.",
            "🆕 NEW · Game library: ALL CONSOLES tab and a search box (also in portrait).",
            "🆕 NEW · Music: search by title or artist, sort by length.",
            "🆕 NEW · Game settings: colours for the EMU and SCREEN counters, with an explanation.",
            "🆕 NEW · Symbol transparency: letters and arrows can follow the button transparency (linked, default) or have their own slider.",
            "NOT DONE · Rest of the 0.3.6 checklist (Game Gear rewind colours, D-pad lights, T indicator, transparency split, picture presets, vibration presets, tempo) is still open.",
        )),
        Release("0.3.6_pre7", "Controllers & Looks (pre-release 7)", "Nov 2026", listOf(
            "🧪 BETA, written but not compiled or tried on a phone yet.",
            "FIXED · The pre5 build did not compile (a missing import in UiModes). Fixed.",
            "FIXED · Nintendo DS crashed with 'out of memory': the rewind history kept 6.5 MB per step. Rewind now uses at most 64 MB and switches itself off for DS.",
            "FIXED · The music notification stayed on 'pause' when the song was already paused (the app replaced the notification's update hook). Now it follows play and pause.",
            "NEW · 📳 Vibration from the game's SOUND for every game on every console (SETTINGS ▸ HAPTICS): deep boom = hit, bright blip = pickup, other loud blips = action. AUTO is on for games that have no memory profile.",
            "NEW · 💿 Sega CD: ⚡ AUTO-FIX reads the disc's region, sets it, and clears the backup RAM; the region is also taken from the disc automatically at start.",
            "NEW · 🎚 Real-time equalizer in the music player (follows the real sound, switchable, needs the microphone permission) and a preview equalizer when you play a recording.",
            "NEW · ★ MEDIA: favourites, sorting (name, newest, oldest, biggest, favourites first, favourites only) and a small date line under every item.",
            "NEW · 📐 Game screen: swap sides (4:3 ↔ 3:4), more ratios (16:10, 8:5, 5:3, 3:2, 5:4, 21:9, 7:3, 32:9), system bars switch, optional PAUSE button, shader for this game / console / all.",
            "NEW · 🔠 Interface size 80 to 135 % with an 8-second 'keep it?' countdown; per-category cache clearing and free space (SETTINGS ▸ DATA).",
            "STILL UNCONFIRMED · Flash showing a black screen: the log held no page error. Test this build, and if it is still black send the log again; the page now prints its own status line.",
            "NOT DONE YET · TV remote pass, x86, translations, exact Sonic RAM events, console guide books.",
        )),
        Release("0.3.6_pre6", "Controllers & Looks (pre-release 6)", "Nov 2026", listOf(
            "🧪 BETA, written but not compiled or tried on a phone yet. Small batch on top of pre5.",
            "FIXED · The rewind hint said 4 seconds while about 12 were kept. Now the length is a choice: 4, 8, 12 or 20 seconds.",
            "NEW · Swap A and B for Nintendo-style consoles (GB, GBA, NES, SNES, DS), SETTINGS ▸ VIDEO.",
            "NOT DONE YET · TV remote pass, x86, translations, Flash FPS lock, Sonic vibration events from memory.",
        )),
        Release("0.3.6_pre5", "Controllers & Looks (pre-release 5)", "Nov 2026", listOf(
            "🧪 BETA, written but not compiled or tried on a phone yet.",
            "NEW · 💿 SEGA CD TOOLS (game page): checks the BIOS files, reads the disc image (cue, track files, boot tag, region), forces the region, and resets the backup RAM. It cannot promise that every fan CD boots.",
            "NEW · 🖼 Picture layers sit BEHIND the interface on every tab by default (in front is optional, with a warning); fit, crop, size, position and offset; APPLY TO ALL; UNDO STEP; GIF animation on Android 9+.",
            "NEW · 📚 Comics: pinch and double-tap zoom, tap the left or right edge to turn the page, manga/scroll mode with width zoom, reorder or delete pages, reorder comics, names count up (Comic 1, 2 ...) and a name clash asks before replacing.",
            "NEW · 🖼 Pictures: zoom, rotate, flip, crop (free or by ratio), save a copy or replace, share, delete. Text files open in the editor from FILES.",
            "NEW · 🎙 Recorder level display: level bar and a scrolling waveform (switchable).",
            "NEW · 📳 Vibration RULES for any game on any console (SETTINGS ▸ HAPTICS): you pick a memory address and a trigger. Starter rules for NES and SNES Mario are included, unverified.",
            "NEW · 🖥 Nintendo DS (experimental, optional core): side by side, top / bottom, top / bottom with the real gap, AUTO and TABLET arrangements; the lower screen is a touch screen.",
            "NEW · 🎨 Themes: Game Jolt, itch, Neon Coast and Dark Rival get their own backgrounds and button shapes; Meadow Day gets bricks, pipes, hills with eyes, plants, ? blocks and coins.",
            "FIXED (unverified) · The TILES bottom bar no longer wraps BACK letter by letter; BACK is tappable; the A / B circles show only with a gamepad.",
            "FIXED (unverified) · Flash starts without waiting for a click and shows its own status line; the recorder now asks for the microphone.",
            "NOT DONE YET · full Android TV remote pass, x86 builds, translations of the new texts, vibration events read from Sonic's memory, tablet-specific layouts for the rest of the app.",
        )),
        Release("0.3.6_pre4", "Controllers & Looks (pre-release 4)", "Nov 2026", listOf(
            "🧪 BETA, written but not compiled or tried on a phone yet.",
            "FIXED · The build errors of pre3 (an experimental layout API in games and a missing import in the mini-games).",
            "NEW · 🗂 MEDIA tab: pictures, comics (pages, scroll or manga mode), video, notes (text editor), files (the app's own folder) and a voice recorder with a backing track. Files are copied into the app.",
            "NEW · ↗ Open with / Share to SonicForge: pictures, video, audio and text ask where they should go.",
            "NEW · ⌨ Flash keyboard: backspace and a ?123 page with symbols, F-keys, Home / End.",
            "NEW · 📺 The app icon shows on Android TV (remote navigation is partly done; a real TV test is still to do).",
            "NOT DONE YET · new vibration sets, Flash FPS lock, translations of the new texts, x86 build.",
        )),
        Release("0.3.6_pre3", "Controllers & Looks (pre-release 3)", "Nov 2026", listOf(
            "🧪 BETA, written but not compiled or tried on a phone yet.",
            "FIXED (unverified) · Flash: the game's file name is now URL-encoded (spaces and special characters used to break loading), the page shows its own error text instead of a silent black screen, and the quick menu has OPEN IN RUFFLE APP for the official app.",
            "NEW · 🎮 SETTINGS ▸ CONTROLS ▸ BY BUTTON: every controller button listed with the function it does; tap to choose another (for example R3 → Mode Select).",
            "NEW · 📖 HELP ▸ CONSOLE MANUALS: illustrated booklets for Mega Drive, Master System, Game Gear, Sega CD, 32X, Game Boy, GBA, NES and SNES (English only for now).",
            "NOT DONE YET · media tabs, recorder/karaoke, new vibration sets, FPS lock for Flash, keyboard symbols page, translations, the rest of the 0.3.6 checklist.",
        )),
        Release("0.3.6_pre2", "Controllers & Looks (pre-release 2)", "Nov 2026", listOf(
            "🧪 BETA, written but not compiled or tried on a phone yet.",
            "NEW · 👾 NES and SNES (experimental, cores are optional downloads at build time).",
            "NEW · 🎨 Themes Blue Blur, Dark Rival and Meadow Day (original palettes, no logos or characters). Neon Coast, Game Jolt and itch stay.",
            "NEW · 🖼 More picture layers: background, background objects (palms), ground, character, foreground. SETTINGS ▸ SCREEN & LOOK.",
            "NEW · ❄ Optional seasonal decoration (snow, confetti, lights, leaves), OFF by default.",
            "NEW · 🕐 24-hour clock option; music notification with cover, seek bar and play/pause state.",
            "IMPROVED · Changing a theme no longer shows a 'saved' notice.",
            "NOT DONE YET · per-button mapping list, console manuals, media tabs (comics, video, notes, files), recorder/karaoke, new vibration sets, extra translations.",
        )),
        Release("0.3.6 pre-release", "Controllers & Looks (pre-release)", "Nov 2026", listOf(
            "🧪 BETA: this is the first build with everything below, and none of it has been tried on a real phone yet. Please tell the developer what breaks. The final 0.3.6 will be this app after your feedback and the rest of the checklist.",
            "NEW · 🕹 Classic mode can now show the on-screen controls over the clean picture (SETTINGS ▸ SCREEN, and the in-game menu). They are see-through; set the opacity yourself.",
            "NEW · 🔆 Controller highlight: a white frame shows which item the gamepad is on in the launcher. SETTINGS ▸ CONTROLS ▸ 'Launcher with a controller' turns the frame off, and lets A / ✕ press and B / ○ go back.",
            "NEW · 📳 Vibration strength: Low / Normal / High / Max separately for the phone and for the controller, with fine tuning (multiplier, weakest buzz, longer buzz). A controller's Normal is stronger than before. Not tested on real pads yet.",
            "NEW · 🎨 Two more launcher looks, Game Jolt and itch (original colour palettes, game-card grid), besides Normal, Mania and Tiles. Your own PNG background / foreground / character with opacity and blur for every look (CUSTOMIZE and SETTINGS ▸ SCREEN).",
            "NEW · 🌅 Neon Coast theme (original sunset / neon poster look). Themes now also change the menus, buttons and background inside games and emulators; switch 'Use the theme inside games and emulators' off to keep your normal style there. The Help topic 'Styles and themes' explains the difference.",
            "NEW · 🎬 Startup intro (experimental, off by default): your own picture or video, optional music, fade from / to a colour, tap to skip. A theme's built-in backdrop is replaced when you add your own background picture.",
            "IMPROVED · Help: ASK A HELPER is now second. MUSIC: switch to hide the small player bar inside the music tab; opening MUSIC always brings a hidden player back.",
            "NEW · 🃏 Game cards: show or hide the title, the system label and the logo. In the card looks a tap opens a small game menu (or starts the game at once, your choice).",
            "NEW · 🎮 Three more mini-games with their own rules: Endless Hills (endless platformer), Sky Spring (vertical bouncer: drag, buttons, D-pad or optional tilt) and Lane Sprint (run into the screen). They work with a gamepad or TV remote.",
            "FIXED · 🎵 The hidden-player ♪ chip now floats above every screen and can be tapped. The 'next songs' strip no longer repeats a song, and the ▲ ▼ reorder arrows follow what you see, also with Reverse order on.",
            "FIXED · 📱 In a game the picture no longer slides under the status bar until you switch apps. Mania is roomier in landscape, the game list is no longer covered by the add buttons, and small text is brighter and larger.",
            "NOT DONE YET (still on the checklist): startup splash, music / video / comics / photos tabs, voice recorder, Flash fix, new equalizers, 'open with' for files, per-button function dropdown and the emulator's own button labels.",
            "NEW · 🎮 Controller setup (SETTINGS ▸ CONTROLS, also in the pause menu ▸ CONTROLS ▸ CONTROLLER MAPPING): detects Xbox, DualShock 4, DualSense, Switch Pro and Steam pads (or pick the family yourself) and draws the pad with real button names and your layout. The button you press lights up. Tap a button on the picture to change it.",
            "NEW · 🔁 Step-by-step re-binding: choose the action, press the button, read what was recognised, then CONFIRM. Nothing is saved before you confirm. Warns when a button is already used. Optional 'also press together with' second action.",
            "NEW · 🧩 Control profiles in three layers: GAME → EMULATOR → GLOBAL → factory. Each layer stores only what you changed, so they never overwrite each other, and each row shows which layer it comes from. Built-in profiles and your own (save, copy, rename, apply, delete). RESET THIS LAYER and RESTORE FACTORY.",
            "NEW · ⌨ New actions for any button: four D-pad diagonals, next / previous save slot, show / hide on-screen buttons, vibration on / off (besides Save, Load, Menu, Fast-forward, Rewind).",
            "NEW · 📳 Vibration goes to the Phone, the Controller, Both or Off (menus and game separately, a game can override, controller strength). TEST DEVICES buzzes each device and shows what Android reports, so you can see which one really vibrates.",
            "NEW · 🕹 While a controller hides the touch buttons, the on-screen buttons stay drawn and light up when you press the real ones (not in Classic mode; can be switched off).",
            "NEW · 🖼 Two extra interface styles besides NORMAL: MANIA (like the Sonic Mania menus) and TILES (like Steam's Big Picture). Switch with the ◐ button in the top bar, rename them, or hide the button: SETTINGS ▸ SCREEN & LOOK ▸ Interface style.",
            "NEW · 👋 A longer tour with a language and look chooser on the second page, and new HELP pages: Control layers & profiles, Interface styles, About this beta.",
            "IMPROVED · 🌍 The whole tour and every HELP page are now translated into all 12 languages (helper answers are still English only).",
            "FIXED · 🔧 The colour-picker bar that stopped the 0.3.5 build from compiling; a missing comma in the tour source.",
            "FIXED · ♥ Favourites update at once (list, counter and the heart on the song).",
            "FIXED · 🎵 The queue stays open when you pick a song; the mini player takes no space when hidden and can be closed; music pauses when headphones disconnect.",
            "FIXED · 🕹 Master System: the Pause button (ST) and buttons 1 / 2 are labelled correctly; A and C both act as button 2.",
            "FIXED · 🎨 Default text colour follows the skin (the storage page was black); LOCATIONS buttons scroll sideways.")),
        Release("0.3.5", "Tilt & Queue", "Nov 2026", listOf(
            "🧊 Tilt (cartridge glitch): six modes (Loose, Hot, Dying, Overheating, Meltdown, Total chaos), a crash-safe switch, SET / RESTORE SAFE POINT, no forced shader, and a coloured ● T badge in the top bar. Warning: tilting can damage saves made during or after it",
            "🎮 Game screen: the top bar explained (menu, lock, awake, α, UI, tilt, hide), UI can be hidden but still touchable, RESET GAME in the menu, the picture stays below the status bar in portrait, one small menu button in classic mode (can be hidden; Back opens the menu)",
            "💾 Save slots show ○ empty / ● saved / ■ latest with date and time; LOAD PREVIOUS SAVE",
            "🎨 Look for games: choose MY OWN SET (default, every game looks the same) or EACH GAME'S OWN SET; shaders no longer come bundled with skins; anime outline is now thin",
            "🎵 Player: BACK now goes to the previous song in the list (history only while shuffling), NOW n/total and JUMP, REORDER with a hint, COPY TO / MOVE TO playlist, mini player with swipe, peek list and scrolling titles, 2 more equalizers, queue as a bottom sheet",
            "🌸 Effects: smoother motion, a sakura-petal effect, a low-power switch; the scene under a game no longer skips rings during a spin-dash",
            "🗂 LOCATIONS: Sega CD BIOS library (choose which file acts as USA / Europe / Japan), OPEN IN APP for every folder; SETTINGS: storage used by SonicForge with a clear-cache button; text and picture files are never imported as games",
            "🧾 Logs: EMU tab with two optional switches (record emulator activity, only while tilting); Flash now reports page errors and missing files in the log",
            "📖 HELP: Sega CD guide (BIOS, regions, the 'RAM cartridge is not initialized' message)")),
        Release("0.3.4", "Rock Solid Rings", "Nov 2026", listOf(
            "🎨 DRAW tab (new): pixel-art canvas with layers (show/hide, opacity, CLIP to the layer below), pencil / eraser / fill / eyedropper, zoom and pan, add a picture onto a layer or as a new layer, resize the canvas, undo, export PNG. Your drawing is saved and reopens next time",
            "🔊 Menu sounds: they only play when you tap something (the little scene under a game used to make them by itself); a new sound pack applies at once, no preview needed; sounds are prepared in the background",
            "🔧 GAMES RUN AGAIN: importing a ROM, ZIP, RAR or 7z really saves the game now (the save step was switched off by mistake in 0.3.3, so the core 'rejected' every ROM). A game whose file is missing is flagged and is repaired by importing it again",
            "💽 Sega CD BIOS: any BIOS dump works whatever its file name; you can pick a whole zip of them. The app reads the region from the file itself and installs it under the name the core needs",
            "🕹 Mini-games no longer crash (an endless loop in the hero colour code). The little scene under a game no longer makes sounds by itself",
            "🎵 Music: the screen can't freeze or crash any more (song details load in the background, the list changes safely), 600+ songs are fine; shuffle plays every song once per round and BACK returns to the songs you really heard; QUEUE panel (what played, what is next); favourites ♥ and built-in lists (Recent, Imported, Built-in, Linked folder); MOVE mode; adding music while a playlist is open puts it into that playlist; a hide-able mini player on every tab; the current song and the list can no longer get out of step after an import",
            "🧾 Logs: every pop-up is also kept in full (NOTICES tab), COPY / SAVE FILE / SHARE for the whole log, one entry, or only errors; the app now records freezes ('not responding') and why the last run ended",
            "🕹 Flash (experimental): Ruffle is now downloaded in two ways at build time; full see-through keyboard over the game (⌨), a key for every gamepad button, left stick/D-pad as arrows, WASD or mouse, touchpad mouse mode",
            "🎛 Sliders: ↺ back to default and tap the number to type an exact value; moving a screen margin shows the real picture area on your screen; vibration test tells you what it did and has RESET ALL",
            "🧭 Settings re-organised: SCREEN & LOOK, SOUND & MUSIC, ABOUT & UPDATES hold everything of their kind; LOCATIONS can BROWSE every app folder; the 'show game UI again' button moved to SETTINGS ▸ GENERAL",
            "📲 Quick Settings tiles: Launcher, Music play/pause, Last game, Ask a character (pull down the shade, tap the pencil, drag a tile in)",
            "🌐 The language switch always shows an English 'Languages' under it (so you can find it in any language); welcome title translated into every language; darker 'Are you sure?' pop-ups; MD/SMS/GG explained",
            "🧰 Build: 7z and RAR4 archives are read; build.yml updated (copy it from SETTINGS ▸ ABOUT & UPDATES) so Ruffle is really included; three APKs per build")),
        Release("0.3.3", "Emerald Everything Plus", "Nov 2026", listOf(
            "🛠 Build stability: no experimental Compose API any more (own swipe pages); one build now makes THREE APKs: Universal, arm64-v8a, armeabi-v7a",
            "📺 Android TV / remote basics (same APK), minimum Android 8.0 stated; ABI and Android info in ABOUT APP",
            "🎮 Systems: Mega Drive, Master System, Game Gear, Sega CD (BIOS needed), optional 32X and Game Boy Advance cores, OpenBOR via its own app with a CPU-match report, Flash games through Ruffle (experimental)",
            "🕹 Flash: touch mouse or touchpad mode (tap, two-finger right-click and scroll, hold buttons), gamepad sticks as arrows/WASD/mouse, on-screen key sets, quality/scale/resolution",
            "⏯ Two-step pause menu that freezes the game; mini music player, vibration, cheats, screen, controls and tools inside it",
            "🕹 Controls: 7 ready-made layouts (close 6-button, GBA) + 6 of your own, gamepad/keyboard maps with APPLY/CANCEL/RESET, combos, controller visualisation, opacity per orientation, Pocket Lock, Stay Awake, quick opacity, UI rescue button",
            "📳 Vibration: 18 events (rings, hits, jump, spin dash, springs, Tails flying, drowning, ring bite and drain, extra life, shields, speed shoes, footsteps), templates, presets, per-game switches, Ring Finder for any game",
            "🎚 Volumes up to 200% with snap, -1/+1 and reset; music in game never restarts your song; 3 menu sound packs",
            "🎵 Music: playlists (merge/ungroup/reorder), multi-select, sorting, covers, equalizers, ±10/30 s, scratch disc, details toggles, failed-import list with reasons, background notification + headphone multi-click, 2-minute test track",
            "🧩 11 mini-games with pause, mute, best, rules, 3-2-1-GO; Speed Cafe uses real menu names; the scene under each game really collects rings; 28 colour palettes",
            "🎨 22 shaders (incl. a lighter bloom), 18 skins, effects behind the game, screen margins/corners/classic mode with a preview, FPS counters (emulated vs screen)",
            "🧑‍🤝‍🧑 9 helpers with 110+ answers (Tails in three depths), character-led tutorial with skip confirmation, Classic/Pro mode, confirmations with delay",
            "🗂 LOCATIONS tab, LIGHT/FULL named backups, logs and crash reports with explanations in two languages (hidden near the version), 13 languages incl. Brazilian Portuguese, Korean, Hindi, Turkish")),
        Release("0.2.0", "Archives n' Cheats", "Oct 2026", listOf(
            "📦 Import ROMs from .zip, .rar and .7z; link a ROM folder; IPS/BPS patches", "🔑 Per-game cheats", "⏪ Rewind, fast-forward, 6-button option, screenshots",
            "🎨 RGB colour pickers, per-game shader/skin/layout/music", "🕹 Tails Flyer and Zone Trivia", "🌍 10 languages, guide, version history")),
        Release("0.1.0", "Customisation n' Blue", "Oct 2026", listOf(
            "First release: launcher with per-game art, mini-scenes", "Genesis Plus GX emulation with saves, save states, FPS control",
            "9 shaders, 10 skins, touch-control editor with 6 presets, controller remapping", "Retro music player, custom launcher sounds, independent volumes, vibration, no INTERNET permission")),
    )
    val unfinished = listOf(
        "Translations of the What's new text, the tutorial, help topics and character dialogues (only buttons and titles are translated)",
        "Music: more equalizer styles, two more player looks, one 'all characters' guide, playlist covers, lyrics/timestamps, karaoke",
        "Image import: recommended sizes and a small crop editor (like changing a Discord avatar) that keeps no unused copies",
        "Console cores: Nintendo DS, SRB2, 3DS/Saturn/Dreamcast are not included (see HELP ▸ systems for why)",
        "Android TV remote layout and an x86 build; home-screen widgets",
        "Holiday themes, gradient/image backgrounds, PNG-mask frames, per-tab presets",
        "Hack-specific vibration profiles (Sonic 2 XL, Hellfire Saga...), wind in Sky Battery, breakable walls")
    val planned = listOf(
        "Drawing tab, round two: brush shapes, selection/move, layer folders, blend modes, a gallery of several drawings",
        "Simple text editor and a file explorer (multi-select, format groups, hidden/system toggle)",
        "Comics reader (Kotatsu-style), photo gallery, video player (YouTube-style controls)",
        "Music: Auxio / YouTube Music style library (songs, albums, artists, genres, playlists with pictures)",
        "Flash: per-game control profiles, Ruffle updates")
}

fun copyText(ctx: Context, t: String) { (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("log", t)); Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show() }

@Composable
fun AboutTab() {
    val ctx = LocalContext.current; val skin = Skins.current()
    val (ver, code) = remember { try { val i = ctx.packageManager.getPackageInfo(ctx.packageName, 0); (i.versionName ?: "?") to (if (Build.VERSION.SDK_INT >= 28) i.longVersionCode else @Suppress("DEPRECATION") i.versionCode.toLong()) } catch (_: Exception) { "?" to 0L } }
    val rel = Changelog.all.first(); var taps by remember { mutableIntStateOf(0) }; var logs by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(Modifier.size(84.dp).clip(RoundedCornerShape(20.dp))) {   // the Chaos-Emerald gem logo
            val w = size.width; drawRect(Color(0xFF0B1F3A))
            val gem = Path().apply { moveTo(w * .33f, w * .3f); lineTo(w * .67f, w * .3f); lineTo(w * .8f, w * .47f); lineTo(w * .5f, w * .79f); lineTo(w * .2f, w * .47f); close() }
            drawPath(gem, Color(0xFF1DE9B6)); drawPath(gem, Color.White, style = Stroke(w * .03f))
            drawLine(Color.White, Offset(w * .2f, w * .47f), Offset(w * .8f, w * .47f), w * .025f); drawLine(Color.White, Offset(w * .33f, w * .3f), Offset(w * .41f, w * .47f), w * .025f); drawLine(Color.White, Offset(w * .67f, w * .3f), Offset(w * .59f, w * .47f), w * .025f)
        }
        Text("SonicForge", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 8.dp))
        Text("Version $ver  ·  “${rel.name}”", color = skin.accent, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { taps++; if (taps >= 5) { taps = 0; logs = true } }.padding(6.dp))
        Text("build $code", color = Color(0xDDFFFFFF), fontSize = 11.sp)
        Btn(if (EngineLog.on()) "ENGINE LOG: ON (tap to switch off)" else "ENGINE LOG: OFF (tap to open it again)", Modifier.padding(top = 6.dp)) { Store.setB("engineLog", !EngineLog.on()); Store.setB("engineLogMini", false) }
    }
    Btn("OPEN GUIDE", Modifier.fillMaxWidth()) { Guide.show = true }
    H("Your device & which APK")
    val abis = Build.SUPPORTED_ABIS.joinToString(); val is64 = Build.SUPPORTED_64_BIT_ABIS.isNotEmpty()
    Text("CPU types supported: $abis\nThis app is running as ${if (android.os.Process.is64Bit()) "64-bit" else "32-bit"}.\nAndroid ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}). SonicForge needs Android 8.0 (API 26) or newer.", color = Color.White, fontSize = 12.sp)
    Text(if (is64) "Recommended APK: arm64-v8a (or Universal)." else if (Build.SUPPORTED_ABIS.any { it.startsWith("armeabi") }) "Recommended APK: armeabi-v7a (or Universal)." else "Your CPU isn't ARM: use the Universal APK (the emulator cores may not run).", color = skin.accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    Text("Universal = works everywhere, largest. arm64-v8a = nearly all phones since about 2017, smaller. armeabi-v7a = older 32-bit phones. Android TV uses the same APK.", color = Color(0xE6FFFFFF), fontSize = 11.sp)
    H("Credits & licences")
    Text("Emulation: Genesis Plus GX, PicoDrive and mGBA (libretro cores, their own licences; Genesis Plus GX is non-commercial). Archives: junrar, Apache Commons Compress, XZ for Java.\nNo ROMs, no ads, no internet permission.", color = Color(0xCCFFFFFF), fontSize = 12.sp)
    if (logs) LogsDialog { logs = false }
}

@Composable
fun UpdatesTab() {
    val skin = Skins.current()
    var open by remember { mutableStateOf(setOf(Changelog.all.first().version)) }
    H("Version history")
    Changelog.all.forEach { r ->
        val isOpen = r.version in open
        Column(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(12.dp)).background(Color.Black.copy(.4f)).forgeClick { open = if (isOpen) open - r.version else open + r.version }.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("v${r.version}  “${r.name}”", color = skin.accent, fontWeight = FontWeight.Black); Text(r.date, color = Color(0xDDFFFFFF), fontSize = 11.sp) }
                Text(if (isOpen) "▲" else "▼", color = Color.White)
            }
            if (isOpen) r.items.forEach { Text("• " + I18n.tr(it), color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp)) }
        }
    }
    H("Not finished yet (carried over)")
    Changelog.unfinished.forEach { Text("• " + I18n.tr(it), color = Color(0xCCFFCC80), fontSize = 12.sp, modifier = Modifier.padding(vertical = 2.dp)) }
    H("Planned for later builds")
    Changelog.planned.forEach { Text("• " + I18n.tr(it), color = Color(0xCCFFFFFF), fontSize = 12.sp, modifier = Modifier.padding(vertical = 2.dp)) }
    H("Build workflow file (build.yml)")
    val wctx = androidx.compose.ui.platform.LocalContext.current
    Text("GitHub only reads the workflow from the REPOSITORY ROOT, not from inside SonicForge.zip. After every update that changes the build steps, replace the file in your repo with this one.", color = Color(0xCCFFFFFF), fontSize = 12.sp)
    Text("Path in your repo:  .github/workflows/build.yml", color = skin.accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    Btn("COPY build.yml (zip method)") {
        val txt = try { wctx.assets.open("build-workflow.yml").bufferedReader().readText() } catch (e: Exception) { "" }
        if (txt.isNotEmpty()) { (wctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("build.yml", txt)); com.sonicforge.data.Store.events.tryEmit(com.sonicforge.data.SaveEvent("build.yml copied (${txt.length} characters). Paste it into .github/workflows/build.yml in your repo.", true)) }
    }
}
