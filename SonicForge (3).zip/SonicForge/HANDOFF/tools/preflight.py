import re,sys,os,glob
root=sys.argv[1]
# symbol -> required import (extension/top-level functions people forget)
NEED={
 'detectDragGestures':'androidx.compose.foundation.gestures.detectDragGestures','detectTapGestures':'androidx.compose.foundation.gestures.detectTapGestures',
 'detectHorizontalDragGestures':'androidx.compose.foundation.gestures.detectHorizontalDragGestures','detectVerticalDragGestures':'androidx.compose.foundation.gestures.detectVerticalDragGestures',
 'pointerInput':'androidx.compose.ui.input.pointer.pointerInput','onKeyEvent':'androidx.compose.ui.input.key.onKeyEvent','rotate':'androidx.compose.ui.graphics.drawscope.rotate',
 'translate':'androidx.compose.ui.graphics.drawscope.translate','withFrameNanos':'androidx.compose.runtime.withFrameNanos','produceState':'androidx.compose.runtime.produceState',
 'rememberLauncherForActivityResult':'androidx.activity.compose.rememberLauncherForActivityResult','rememberPagerState':'androidx.compose.foundation.pager.rememberPagerState',
 'clip':'androidx.compose.ui.draw.clip','alpha':'androidx.compose.ui.draw.alpha','horizontalScroll':'androidx.compose.foundation.horizontalScroll','verticalScroll':'androidx.compose.foundation.verticalScroll',
 'rememberScrollState':'androidx.compose.foundation.rememberScrollState','asImageBitmap':'androidx.compose.ui.graphics.asImageBitmap','background':'androidx.compose.foundation.background',
}
EXP_LAYOUT=['statusBarsIgnoringVisibility','FlowRow','FlowColumn','ExperimentalLayoutApi']
EXP_FOUND=['HorizontalPager','VerticalPager','rememberPagerState','stickyHeader','combinedClickable','LazyVerticalStaggeredGrid']
bad=0
for f in glob.glob(root+'/**/*.kt',recursive=True):
    s=open(f).read(); body=re.sub(r'"(?:\\.|[^"\\])*"','""',s)
    imps=set(re.findall(r'^import\s+([\w.]+\*?)',s,re.M))
    pkg=re.search(r'^package\s+([\w.]+)',s,re.M).group(1)
    def has(imp):
        if imp in imps: return True
        base=imp.rsplit('.',1)[0]+'.*'
        return base in imps
    for sym,imp in NEED.items():
        for m in re.finditer(r'(?<![\w.])'+sym+r'\s*[({]',body):
            # defined locally?
            if re.search(r'fun\s+(?:[\w.<>]+\.)?'+sym+r'\b',body): break
            if not has(imp): print('MISSING IMPORT',os.path.basename(f),sym,'->',imp); bad+=1; break
    # qualified extension misuse
    for m in re.finditer(r'androidx\.compose\.[\w.]*\.(detect\w+Gestures|pointerInput|clickable)\(',body): print('QUALIFIED EXTENSION CALL',os.path.basename(f),m.group(0)); bad+=1
    for sym in EXP_LAYOUT:
        if re.search(r'\b'+sym+r'\b',body) and 'OptIn' not in s and sym!='ExperimentalLayoutApi': print('NEEDS @OptIn(ExperimentalLayoutApi)',os.path.basename(f),sym); bad+=1; break
    for sym in EXP_FOUND:
        if re.search(r'\b'+sym+r'\b',body) and 'ExperimentalFoundationApi' not in s: print('NEEDS @OptIn(ExperimentalFoundationApi)',os.path.basename(f),sym); bad+=1; break
print('preflight problems:',bad)
