cmake_minimum_required(VERSION 3.22.1)
project(bridge CXX)
add_library(bridge SHARED bridge.cpp)
target_link_libraries(bridge log dl)
