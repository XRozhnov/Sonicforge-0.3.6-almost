package com.sonicforge.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.sonicforge.data.Logger
import com.sonicforge.data.Store
import java.io.File

/**
 * Pinch-to-zoom + drag + double-tap zoom. One finger is only taken over while zoomed in, so a pager around it still swipes normally at 100 %.
 * [onTap] gets the tap position and the size of the box (used for "tap the left/right edge to turn the page"). Written, not compiled.
 */
@Composable
fun ZoomBox(modifier: Modifier = Modifier, resetKey: Any? = null, onTap: (Offset, IntSize) -> Unit = { _, _ -> }, content: @Composable () -> Unit) {
    var scale by remember { mutableFloatStateOf(1f) }
    var off by remember { mutableStateOf(Offset.Zero) }
    var size by remember { mutableStateOf(IntSize.Zero) }
    LaunchedEffect(resetKey) { scale = 1f; off = Offset.Zero }
    fun clampOff(o: Offset, s: Float): Offset { val mx = size.width * (s - 1f) / 2f; val my = size.height * (s - 1f) / 2f; return Offset(o.x.coerceIn(-mx, mx), o.y.coerceIn(-my, my)) }
    Box(modifier.onSizeChanged { size = it }
        .pointerInput(Unit) { detectTapGestures(onTap = { p -> onTap(p, size) }, onDoubleTap = { if (scale > 1f) { scale = 1f; off = Offset.Zero } else scale = 2.5f }) }
        .pointerInput(Unit) {
            awaitEachGesture {
                awaitFirstDown(requireUnconsumed = false)
                do {
                    val ev = awaitPointerEvent()
                    val z = ev.calculateZoom(); val p = ev.calculatePan()
                    if (ev.changes.size > 1 || scale > 1f) {
                        val ns = (scale * z).coerceIn(1f, 6f)
                        scale = ns; off = clampOff(off + p, ns)
                        ev.changes.forEach { if (it.positionChanged()) it.consume() }
                    }
                } while (ev.changes.any { it.pressed })
            }
        }
        .graphicsLayer { scaleX = scale; scaleY = scale; translationX = off.x; translationY = off.y }) { content() }
}

object ImageOps {
    fun load(f: File, max: Int = 4096): Bitmap? = try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }; BitmapFactory.decodeFile(f.path, o)
        var s = 1; while (o.outWidth / s > max || o.outHeight / s > max) s *= 2
        BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
    } catch (_: Throwable) { null }

    fun rotated(b: Bitmap, rot: Int, flip: Boolean): Bitmap {
        if (rot % 360 == 0 && !flip) return b
        val m = Matrix(); m.postRotate(rot.toFloat()); if (flip) m.postScale(-1f, 1f)
        return Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
    }
    /** crop fractions are the share removed from each side (0..0.9) */
    fun cropped(b: Bitmap, l: Float, t: Float, r: Float, bt: Float): Bitmap {
        if (l <= 0f && t <= 0f && r <= 0f && bt <= 0f) return b
        val x = (b.width * l).toInt().coerceIn(0, b.width - 1); val y = (b.height * t).toInt().coerceIn(0, b.height - 1)
        val w = (b.width * (1f - l - r)).toInt().coerceIn(1, b.width - x); val h = (b.height * (1f - t - bt)).toInt().coerceIn(1, b.height - y)
        return Bitmap.createBitmap(b, x, y, w, h)
    }
    fun save(b: Bitmap, target: File): Boolean = try {
        val png = target.extension.lowercase() == "png"
        target.outputStream().use { b.compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 95, it) }; true
    } catch (e: Exception) { Logger.e("Media", "could not save ${target.name}", e); false }
}

/** rotate / flip / crop a picture, then save a COPY (the default) or replace the original. GIFs are not edited (it would drop the animation). */
@Composable
fun ImageEditDialog(file: File, onDone: () -> Unit) {
    val src = remember(file.path) { ImageOps.load(file) }
    var rot by remember { mutableIntStateOf(0) }; var flip by remember { mutableStateOf(false) }
    var cl by remember { mutableFloatStateOf(0f) }; var ct by remember { mutableFloatStateOf(0f) }; var cr by remember { mutableFloatStateOf(0f) }; var cb by remember { mutableFloatStateOf(0f) }
    var askReplace by remember { mutableStateOf(false) }
    val isGif = file.extension.lowercase() == "gif"
    Dialog(onDismissRequest = onDone, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(Color(0xFF101018)).padding(12.dp)) {
            if (src == null || isGif) {
                Text(if (isGif) "GIFs are not edited here (the animation would be lost). You can still save a copy or share it." else "This picture could not be opened.", color = Color.White)
                Btn("CLOSE") { onDone() }
            } else {
                val base = remember(rot, flip) { ImageOps.rotated(src, rot, flip) }
                val preview = remember(rot, flip, cl, ct, cr, cb) { ImageOps.cropped(base, cl, ct, cr, cb) }
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Image(preview.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                }
                Text("${preview.width} × ${preview.height} px", color = Color(0xCCFFFFFF), fontSize = 11.sp)
                Column(Modifier.heightIn(max = 250.dp).verticalScroll(rememberScrollState())) {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Btn("⟲ 90°") { rot = (rot + 270) % 360 }; Btn("⟳ 90°") { rot = (rot + 90) % 360 }; Btn("⇋ FLIP", selected = flip) { flip = !flip }
                        Btn("RESET") { rot = 0; flip = false; cl = 0f; ct = 0f; cr = 0f; cb = 0f }
                    }
                    Text("CROP: ratio (centred)", color = Color(0xFFFFD54F), fontSize = 12.sp)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("FREE" to 0f, "1:1" to 1f, "4:3" to 4f / 3f, "3:4" to 3f / 4f, "16:9" to 16f / 9f, "9:16" to 9f / 16f).forEach { (n, a) ->
                            Btn(n) {
                                if (a == 0f) { cl = 0f; ct = 0f; cr = 0f; cb = 0f } else {
                                    val w = base.width.toFloat(); val h = base.height.toFloat()
                                    if (w / h > a) { val k = (1f - h * a / w) / 2f; cl = k; cr = k; ct = 0f; cb = 0f } else { val k = (1f - w / a / h) / 2f; ct = k; cb = k; cl = 0f; cr = 0f }
                                }
                            }
                        }
                    }
                    listOf("LEFT" to 0, "TOP" to 1, "RIGHT" to 2, "BOTTOM" to 3).forEach { (n, i) ->
                        val v = when (i) { 0 -> cl; 1 -> ct; 2 -> cr; else -> cb }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("$n ${(v * 100).toInt()}%", color = Color.White, fontSize = 11.sp, modifier = Modifier.width(92.dp))
                            Slider(v, { x -> when (i) { 0 -> cl = x; 1 -> ct = x; 2 -> cr = x; else -> cb = x } }, valueRange = 0f..0.8f, modifier = Modifier.weight(1f))
                        }
                    }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Btn("💾 SAVE AS COPY", selected = true) {
                        val ext = if (file.extension.lowercase() == "png") "png" else "jpg"
                        val t = Media.unique(file.parentFile ?: Media.root, file.nameWithoutExtension + "_edit." + ext)
                        if (ImageOps.save(preview, t)) Logger.notice("Saved a copy: ${t.name}") else Logger.notice("Could not save the copy", false)
                        Media.tick++; onDone()
                    }
                    Btn("REPLACE ORIGINAL", color = Color(0xFFE53935)) { askReplace = true }
                    Btn("CANCEL") { onDone() }
                }
                if (askReplace) ConfirmDialog("Replace the original?", "Overwrites ${file.name} with the edited picture.", "Use SAVE AS COPY to keep the original.", onYes = {
                    if (ImageOps.save(preview, file)) Logger.notice("Replaced ${file.name}") else Logger.notice("Could not save", false)
                    askReplace = false; Media.tick++; onDone() }, onNo = { askReplace = false })
            }
        }
    }
}

/** reorder / delete the pages of a comic. Saving renames the files 0001, 0002, ... so the order sticks. */
@Composable
fun ComicPagesDialog(dir: File, onDone: () -> Unit) {
    val original = remember(dir.path) { Media.list(dir, "img") }
    var order by remember { mutableStateOf(original) }
    fun swap(i: Int, j: Int) { if (j !in order.indices) return; val m = order.toMutableList(); val t = m[i]; m[i] = m[j]; m[j] = t; order = m }
    Dialog(onDismissRequest = onDone, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(Color(0xFF101018)).padding(12.dp)) {
            Text("PAGES of ${dir.name}", color = Color.White, fontWeight = FontWeight.Black)
            Text("Move pages with ▲ ▼ (⤒ puts a page first). Press SAVE to apply. ✕ removes a page when you save.", color = Color(0xCCFFFFFF), fontSize = 11.sp)
            LazyColumn(Modifier.weight(1f)) {
                itemsIndexed(order) { i, f ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp).clip(RoundedCornerShape(8.dp)).background(Color.Black.copy(.35f)).padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Thumb(f, 120, Modifier.size(44.dp, 60.dp).clip(RoundedCornerShape(4.dp)))
                        Text("${i + 1}.  ${f.name}", color = Color.White, fontSize = 12.sp, maxLines = 1, modifier = Modifier.weight(1f).padding(start = 8.dp))
                        Text("⤒", color = Color.White, modifier = Modifier.forgeClick { if (i > 0) { val m = order.toMutableList(); m.add(0, m.removeAt(i)); order = m } }.padding(10.dp))
                        Text("▲", color = Color.White, modifier = Modifier.forgeClick { swap(i, i - 1) }.padding(10.dp))
                        Text("▼", color = Color.White, modifier = Modifier.forgeClick { swap(i, i + 1) }.padding(10.dp))
                        Text("✕", color = Color(0xFFFFCDD2), modifier = Modifier.forgeClick { order = order.filter { it != f } }.padding(10.dp))
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 6.dp)) {
                Btn("SAVE", selected = true) {
                    try {
                        original.filter { it !in order }.forEach { it.delete() }
                        order.forEachIndexed { i, f -> f.renameTo(File(dir, ".r$i.${f.extension}")) }
                        order.forEachIndexed { i, f -> File(dir, ".r$i.${f.extension}").renameTo(File(dir, "%04d.%s".format(i + 1, f.extension))) }
                    } catch (e: Exception) { Logger.notice("Could not reorder: ${e.message}", false) }
                    Media.tick++; onDone()
                }
                Btn("CANCEL") { onDone() }
            }
        }
    }
}


/** GIF / animated WebP that the user can start and stop. q = sample size (1 original, 2, 4, 8 = smaller picture, lighter on weak phones). Decoding runs in the background. Android 9+ (older: first frame). */
fun isGifFile(f: java.io.File): Boolean = f.extension.lowercase().let { it == "gif" || it == "webp" } && try { f.inputStream().use { i -> val h = ByteArray(12); i.read(h); (h[0] == 'G'.code.toByte() && h[1] == 'I'.code.toByte()) || (h[8] == 'W'.code.toByte() && h[9] == 'E'.code.toByte()) } } catch (_: Exception) { false }

@androidx.compose.runtime.Composable
fun GifPicture(file: java.io.File, q: Int, playing: Boolean, modifier: Modifier) {
    val dr by androidx.compose.runtime.produceState<android.graphics.drawable.Drawable?>(null, file.path, q) {
        value = null
        value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            try { if (android.os.Build.VERSION.SDK_INT < 28) null else android.graphics.ImageDecoder.decodeDrawable(android.graphics.ImageDecoder.createSource(file)) { dec, _, _ -> if (q > 1) dec.setTargetSampleSize(q) } }
            catch (e: Throwable) { com.sonicforge.data.Logger.w("Gif", "decode failed ${file.name}: $e"); null } }
    }
    androidx.compose.ui.viewinterop.AndroidView(factory = { c -> android.widget.ImageView(c).apply { scaleType = android.widget.ImageView.ScaleType.FIT_CENTER } },
        update = { iv ->
            val d = dr
            if (iv.drawable !== d && d != null) iv.setImageDrawable(d)
            (d as? android.graphics.drawable.AnimatedImageDrawable)?.let { a -> if (playing) { a.repeatCount = android.graphics.drawable.AnimatedImageDrawable.REPEAT_INFINITE; if (!a.isRunning) a.start() } else if (a.isRunning) a.stop() }
        }, modifier = modifier)
}


/** Page of one comic: cover + title (can be hidden), START / CONTINUE / INCOGNITO buttons (can be hidden), then the page list (tap a page to read from there). Comics here have pages, not chapters. */
@androidx.compose.runtime.Composable
fun ComicDetail(c: java.io.File, onBack: () -> Unit, onRead: (Int, Boolean) -> Unit, onPages: () -> Unit) {
    val pages = Media.list(c, "img"); val saved = Store.i("cm_" + c.name, 0).coerceIn(0, (pages.size - 1).coerceAtLeast(0))
    val showHdr = Store.b("cmHdr", true); val showBtns = Store.b("cmBtns", true); val showList = Store.b("cmList", true)
    androidx.compose.foundation.lazy.LazyColumn(Modifier.fillMaxSize()) {
        item { androidx.compose.foundation.layout.Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Btn("◀ COMICS") { onBack() }; Btn("PAGES / ORDER") { onPages() }
            Btn(if (showHdr) "COVER+TITLE: SHOWN" else "COVER+TITLE: HIDDEN", selected = showHdr) { Store.setB("cmHdr", !showHdr) }
            Btn(if (showBtns) "READ BUTTONS: SHOWN" else "READ BUTTONS: HIDDEN", selected = showBtns) { Store.setB("cmBtns", !showBtns) }
            Btn(if (showList) "PAGE LIST: SHOWN" else "PAGE LIST: HIDDEN", selected = showList) { Store.setB("cmList", !showList) } } }
        if (showHdr) item { androidx.compose.foundation.layout.Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            pages.firstOrNull()?.let { Thumb(it, 420, Modifier.size(110.dp, 150.dp).clip(RoundedCornerShape(10.dp))) }
            Column(Modifier.padding(start = 12.dp)) { Text(c.name, color = Color.White, fontWeight = FontWeight.Black, fontSize = 20.sp); Text("${pages.size} pages · you are on page ${saved + 1}", color = Color(0xCCFFFFFF), fontSize = 12.sp) } } }
        if (showBtns) item { androidx.compose.foundation.layout.Row(Modifier.horizontalScroll(rememberScrollState()).padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Btn("▶ START READING", selected = true) { onRead(0, false) }
            if (saved > 0) Btn("⏵ CONTINUE (page ${saved + 1})") { onRead(saved, false) }
            Btn("🕶 INCOGNITO") { onRead(saved, true) } }
            Text("Incognito reads without remembering your page.", color = Color(0x99FFFFFF), fontSize = 10.sp) }
        if (showList) items(pages.size) { i -> androidx.compose.foundation.layout.Row(Modifier.fillMaxWidth().padding(vertical = 2.dp).clip(RoundedCornerShape(8.dp)).background(Color.Black.copy(.3f)).forgeClick { onRead(i, false) }.padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
            Thumb(pages[i], 160, Modifier.size(40.dp, 54.dp).clip(RoundedCornerShape(4.dp)))
            Text("Page ${i + 1}" + if (i == saved) "  ◀ you are here" else "", color = Color.White, modifier = Modifier.padding(start = 10.dp)) } }
    }
}
