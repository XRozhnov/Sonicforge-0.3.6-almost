package com.sonicforge.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonicforge.data.Store

/**
 * Setup of the on-screen keys for Flash games. Shared by the Flash in-game menu and SETTINGS > CONTROLS > FLASH KEYS.
 * "custom" layout: pick the direction keys (arrows / WASD / none) and up to 4 action buttons, each with any key.
 * Written, not compiled, not tried on a device.
 */
object FlashKeys {
    val ACTION_CHOICES = listOf("NONE", "SPACE", "ENTER", "ESC", "TAB", "SHIFT", "CTRL", "ALT", "Z", "X", "C", "V", "A", "S", "D", "F", "Q", "W", "E", "R", "1", "2", "3", "4", "UP", "DOWN", "LEFT", "RIGHT")
    fun def(slot: Int) = when (slot) { 1 -> "SPACE"; 2 -> "Z"; 3 -> "X"; else -> "NONE" }
    fun action(slot: Int): String = Store.s("fk_a$slot").ifEmpty { def(slot) }
}

@Composable
fun FlashKeySetup(full: Boolean = true) {
    if (full) FlashKeyTop()
    if (Store.s("flashKeys", "arrows+space") == "custom") FlashKeyCustom()
    if (full) { SSlider("Key size", "flashKeyScale", 100, 200); SSlider("On-screen key opacity", "flashKeyAlpha", 60) }
}

@Composable
private fun FlashKeyTop() {
    H("Flash: on-screen keys")
    Text("Layout of the touch keys inside Flash games. Choose a ready layout or CUSTOM to pick every key yourself. The same list is in the game's own CONTROLS menu.", color = Color(0xCCFFFFFF), fontSize = 11.sp)
    SToggle("Show on-screen keys", "flashPadOn", true)
    SChips("Layout", "flashKeys", "arrows+space", listOf("arrows+space" to "Arrows + Space/Enter", "wasd" to "WASD + Space", "zx" to "Arrows + Z X C", "movie" to "Movie (Space/Enter/Esc)", "custom" to "CUSTOM (my own)", "none" to "None (mouse only)"))
}

@Composable
private fun FlashKeyCustom() {
    run {
        SChips("Direction keys", "fk_dir", "arrows", listOf("arrows" to "Arrow keys", "wasd" to "W A S D", "none" to "None"))
        Text("Action buttons (right side). Tap a box to pick the key it presses; NONE hides the button.", color = Color(0xAAFFFFFF), fontSize = 11.sp)
        for (n in 1..4) {
            var open by remember { mutableStateOf(false) }; var tick by remember { mutableIntStateOf(0) }
            @Suppress("UNUSED_VARIABLE") val t = tick
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
                Text("Button $n", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.width(90.dp))
                Box { Btn(FlashKeys.action(n)) { open = true }
                    DropdownMenu(open, { open = false }) { FlashKeys.ACTION_CHOICES.forEach { c -> DropdownMenuItem({ Text(c) }, { Store.set("fk_a$n", c); open = false; tick++ }) } } }
            }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Btn("PLATFORMER") { Store.set("fk_a1", "SPACE"); Store.set("fk_a2", "Z"); Store.set("fk_a3", "X"); Store.set("fk_a4", "NONE") }
            Btn("FIGHTER") { Store.set("fk_a1", "Z"); Store.set("fk_a2", "X"); Store.set("fk_a3", "C"); Store.set("fk_a4", "V") }
            Btn("RESET") { for (n in 1..4) Store.set("fk_a$n", "") }
        }
    }
}
