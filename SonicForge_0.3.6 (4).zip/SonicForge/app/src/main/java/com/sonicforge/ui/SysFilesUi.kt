package com.sonicforge.ui

import android.content.Context
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonicforge.data.*
import java.io.File
import kotlin.concurrent.thread

/** SYSTEM FILES (BIOS / firmware): one place for every system. Files are recognised by size and name (a .zip is opened), copied under the name the emulator core looks for. Written, not compiled. */
object SysFiles {
    /** which files each system's core looks for in the app's system folder */
    val targets: Map<String, List<String>> = mapOf(
        "nds" to listOf("bios7.bin", "bios9.bin", "firmware.bin"), "gba" to listOf("gba_bios.bin"), "gb" to listOf("gb_bios.bin", "gbc_bios.bin"),
        "nes" to listOf("disksys.rom"), "scd" to listOf("bios_CD_U.bin", "bios_CD_E.bin", "bios_CD_J.bin"))

    /** the name to install under, "SCD" for a Sega CD BIOS (handled by the Sega CD importer), or null when unknown */
    fun classify(name: String, size: Long): String? {
        val n = name.lowercase()
        return when {
            n.contains("biosgba") || n.contains("gba_bios") || (size == 16384L && n.contains("gba")) -> "gba_bios.bin"
            n.contains("bios7") || n.contains("arm7") -> "bios7.bin"
            n.contains("bios9") || n.contains("arm9") -> "bios9.bin"
            n.contains("firmware") || Regex("(^|[^a-z])fw[^a-z]|nds.*fw").containsMatchIn(n) -> "firmware.bin"
            size == 4096L && n.endsWith(".bin") -> "bios9.bin"
            size == 2304L -> "gbc_bios.bin"
            size == 256L && (n.contains("gb") || n.contains("dmg")) -> "gb_bios.bin"
            n.contains("disksys") || (size == 8192L && n.contains("fds")) -> "disksys.rom"
            size == 262144L || size == 524288L -> "firmware.bin"
            size in 0x10000L..0x100000L -> "SCD"
            else -> null
        }
    }

    /** installs the picked files (zip / 7z / rar are opened); reports what each file was recognised as */
    fun importUris(ctx: Context, uris: List<Uri>, done: () -> Unit = {}) = thread {
        val sys = File(ctx.filesDir, "system").also { it.mkdirs() }
        val ok = mutableListOf<String>(); val bad = mutableListOf<String>(); val scd = mutableListOf<Uri>()
        try {
            for (u in uris) {
                val ex = Archives.extractAll(ctx, listOf(u to Library.displayName(ctx, u)))
                var scdHere = false
                for (f in ex.files) {
                    val t = classify(f.name, f.length())
                    when {
                        t == null -> bad.add(f.name + " (" + f.length() + " B)")
                        t == "SCD" -> scdHere = true
                        else -> { f.copyTo(File(sys, t), true); ok.add(f.name + " → " + t); Logger.i("Import", "system file ${f.name} (${f.length()} bytes) installed as $t") }
                    }
                }
                if (scdHere) scd.add(u)
            }
        } catch (e: Exception) { Logger.notice("Could not read the file: ${e.message}", false) }
        if (scd.isNotEmpty()) { Library.addBios(ctx, scd); ok.add("Sega CD BIOS: handed to the Sega CD importer") }
        if (ok.isNotEmpty()) Logger.notice("Installed: " + ok.joinToString("; "))
        if (bad.isNotEmpty()) Logger.notice("Not recognised: " + bad.joinToString("; ") + ". Rename to the exact name (see the list) and add again.", false)
        done()
    }
}

/** the panel itself: with sys = null it lists every system (LOCATIONS), otherwise just that one (game page / tile menu) */
@Composable
fun SystemFilesPanel(sys: String? = null) {
    val ctx = LocalContext.current; var tick by remember { mutableIntStateOf(0) }; @Suppress("UNUSED_VARIABLE") val tk = tick
    val dir = File(ctx.filesDir, "system")
    val list = if (sys == null) NeedsInfo.all.keys.toList() else listOf(sys)
    Column(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
        Text("System files (BIOS / firmware)", fontWeight = FontWeight.Bold)
        Text("Add everything at once: the app recognises each file by its size and name and installs it under the right name. A .zip is opened (for example “NDS BIOS & Firmware.zip” with bios7.bin 16 KB, bios9.bin 4 KB, firmware.bin 128–512 KB, BIOSGBA.ROM 16 KB). Only your own dumps; nothing is downloaded.", fontSize = 11.sp, color = Color(0xCCFFFFFF))
        Btn("+ ADD SYSTEM FILES") { Picker.pick { u -> SysFiles.importUris(ctx, u) { tick++ } } }
        list.forEach { k ->
            val need = NeedsInfo.all[k] ?: return@forEach
            val t = SysFiles.targets[k]
            Column(Modifier.padding(top = 6.dp)) {
                Text(k.uppercase() + ": " + need.summary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                if (t != null) Text("Installed now: " + t.joinToString("   ") { n -> n + if (File(dir, n).exists()) " ✓" else " –" }, fontSize = 11.sp)
                need.items.forEach { Text("• ${it.level}: ${it.file} — ${it.looks}. Where: ${it.where}", fontSize = 10.sp, color = Color(0xAAFFFFFF)) }
                if (k == "nds") Text("Without them DS games start with a built-in replacement (the message about FreeBIOS is only information).", fontSize = 10.sp, color = Color(0xAAFFFFFF))
                if (t == null && k != "snes" && k != "psp") Text("This system runs in its own emulator: its files go into that emulator, not here.", fontSize = 10.sp, color = Color(0xAAFFFFFF))
            }
        }
        if (sys == "3ds" || sys == null) Text("About 3DS: it is not a system of the main app (it needs a separate heavy emulator and keys); it is planned for the Super edition.", fontSize = 10.sp, color = Color(0xAAFFFFFF))
    }
}

@Composable
fun SystemFilesDialog(sys: String, onClose: () -> Unit) {
    AlertDialog(onDismissRequest = onClose, containerColor = Color(0xFF0D0D14), titleContentColor = Color.White, textContentColor = Color.White,
        confirmButton = { TextButton(onClose) { Text("CLOSE") } }, title = { Text("SYSTEM FILES (BIOS)") },
        text = { Column(Modifier.verticalScroll(rememberScrollState())) { SystemFilesPanel(sys) } })
}
