package com.sonicforge.audio

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.Icon
import android.media.MediaMetadata
import android.media.MediaMetadataRetriever
import android.net.Uri
import java.io.File
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.KeyEvent
import com.sonicforge.MainActivity
import com.sonicforge.data.Store

/**
 * Keeps music playing in the background with a media notification, handles lock-screen/headphone buttons:
 * 1 press = play/pause, 2 presses = next, 3 presses = restart the song (or previous track if you're within the first 3 s).
 */
class MusicService : Service() {
    private var session: MediaSession? = null
    private val h = Handler(Looper.getMainLooper()); private var clicks = 0
    private val flush = Runnable { when (clicks) { 1 -> Music.toggle(); 2 -> Music.next(); else -> if (clicks >= 3) Music.prev() }; clicks = 0 }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CH, "Music", NotificationManager.IMPORTANCE_LOW))
        session = MediaSession(this, "SonicForge").apply {
            setCallback(object : MediaSession.Callback() {
                override fun onMediaButtonEvent(i: Intent): Boolean {
                    val e = i.getParcelableExtra<KeyEvent>(Intent.EXTRA_KEY_EVENT) ?: return false
                    if (e.action != KeyEvent.ACTION_DOWN || e.repeatCount > 0) return true
                    when (e.keyCode) {
                        KeyEvent.KEYCODE_HEADSETHOOK, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> { clicks++; h.removeCallbacks(flush); h.postDelayed(flush, 380) }
                        KeyEvent.KEYCODE_MEDIA_PLAY, KeyEvent.KEYCODE_MEDIA_PAUSE -> Music.toggle()
                        KeyEvent.KEYCODE_MEDIA_NEXT -> Music.next(); KeyEvent.KEYCODE_MEDIA_PREVIOUS -> Music.prev()
                        else -> return false
                    }
                    return true
                }
                override fun onSeekTo(pos: Long) { Music.seek(pos.toInt()); push() }
                override fun onPlay() = Music.toggle(); override fun onPause() = Music.toggle(); override fun onSkipToNext() = Music.next(); override fun onSkipToPrevious() = Music.prev()
            })
            isActive = true
        }
        live = this
        Music.onChange = { push() }
    }
    fun refresh() { try { push() } catch (_: Exception) {} }
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        when (i?.action) { A_TOGGLE -> Music.toggle(); A_NEXT -> Music.next(); A_PREV -> Music.prev(); A_STOP -> { Music.stop(); stopForeground(true); stopSelf(); return START_NOT_STICKY } }
        push(); return START_STICKY
    }
    private fun act(a: String, icon: Int, label: String): Notification.Action {
        val pi = PendingIntent.getService(this, a.hashCode(), Intent(this, MusicService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return Notification.Action.Builder(Icon.createWithResource(this, icon), label, pi).build()
    }
    private var artPath = ""; private var art: Bitmap? = null
    /** the album picture for the notification (loaded in the background, then the notification is refreshed once); off = no picture */
    private fun artFor(t: Track?): Bitmap? {
        if (t == null || !Store.b("notifCover", true)) { artPath = ""; art = null; return null }
        if (t.path == artPath) return art
        artPath = t.path; art = null
        val svc = this
        Thread {
            val bm: Bitmap? = try {
                val own = Store.s("cov_" + t.path)
                if (own.isNotEmpty() && File(own).exists()) BitmapFactory.decodeFile(own, BitmapFactory.Options().apply { inSampleSize = 2 })
                else { val r = MediaMetadataRetriever(); if (t.isUri) r.setDataSource(svc, Uri.parse(t.path)) else r.setDataSource(t.path)
                    val pic = r.embeddedPicture; r.release(); pic?.let { BitmapFactory.decodeByteArray(it, 0, it.size, BitmapFactory.Options().apply { inSampleSize = 2 }) } }
            } catch (_: Exception) { null }
            h.post { if (artPath == t.path) { art = bm; if (bm != null) push() } }
        }.start()
        return null
    }
    private fun push() {
        val t = Music.tracks.getOrNull(Music.current)
        val bm = artFor(t)
        val md = MediaMetadata.Builder().putString(MediaMetadata.METADATA_KEY_TITLE, t?.title ?: "SonicForge").putString(MediaMetadata.METADATA_KEY_ARTIST, if (t != null) Music.artist(t) else "").putLong(MediaMetadata.METADATA_KEY_DURATION, Music.dur().toLong())
        if (bm != null) md.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, bm)
        session?.setMetadata(md.build())
        session?.setPlaybackState(PlaybackState.Builder().setActions(PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or PlaybackState.ACTION_SEEK_TO)
            .setState(if (Music.playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED, Music.pos().toLong(), if (Music.playing) 1f else 0f).build())
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CH).setSubText(if (Music.playing) "▶ Playing" else "⏸ Paused") else @Suppress("DEPRECATION") Notification.Builder(this)
        b.setSmallIcon(android.R.drawable.ic_media_play).setContentTitle(t?.title ?: "SonicForge").setContentText(if (Music.playing) "Playing" else "Paused").setContentIntent(open).setOngoing(Music.playing).apply { if (bm != null) setLargeIcon(bm) }
            .addAction(act(A_PREV, android.R.drawable.ic_media_previous, "Previous"))
            .addAction(act(A_TOGGLE, if (Music.playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play, "Play/Pause"))
            .addAction(act(A_NEXT, android.R.drawable.ic_media_next, "Next"))
            .addAction(act(A_STOP, android.R.drawable.ic_menu_close_clear_cancel, "Close"))
            .setStyle(Notification.MediaStyle().setMediaSession(session?.sessionToken).setShowActionsInCompactView(0, 1, 2))
        val n = b.build()
        try { if (Build.VERSION.SDK_INT >= 29) startForeground(NID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK) else startForeground(NID, n) } catch (_: Exception) {}
    }
    override fun onDestroy() { live = null; Music.onChange = null; session?.release(); super.onDestroy() }

    companion object {
        @Volatile var live: MusicService? = null
        const val CH = "music"; const val NID = 7; const val A_TOGGLE = "sf.toggle"; const val A_NEXT = "sf.next"; const val A_PREV = "sf.prev"; const val A_STOP = "sf.stop"
        /** called when music starts: shows the notification service if the setting is on */
        fun ensure(ctx: Context) { if (!Store.b("musicNotif", true)) return; try { val i = Intent(ctx, MusicService::class.java); if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i) } catch (_: Exception) {} }
        fun stop(ctx: Context) { try { ctx.stopService(Intent(ctx, MusicService::class.java)) } catch (_: Exception) {} }
    }
}
