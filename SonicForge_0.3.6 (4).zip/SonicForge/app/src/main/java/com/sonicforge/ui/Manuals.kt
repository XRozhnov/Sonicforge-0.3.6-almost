package com.sonicforge.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * CONSOLE MANUALS: one illustrated "instruction booklet" page set per console, written in a light, fun voice.
 * Numbers are rounded and widely quoted figures; where a detail varies by region or version it says so.
 * English only for now (translations come later).
 */
class Manual(val id: String, val name: String, val tag: String, val color: Color, val pad: Int, val sections: List<Pair<String, String>>)

object Manuals {
    val all = listOf(
        Manual("md", "Mega Drive / Genesis", "16-bit · 1988", Color(0xFF1E88E5), 3, listOf(
            "Quick history" to "Released in Japan in October 1988 as the Mega Drive and in North America in 1989 as the Genesis. Sega's 16-bit answer to the NES era: a Motorola 68000 main chip with a Z80 helping on sound.",
            "Why it was loved" to "Arcade-style games, a punchy FM + PCM sound chip and a bold attitude ('Genesis does what Nintendon't'). Sonic the Hedgehog (1991) became the mascot that sold it.",
            "How it felt in 1990" to "Pictures: sharp sprites, fast scrolling, but only 64 colours on screen at once. Controls: a 3-button pad (A, B, C); the 6-button pad arrived with Street Fighter II. Performance: speed was the selling point, though big sprite counts could flicker.",
            "Popularity & sales" to "Roughly 30 million units are usually quoted worldwide. It did especially well in North America, Europe and Brazil; in Japan the Super Famicom was far ahead.",
            "In this app" to "Genesis Plus GX core. Sonic 1 level select (widely documented): on the title screen press Up, Down, Left, Right, then hold A and press Start. Sonic 2: Options ▸ sound test 19, 65, 09, 17, then hold A and press Start. Codes can differ between versions.",
            "Fun fact" to "The 6-button pad is why the app has X / Y / Z: three extra buttons on the shoulder side."
        )),
        Manual("sms", "Master System", "8-bit · 1985", Color(0xFFE53935), 2, listOf(
            "Quick history" to "Launched as the Mark III in Japan in 1985 and as the Master System in the West in 1986. An 8-bit rival to the NES.",
            "Why it mattered" to "Strong arcade ports and good colour for its day. It had an odd position: Nintendo dominated the US and Japan, while Europe and especially Brazil embraced Sega.",
            "How it felt" to "Pictures: bright colours, 32 on screen. Controls: a D-pad with two action buttons (1 and 2), and Pause on the console itself, which is why this app has a PAUSE button. Performance: smooth, simple.",
            "Popularity & sales" to "Commercially modest in Japan and the US but very successful in Brazil and parts of Europe, where local companies kept selling it for decades.",
            "Fun fact" to "Both action buttons are real game mechanics here: one jumps, the other often does something different, so keep both on screen."
        )),
        Manual("gg", "Game Gear", "Handheld · 1990", Color(0xFF8E24AA), 2, listOf(
            "Quick history" to "Sega's colour handheld: Japan 1990, North America 1991. Technically close to a pocket Master System.",
            "Why it mattered" to "A backlit colour screen when the Game Boy was still green and grey. The price was battery life: six AA batteries lasted only a few hours.",
            "How it felt" to "Pictures: colourful but small and sometimes smeary. Controls: D-pad, buttons 1 and 2, Start. Performance: smooth.",
            "Popularity & sales" to "Sold well enough to be second place behind the Game Boy, but far behind it. It saw a long list of Sonic spin-offs.",
            "Fun fact" to "Many games are Master System games reworked for the smaller screen."
        )),
        Manual("scd", "Sega CD / Mega-CD", "Add-on · 1991", Color(0xFF00897B), 3, listOf(
            "Quick history" to "A CD-ROM add-on for the Mega Drive: Japan 1991, North America 1992. It added more memory, extra graphics scaling and CD audio.",
            "Why it mattered" to "Full-motion video, CD music and big games. Sonic CD (1993) is the best-known showcase for its soundtrack and time travel.",
            "How it felt" to "Pictures: more colours and video clips of varying quality. Controls: same as the Mega Drive. Performance: long loading times were a common complaint.",
            "Popularity & sales" to "Sales were a small fraction of the main console's and the library was uneven, but the best games are still loved.",
            "In this app" to "You must provide your own BIOS files (LOCATIONS tab). The app cannot supply them."
        )),
        Manual("x32", "Sega 32X", "Add-on · 1994", Color(0xFFFF6F00), 3, listOf(
            "Quick history" to "A fast-built add-on that gave the Mega Drive two extra processors. Released in late 1994.",
            "Why it mattered" to "It was meant to bridge to the Saturn, but both arrived close together, which confused buyers and developers.",
            "How it felt" to "Pictures: more colours and 3D-style scaling. Performance: good in the best games. The cabling and power bricks were a pile of wires.",
            "Popularity & sales" to "A short-lived product with a small library. Knuckles' Chaotix (1995) is the Sonic game most players remember.",
            "In this app" to "Experimental PicoDrive core."
        )),
        Manual("gb", "Game Boy / Color", "Handheld · 1989", Color(0xFF7CB342), 2, listOf(
            "Quick history" to "Nintendo's handheld, Japan April 1989, bundled with Tetris in the West. The Game Boy Color followed in 1998 with colour and some backwards compatibility.",
            "Why it mattered" to "Battery life (four AA batteries lasted a long time), toughness, price and a huge library beat Sega's and Atari's colour screens.",
            "How it felt" to "Pictures: four shades of green-grey, and the screen blurred in fast motion. Controls: D-pad, A, B, Select, Start. Performance: slow-paced but solid.",
            "Popularity & sales" to "The Game Boy and Game Boy Color together are usually quoted at over 100 million units.",
            "Fun fact" to "The app has an A/B swap idea on the to-do list because some people expect the Nintendo layout, others the Sega one."
        )),
        Manual("gba", "Game Boy Advance", "Handheld · 2001", Color(0xFF3949AB), 4, listOf(
            "Quick history" to "Launched in 2001. 32-bit, with shoulder buttons L and R. The Sonic Advance series started here.",
            "Why it mattered" to "Console-like graphics in your pocket, backward compatible with Game Boy games.",
            "How it felt" to "Pictures: bright, but the first model had no backlight. Controls: D-pad, A, B, L, R, Select, Start. Performance: great for the era.",
            "Popularity & sales" to "Usually quoted at around 80 million units for the whole family of GBA models.",
            "In this app" to "mGBA core. Sonic Advance has no controller vibration yet."
        )),
        Manual("nes", "NES / Famicom", "8-bit · 1983", Color(0xFFD32F2F), 2, listOf(
            "Quick history" to "The Famicom came out in Japan in 1983; the redesigned NES reached North America in 1985 and 1986. It rebuilt the home video-game business after the crash of the early 1980s.",
            "Why it mattered" to "Super Mario Bros., The Legend of Zelda, Metroid and a licensing system that policed game quality (and which developers sometimes disliked).",
            "How it felt" to "Pictures: chunky and colourful. Controls: D-pad, A, B, Select, Start. Performance: some flicker when many sprites shared a line.",
            "Popularity & sales" to "Usually quoted at around 60 million units. It was the dominant home console in Japan and North America.",
            "Tips" to "The famous Konami code: Up, Up, Down, Down, Left, Right, Left, Right, B, A. It works in several Konami games, and in the first Contra it gives extra lives.",
            "In this app" to "Experimental FCEUmm core."
        )),
        Manual("nds", "Nintendo DS", "Handheld · 2004", Color(0xFF90A4AE), 6, listOf(
            "What it is" to "Two screens, the lower one touch-sensitive, and a stylus. Backwards compatible with Game Boy Advance cartridges (the original model).",
            "How it plays" to "A D-pad, A B X Y, two shoulder buttons, START and SELECT. Games use the touch screen for maps, drawing, puzzles and menus.",
            "In this app" to "Experimental. Two screens are drawn in one picture: choose SIDE BY SIDE, TOP / BOTTOM or TOP / BOTTOM WITH THE REAL GAP (DS SCREENS on the game page). Touch the lower screen with your finger.",
            "Good to know" to "DS states are big (about 6.5 MB), so rewind is switched off for it to protect memory. Free firmware is built in; real DS firmware files are optional.",
            "Tip" to "Use the phone upright for TOP / BOTTOM, or sideways for SIDE BY SIDE; TABLET mode picks for you."
        )),
        Manual("snes", "SNES / Super Famicom", "16-bit · 1990", Color(0xFF6A1B9A), 6, listOf(
            "Quick history" to "Super Famicom in Japan in November 1990, SNES in North America in 1991. It went head to head with the Mega Drive.",
            "Why it mattered" to "Mode 7 rotation and scaling, strong sound and RPGs. Super Mario World, Zelda: A Link to the Past and Super Metroid still top many lists.",
            "How it felt" to "Pictures: lots of colours and effects. Controls: four face buttons (A, B, X, Y) and L, R shoulders. Performance: some slowdown in busy games.",
            "Popularity & sales" to "Usually quoted at around 49 million units. In North America the Genesis and SNES traded the lead for several years.",
            "In this app" to "Experimental Snes9x core. The 3-button on-screen layout has no X and Y yet; use a controller or the 6-button layout."
        ))
    )
}

/** quick facts for the SPECS box (rounded, widely quoted figures; regions and revisions differ) */
private val SPECS = mapOf(
    "md" to listOf("Launched" to "1988 Japan · 1989 USA", "Launch price" to "about \$190 (USA)", "CPU" to "Motorola 68000 + Z80", "Memory" to "64 KB RAM + 64 KB video RAM", "Media" to "Cartridges up to 4 MB"),
    "sms" to listOf("Launched" to "1985 Japan · 1986 USA", "Launch price" to "about \$200 (USA)", "CPU" to "Z80, 3.58 MHz", "Memory" to "8 KB RAM + 16 KB video RAM", "Media" to "Cartridges and Sega Cards"),
    "gg" to listOf("Launched" to "1990 Japan · 1991 USA", "Launch price" to "about \$150 (USA)", "CPU" to "Z80, 3.58 MHz", "Screen" to "160 × 144, colour, backlit", "Power" to "6 AA batteries, a few hours"),
    "scd" to listOf("Launched" to "1991 Japan · 1992 USA", "Launch price" to "about \$300 (USA)", "Extra CPU" to "Second 68000, 12.5 MHz", "Memory" to "768 KB RAM + backup memory", "Media" to "CD-ROM, 2× speed"),
    "x32" to listOf("Launched" to "1994", "Launch price" to "about \$160 (USA)", "CPUs" to "Two Hitachi SH-2, 23 MHz", "Memory" to "256 KB RAM + 256 KB video RAM", "Games" to "About 40 released"),
    "gb" to listOf("Launched" to "1989 Japan · 1989 USA", "Launch price" to "about \$90 (USA)", "CPU" to "Custom Z80-like, 4.19 MHz", "Screen" to "160 × 144, four shades of green", "Memory" to "8 KB RAM + 8 KB video RAM"),
    "gba" to listOf("Launched" to "2001", "Launch price" to "about \$100 (USA)", "CPU" to "ARM7, 16.8 MHz", "Screen" to "240 × 160, 32,768 colours", "Memory" to "32 KB + 256 KB RAM, 96 KB video RAM"),
    "nes" to listOf("Launched" to "1983 Japan (Famicom) · 1985-86 USA", "Launch price" to "about \$180 (USA)", "CPU" to "MOS 6502 derivative, 1.79 MHz", "Memory" to "2 KB RAM + 2 KB video RAM", "Sold" to "About 62 million"),
    "snes" to listOf("Launched" to "1990 Japan · 1991 USA", "Launch price" to "about \$200 (USA)", "CPU" to "65816, 3.58 MHz", "Memory" to "128 KB RAM + 64 KB video RAM", "Colours" to "256 on screen from 32,768"),
    "nds" to listOf("Launched" to "2004", "Launch price" to "about \$150 (USA)", "CPUs" to "ARM9 67 MHz + ARM7 33 MHz", "Screens" to "Two 256 × 192, the lower one touch", "Sold" to "About 154 million"))

/** numbered callouts: x, y as fractions of the picture, and the legend line */
private val CALLOUTS = mapOf(
    "md" to listOf(Triple(.50f, .30f, "Cartridge slot (the game goes in the top)"), Triple(.20f, .58f, "Power switch and volume slider"), Triple(.80f, .60f, "Controller ports (in the front)")),
    "sms" to listOf(Triple(.50f, .28f, "Cartridge slot on top"), Triple(.80f, .52f, "Pause button (this is the console's own)"), Triple(.22f, .62f, "Two controller ports")),
    "gg" to listOf(Triple(.50f, .42f, "Colour screen"), Triple(.20f, .55f, "Directional pad"), Triple(.84f, .55f, "Buttons 1 and 2, START at the top right")),
    "scd" to listOf(Triple(.30f, .28f, "Disc lid: the CD sits on the Mega Drive's side"), Triple(.72f, .62f, "The Mega Drive on top, the BIOS lives inside"), Triple(.50f, .82f, "Needs a BIOS file in this app")),
    "x32" to listOf(Triple(.50f, .22f, "The 32X sits in the cartridge slot like a big mushroom"), Triple(.20f, .62f, "Video cable joins the Mega Drive"), Triple(.80f, .62f, "Power for the add-on")),
    "gb" to listOf(Triple(.50f, .26f, "Screen: four shades"), Triple(.34f, .66f, "Directional pad"), Triple(.72f, .66f, "A and B buttons")),
    "gba" to listOf(Triple(.50f, .46f, "Wide 240 × 160 screen"), Triple(.12f, .10f, "L shoulder button"), Triple(.88f, .10f, "R shoulder button")),
    "nes" to listOf(Triple(.50f, .30f, "Front flap: the cartridge goes in the front"), Triple(.18f, .62f, "Power and RESET"), Triple(.80f, .62f, "Two controller ports")),
    "snes" to listOf(Triple(.50f, .30f, "Cartridge slot on top"), Triple(.20f, .62f, "Power and RESET"), Triple(.80f, .62f, "Two controller ports")),
    "nds" to listOf(Triple(.50f, .22f, "Upper screen"), Triple(.50f, .66f, "Lower touch screen (touch it with your finger here)"), Triple(.84f, .74f, "A B X Y buttons")))

private fun androidx.compose.ui.graphics.drawscope.DrawScope.consoleArt(id: String, w: Float, h: Float, c: Color) {
    val dark = Color(0xFF1B1B22); val light = Color(0xFFD6D6DA); val edge = Color.Black.copy(.5f)
    fun box(x: Float, y: Float, bw: Float, bh: Float, col: Color, r: Float = 12f) { drawRoundRect(col, Offset(x, y), Size(bw, bh), CornerRadius(r)); drawRoundRect(edge, Offset(x, y), Size(bw, bh), CornerRadius(r), style = androidx.compose.ui.graphics.drawscope.Stroke(2f)) }
    fun pad(cx: Float, cy: Float, k: Float) { drawRect(Color.Black.copy(.7f), Offset(cx - k, cy - k * .32f), Size(k * 2, k * .64f)); drawRect(Color.Black.copy(.7f), Offset(cx - k * .32f, cy - k), Size(k * .64f, k * 2)) }
    // soft floor shadow
    drawOval(Color.Black.copy(.25f), Offset(w * .08f, h * .86f), Size(w * .84f, h * .1f))
    when (id) {
        "md", "scd", "x32" -> {
            val top = h * .30f; val bh = h * .5f
            if (id == "scd") { box(w * .06f, top, w * .88f, bh, dark); box(w * .08f, top - h * .1f, w * .42f, h * .14f, Color(0xFF2B2B35)); drawCircle(Color(0xFF9E9EA6), h * .12f, Offset(w * .3f, top - h * .03f)); drawCircle(dark, h * .03f, Offset(w * .3f, top - h * .03f)) }
            else box(w * .12f, top, w * .76f, bh, dark)
            if (id == "x32") { box(w * .30f, top - h * .26f, w * .40f, h * .3f, Color(0xFF3A3A46), 40f); drawRect(Color(0xFFFF6F00), Offset(w * .36f, top - h * .12f), Size(w * .28f, h * .04f)) }
            if (id == "md") { drawRoundRect(Color(0xFF3A3A46), Offset(w * .33f, top - h * .08f), Size(w * .34f, h * .12f), CornerRadius(8f)); drawRect(Color.Black, Offset(w * .36f, top - h * .04f), Size(w * .28f, h * .03f)) }
            drawCircle(Color(0xFFB0B0B8), h * .1f, Offset(w * .5f, top + bh * .45f)); drawCircle(dark, h * .075f, Offset(w * .5f, top + bh * .45f))
            drawRect(c, Offset(w * .17f, top + bh * .78f), Size(w * .14f, h * .04f)); drawRect(Color(0xFF3A3A46), Offset(w * .66f, top + bh * .62f), Size(w * .12f, h * .1f))
        }
        "sms" -> { box(w * .10f, h * .34f, w * .80f, h * .48f, Color(0xFF26262E)); box(w * .30f, h * .20f, w * .40f, h * .18f, Color(0xFF3A3A46)); drawRect(c, Offset(w * .10f, h * .66f), Size(w * .80f, h * .06f)); drawRect(Color(0xFFE53935), Offset(w * .74f, h * .44f), Size(w * .08f, h * .06f)) }
        "gg" -> { box(w * .12f, h * .14f, w * .76f, h * .7f, Color(0xFF22222A), 36f); box(w * .30f, h * .24f, w * .40f, h * .4f, Color(0xFF6A9E8A), 8f); pad(w * .20f, h * .54f, h * .09f); drawCircle(Color(0xFFB0B0B8), h * .05f, Offset(w * .78f, h * .56f)); drawCircle(Color(0xFFB0B0B8), h * .05f, Offset(w * .84f, h * .46f)) }
        "gb" -> { box(w * .32f, h * .04f, w * .36f, h * .9f, Color(0xFFC5C5C9), 18f); box(w * .36f, h * .1f, w * .28f, h * .34f, Color(0xFF3B4A3B), 8f); drawRect(Color(0xFF9BBC0F), Offset(w * .39f, h * .14f), Size(w * .22f, h * .24f)); pad(w * .42f, h * .62f, h * .07f); drawCircle(Color(0xFF8E1B4A), h * .05f, Offset(w * .56f, h * .64f)); drawCircle(Color(0xFF8E1B4A), h * .05f, Offset(w * .62f, h * .58f)) }
        "gba" -> { box(w * .14f, h * .22f, w * .72f, h * .58f, c.copy(alpha = .95f), 40f); box(w * .34f, h * .28f, w * .32f, h * .36f, Color(0xFF111118), 6f); drawRect(Color(0xFF9BBC0F).copy(.35f), Offset(w * .36f, h * .31f), Size(w * .28f, h * .3f)); pad(w * .22f, h * .5f, h * .08f); drawCircle(Color(0xFFB0B0B8), h * .05f, Offset(w * .73f, h * .5f)); drawCircle(Color(0xFFB0B0B8), h * .05f, Offset(w * .79f, h * .42f)); drawRect(Color(0xFF8E8E96), Offset(w * .10f, h * .16f), Size(w * .14f, h * .08f)); drawRect(Color(0xFF8E8E96), Offset(w * .76f, h * .16f), Size(w * .14f, h * .08f)) }
        "nes" -> { box(w * .10f, h * .34f, w * .80f, h * .46f, Color(0xFFBDBDC2)); drawRect(Color(0xFF2B2B33), Offset(w * .14f, h * .44f), Size(w * .72f, h * .1f)); drawRect(Color(0xFFD32F2F), Offset(w * .10f, h * .66f), Size(w * .80f, h * .05f)); drawCircle(Color(0xFFD32F2F), h * .03f, Offset(w * .18f, h * .75f)); drawCircle(Color(0xFF9E9EA6), h * .03f, Offset(w * .26f, h * .75f)) }
        "snes" -> { box(w * .10f, h * .36f, w * .80f, h * .44f, Color(0xFFD0D0D4), 30f); drawRect(Color(0xFF8E8E96), Offset(w * .30f, h * .30f), Size(w * .40f, h * .1f)); drawRect(Color(0xFF6A5FB0), Offset(w * .20f, h * .58f), Size(w * .12f, h * .08f)); drawRect(Color(0xFF6A5FB0), Offset(w * .68f, h * .58f), Size(w * .12f, h * .08f)); drawCircle(Color(0xFF6A5FB0), h * .06f, Offset(w * .5f, h * .58f)) }
        "nds" -> { box(w * .24f, h * .06f, w * .52f, h * .36f, Color(0xFFCFCFD4), 14f); box(w * .30f, h * .10f, w * .40f, h * .28f, Color(0xFF111118), 4f); box(w * .24f, h * .46f, w * .52f, h * .42f, Color(0xFFCFCFD4), 14f); box(w * .30f, h * .50f, w * .40f, h * .26f, Color(0xFF1B2A44), 4f); pad(w * .30f, h * .8f, h * .05f); drawCircle(Color(0xFFB0B0B8), h * .03f, Offset(w * .70f, h * .8f)) }
    }
}

@Composable
private fun ConsoleHero(m: Manual) {
    val ca = CALLOUTS[m.id].orEmpty()
    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp).clip(RoundedCornerShape(16.dp)).background(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(m.color.copy(alpha = .45f), Color.Black.copy(.35f)))).padding(10.dp)) {
        Canvas(Modifier.fillMaxWidth().height(190.dp)) {
            val w = size.width; val h = size.height
            consoleArt(m.id, w, h, m.color)
            val paint = android.graphics.Paint().apply { color = android.graphics.Color.BLACK; textSize = 26f; isFakeBoldText = true; textAlign = android.graphics.Paint.Align.CENTER; isAntiAlias = true }
            ca.forEachIndexed { i, (fx, fy, _) -> drawCircle(Color.White, 20f, Offset(w * fx, h * fy)); drawCircle(Color(0xFFFFD54F), 20f, Offset(w * fx, h * fy), style = androidx.compose.ui.graphics.drawscope.Stroke(3f)); drawContext.canvas.nativeCanvas.drawText("${i + 1}", w * fx, h * fy + 9f, paint) }
        }
        ca.forEachIndexed { i, (_, _, t) -> Row(Modifier.padding(top = 3.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("${i + 1}", color = Color.Black, fontWeight = FontWeight.Black, fontSize = 12.sp, modifier = Modifier.clip(androidx.compose.foundation.shape.CircleShape).background(Color(0xFFFFD54F)).padding(horizontal = 7.dp, vertical = 1.dp))
            Text(t, color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(start = 8.dp)) } }
    }
}

@Composable
private fun SpecsBox(m: Manual) {
    val rows = SPECS[m.id] ?: return
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(12.dp)).background(Color.White.copy(.92f))) {
        Box(Modifier.background(m.color).padding(horizontal = 8.dp).fillMaxHeight()) { Text("SPECS", color = Color.White, fontWeight = FontWeight.Black, fontSize = 12.sp, modifier = Modifier.align(Alignment.Center).padding(vertical = 30.dp)) }
        Column(Modifier.padding(10.dp)) { rows.forEach { (k, v) -> Row(Modifier.padding(vertical = 1.dp)) { Text(I18n.tr(k) + ":", color = Color(0xFF222222), fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.width(96.dp)); Text(v, color = Color(0xFF222222), fontSize = 12.sp) } }
            Text("Rounded, widely quoted figures; regions and revisions differ.", color = Color(0xFF666666), fontSize = 9.sp, modifier = Modifier.padding(top = 3.dp)) }
    }
}

@Composable
private fun PadDrawing(n: Int, c: Color, modifier: Modifier = Modifier) {
    Canvas(modifier.fillMaxWidth().height(84.dp)) {
        val w = size.width; val h = size.height; val bw = minOf(w * .8f, 280f); val x0 = (w - bw) / 2f
        drawRoundRect(c.copy(alpha = .85f), Offset(x0, 8f), Size(bw, h - 16f), CornerRadius(h * .4f))
        drawRoundRect(Color.Black.copy(.45f), Offset(x0 + bw * .1f, h / 2f - 4f), Size(bw * .2f, 8f), CornerRadius(4f))
        drawRoundRect(Color.Black.copy(.45f), Offset(x0 + bw * .17f, h / 2f - bw * .1f), Size(8f, bw * .2f), CornerRadius(4f))
        for (i in 0 until n.coerceAtMost(6)) drawCircle(Color.White.copy(.9f), 9f, Offset(x0 + bw * (.55f + .1f * (i % 3)), h / 2f + (if (i < 3) -10f else 12f)))
    }
}

@Composable
fun ManualsScreen() {
    val skin = Skins.current()
    var sel by remember { mutableStateOf<String?>(null) }
    val m = Manuals.all.firstOrNull { it.id == sel }
    Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp).padding(top = 6.dp)) {
        if (m == null) {
            Text("CONSOLE MANUALS", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
            Text("Pocket booklets for each console: history, how it felt to play, sales, codes. Tap one to open. Numbers are rounded and widely quoted; treat them as a friendly guide, not a source.", color = Color(0xCCFFFFFF), fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp))
            Manuals.all.forEach { x ->
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(12.dp)).background(Color.Black.copy(.35f)).forgeClick { sel = x.id }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Canvas(Modifier.size(34.dp)) { drawCircle(x.color, size.width / 2f) }
                    Column(Modifier.padding(start = 10.dp).weight(1f)) { Text(x.name, color = Color.White, fontWeight = FontWeight.Bold); Text(x.tag, color = Color(0xCCFFFFFF), fontSize = 11.sp) }
                    Text("▶", color = skin.accent)
                }
            }
            Text("Still to come: Flash, OpenBOR and Sonic-specific booklets, plus translations.", color = Color(0x99FFFFFF), fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
        } else {
            Btn("◀ ALL MANUALS") { sel = null }
            Text(m.name, color = m.color, fontSize = 24.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 6.dp))
            Text(m.tag, color = Color(0xCCFFFFFF), fontSize = 12.sp)
            ConsoleHero(m)
            SpecsBox(m)
            Text("THE CONTROLLER", color = m.color, fontWeight = FontWeight.Black, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            PadDrawing(m.pad, m.color, Modifier.padding(vertical = 2.dp))
            val icons = listOf("📖", "🎮", "🏆", "🔧", "💡", "⚙")
            m.sections.forEachIndexed { i, (h, body) ->
                Column(Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(14.dp)).background(Color.Black.copy(.3f))) {
                    Row(Modifier.fillMaxWidth().background(m.color.copy(alpha = if (i % 2 == 0) .85f else .6f)).padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(icons[i % icons.size], fontSize = 18.sp); Text(I18n.tr(h).uppercase(), color = Color.White, fontWeight = FontWeight.Black, fontSize = 13.sp, letterSpacing = 1.sp, modifier = Modifier.padding(start = 8.dp)) }
                    Text(body, color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(12.dp))
                }
            }
        }
    }
}
