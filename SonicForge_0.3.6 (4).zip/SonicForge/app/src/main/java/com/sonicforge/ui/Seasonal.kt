package com.sonicforge.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonicforge.data.Store
import kotlin.math.sin

/**
 * Optional seasonal decoration drawn OVER the whole launcher (also over icons and buttons), never catches touches.
 * Off by default. Works with every theme and style. SETTINGS ▸ SCREEN & LOOK ▸ Seasonal decoration.
 */
private fun inSeason(): Boolean { val c = java.util.Calendar.getInstance(); val m = c.get(java.util.Calendar.MONTH); val d = c.get(java.util.Calendar.DAY_OF_MONTH); return (m == java.util.Calendar.DECEMBER && d >= 10) || (m == java.util.Calendar.JANUARY && d <= 10) }

@Composable
fun SeasonalOverlay() {
    val mode = Store.s("holiday", "off")
    if (mode == "off" || (mode == "auto" && !inSeason())) return
    val kind = Store.s("holidayKind", "snow"); val n = Store.i("holidayAmount", 60).coerceIn(10, 200)
    var t by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) { var last = 0L; while (true) { androidx.compose.runtime.withFrameNanos { ns -> if (last != 0L) t += (ns - last) / 1e9f; last = ns } } }
    val cols = listOf(Color(0xFFE53935), Color(0xFF43A047), Color(0xFFFFD54F), Color(0xFF29B6F6), Color(0xFFFF4F9A))
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width; val h = size.height; val tt = t
        if (kind == "lights") {
            val cnt = 18
            for (i in 0..cnt) { val x = w * i / cnt; val y = 10f + 14f * sin(i * Math.PI.toFloat() / cnt) * 2f + 8f
                val on = ((tt * 2f + i) % 3f) < 2f
                drawCircle(cols[i % cols.size].copy(alpha = if (on) .95f else .35f), 7f, Offset(x, y)) }
        } else for (i in 0 until n) {
            val f1 = (i * 0.618034f) % 1f; val f2 = (i * 0.37f) % 1f
            val x = f1 * w + sin(tt * .6f + i) * 18f
            val speed = .03f + .06f * f2
            val y = ((i * 0.131f + tt * speed) % 1f) * (h + 20f) - 10f
            when (kind) {
                "confetti" -> rotate(tt * 120f + i * 30f, Offset(x, y)) { drawRect(cols[i % cols.size].copy(alpha = .9f), Offset(x, y), Size(7f, 11f)) }
                "leaves" -> rotate(tt * 60f + i * 40f, Offset(x, y)) { drawOval(if (i % 2 == 0) Color(0xFFFF8F00).copy(alpha = .9f) else Color(0xFFD84315).copy(alpha = .9f), Offset(x, y), Size(14f, 8f)) }
                else -> drawCircle(Color.White.copy(alpha = .55f + .4f * f2), 2f + 3.5f * f2, Offset(x, y))
            }
        }
    }
}

/** SETTINGS ▸ SCREEN & LOOK ▸ Seasonal decoration */
@Composable
fun SeasonalSettings() {
    H("Seasonal decoration (optional)")
    Text("Snow, confetti, lights or falling leaves over the whole launcher, also over icons. It works with every theme and style and is OFF by default. AUTO = only from 10 December to 10 January. A first version: more holidays can follow.", color = Color(0xE6FFFFFF), fontSize = 11.sp)
    SChips("Show", "holiday", "off", listOf("off" to "Off", "auto" to "Auto (New Year)", "always" to "Always"))
    SChips("Kind", "holidayKind", "snow", listOf("snow" to "Snow", "confetti" to "Confetti", "lights" to "Lights", "leaves" to "Leaves"))
    SSlider("Amount", "holidayAmount", 60, 200, "")
}
