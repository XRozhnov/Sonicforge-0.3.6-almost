package com.sonicforge.core

import com.sonicforge.data.Store

/** One button for the two speed tools: both on, rewind only, fast-forward only, both off. The two real switches are "rewind" and "ffOn" (SETTINGS and the in-game menus change the same two keys). */
object SpeedMode {
    fun rewOn() = Store.b("rewind", true)
    fun ffOn() = Store.b("ffOn", true)
    fun cur(): Int = when { rewOn() && ffOn() -> 0; rewOn() -> 1; ffOn() -> 2; else -> 3 }
    fun next() { val n = (cur() + 1) % 4; Store.setB("rewind", n == 0 || n == 1); Store.setB("ffOn", n == 0 || n == 2) }
    fun label(): String = when (cur()) { 0 -> "⏪⏩ REWIND + FAST-FORWARD: ON"; 1 -> "⏪ REWIND ONLY"; 2 -> "⏩ FAST-FORWARD ONLY"; else -> "⏪⏩ BOTH OFF" }
}
