package com.sonicforge.ui

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas as ACanvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.os.Build
import android.provider.MediaStore
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonicforge.data.Logger
import com.sonicforge.data.SaveEvent
import com.sonicforge.data.Store
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Pixel-art / drawing canvas. Layers (visibility, opacity, clipping to the layer below), pencil / eraser / fill / eyedropper,
 * paste a picture onto a layer or as a new layer, canvas resize (crop or extend), undo, export to PNG. The drawing is saved on its own and reopens next time.
 */
object Draw {
    class Layer(var name: String, var bmp: Bitmap, var visible: Boolean = true, var opacity: Int = 100, var clip: Boolean = false)
    const val MAX = 512
    var w by mutableIntStateOf(64); var h by mutableIntStateOf(64)
    val layers = mutableStateListOf<Layer>()
    var active by mutableIntStateOf(0)
    var color by mutableIntStateOf(0xFF1E88E5.toInt())
    var tool by mutableStateOf("pencil")
    var brush by mutableIntStateOf(1)
    var grid by mutableStateOf(true)
    var version by mutableIntStateOf(0)
    private val undoStack = ArrayList<Pair<Int, Bitmap>>()
    private var loaded = false
    val recent = mutableStateListOf<Int>()

    fun bump() { version++ }
    fun newCanvas(nw: Int, nh: Int) {
        w = nw.coerceIn(1, MAX); h = nh.coerceIn(1, MAX); layers.clear(); layers.add(Layer("Layer 1", Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888))); active = 0; undoStack.clear(); bump()
    }
    private fun cur(): Layer? = layers.getOrNull(active)
    private fun baseIndex(i: Int): Int { var b = i - 1; while (b >= 0 && layers[b].clip) b--; return b }

    // ---- undo ----
    fun begin() { val l = cur() ?: return; undoStack.add(active to l.bmp.copy(Bitmap.Config.ARGB_8888, true)); if (undoStack.size > 30) undoStack.removeAt(0) }
    fun undo() { val (i, b) = undoStack.removeLastOrNull() ?: return; if (i in layers.indices && b.width == layers[i].bmp.width && b.height == layers[i].bmp.height) { layers[i].bmp = b; bump() } }
    val canUndo get() = undoStack.isNotEmpty()

    // ---- painting ----
    private fun allowed(l: Layer, x: Int, y: Int): Boolean {
        if (x !in 0 until w || y !in 0 until h) return false
        if (!l.clip) return true
        val bi = baseIndex(layers.indexOf(l)); if (bi < 0) return true
        return (layers[bi].bmp.getPixel(x, y) ushr 24) != 0       // a clipped layer only takes paint where the layer below has paint
    }
    fun dot(x: Int, y: Int) {
        val l = cur() ?: return; val half = brush / 2
        for (bx in 0 until brush) for (by in 0 until brush) {
            val px = x - half + bx; val py = y - half + by
            if (allowed(l, px, py)) l.bmp.setPixel(px, py, if (tool == "eraser") 0 else color)
        }
    }
    fun line(x0: Int, y0: Int, x1: Int, y1: Int) {
        var x = x0; var y = y0; val dx = abs(x1 - x0); val dy = -abs(y1 - y0); val sx = if (x0 < x1) 1 else -1; val sy = if (y0 < y1) 1 else -1; var err = dx + dy
        var guard = 0
        while (guard++ < 4000) { dot(x, y); if (x == x1 && y == y1) break; val e2 = 2 * err; if (e2 >= dy) { err += dy; x += sx }; if (e2 <= dx) { err += dx; y += sy } }
        bump()
    }
    fun fill(x: Int, y: Int) {
        val l = cur() ?: return; if (x !in 0 until w || y !in 0 until h) return
        val px = IntArray(w * h); l.bmp.getPixels(px, 0, w, 0, 0, w, h)
        val target = px[y * w + x]; val newC = color; if (target == newC) return
        val q = ArrayDeque<Int>(); q.add(y * w + x)
        while (q.isNotEmpty()) {
            val p = q.removeLast(); val cx = p % w; val cy = p / w
            if (px[p] != target || !allowed(l, cx, cy)) continue
            px[p] = newC
            if (cx > 0) q.add(p - 1); if (cx < w - 1) q.add(p + 1); if (cy > 0) q.add(p - w); if (cy < h - 1) q.add(p + w)
        }
        l.bmp.setPixels(px, 0, w, 0, 0, w, h); bump()
    }
    fun pick(x: Int, y: Int) { if (x in 0 until w && y in 0 until h) { val c = composite().getPixel(x, y); if ((c ushr 24) != 0) chooseColor(c) } }
    /** only sets the active colour; the colour joins "recent" the first time you really paint with it (not while a slider moves) */
    fun chooseColor(c: Int) { color = c }
    fun noteUsed() { if (recent.firstOrNull() != color) { recent.remove(color); recent.add(0, color); while (recent.size > 10) recent.removeAt(recent.size - 1) } }
    val fav = mutableStateListOf<Int>()
    const val FAV_MAX = 30
    var paletteSet by mutableIntStateOf(0)
    private fun saveFav() { Store.set("drawFav", fav.joinToString(",") { "%08X".format(it) }) }
    fun loadFav() { if (fav.isEmpty()) Store.s("drawFav").split(',').filter { it.length == 8 }.forEach { h -> h.toLongOrNull(16)?.let { fav.add(it.toInt()) } } }
    fun addFav() { if (color !in fav && fav.size < FAV_MAX) { fav.add(color); saveFav() } }
    fun removeFav(c: Int) { fav.remove(c); saveFav() }
    fun clearFav() { fav.clear(); saveFav() }

    // ---- layers ----
    fun addLayer() { layers.add(active + 1, Layer("Layer ${layers.size + 1}", Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888))); active += 1; bump() }
    fun deleteLayer() { if (layers.size <= 1) return; layers.removeAt(active); active = active.coerceAtMost(layers.size - 1); bump() }
    fun move(delta: Int) { val j = active + delta; if (j !in layers.indices) return; val l = layers.removeAt(active); layers.add(j, l); active = j; bump() }
    fun mergeDown() {
        if (active <= 0) return; val top = layers[active]; val under = layers[active - 1]
        val p = Paint().apply { alpha = (top.opacity * 255 / 100).coerceIn(0, 255) }
        ACanvas(under.bmp).drawBitmap(clipped(active), 0f, 0f, p); layers.removeAt(active); active -= 1; bump()
    }
    private fun clipped(i: Int): Bitmap {
        val l = layers[i]; val bi = if (l.clip) baseIndex(i) else -1
        if (bi < 0) return l.bmp
        val t = l.bmp.copy(Bitmap.Config.ARGB_8888, true)
        ACanvas(t).drawBitmap(layers[bi].bmp, 0f, 0f, Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) })
        return t
    }
    fun composite(): Bitmap {
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); val c = ACanvas(out); val p = Paint()
        layers.forEachIndexed { i, l -> if (l.visible) { p.alpha = (l.opacity * 255 / 100).coerceIn(0, 255); c.drawBitmap(clipped(i), 0f, 0f, p) } }
        return out
    }

    // ---- canvas size and pictures ----
    fun resize(nw: Int, nh: Int, center: Boolean) {
        val tw = nw.coerceIn(1, MAX); val th = nh.coerceIn(1, MAX)
        val dx = if (center) (tw - w) / 2 else 0; val dy = if (center) (th - h) / 2 else 0
        layers.forEach { l -> val nb = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888); ACanvas(nb).drawBitmap(l.bmp, dx.toFloat(), dy.toFloat(), null); l.bmp = nb }
        w = tw; h = th; undoStack.clear(); bump()
    }
    fun paste(src: Bitmap, fit: Boolean, asNewLayer: Boolean) {
        if (asNewLayer) addLayer() else begin()
        val l = cur() ?: return; val c = ACanvas(l.bmp); val p = Paint().apply { isFilterBitmap = false; isAntiAlias = false }
        if (fit) { val s = min(w / src.width.toFloat(), h / src.height.toFloat()); val dw = src.width * s; val dh = src.height * s; c.drawBitmap(src, null, android.graphics.RectF((w - dw) / 2, (h - dh) / 2, (w + dw) / 2, (h + dh) / 2), p) }
        else c.drawBitmap(src, 0f, 0f, p)
        bump()
    }
    fun decode(ctx: Context, uri: android.net.Uri): Bitmap? = try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1; while (max(o.outWidth, o.outHeight) / s > 2048) s *= 2
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s }) }
    } catch (e: Throwable) { Logger.w("Draw", "could not read the picture: $e"); null }

    // ---- save / load / export ----
    private fun dir(ctx: Context) = File(ctx.filesDir, "draw").apply { mkdirs() }
    fun save(ctx: Context) {
        if (!loaded) return
        try {
            val d = dir(ctx); val arr = JSONArray()
            layers.forEachIndexed { i, l -> File(d, "layer$i.png").outputStream().use { l.bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                arr.put(JSONObject().put("name", l.name).put("v", l.visible).put("o", l.opacity).put("c", l.clip)) }
            File(d, "meta.json").writeText(JSONObject().put("w", w).put("h", h).put("active", active).put("layers", arr).toString())
            d.listFiles()?.filter { f -> f.name.startsWith("layer") && (f.name.removePrefix("layer").removeSuffix(".png").toIntOrNull() ?: -1) >= layers.size }?.forEach { it.delete() }
        } catch (e: Throwable) { Logger.w("Draw", "could not save the drawing: $e") }
    }
    fun ensureLoaded(ctx: Context) {
        if (loaded) return; loaded = true; loadFav()
        try {
            val m = File(dir(ctx), "meta.json"); if (!m.exists()) { newCanvas(64, 64); return }
            val j = JSONObject(m.readText()); val arr = j.getJSONArray("layers"); val nl = ArrayList<Layer>()
            for (i in 0 until arr.length()) { val o = arr.getJSONObject(i); val b = BitmapFactory.decodeFile(File(dir(ctx), "layer$i.png").path)?.copy(Bitmap.Config.ARGB_8888, true) ?: continue
                nl.add(Layer(o.optString("name", "Layer ${i + 1}"), b, o.optBoolean("v", true), o.optInt("o", 100), o.optBoolean("c", false))) }
            if (nl.isEmpty()) { newCanvas(64, 64); return }
            w = j.getInt("w"); h = j.getInt("h"); layers.clear(); layers.addAll(nl); active = j.optInt("active", 0).coerceIn(0, layers.size - 1); bump()
        } catch (e: Throwable) { Logger.w("Draw", "could not open the saved drawing: $e"); newCanvas(64, 64) }
    }
    fun export(ctx: Context, scale: Int): String? = exportSize(ctx, w * scale, h * scale)
    fun exportSize(ctx: Context, ew: Int, eh: Int): String? {
        val bm = composite(); val big = if (ew != w || eh != h) Bitmap.createScaledBitmap(bm, ew.coerceIn(1, 8192), eh.coerceIn(1, 8192), false) else bm
        val name = "sonicforge-${System.currentTimeMillis()}.png"
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues().apply { put(MediaStore.Images.Media.DISPLAY_NAME, name); put(MediaStore.Images.Media.MIME_TYPE, "image/png"); put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/SonicForge") }
                val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return null
                ctx.contentResolver.openOutputStream(uri)?.use { big.compress(Bitmap.CompressFormat.PNG, 100, it) }; "Pictures/SonicForge/$name"
            } else {
                val d = File(ctx.getExternalFilesDir(null), "drawings").apply { mkdirs() }; File(d, name).outputStream().use { big.compress(Bitmap.CompressFormat.PNG, 100, it) }; File(d, name).path
            }
        } catch (e: Throwable) { Logger.e("Draw", "export failed", e); null }
    }
}

private val PALETTE = listOf(0xFF000000, 0xFFFFFFFF, 0xFF9E9E9E, 0xFF424242, 0xFF1E88E5, 0xFF0D47A1, 0xFFE53935, 0xFFFFD54F, 0xFF558B2F, 0xFF00ACC1, 0xFFFFE0B2, 0xFFFFA000, 0xFFF06292, 0xFF7B1FA2, 0xFF6D4C41, 0xFF69F0AE).map { it.toInt() }

@Composable
fun DrawScreen() {
    val ctx = LocalContext.current; val skin = Skins.current()
    LaunchedEffect(Unit) { Draw.ensureLoaded(ctx) }
    DisposableEffect(Unit) { onDispose { Draw.save(ctx) } }
    var showColor by remember { mutableStateOf(false) }; var showLayers by remember { mutableStateOf(false) }; var showCanvas by remember { mutableStateOf(false) }
    var showExport by remember { mutableStateOf(false) }; var pasted by remember { mutableStateOf<Bitmap?>(null) }
    var sc by remember { mutableFloatStateOf(8f) }; var ox by remember { mutableFloatStateOf(0f) }; var oy by remember { mutableFloatStateOf(0f) }
    var box by remember { mutableStateOf(IntSize.Zero) }
    fun fit() { if (box.width > 0 && box.height > 0) { sc = min(box.width.toFloat() / Draw.w, box.height.toFloat() / Draw.h) * .96f; ox = (box.width - Draw.w * sc) / 2; oy = (box.height - Draw.h * sc) / 2 } }
    LaunchedEffect(box, Draw.w, Draw.h) { fit() }
    val scU by rememberUpdatedState(sc); val oxU by rememberUpdatedState(ox); val oyU by rememberUpdatedState(oy)

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(6.dp), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
            Btn("↶ UNDO") { Draw.undo() }
            listOf("pencil" to "✏ PENCIL", "eraser" to "⌫ ERASER", "fill" to "🪣 FILL", "pick" to "💧 PICK", "move" to "✥ MOVE / ZOOM").forEach { (k, n) -> Btn(n, selected = Draw.tool == k) { Draw.tool = k } }
            Btn("SIZE ${Draw.brush}") { Draw.brush = when (Draw.brush) { 1 -> 2; 2 -> 3; 3 -> 4; 4 -> 6; 6 -> 8; else -> 1 } }
            Btn("GRID: " + if (Draw.grid) "ON" else "OFF", selected = Draw.grid) { Draw.grid = !Draw.grid }
            Btn("FIT") { fit() }
        }
        Box(Modifier.weight(1f).fillMaxWidth().background(Color(0xFF263238)).clip(RoundedCornerShape(0.dp)).onSizeChanged { box = it }
            .pointerInput(Draw.tool) {
                if (Draw.tool == "move") detectTransformGestures { _, pan, zoom, _ -> sc = (sc * zoom).coerceIn(1f, 90f); ox += pan.x; oy += pan.y }
                else awaitPointerEventScope {
                    while (true) {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        fun cell(o: Offset) = Pair(((o.x - oxU) / scU).toInt().let { if (o.x < oxU) -1 else it }, ((o.y - oyU) / scU).toInt().let { if (o.y < oyU) -1 else it })
                        var last = cell(down.position)
                        when (Draw.tool) {
                            "fill" -> { Draw.begin(); Draw.noteUsed(); Draw.fill(last.first, last.second) }
                            "pick" -> Draw.pick(last.first, last.second)
                            else -> { Draw.begin(); if (Draw.tool == "pencil") Draw.noteUsed(); Draw.line(last.first, last.second, last.first, last.second) }
                        }
                        down.consume()
                        var go = true
                        while (go) {
                            val ev = awaitPointerEvent(); val ch = ev.changes.firstOrNull() ?: break
                            if (!ch.pressed) { go = false } else {
                                val now = cell(ch.position)
                                if (Draw.tool == "pencil" || Draw.tool == "eraser") Draw.line(last.first, last.second, now.first, now.second) else if (Draw.tool == "pick") Draw.pick(now.first, now.second)
                                last = now
                            }
                            ch.consume()
                        }
                    }
                }
            }) {
            androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
                @Suppress("UNUSED_VARIABLE") val v = Draw.version
                val cw = Draw.w * sc; val chh = Draw.h * sc
                drawRect(Color(0xFFCFD8DC), Offset(ox, oy), Size(cw, chh))
                val tile = max(sc * 2f, 12f); var yy = 0f; var row = 0
                while (yy < chh) { var xx = 0f; var colI = row % 2; while (xx < cw) { if (colI % 2 == 1) drawRect(Color(0xFFB0BEC5), Offset(ox + xx, oy + yy), Size(min(tile, cw - xx), min(tile, chh - yy))); xx += tile; colI++ }; yy += tile; row++ }
                val img = Draw.composite().asImageBitmap()
                drawImage(img, srcOffset = IntOffset.Zero, srcSize = IntSize(Draw.w, Draw.h), dstOffset = IntOffset(ox.toInt(), oy.toInt()), dstSize = IntSize(cw.toInt(), chh.toInt()), filterQuality = FilterQuality.None)
                if (Draw.grid && sc >= 8f) {
                    for (i in 0..Draw.w) drawLine(Color(0x33000000), Offset(ox + i * sc, oy), Offset(ox + i * sc, oy + chh), 1f)
                    for (j in 0..Draw.h) drawLine(Color(0x33000000), Offset(ox, oy + j * sc), Offset(ox + cw, oy + j * sc), 1f)
                }
            }
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(6.dp), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(38.dp).clip(RoundedCornerShape(8.dp)).background(Color(Draw.color)).border(2.dp, Color.White, RoundedCornerShape(8.dp)).clickable { showColor = true })
            Btn("COLOR") { showColor = true }; Btn("LAYERS (${Draw.layers.size})") { showLayers = true }; Btn("CANVAS ${Draw.w}×${Draw.h}") { showCanvas = true }
            Btn("＋ IMAGE") { Picker.pick(arrayOf("image/*")) { u -> u.firstOrNull()?.let { uri -> val b = Draw.decode(ctx, uri); if (b != null) pasted = b else Store.events.tryEmit(SaveEvent("That picture could not be read", false)) } } }
            Btn("EXPORT PNG") { showExport = true }
        }
    }

    if (showColor) {
        var tab by remember { mutableStateOf("palette") }; var removeMode by remember { mutableStateOf(false) }
        val hsv = remember(Draw.color) { FloatArray(3).also { android.graphics.Color.colorToHSV(Draw.color, it) } }
        AlertDialog(onDismissRequest = { showColor = false }, containerColor = Color(0xFF0D0D14), confirmButton = { TextButton({ showColor = false }) { Text("Close") } }, title = { Text("Color") },
            text = { Column(Modifier.verticalScroll(rememberScrollState())) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) { listOf("palette" to "PALETTES", "wheel" to "WHEEL / SQUARE", "num" to "NUMBERS").forEach { (k, n) -> Btn(n, selected = tab == k) { tab = k } } }
                Row(Modifier.padding(vertical = 6.dp).fillMaxWidth().height(30.dp).clip(RoundedCornerShape(6.dp)).background(Color(Draw.color)), verticalAlignment = Alignment.CenterVertically) { Text("  #" + "%06X".format(Draw.color and 0xFFFFFF), fontSize = 11.sp, color = if (hsv[2] > .6f && hsv[1] < .5f) Color.Black else Color.White) }
                when (tab) {
                    "palette" -> {
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) { PALETTE_SETS.forEachIndexed { i, (n, _) -> Btn(n, selected = Draw.paletteSet == i) { Draw.paletteSet = i } } }
                        PALETTE_SETS[Draw.paletteSet.coerceIn(0, PALETTE_SETS.size - 1)].second.chunked(8).forEach { row -> Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) { row.forEach { c -> Swatch(c, c == Draw.color) { Draw.chooseColor(c) } } } }
                        Text("Favourites (${Draw.fav.size}/${Draw.FAV_MAX})", fontSize = 11.sp, modifier = Modifier.padding(top = 10.dp))
                        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) { Btn("＋ ADD CURRENT") { Draw.addFav() }; Btn(if (removeMode) "DONE" else "REMOVE…", selected = removeMode) { removeMode = !removeMode }; Btn("CLEAR ALL", color = Color(0xFFE53935)) { Draw.clearFav() } }
                        if (Draw.fav.isEmpty()) Text("Empty. Pick a colour, then ＋ ADD CURRENT.", fontSize = 11.sp, color = Color(0xDDFFFFFF))
                        Draw.fav.toList().chunked(8).forEach { row -> Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) { row.forEach { c -> Swatch(c, c == Draw.color, if (removeMode) Color(0xFFE53935) else Color.White) { if (removeMode) Draw.removeFav(c) else Draw.chooseColor(c) } } } }
                        if (Draw.recent.isNotEmpty()) { Text("Recently used", fontSize = 11.sp, modifier = Modifier.padding(top = 10.dp)); Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) { Draw.recent.toList().forEach { c -> Swatch(c, c == Draw.color) { Draw.chooseColor(c) } } } }
                    }
                    "wheel" -> {
                        Text("Drag in the square for saturation and brightness, and on the bar for the hue.", fontSize = 11.sp, color = Color(0xDDFFFFFF))
                        SvSquare(hsv[0], hsv[1], hsv[2]) { sat, v -> Draw.chooseColor(android.graphics.Color.HSVToColor(floatArrayOf(hsv[0], sat, v))) }
                        Spacer(Modifier.height(8.dp))
                        HueBar(hsv[0]) { h -> Draw.chooseColor(android.graphics.Color.HSVToColor(floatArrayOf(h, hsv[1].coerceAtLeast(.01f), hsv[2].coerceAtLeast(.01f)))) }
                    }
                    else -> {
                        var hex by remember(Draw.color) { mutableStateOf("%06X".format(Draw.color and 0xFFFFFF)) }
                        OutlinedTextField(hex, { t -> hex = t.filter { c -> c.isLetterOrDigit() }.take(6).uppercase(); if (hex.length == 6) hex.toIntOrNull(16)?.let { Draw.chooseColor(it or (0xFF shl 24)) } }, singleLine = true, label = { Text("Hex number (RRGGBB)") })
                        val c = Draw.color; val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
                        fun rgb(rr: Int, gg: Int, bb: Int) { Draw.chooseColor((0xFF shl 24) or (rr.coerceIn(0, 255) shl 16) or (gg.coerceIn(0, 255) shl 8) or bb.coerceIn(0, 255)) }
                        Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedTextField(r.toString(), { t -> t.toIntOrNull()?.let { rgb(it, g, b) } }, singleLine = true, label = { Text("R") }, modifier = Modifier.weight(1f))
                            OutlinedTextField(g.toString(), { t -> t.toIntOrNull()?.let { rgb(r, it, b) } }, singleLine = true, label = { Text("G") }, modifier = Modifier.weight(1f))
                            OutlinedTextField(b.toString(), { t -> t.toIntOrNull()?.let { rgb(r, g, it) } }, singleLine = true, label = { Text("B") }, modifier = Modifier.weight(1f))
                        }
                        Slider(r.toFloat(), { rgb(it.toInt(), g, b) }, valueRange = 0f..255f); Slider(g.toFloat(), { rgb(r, it.toInt(), b) }, valueRange = 0f..255f); Slider(b.toFloat(), { rgb(r, g, it.toInt()) }, valueRange = 0f..255f)
                    }
                }
            } })
    }

    if (showLayers) AlertDialog(onDismissRequest = { showLayers = false }, containerColor = Color(0xFF0D0D14), confirmButton = { TextButton({ showLayers = false }) { Text("Close") } }, title = { Text("Layers") },
        text = { @Suppress("UNUSED_VARIABLE") val vv = Draw.version; Column {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) { Btn("＋ NEW") { Draw.addLayer() }; Btn("▲") { Draw.move(1) }; Btn("▼") { Draw.move(-1) }; Btn("MERGE DOWN") { Draw.mergeDown() }; Btn("DELETE", color = Color(0xFFE53935)) { Draw.deleteLayer() } }
            Text("Tap a layer to draw on it. 👁 shows/hides it. CLIP = paint only where the layer below has paint (draw inside a circle without leaving it).", fontSize = 11.sp, color = Color(0xE6FFFFFF), modifier = Modifier.padding(vertical = 4.dp))
            Column(Modifier.heightIn(max = 340.dp).verticalScroll(rememberScrollState())) {
                for (i in Draw.layers.indices.reversed()) {
                    val l = Draw.layers[i]; val sel = i == Draw.active
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp).clip(RoundedCornerShape(8.dp)).background(if (sel) skin.accent.copy(.3f) else Color.White.copy(.07f)).clickable { Draw.active = i }.padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (l.clip) Text("↳", fontSize = 16.sp, modifier = Modifier.padding(end = 4.dp))
                        Text(if (l.visible) "👁" else "—", fontSize = 18.sp, modifier = Modifier.clickable { l.visible = !l.visible; Draw.bump() }.padding(horizontal = 6.dp))
                        Column(Modifier.weight(1f)) { Text(l.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1); Text("${l.opacity}%" + if (l.clip) " · clipped" else "", fontSize = 11.sp) }
                        Text("−", fontSize = 18.sp, modifier = Modifier.clickable { l.opacity = (l.opacity - 10).coerceAtLeast(0); Draw.bump() }.padding(horizontal = 8.dp))
                        Text("+", fontSize = 18.sp, modifier = Modifier.clickable { l.opacity = (l.opacity + 10).coerceAtMost(100); Draw.bump() }.padding(horizontal = 8.dp))
                        Text("CLIP", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (l.clip) skin.accent else Color.White, modifier = Modifier.clickable { if (i > 0) { l.clip = !l.clip; Draw.bump() } }.padding(horizontal = 6.dp))
                    }
                }
            }
        } })

    if (showCanvas) {
        var tw by remember { mutableStateOf(Draw.w.toString()) }; var th by remember { mutableStateOf(Draw.h.toString()) }
        AlertDialog(onDismissRequest = { showCanvas = false }, containerColor = Color(0xFF0D0D14), confirmButton = {}, dismissButton = { TextButton({ showCanvas = false }) { Text("Close") } }, title = { Text("Canvas") },
            text = { Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("Size in pixels (1 to ${Draw.MAX}). Making it smaller crops, making it bigger adds empty space; your layers are kept.", fontSize = 11.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(tw, { tw = it.filter { c -> c.isDigit() }.take(4) }, singleLine = true, label = { Text("Width") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(th, { th = it.filter { c -> c.isDigit() }.take(4) }, singleLine = true, label = { Text("Height") }, modifier = Modifier.weight(1f))
                }
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf(16, 32, 64, 128, 256).forEach { n -> Btn("$n×$n") { tw = "$n"; th = "$n" } } }
                Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Btn("RESIZE (anchor top-left)") { Draw.resize(tw.toIntOrNull() ?: Draw.w, th.toIntOrNull() ?: Draw.h, false); showCanvas = false }
                    Btn("RESIZE (centered)") { Draw.resize(tw.toIntOrNull() ?: Draw.w, th.toIntOrNull() ?: Draw.h, true); showCanvas = false } }
                Btn("NEW EMPTY CANVAS", Modifier.padding(top = 6.dp), color = Color(0xFFE53935)) { Draw.newCanvas(tw.toIntOrNull() ?: 64, th.toIntOrNull() ?: 64); showCanvas = false }
                Text("NEW EMPTY CANVAS throws the current drawing away.", fontSize = 11.sp, color = Color(0xFFFFAB91))
            } })
    }

    pasted?.let { bm -> AlertDialog(onDismissRequest = { pasted = null }, containerColor = Color(0xFF0D0D14), confirmButton = {}, dismissButton = { TextButton({ pasted = null }) { Text("Cancel") } }, title = { Text("Add this picture") },
        text = { Column {
            Text("${bm.width}×${bm.height} px. 'Fit' scales it into the canvas, 'Original size' keeps its pixels from the top-left corner.", fontSize = 11.sp)
            Btn("ON THIS LAYER · fit", Modifier.fillMaxWidth().padding(2.dp)) { Draw.paste(bm, true, false); pasted = null }
            Btn("NEW LAYER · fit", Modifier.fillMaxWidth().padding(2.dp)) { Draw.paste(bm, true, true); pasted = null }
            Btn("NEW LAYER · original size", Modifier.fillMaxWidth().padding(2.dp)) { Draw.paste(bm, false, true); pasted = null }
            Btn("ON THIS LAYER · original size", Modifier.fillMaxWidth().padding(2.dp)) { Draw.paste(bm, false, false); pasted = null }
        } }) }

    if (showExport) {
        var ew by remember { mutableStateOf((Draw.w * 8).toString()) }; var eh by remember { mutableStateOf((Draw.h * 8).toString()) }
        AlertDialog(onDismissRequest = { showExport = false }, containerColor = Color(0xFF0D0D14), confirmButton = {}, dismissButton = { TextButton({ showExport = false }) { Text("Close") } }, title = { Text("Export PNG") },
            text = { Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("Saves the finished picture (visible layers only) to Pictures/SonicForge. Scaling keeps the pixels sharp.", fontSize = 11.sp)
                listOf(1, 4, 8, 16).forEach { sc2 -> if (Draw.w * sc2 <= 4096 && Draw.h * sc2 <= 4096) Btn("×$sc2  (${Draw.w * sc2}×${Draw.h * sc2})", Modifier.fillMaxWidth().padding(2.dp)) {
                    val where = Draw.export(ctx, sc2); showExport = false
                    Store.events.tryEmit(SaveEvent(if (where != null) "Drawing saved: $where" else "Could not save the drawing (see LOGS)", where != null)) } }
                Text("Custom size (pixels, up to 8192)", fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(ew, { ew = it.filter { c -> c.isDigit() }.take(4) }, singleLine = true, label = { Text("Width") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(eh, { eh = it.filter { c -> c.isDigit() }.take(4) }, singleLine = true, label = { Text("Height") }, modifier = Modifier.weight(1f))
                }
                Btn("KEEP PROPORTIONS FROM WIDTH", Modifier.fillMaxWidth().padding(vertical = 2.dp)) { ew.toIntOrNull()?.let { eh = (it * Draw.h / Draw.w.toFloat()).toInt().coerceAtLeast(1).toString() } }
                Btn("EXPORT THIS SIZE", Modifier.fillMaxWidth().padding(2.dp), selected = true) {
                    val where = Draw.exportSize(ctx, ew.toIntOrNull() ?: Draw.w, eh.toIntOrNull() ?: Draw.h); showExport = false
                    Store.events.tryEmit(SaveEvent(if (where != null) "Drawing saved: $where" else "Could not save the drawing (see LOGS)", where != null)) }
            } })
    }
}

private val PALETTE_SETS: List<Pair<String, List<Int>>> = listOf(
    "Basic" to PALETTE,
    "Sonic zones" to listOf(0xFF1E88E5, 0xFF0D47A1, 0xFF558B2F, 0xFF8D6E63, 0xFFFFD54F, 0xFFE53935, 0xFF7B1FA2, 0xFF00ACC1, 0xFFFF6D00, 0xFFF5F5F5, 0xFF263238, 0xFF69F0AE, 0xFFFFE0B2, 0xFFBF360C, 0xFF4E342E, 0xFFB0BEC5).map { it.toInt() },
    "Pastel" to listOf(0xFFFFCDD2, 0xFFF8BBD0, 0xFFE1BEE7, 0xFFD1C4E9, 0xFFC5CAE9, 0xFFBBDEFB, 0xFFB3E5FC, 0xFFB2EBF2, 0xFFB2DFDB, 0xFFC8E6C9, 0xFFDCEDC8, 0xFFF0F4C3, 0xFFFFF9C4, 0xFFFFECB3, 0xFFFFE0B2, 0xFFFFCCBC).map { it.toInt() },
    "Grays" to (0..15).map { v -> (0xFF shl 24) or (v * 17 shl 16) or (v * 17 shl 8) or (v * 17) },
)

@Composable private fun Swatch(c: Int, selected: Boolean, ring: Color = Color.White, onClick: () -> Unit) =
    Box(Modifier.size(34.dp).clip(RoundedCornerShape(6.dp)).background(Color(c)).border(if (selected) 3.dp else 1.dp, ring, RoundedCornerShape(6.dp)).clickable(onClick = onClick))

/** saturation (left→right) and brightness (bottom→top) square for one hue */
@Composable private fun SvSquare(hue: Float, s: Float, v: Float, onChange: (Float, Float) -> Unit) {
    val hueColor = Color(android.graphics.Color.HSVToColor(floatArrayOf(hue, 1f, 1f)))
    var size by remember { mutableStateOf(IntSize.Zero) }
    Box(Modifier.fillMaxWidth().height(180.dp).clip(RoundedCornerShape(8.dp)).onSizeChanged { size = it }.pointerInput(hue) {
        awaitPointerEventScope { while (true) { val ev = awaitPointerEvent(); val c = ev.changes.firstOrNull() ?: continue
            if (c.pressed && size.width > 0 && size.height > 0) { onChange((c.position.x / size.width).coerceIn(0f, 1f), 1f - (c.position.y / size.height).coerceIn(0f, 1f)); c.consume() } } } }) {
        androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
            drawRect(Brush.horizontalGradient(listOf(Color.White, hueColor))); drawRect(Brush.verticalGradient(listOf(Color.Transparent, Color.Black)))
            drawCircle(Color.White, 11f, Offset(s * size.width, (1f - v) * size.height), style = Stroke(3f)); drawCircle(Color.Black, 13f, Offset(s * size.width, (1f - v) * size.height), style = Stroke(1.5f))
        }
    }
}

@Composable private fun HueBar(hue: Float, onChange: (Float) -> Unit) {
    var size by remember { mutableStateOf(IntSize.Zero) }
    Box(Modifier.fillMaxWidth().height(34.dp).clip(RoundedCornerShape(8.dp)).onSizeChanged { size = it }.pointerInput(Unit) {
        awaitPointerEventScope { while (true) { val ev = awaitPointerEvent(); val c = ev.changes.firstOrNull() ?: continue
            if (c.pressed && size.width > 0) { onChange((c.position.x / size.width).coerceIn(0f, 1f) * 359f); c.consume() } } } }) {
        androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
            drawRect(Brush.horizontalGradient(listOf(Color.Red, Color.Yellow, Color.Green, Color.Cyan, Color.Blue, Color.Magenta, Color.Red)))
            drawRect(Color.White, Offset(hue / 359f * size.width - 3f, 0f), Size(6f, size.height.toFloat()))
        }
    }
}
