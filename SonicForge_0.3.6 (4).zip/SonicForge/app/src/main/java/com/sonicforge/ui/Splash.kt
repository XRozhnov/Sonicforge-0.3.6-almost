package com.sonicforge.ui

import android.media.MediaPlayer
import android.widget.VideoView
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.sonicforge.data.Library
import com.sonicforge.data.Store
import java.io.File
import kotlinx.coroutines.delay

/**
 * Optional startup intro (EXPERIMENTAL): your own picture or video, optional music, fades in from and out to a colour, tap to skip.
 * Shown once each time the app starts. Off by default. Settings: SETTINGS ▸ SCREEN & LOOK ▸ Startup intro.
 */
object Splash {
    var done by mutableStateOf(false)
    var preview by mutableStateOf(false)
    fun file(): String = Store.s("splashFile")
    fun want(): Boolean = (preview || (!done && Store.b("splashOn", false))) && file().isNotEmpty() && File(file()).exists()
}

@Composable
fun StartupSplash() {
    if (!Splash.want()) return
    val path = Splash.file(); val video = Store.s("splashKind", "image") == "video"
    val fadeMs = Store.i("splashFade", 700).coerceIn(100, 3000); val holdMs = Store.i("splashHold", 3).coerceIn(1, 15) * 1000L
    val col = when (Store.s("splashColor", "black")) { "white" -> Color.White; "theme" -> Skins.current().bgTop; else -> Color.Black }
    val a = remember { Animatable(0f) }; var ended by remember { mutableStateOf(false) }
    val bmp = if (video) null else rememberBitmap(path)
    val finish = { Splash.done = true; Splash.preview = false }
    DisposableEffect(Unit) {
        var mp: MediaPlayer? = null
        try { val m = Store.s("splashMusic"); if (m.isNotEmpty() && File(m).exists()) mp = MediaPlayer().apply { setDataSource(m); prepare(); start() } } catch (_: Exception) { mp = null }
        onDispose { try { mp?.stop() } catch (_: Exception) {}; try { mp?.release() } catch (_: Exception) {} }
    }
    LaunchedEffect(Unit) {
        a.animateTo(1f, tween(fadeMs))
        var waited = 0L; val limit = if (video) 180000L else holdMs
        while (!ended && waited < limit) { delay(100); waited += 100 }
        a.animateTo(0f, tween(fadeMs)); finish()
    }
    Box(Modifier.fillMaxSize().background(col).pointerInput(Unit) { detectTapGestures { ended = true } }, Alignment.Center) {
        if (video) AndroidView(factory = { c ->
            VideoView(c).apply {
                setVideoPath(path)
                setOnPreparedListener { m -> m.isLooping = false; if (Store.s("splashMusic").isNotEmpty() || !Store.b("splashVideoSound", true)) m.setVolume(0f, 0f); start() }
                setOnCompletionListener { ended = true }
                setOnErrorListener { _, _, _ -> ended = true; true }
            } }, modifier = Modifier.fillMaxSize().alpha(a.value))
        else if (bmp != null) AnyPicture(path!!, Modifier.fillMaxSize().alpha(a.value), if (Store.s("splashFit", "fit") == "fill") ContentScale.Crop else ContentScale.Fit)
    }
}

/** SETTINGS ▸ SCREEN & LOOK ▸ Startup intro */
@Composable
fun SplashSettings() {
    val ctx = LocalContext.current
    fun copyIn(u: android.net.Uri, name: String): String? = try {
        val f = File(Library.art, name + "-" + System.currentTimeMillis() + ".bin")
        ctx.contentResolver.openInputStream(u)!!.use { i -> f.outputStream().use { i.copyTo(it) } }; f.path
    } catch (_: Exception) { null }
    H("Startup intro (experimental)")
    Text("Show your own picture or video when the app starts, with fade in and out, like a console boot screen. Tap to skip. Needs a file you choose here; nothing is built in.", color = Color(0xE6FFFFFF), fontSize = 11.sp)
    SToggle("Play the intro at start", "splashOn", false)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Btn("CHOOSE PICTURE OR VIDEO") { Picker.pick(arrayOf("image/*", "video/*")) { u -> u.firstOrNull()?.let { uri ->
            val kind = if ((ctx.contentResolver.getType(uri) ?: "").startsWith("video/")) "video" else "image"
            copyIn(uri, "splash")?.let { p -> Store.s("splashFile").takeIf { it.isNotEmpty() }?.let { File(it).delete() }; Store.set("splashFile", p); Store.set("splashKind", kind) } } } }
        Btn("CLEAR") { Store.s("splashFile").takeIf { it.isNotEmpty() }?.let { File(it).delete() }; Store.set("splashFile", ""); Store.set("splashMusic", "") }
    }
    Text(if (Store.s("splashFile").isEmpty()) "Nothing chosen yet." else "Chosen: " + Store.s("splashKind", "image"), color = Color(0xE6FFFFFF), fontSize = 11.sp)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Btn("CHOOSE MUSIC") { Picker.pick(arrayOf("audio/*")) { u -> u.firstOrNull()?.let { uri -> copyIn(uri, "splashmus")?.let { p -> Store.s("splashMusic").takeIf { it.isNotEmpty() }?.let { File(it).delete() }; Store.set("splashMusic", p) } } } }
        Btn("NO MUSIC") { Store.s("splashMusic").takeIf { it.isNotEmpty() }?.let { File(it).delete() }; Store.set("splashMusic", "") }
    }
    SChips("Fade from / to", "splashColor", "black", listOf("black" to "Black", "white" to "White", "theme" to "Theme colour"))
    SChips("Picture size", "splashFit", "fit", listOf("fit" to "Fit whole picture", "fill" to "Fill screen"))
    SToggle("Keep the video's own sound", "splashVideoSound", true, "Ignored when you chose separate music.")
    SSlider("Fade time", "splashFade", 700, 3000, " ms")
    SSlider("Picture time", "splashHold", 3, 15, " s")
    Btn("▶ PREVIEW NOW") { Splash.preview = true }
}
