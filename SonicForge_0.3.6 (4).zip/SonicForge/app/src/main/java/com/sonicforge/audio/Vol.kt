package com.sonicforge.audio

import com.sonicforge.data.Store

/** Volumes that exist twice: one for the launcher, one for while a game is open. */
object Vol {
    /** one-time: the old single "music" / "menu sounds" value was the in-game one (it was set low in a game and then stuck everywhere), so it moves to the game slot and the launcher goes back to 100 */
    fun migrate() {
        if (Store.s("volSplit") == "1") return
        Store.set("volMusicG", Store.s("volMusic").ifEmpty { "100" }); Store.set("volMusic", "100")
        Store.set("volUiG", Store.s("volUi").ifEmpty { "100" })
        Store.set("volSplit", "1")
    }
}
