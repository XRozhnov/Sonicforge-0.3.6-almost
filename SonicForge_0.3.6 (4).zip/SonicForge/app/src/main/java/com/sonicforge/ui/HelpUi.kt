package com.sonicforge.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private data class Topic(val id: String, val title: String, val pic: String, val lines: List<String>, val go: List<Pair<String, String>> = emptyList())

private val topics = listOf(
    Topic("quick", "Quick start", "tabs", listOf(
        "WHAT IS THIS? SonicForge is an offline launcher and emulator frontend for retro Sonic games (Mega Drive, Master System, Game Gear, Sega CD, optional 32X and Game Boy Advance) plus a music player, mini-games and lots of customisation.",
        "1. Get your own original game files (ROM dumps of games you own). The app contains no games.",
        "2. GAMES tab ▸ + ADD GAME and pick the files. Archives work: .zip, .rar (RAR4 only) and .7z. Or 📁 LINK FOLDER to scan a whole folder.",
        "3. Tap the game, then ▶ PLAY. Back button or ≡ opens the pause menu (save states, speed, screenshot, music).",
        "4. Make it yours: CUSTOMIZE (skins, shaders, controls), SETTINGS (volumes, vibration, screen).",
        "FORMATS: Mega Drive .md .gen .bin .smd; Master System .sms; Game Gear .gg; Sega CD .cue+.bin / .chd / .iso (BIOS needed); 32X .32x; GBA .gba; GB .gb .gbc."),
        listOf("games" to "Open GAMES", "custom" to "Open CUSTOMIZE")),
    Topic("systems", "Systems & formats", "folder", listOf(
        "FULL SUPPORT: Mega Drive / Genesis, Master System, Game Gear.",
        "EXPERIMENTAL: Sega CD (add your own BIOS in LOCATIONS), 32X and Game Boy / GBA (optional cores that are downloaded when the APK is built; if one is missing the game says so).",
        "OPENBOR: opens the separate OpenBOR app. SonicForge exports the .pak to your Downloads folder; move it into OpenBOR's Paks folder. (The OpenBOR.apk you tested is 32-bit only, so it needs a phone that still runs 32-bit apps.)",
        "NOT INSIDE THIS APP: Saturn, Dreamcast, PSP, GameCube, Wii, 3DS, PS2, Xbox and newer. They need dedicated emulators. See What this app can't do."),
        listOf("locations" to "Open LOCATIONS")),
    Topic("controls", "Controls", "pad", listOf(
        "TOUCH: CUSTOMIZE ▸ CONTROLS. Drag buttons, switch D-pad ↔ stick, size and opacity. Ready-made presets 11-17 (close 6-button layouts like MD.emu, GBA) can't be changed; My presets 1-6 are yours.",
        "GAMEPAD: SETTINGS ▸ CONTROLS. The app detects Xbox, DualShock 4, DualSense, Switch Pro and Steam pads (you can also pick the family by hand) and shows a picture with real button names and your current layout. A button you press lights up on the picture.",
        "RE-BIND STEP BY STEP: press REBIND on an action (or tap a button on the picture and pick an action), press the button, read what was recognised, then CONFIRM. Nothing is saved until you confirm, so a stray press cannot change it. ∅ unassigns a button, ↺ goes back to what the layer below says.",
        "EXTRA ACTIONS: besides the pad buttons you can assign Save state, Load state, Menu, Fast-forward, Rewind, next / previous save slot, show or hide the on-screen buttons, vibration on or off, and four diagonals (two directions at once).",
        "If you bind a button that is already used, the app warns you and lets you UNBIND THE OTHER or KEEP BOTH.",
        "KEYBOARD: a separate map (arrows, Z X C, Enter ...). Turning keyboard or pad off never touches your touch layout.",
        "ALSO PRESS TOGETHER: in the re-bind step you can choose a second action, so one button presses two (for example a stick click that does A + B).",
        "SCREEN BUTTONS FOLLOW THE PAD: when a controller hides the touch controls, the on-screen buttons stay drawn and light up when you press the real ones (not in Classic mode). Switch it in SETTINGS ▸ CONTROLS ▸ Controller options.",
        "If the touch buttons ever vanish: tap the small ≡ in the corner, or the UI button in the launcher top bar."),
        listOf("settings" to "Open SETTINGS")),
    Topic("screen", "Screen & FPS", "tabs", listOf(
        "SETTINGS ▸ VIDEO ▸ Screen: aspect (original, 4:3, 16:9, 1:1, stretch), classic mode (just the picture), safe-area insets for notches, corner roundness, scale and offset, and pixel-perfect or smooth scaling.",
        "FPS COUNTER shows two numbers. EMU = frames the game produced per second (60 for NTSC consoles, 50 for PAL). If it drops, the game is lagging. SCREEN = how often your phone redrew the picture; it follows your display (60/90/120 Hz).",
        "Speed chips (30 ... 144, Unlimited) change how fast the GAME runs; they are not display refresh. Rewind and fast-forward are in the pause menu and on the touch buttons."),
        listOf("settings" to "Open SETTINGS")),
    Topic("music", "Music & mini-games", "note", listOf(
        "MUSIC: import files or link a folder, make playlists, sort, re-order, skip ±10/30 s, scratch the disc to seek. Several player looks and equalizers.",
        "Notification: music keeps playing with the app in the background; switch it off in SETTINGS ▸ AUDIO. CLOSE APP COMPLETELY (SETTINGS ▸ GENERAL) stops everything.",
        "In a game the pause menu has a mini player. SETTINGS ▸ AUDIO ▸ Music in game decides: pause (and resume afterwards), keep playing, or play my playlist.",
        "MINI-GAMES: pause, mute, best score and a 3-2-1 restart. The ? button shows each game's rules."),
        listOf("music" to "Open MUSIC", "mini" to "Open MINI-GAMES")),
    Topic("vibration", "Vibration", "vibe", listOf(
        "SETTINGS ▸ VIBRATION has separate switches for the app and for the emulator. Each in-game event (rings, hurt, jump, spin dash, spring, shield, drowning...) has its own on/off and strength.",
        "Templates Quiet / Medium / Max set everything at once. Presets 1-3 are built in; 4-9 are empty slots for you. You can switch vibration off per game too.",
        "WHERE IT VIBRATES: Phone, Controller, Both or Off, separately for menus and for the game, and a single game can override its own. Controller strength has its own slider; pads that only support on / off ignore it.",
        "TEST DEVICES buzzes the phone and each connected controller for half a second and shows what Android reports (motor present, adjustable strength). Tell the app 'I felt it' or 'nothing' so you can see which device really vibrates. If Android reports no rumble for a pad (common with some Bluetooth pads), the app cannot force it.",
        "HOW IT WORKS: the app reads the game's memory to notice events. It is accurate for Sonic 1, 2 and 3&K and best-effort for hacks. Other systems only vibrate for touch buttons. Footstep vibration is experimental and off by default."),
        listOf("settings" to "Open SETTINGS")),
    Topic("profiles", "Control layers & profiles", "pad", listOf(
        "THREE LAYERS decide every button: GAME → EMULATOR → GLOBAL → factory. The first layer that has a setting for a button wins. GLOBAL is for everything, EMULATOR is for one system (for example only Game Boy or only Mega Drive), GAME is for one game.",
        "Each layer only stores what YOU changed there, so editing one never rewrites another. Every row in SETTINGS ▸ CONTROLS has a coloured tag (Game, Emulator, Global, Factory) that tells where it comes from, and the line above the list shows the active order.",
        "PROFILES are saved sets of buttons. Three are built in (Standard, Compact, Triggers = Save / Load). SAVE THIS LAYER AS A NEW PROFILE makes your own; you can copy, rename, edit (MY PROFILE) and delete it. APPLY copies a profile into the layer you are editing and asks first.",
        "RESET THIS LAYER removes only that layer's changes. RESTORE FACTORY clears the global, emulator and game layers but keeps your saved profiles and the touch layout.",
        "In a game: pause menu ▸ CONTROLS ▸ CONTROLLER MAPPING opens the same editor for the game you are playing."),
        listOf("settings" to "Open SETTINGS")),
    Topic("uistyles", "Styles and themes", "tabs", listOf(
        "STYLE = what you build in CUSTOMIZE: skin colours, frames, shaders, particles, backgrounds.",
        "THEME = a ready-made launcher look that changes the layout and how buttons are drawn: Normal (your style, as always), Mania (yellow stripes, slanted buttons), Tiles (dark blue cards and a button-hint bar), Game Jolt, itch (card grids) and Neon Coast (sunset poster look). The themes are original designs inspired by the feel of those places, not copies.",
        "A theme sits on top of your style. Normal shows your style unchanged; the other themes bring their own colours. Your own PNG background / foreground / character pictures (CUSTOMIZE ▸ BACKGROUNDS or SETTINGS ▸ SCREEN & LOOK) work on every theme, and a background replaces the theme's built-in backdrop.",
        "Change the theme with the ◐ button in the top bar (it cycles through all themes), or in SETTINGS ▸ SCREEN & LOOK ▸ Launcher theme, where you can also rename themes and hide the quick-switch button.",
        "Inside games and emulators the pause menu, buttons and background follow the theme too. Turn 'Use the theme inside games and emulators' off to keep your normal style there."),
        listOf("settings" to "Open SETTINGS")),
    Topic("beta", "About this beta (0.3.6 beta)", "shield", listOf(
        "This is a BETA: the next update, 0.3.6, is the same app after more testing and the remaining checklist items are done. Beta features can still have rough edges.",
        "NEW IN THIS BETA: controller setup with pictures and step-by-step re-binding, three-layer control profiles, vibration to phone / controller / both with a device test, on-screen buttons that light up with a real pad, the Mania and Tiles looks with a quick-switch button, a longer tour with a language chooser, and the tour and HELP translated into 12 languages.",
        "If something breaks, note what you pressed and look at the app's logs page for crash notes. Backups from before the beta can still be restored.",
        "Helper answers (ASK A HELPER) are still English only; translating them is on the list."),
        emptyList()),
    Topic("saves", "Saves & backups", "floppy", listOf(
        "A floppy icon pops up after every save: ✓ = written and verified, ✗ = failed. It says what was saved.",
        "Each game has 4 save-state slots; saving over a slot keeps the previous one (pause menu ▸ RESTORE PREV).",
        "UPDATING: install the new APK over the old one. Nothing is lost (same signing key). BACKUP: SETTINGS ▸ DATA & PRIVACY. LIGHT = settings only, FULL = settings plus the files you pick. Name the file first.",
        "WHERE: LOCATIONS lists every folder."),
        listOf("locations" to "Open LOCATIONS")),
    Topic("cheats", "Cheats & tips", "shield", listOf(
        "A game's ✎ EDIT has a Cheats box: one per line, NAME=CODE. Game Genie (ABCD-EFGH) and Action Replay (FFFFFF:0000) both work. Start a line with # to disable it. ＋ ADD KNOWN adds verified codes (Sonic 3 & Knuckles: no ring loss AWXT-CA4C, infinite time HXRT-AA6A).",
        "Each Sonic game shows a tip card with its level-select code.",
        "Cheats are optional: they live here and in Shadow's corner, nowhere else."),
        listOf("games" to "Open GAMES")),
    Topic("limits", "What this app can't do", "shield", listOf(
        "ANDROID: needs Android 8.0 (API 26) or newer. Android 5-7 are not supported (newer audio, vibration and notification features).",
        "NOT INCLUDED IN THIS BUILD: comics / photo / video tabs, Flash (Ruffle), Nintendo DS/3DS and other heavy consoles, SRB2, PNG-shaped frames, home-screen widgets, a separate Android TV APK. They are planned; some need big changes.",
        "TV: the app declares basic Android TV support (remote/gamepad focus). It is untested.",
        "APP ICON: the launcher icon/name can be switched to other presets in SETTINGS ▸ APPEARANCE (experimental; some launchers need a few seconds or a restart).",
        "ARM: the APK contains 64-bit and 32-bit ARM code. Optional cores can be missing for either."),
        emptyList()),
    Topic("segacd", "Sega CD: BIOS, regions and the 'RAM cartridge' message", "folder", listOf(
        "WHAT YOU NEED: a Sega CD BIOS file (LOCATIONS ▸ + ADD BIOS; any file name works, you can pick a whole zip) and the disc image (.cue + .bin, .chd or .iso). Games can't start without the BIOS.",
        "WHAT THE SEGA CD WAS: an add-on that slid under the Mega Drive / Genesis and played game CDs and audio CDs. It has its own start screen (the CD player you may see with no disc) and a small backup memory for saves. In Europe and Japan it was called Mega-CD.",
        "'RAM cartridge is not initialized. Use options screen to initialize RAM cartridge' (seen in Sonic CD): the game wants to save to a memory that was never formatted. On a fresh install this is normal, not a broken game. Look in the game's own options / data screen for the internal memory or an initialize (format) entry. Exact menu names differ between games and versions, so this is not verified for every title.",
        "REGIONS: use the BIOS that matches the disc (U = USA, E = Europe, J = Japan). If a game won't start, try another region's BIOS: LOCATIONS ▸ Sega CD BIOS library ▸ USE AS U / E / J.",
        "PRO: the core keeps the backup memory in the saves folder; deleting those files resets it. Going straight to the console's CD-player screen without a disc is not available yet."),
        listOf("locations" to "Open LOCATIONS")),
    Topic("consoles", "Consoles in short (handbook)", "folder", listOf(
        "MEGA DRIVE / GENESIS (1988 Japan, 1989 USA): 16-bit, cartridges, 3-button or 6-button pad. Plugs into a TV with an AV cable. Add-ons: Sega CD (under it) and 32X (in the cartridge slot). In this launcher: tab MEGA DRIVE.",
        "MASTER SYSTEM (1985 Japan, 1986 USA): 8-bit. The pad has two action buttons (1 and 2). The PAUSE button is on the console, not on the pad: here it is the PAUSE (ST) button. Many games start with button 1 or 2, not with Pause.",
        "GAME GEAR (1990): colour handheld made from Master System parts, needs six AA batteries, has a real START button. Same family as the Master System.",
        "SEGA CD / MEGA-CD (1991 Japan, 1992 USA): a CD-ROM drive under the Mega Drive. Needs a BIOS of the disc's region. Keeps saves in a small backup memory; some games ask for a formatted memory (see the Sega CD topic).",
        "32X (1994): add-on in the cartridge slot with two 32-bit processors; it needs a Mega Drive. GAME BOY family (1989 and later): handhelds; Game Boy Color (1998) and Game Boy Advance (2001) play older games too.",
        "VIBRATION: your phone can buzz for Sonic games on the Mega Drive; other consoles can use the Ring Finder tool. Controller (Bluetooth or cable) vibration is planned, not done yet."),
        listOf("games" to "Open GAMES")),
    Topic("flash", "Flash (Ruffle)", "tabs", listOf(
        "EXPERIMENTAL. Add a .swf file (GAMES ▸ + ADD GAME) and open it in the FLASH tab. It runs inside the Ruffle web player (downloaded while the APK is built; if that download failed, the game tells you).",
        "TOUCH: Direct = your finger is the mouse. Touchpad = drag moves a cursor, tap = left click, two-finger tap = right click, two-finger drag = scroll, and the LEFT/RIGHT HOLD buttons let you drag things with one finger while another finger moves the cursor.",
        "KEYBOARD: the ⌨ button shows a full see-through keyboard over the game (opacity in the controls menu). GAMEPAD: left stick / D-pad = arrow keys, WASD or the mouse; EVERY gamepad button can be given its own key or mouse click in ≡ CONTROLS ▸ Gamepad buttons; right stick = cursor. A PlayStation pad's touchpad isn't exposed by Android, so it can't be used.",
        "PERFORMANCE: a Flash game runs at the frame rate it was made for and Ruffle can't change that. Lower the quality, use a smaller resolution, or close other apps if it stutters. Not every game works (ActionScript 1/2 works best; some ActionScript 3, 3D and video features may fail). Vibration is off by default for Flash."),
        listOf("games" to "Open GAMES")),
    Topic("androidfolders", "Android folders & limits (advanced)", "folder", listOf(
        "WHY: since Android 10/11 apps can't freely read each other's folders. Android/data and Android/obb are protected: normal apps and the file picker can't open them on Android 11+, and many file managers lose access on Android 13+. It protects your data but makes installing mods, OBB data or emulator files harder.",
        "WHAT SONICFORGE DOES: it never asks for broad storage access. It keeps private folders of its own and reads only what you pick, or a folder you link (LINK FOLDER). A folder in public storage (Documents, Download) works well for games, music and mods.",
        "IF YOU NEED MORE (for experienced users only; mistakes can break apps or lose data): 1) The system Files app can sometimes open Android/data on Android 10 and below. 2) A PC with ADB (USB debugging): adb push file /sdcard/Android/data/<package>/files/ ; adb install app.apk ; adb install-multiple base.apk split.apk for split APKs. 3) Shizuku lets some apps use ADB-level access after you start it (wireless debugging on Android 11+); it must be restarted after a reboot without root. 4) Split-APK installers install .apks/.xapk/.apkm bundles. 5) 'Install unknown apps' must be allowed for each app that installs files.",
        "WHEN YOU NEED IT: installing a mod or game that ships an OBB/data folder, restoring emulator data, or sideloading when a store isn't available. LIMITS: methods differ by phone brand and Android version, new versions keep closing loopholes, and sideloading rules are changing: see keepandroidopen.org for the latest. Never use tools from untrusted sources."),
        emptyList()),
    Topic("build", "Build / update", "folder", listOf(
        "Upload SonicForge.zip to your GitHub repo and run Actions ▸ Build APK (zip method). The artifact contains three APKs: Universal (works everywhere, largest), arm64-v8a (almost all phones since about 2017) and armeabi-v7a (older 32-bit phones). SETTINGS ▸ ABOUT APP shows which one your phone needs. Install over the old app.",
        "If the build fails: open the run ▸ Summary: compiler errors are listed there, and the full log is in the build-log artifact."),
        emptyList()),
)

@Composable
private fun Picto(kind: String, accent: Color) {
    androidx.compose.foundation.Canvas(Modifier.size(110.dp, 56.dp).clip(RoundedCornerShape(10.dp)).background(Color(0x33000000))) {
        val w = size.width; val h = size.height
        fun DrawScope.box(x: Float, y: Float, bw: Float, bh: Float, c: Color) = drawRoundRect(c, Offset(x, y), Size(bw, bh), CornerRadius(6f))
        when (kind) {
            "tabs" -> { for (i in 0..3) box(8f + i * 24f, 8f, 20f, 8f, if (i == 1) accent else Color.White.copy(.5f)); box(8f, 22f, w - 16f, h - 30f, Color.White.copy(.25f)) }
            "folder" -> { box(10f, 16f, 44f, 32f, accent); box(10f, 12f, 18f, 8f, accent); drawLine(Color.White, Offset(58f, 32f), Offset(92f, 32f), 4f); drawLine(Color.White, Offset(84f, 24f), Offset(92f, 32f), 4f); drawLine(Color.White, Offset(84f, 40f), Offset(92f, 32f), 4f) }
            "pad" -> { drawCircle(accent, 9f, Offset(26f, 28f)); box(14f, 25f, 24f, 6f, Color.White.copy(.7f)); box(23f, 16f, 6f, 24f, Color.White.copy(.7f)); drawCircle(accent, 7f, Offset(76f, 34f)); drawCircle(accent, 7f, Offset(92f, 24f)) }
            "note" -> { for (i in 0..6) box(14f + i * 12f, h - 12f - (6 + (i * 7) % 28), 8f, 6f + (i * 7) % 28, accent); }
            "vibe" -> { box(40f, 8f, 30f, 40f, Color.White.copy(.6f)); for (i in 1..2) { drawArc(accent, 150f, 60f, false, Offset(40f - i * 12f, 28f - i * 6f), Size(i * 12f, i * 12f), style = Stroke(3f)); drawArc(accent, -30f, 60f, false, Offset(70f, 28f - i * 6f), Size(i * 12f, i * 12f), style = Stroke(3f)) } }
            "floppy" -> { box(36f, 8f, 38f, 40f, Color(0xFF90A4AE)); box(42f, 8f, 26f, 14f, Color(0xFFECEFF1)); box(42f, 30f, 26f, 18f, Color(0xFF37474F)); drawLine(Color(0xFF43A047), Offset(82f, 22f), Offset(88f, 30f), 4f); drawLine(Color(0xFF43A047), Offset(88f, 30f), Offset(100f, 12f), 4f) }
            else -> { drawCircle(accent, 20f, Offset(w / 2, h / 2), style = Stroke(4f)); drawLine(accent, Offset(w / 2 - 8f, h / 2), Offset(w / 2 - 2f, h / 2 + 8f), 4f); drawLine(accent, Offset(w / 2 - 2f, h / 2 + 8f), Offset(w / 2 + 10f, h / 2 - 8f), 4f) }
        }
    }
}

@Composable
fun HelpScreen(onGoto: (String) -> Unit) {
    var tab by remember { mutableStateOf("quick") }
    val skin = Skins.current()
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            topics.take(1).forEach { Btn(it.title, selected = tab == it.id) { tab = it.id } }
            Btn("ASK A HELPER", selected = tab == "helpers", color = Color(0xFFFFA000)) { tab = "helpers" }
            Btn("CONSOLE MANUALS", selected = tab == "manuals", color = Color(0xFF26A69A)) { tab = "manuals" }
            topics.drop(1).forEach { Btn(it.title, selected = tab == it.id) { tab = it.id } }
        }
        if (tab == "helpers") HelpersChat(onGoto) else if (tab == "manuals") Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) { ManualsScreen() } else {
            val t = topics.first { it.id == tab }
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) { Picto(t.pic, skin.accent); Spacer(Modifier.width(10.dp)); Text(t.title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black) }
                t.lines.forEach { Text(it, color = Color.White, fontSize = 14.sp, modifier = Modifier.padding(vertical = 5.dp)) }
                if (t.go.isNotEmpty()) Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) { t.go.forEach { (k, n) -> Btn("▶ " + I18n.tr(n)) { onGoto(k) } } }
                Text("Helpers' knowledge can be incomplete. For anything important check official manuals, Sonic Retro / Sonic Stadium or fan forums.", color = Color(0xCCFFFFFF), fontSize = 11.sp, modifier = Modifier.padding(top = 14.dp, bottom = 30.dp))
            }
        }
    }
}

@Composable
private fun Avatar(h: Helper, size: Int = 44) {
    androidx.compose.foundation.Canvas(Modifier.size(size.dp)) {
        val w = this.size.width; val hh = this.size.height
        drawCircle(h.color, w / 2); drawCircle(Color.White.copy(.92f), w * .3f, Offset(w * .5f, hh * .5f))
        drawCircle(Color(0xFF212121), w * .05f, Offset(w * .4f, hh * .44f)); drawCircle(Color(0xFF212121), w * .05f, Offset(w * .6f, hh * .44f))
        if (h.id == "tails") { drawCircle(Color(0xFF212121), w * .12f, Offset(w * .38f, hh * .44f), style = Stroke(3f)); drawCircle(Color(0xFF212121), w * .12f, Offset(w * .62f, hh * .44f), style = Stroke(3f)) }   // scientist's glasses
        if (h.id == "eggman") { val m = Color(0xFF6D3B14)   // big moustache
            drawOval(m, Offset(w * .22f, hh * .52f), Size(w * .28f, hh * .2f)); drawOval(m, Offset(w * .5f, hh * .52f), Size(w * .28f, hh * .2f))
            drawCircle(m, w * .05f, Offset(w * .2f, hh * .5f)); drawCircle(m, w * .05f, Offset(w * .8f, hh * .5f)) }
    }
}

/** a simple themed location behind each helper's dialogue */
@Composable
private fun Backdrop(h: Helper, modifier: Modifier) {
    androidx.compose.foundation.Canvas(modifier) {
        val w = size.width; val hh = size.height
        val (top, bot) = when (h.id) { "tails" -> Color(0xFF81D4FA) to Color(0xFFFFE0B2); "sonic" -> Color(0xFF4FC3F7) to Color(0xFF66BB6A); "amy" -> Color(0xFFFFCDD2) to Color(0xFFF8BBD0)
            "knuckles" -> Color(0xFF7E57C2) to Color(0xFFD7CCC8); "eggman" -> Color(0xFF4E342E) to Color(0xFFBF360C); "metal" -> Color(0xFF263238) to Color(0xFF455A64)
            "motobug" -> Color(0xFF81D4FA) to Color(0xFF558B2F); "buzz" -> Color(0xFF81D4FA) to Color(0xFFFFF59D); else -> Color(0xFF212121) to Color(0xFF4A148C) }
        drawRect(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(top, bot)), Offset.Zero, Size(w, hh), alpha = .55f)
        when (h.id) {
            "tails" -> { for (i in 0..3) drawCircle(Color.White.copy(.5f), 24f, Offset(w * (.15f + i * .25f), hh * .15f)); drawRect(Color(0xFF8D6E63), Offset(0f, hh * .9f), Size(w, hh * .1f)) }   // workshop sky + floor
            "sonic", "motobug" -> { for (i in 0..8) drawRect(if (i % 2 == 0) Color(0xFF6D4C41) else Color(0xFF8D6E63), Offset(i * w / 8f, hh * .88f), Size(w / 8f, hh * .12f)); drawCircle(Color(0xFFFFEB3B), 30f, Offset(w * .85f, hh * .12f)) }   // Green Hill checkerboard
            "amy" -> for (i in 0..6) drawCircle(Color(0xFFF06292).copy(.5f), 14f, Offset(w * (.1f + i * .14f), hh * (.2f + (i % 3) * .25f)))
            "knuckles" -> { drawCircle(Color(0xFF69F0AE).copy(.6f), 22f, Offset(w * .8f, hh * .2f)); drawRect(Color(0xFF6D4C41), Offset(0f, hh * .92f), Size(w, hh * .08f)) }   // Master Emerald over rock
            "eggman" -> { drawCircle(Color(0xFF9E9E9E), 50f, Offset(w * .85f, hh * .18f)); drawLine(Color(0xFFFF5722), Offset(0f, hh * .93f), Offset(w, hh * .93f), 6f) }
            "metal" -> for (i in 0..6) drawLine(Color(0xFF00E5FF).copy(.4f), Offset(i * w / 6f, 0f), Offset(i * w / 6f, hh), 2f)
            "buzz" -> for (i in 0..4) drawCircle(Color.White.copy(.6f), 20f, Offset(w * (.1f + i * .22f), hh * (.12f + (i % 2) * .1f)))
            else -> { drawCircle(Color(0xFFD32F2F).copy(.5f), 40f, Offset(w * .82f, hh * .2f)); for (i in 0..14) drawCircle(Color.White.copy(.6f), 2f, Offset(w * ((i * 37) % 100) / 100f, hh * ((i * 53) % 70) / 100f)) }   // space
        }
    }
}

@Composable
private fun HelpersChat(onGoto: (String) -> Unit) {
    var who by remember { mutableStateOf("tails") }
    var text by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf("both") }       // list | type | both
    var depth by remember { mutableIntStateOf(0) }        // 0 simple, 1 technical, 2 developer (Tails)
    val msgs = remember { mutableStateListOf<Pair<Boolean, String>>() }
    val h = Helpers.byId(who)
    var suggest by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(who) { msgs.clear(); msgs.add(false to (h.intro + "  [" + h.role + "]")); suggest = null }
    fun reply(q: QA): String = when { who == "tails" && depth == 2 -> q.dev ?: q.tech ?: q.a; who == "tails" && depth == 1 -> q.tech ?: q.a; else -> q.a }
    fun ask(q: String) {
        if (q.isBlank()) return
        msgs.add(true to q)
        val own = Helpers.search(q, who)
        if (own != null) { msgs.add(false to reply(own.second)); suggest = null; return }
        val other = Helpers.search(q, null)
        if (other != null) { msgs.add(false to "That sounds like a question for ${other.first.name} (${other.first.role}). Tap their name above to switch!"); suggest = other.first.id }
        else { msgs.add(false to "I don't know that one. Try the suggested questions or another helper, or look it up in manuals and fan forums. I can be incomplete or wrong."); suggest = null }
    }
    Box(Modifier.fillMaxSize()) {
        Backdrop(h, Modifier.fillMaxSize())
        Column(Modifier.fillMaxSize().padding(horizontal = 10.dp)) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Helpers.all.forEach { x -> Column(Modifier.clip(RoundedCornerShape(10.dp)).background(if (x.id == who) Color.White.copy(.3f) else Color.Transparent).forgeClick { who = x.id }.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) { Avatar(x, 36); Text(x.name, color = Color.White, fontSize = 11.sp, maxLines = 1) } }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 2.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Ask by:", color = Color.White, fontSize = 11.sp)
                Btn("LIST", selected = mode == "list") { mode = "list" }; Btn("TYPE", selected = mode == "type") { mode = "type" }; Btn("BOTH", selected = mode == "both") { mode = "both" }
                if (who == "tails") { Text("Depth:", color = Color.White, fontSize = 11.sp); Btn("SIMPLE", selected = depth == 0) { depth = 0 }; Btn("TECHNICAL", selected = depth == 1) { depth = 1 }; Btn("DEVELOPER", selected = depth == 2) { depth = 2 } }
            }
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState(), reverseScrolling = true).padding(vertical = 6.dp)) {
                msgs.forEach { (user, t) ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = if (user) Arrangement.End else Arrangement.Start, verticalAlignment = Alignment.Top) {
                        if (!user) { Avatar(h, 30); Spacer(Modifier.width(6.dp)) }
                        Text(t, color = if (user) Color.Black else Color.White, fontSize = 13.sp, modifier = Modifier.widthIn(max = 320.dp).clip(RoundedCornerShape(12.dp)).background(if (user) Skins.current().accent else Color.Black.copy(.6f)).padding(10.dp))
                    }
                }
            }
            suggest?.let { id -> Btn("Switch to " + Helpers.byId(id).name, color = Helpers.byId(id).color) { who = id } }
            if (mode != "type") Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) { h.qa.forEach { q -> Btn(q.q) { ask(q.q) } } }
            if (mode != "list") Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 6.dp)) {
                OutlinedTextField(text, { text = it }, placeholder = { Text("Ask ${h.name}...") }, singleLine = true, modifier = Modifier.weight(1f))
                Spacer(Modifier.width(6.dp)); Btn("ASK", selected = true) { ask(text); text = "" }
            }
            Text("${Helpers.total} answers · helpers can be wrong or out of date", color = Color(0xCCFFFFFF), fontSize = 10.sp, modifier = Modifier.padding(bottom = 2.dp))
        }
    }
}
