package com.sonicforge.input

import android.view.InputDevice
import android.view.KeyEvent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import com.sonicforge.data.Store
import org.json.JSONArray
import org.json.JSONObject

/** Which family a connected controller belongs to. Detected from the name / USB vendor id; the user can override it. */
enum class PadStyle(val label: String) {
    XBOX("Xbox"), PS4("DualShock 4"), PS5("DualSense"), SWITCH("Switch Pro"), STEAM("Steam Controller"), GENERIC("Generic gamepad");
    val ps: Boolean get() = this == PS4 || this == PS5
    companion object {
        fun detect(name: String, vendor: Int, product: Int): PadStyle {
            val n = name.lowercase()
            return when {
                "dualsense" in n || (vendor == 0x054c && (product == 0x0ce6 || product == 0x0df2)) -> PS5
                "dualshock" in n || vendor == 0x054c || "ps4" in n -> PS4
                vendor == 0x057e || "pro controller" in n || "switch" in n -> SWITCH
                vendor == 0x28de || "steam" in n -> STEAM
                vendor == 0x045e || "xbox" in n || "x-box" in n -> XBOX
                else -> GENERIC
            }
        }
    }
}

/** One layer of overrides. Only the actions the user changed are stored, so layers never overwrite each other. Code 0 = "explicitly unassigned". */
class Layer(val pad: MutableMap<String, Int> = mutableMapOf(), val kb: MutableMap<String, Int> = mutableMapOf(), val combo: MutableMap<String, String> = mutableMapOf()) {
    fun isEmpty() = pad.isEmpty() && kb.isEmpty() && combo.isEmpty()
    fun copyOf() = Layer(pad.toMutableMap(), kb.toMutableMap(), combo.toMutableMap())
}

data class Template(val id: String, val name: String, val info: String, val builtin: Boolean)

/**
 * Control profiles, three levels with a clear priority:   GAME  →  EMULATOR  →  GLOBAL  →  factory default.
 * Each level is its own sparse layer, so editing one never rewrites another. Named "templates" (built in or yours) can be copied into any layer.
 * Old installs: the former single map (keys pad_* / kb_* / combo_*) is read as the GLOBAL layer's base, so nothing is lost.
 */
object Profiles {
    const val GLOBAL = "g"
    /** bumped after every change so Compose screens recompose */
    var tick by mutableIntStateOf(0)
    /** the running game (set by GameActivity); empty while in the launcher */
    @Volatile var emu = ""
    @Volatile var game = ""

    fun emuLayer(sys: String) = "e:$sys"
    fun gameLayer(romId: String) = "r:$romId"
    fun tplLayer(id: String) = "n:$id"
    fun chainFor(sys: String, romId: String): List<String> {
        val l = ArrayList<String>(); if (romId.isNotEmpty()) l.add(gameLayer(romId)); if (sys.isNotEmpty()) l.add(emuLayer(sys)); l.add(GLOBAL); return l
    }
    fun activeChain() = chainFor(emu, game)

    private val cache = HashMap<String, Layer>()
    fun layer(id: String): Layer = synchronized(cache) { cache.getOrPut(id) { parse(Store.s("pfl_$id")) } }.let { it }
    private fun parse(t: String): Layer {
        val l = Layer(); if (t.isEmpty()) return l
        try {
            val o = JSONObject(t)
            fun ints(k: String, into: MutableMap<String, Int>) { o.optJSONObject(k)?.let { j -> j.keys().forEach { into[it] = j.optInt(it, 0) } } }
            ints("pad", l.pad); ints("kb", l.kb)
            o.optJSONObject("combo")?.let { j -> j.keys().forEach { l.combo[it] = j.optString(it, "") } }
        } catch (_: Exception) {}
        return l
    }
    fun save(id: String, l: Layer) {
        synchronized(cache) { cache[id] = l }
        if (l.isEmpty()) Store.set("pfl_$id", "") else {
            val o = JSONObject(); o.put("pad", JSONObject(l.pad as Map<*, *>)); o.put("kb", JSONObject(l.kb as Map<*, *>)); o.put("combo", JSONObject(l.combo as Map<*, *>))
            Store.set("pfl_$id", o.toString())
        }
        tick++
    }
    fun invalidate() { synchronized(cache) { cache.clear() }; tick++ }

    /** the button/key an action uses in this context, and which layer decided it ("" = factory) */
    fun resolve(a: Act, kb: Boolean, chain: List<String>): Pair<Int, String> {
        for (id in chain) { val m = if (kb) layer(id).kb else layer(id).pad; m[a.name]?.let { return it to id } }
        Store.settings[(if (kb) "kb_" else "pad_") + a.name]?.toIntOrNull()?.let { return it to GLOBAL }
        return (if (kb) a.kbDef else a.def) to ""
    }
    fun code(a: Act, kb: Boolean, chain: List<String>) = resolve(a, kb, chain).first
    fun comboOf(a: Act, chain: List<String>): Act? {
        var n = ""
        run { for (id in chain) { layer(id).combo[a.name]?.let { n = it; return@run } }; n = Store.s("combo_${a.name}") }
        if (n.isEmpty() || n == "NONE") return null
        return Act.values().firstOrNull { it.name == n }
    }
    /** a diagonal is simply two directions at once */
    fun expand(a: Act): List<Act> = when (a) {
        Act.UPRIGHT -> listOf(Act.UP, Act.RIGHT); Act.UPLEFT -> listOf(Act.UP, Act.LEFT)
        Act.DOWNRIGHT -> listOf(Act.DOWN, Act.RIGHT); Act.DOWNLEFT -> listOf(Act.DOWN, Act.LEFT); else -> listOf(a) }

    fun layerLabel(id: String): String = when {
        id.isEmpty() -> "Factory"; id == GLOBAL -> "Global"
        id.startsWith("e:") -> "Emulator"; id.startsWith("r:") -> "Game"; else -> "Profile"
    }

    /** removes every override in one layer (for GLOBAL also the old pre-profile keys) */
    fun resetLayer(id: String) {
        if (id == GLOBAL) Act.values().forEach { Store.set("pad_${it.name}", ""); Store.set("kb_${it.name}", ""); Store.set("combo_${it.name}", "") }
        save(id, Layer())
    }
    /** wipes GLOBAL, every emulator and every game layer; your named profiles stay */
    fun restoreFactory(romIds: List<String>, sysIds: List<String>) {
        resetLayer(GLOBAL); sysIds.forEach { resetLayer(emuLayer(it)) }; romIds.forEach { resetLayer(gameLayer(it)) }
    }
    fun resetAction(id: String, a: Act, kb: Boolean) {
        if (id == GLOBAL) Store.set((if (kb) "kb_" else "pad_") + a.name, "")
        val l = layer(id).copyOf(); (if (kb) l.kb else l.pad).remove(a.name); l.combo.remove(a.name); save(id, l)
    }
    fun setBinding(id: String, a: Act, kb: Boolean, code: Int, combo: Act?) {
        val l = layer(id).copyOf(); (if (kb) l.kb else l.pad)[a.name] = code
        if (!kb) l.combo[a.name] = combo?.name ?: "NONE"
        save(id, l)
    }
    /** other actions (in this context) that already use this code */
    fun conflicts(code: Int, kb: Boolean, chain: List<String>, except: Act): List<Act> =
        if (code == 0) emptyList() else Act.values().filter { it != except && code(it, kb, chain) == code }

    // ---------- templates ----------
    val builtins = listOf(
        Template("std", "Standard (factory)", "The normal layout: three face buttons = A/B/C, shoulders = X/Y/Z. Applying it clears the layer.", true),
        Template("compact", "Compact (3 buttons)", "Turns the 6-button extras off so the shoulder triggers are free.", true),
        Template("trig", "Triggers = Save / Load", "L2 quick-saves, R2 quick-loads (the 6-button Y/Z are switched off).", true))
    fun builtinLayer(id: String): Layer = when (id) {
        "compact" -> Layer(mutableMapOf("X" to 0, "Y" to 0, "Z" to 0))
        "trig" -> Layer(mutableMapOf("Y" to 0, "Z" to 0, "SAVE" to KeyEvent.KEYCODE_BUTTON_L2, "LOAD" to KeyEvent.KEYCODE_BUTTON_R2))
        else -> Layer()
    }
    fun custom(): List<Template> {
        val out = ArrayList<Template>()
        try { val a = JSONArray(Store.s("pf_tpls", "[]")); for (i in 0 until a.length()) { val o = a.getJSONObject(i); out.add(Template(o.getString("id"), o.getString("name"), "Your profile", false)) } } catch (_: Exception) {}
        return out
    }
    private fun writeCustom(l: List<Template>) { val a = JSONArray(); l.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name)) }; Store.set("pf_tpls", a.toString()); tick++ }
    fun templateLayer(t: Template): Layer = if (t.builtin) builtinLayer(t.id) else layer(tplLayer(t.id)).copyOf()
    fun createTemplate(name: String, from: Layer): Template {
        val id = System.currentTimeMillis().toString(36); val t = Template(id, name.ifBlank { "My profile" }, "Your profile", false)
        writeCustom(custom() + t); save(tplLayer(id), from.copyOf()); return t
    }
    fun renameTemplate(id: String, name: String) { writeCustom(custom().map { if (it.id == id) it.copy(name = name.ifBlank { it.name }) else it }) }
    fun deleteTemplate(id: String) { writeCustom(custom().filter { it.id != id }); save(tplLayer(id), Layer()) }
    /** copy a template into a layer. The template's entries replace that layer's entries; nothing else is touched. */
    fun applyTemplate(t: Template, target: String) {
        val src = templateLayer(t)
        if (t.builtin && t.id == "std") { resetLayer(target); return }
        val l = layer(target).copyOf(); l.pad.putAll(src.pad); l.kb.putAll(src.kb); l.combo.putAll(src.combo); save(target, l)
    }

    fun codeName(code: Int): String = if (code == 0) "—" else KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_")

    /** friendly name of a button for a controller family (Android reports buttons by POSITION: BUTTON_A is the bottom face button) */
    fun btnLabel(style: PadStyle, code: Int): String {
        val ps = style.ps; val sw = style == PadStyle.SWITCH
        return when (code) {
            KeyEvent.KEYCODE_BUTTON_A -> if (ps) "✕" else if (sw) "B" else "A"
            KeyEvent.KEYCODE_BUTTON_B -> if (ps) "○" else if (sw) "A" else "B"
            KeyEvent.KEYCODE_BUTTON_X -> if (ps) "□" else if (sw) "Y" else "X"
            KeyEvent.KEYCODE_BUTTON_Y -> if (ps) "△" else if (sw) "X" else "Y"
            KeyEvent.KEYCODE_BUTTON_L1 -> if (ps) "L1" else if (sw) "L" else "LB"
            KeyEvent.KEYCODE_BUTTON_R1 -> if (ps) "R1" else if (sw) "R" else "RB"
            KeyEvent.KEYCODE_BUTTON_L2 -> if (ps) "L2" else if (sw) "ZL" else "LT"
            KeyEvent.KEYCODE_BUTTON_R2 -> if (ps) "R2" else if (sw) "ZR" else "RT"
            KeyEvent.KEYCODE_BUTTON_SELECT -> when (style) { PadStyle.PS4 -> "Share"; PadStyle.PS5 -> "Create"; PadStyle.SWITCH -> "−"; PadStyle.STEAM -> "Back"; PadStyle.XBOX -> "View"; else -> "Select" }
            KeyEvent.KEYCODE_BUTTON_START -> when (style) { PadStyle.PS4, PadStyle.PS5 -> "Options"; PadStyle.SWITCH -> "+"; PadStyle.XBOX -> "Menu"; else -> "Start" }
            KeyEvent.KEYCODE_BUTTON_MODE -> when (style) { PadStyle.PS4, PadStyle.PS5 -> "PS"; PadStyle.STEAM -> "Steam"; PadStyle.SWITCH -> "Home"; PadStyle.XBOX -> "Xbox"; else -> "Mode" }
            KeyEvent.KEYCODE_BUTTON_THUMBL -> if (ps) "L3" else "LS"
            KeyEvent.KEYCODE_BUTTON_THUMBR -> if (ps) "R3" else "RS"
            KeyEvent.KEYCODE_DPAD_UP -> "D-pad ↑"; KeyEvent.KEYCODE_DPAD_DOWN -> "D-pad ↓"; KeyEvent.KEYCODE_DPAD_LEFT -> "D-pad ←"; KeyEvent.KEYCODE_DPAD_RIGHT -> "D-pad →"
            0 -> "—"
            else -> codeName(code)
        }
    }
    fun actShort(a: Act): String = when (a) {
        Act.UP -> "↑"; Act.DOWN -> "↓"; Act.LEFT -> "←"; Act.RIGHT -> "→"; Act.UPRIGHT -> "↗"; Act.UPLEFT -> "↖"; Act.DOWNRIGHT -> "↘"; Act.DOWNLEFT -> "↙"
        Act.START -> "START"; Act.MODE -> "MODE"; Act.TURBO -> "FF"; Act.REWIND -> "REW"; Act.SLOTNEXT -> "SLOT+"; Act.SLOTPREV -> "SLOT−"; Act.UITOGGLE -> "UI"; Act.VIBTOGGLE -> "VIB"
        else -> a.name
    }
    fun isGamepad(e: KeyEvent): Boolean = (e.source and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD || (e.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
}
