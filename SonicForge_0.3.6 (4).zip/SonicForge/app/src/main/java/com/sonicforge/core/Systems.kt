package com.sonicforge.core

import com.sonicforge.data.Store

data class SysInfo(val id: String, val label: String, val core: String?, val exts: String, val note: String, val experimental: Boolean = false)

/** The systems the launcher knows. core = libretro core file shipped in the APK (optional ones are downloaded at build time). */
object Systems {
    val all = listOf(
        SysInfo("md", "Mega Drive / Genesis", "libgpgx.so", ".md .gen .bin .smd (+ .zip .rar .7z)", "Full support. Genesis Plus GX."),
        SysInfo("sms", "Master System", "libgpgx.so", ".sms", "Full support. Sonic 8-bit games."),
        SysInfo("gg", "Game Gear", "libgpgx.so", ".gg", "Full support. Sonic 8-bit games."),
        SysInfo("scd", "Sega CD", "libgpgx.so", ".cue + .bin, .chd, .iso (or a zip/rar/7z of them)", "Needs your own BIOS: bios_CD_U/E/J.bin (LOCATIONS tab). Large files.", true),
        SysInfo("x32", "Sega 32X", "libpicodrive.so", ".32x", "PicoDrive core (Knuckles' Chaotix). Optional core.", true),
        SysInfo("gba", "Game Boy Advance", "libmgba.so", ".gba", "mGBA core (Sonic Advance). Optional core.", true),
        SysInfo("gb", "Game Boy / Color", "libmgba.so", ".gb .gbc", "mGBA core. Optional core.", true),
        SysInfo("nes", "NES / Famicom", "libfceumm.so", ".nes (+ .zip)", "FCEUmm core (GPL). Optional core, downloaded at build time. Bring your own games.", true),
        SysInfo("snes", "Super Nintendo", "libsnes9x.so", ".sfc .smc (+ .zip)", "Snes9x core (non-commercial licence, personal use). Optional core. Bring your own games.", true),
        SysInfo("nds", "Nintendo DS", "libmelonds.so", ".nds (+ .zip)", "Experimental: melonDS core (or DeSmuME as a fallback). Optional core, downloaded at build time; it may not exist for your CPU. Two screens, the lower one is the touch screen. Bring your own games.", true),
        SysInfo("bor", "OpenBOR", null, ".pak", "Not emulated here: opens the OpenBOR app and exports the PAK.", true),
        SysInfo("flash", "Flash (Ruffle)", null, ".swf", "Experimental: Flash games and movies through the Ruffle web player. Speed depends on the SWF and the quality setting.", true),
    )
    fun byId(id: String) = all.firstOrNull { it.id == id } ?: all[0]
    /** which launcher tab a system lives in */
    fun tabOf(sys: String) = when (sys) { "md", "sms", "gg" -> "md"; "scd" -> "scd"; "x32" -> "x32"; "gba", "gb" -> "gba"; "nes" -> "nes"; "snes" -> "snes"; "nds" -> "nds"; "bor" -> "bor"; "flash" -> "flash"; else -> "md" }
    /** libretro joypad bit for an on-screen/keyboard action id */
    fun bit(sys: String, id: String): Int = if (sys == "sms" || sys == "gg") when (id) {   // 2-button Sega pads: button 1 = RetroPad B, button 2 = RetroPad A; old Mega Drive layouts keep working
        "1", "B" -> Bits.B; "2", "C", "A" -> Bits.A; "START" -> Bits.START; else -> 0
    } else if (sys == "gba" || sys == "gb" || sys == "nes" || sys == "snes" || sys == "nds") when (id) {
        "A" -> if (Store.b("abSwap", false)) Bits.B else Bits.A; "B" -> if (Store.b("abSwap", false)) Bits.A else Bits.B; "L" -> Bits.L; "R" -> Bits.R; "START" -> Bits.START; "MODE" -> Bits.SELECT; "X" -> Bits.X; "Y" -> Bits.Y; else -> 0
    } else when (id) {
        "A" -> Bits.Y; "B" -> Bits.B; "C" -> Bits.A; "X" -> Bits.L; "Y" -> Bits.X; "Z" -> Bits.R; "START" -> Bits.START; "MODE" -> Bits.SELECT; else -> 0
    }
}
object PadSys { @Volatile var current = "md" }
