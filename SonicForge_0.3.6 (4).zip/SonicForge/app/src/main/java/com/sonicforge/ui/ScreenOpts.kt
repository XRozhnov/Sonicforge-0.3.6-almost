package com.sonicforge.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonicforge.data.Logger
import com.sonicforge.data.Store
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.documentfile.provider.DocumentFile
import com.sonicforge.data.Archives
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.font.FontWeight
import java.io.File

/** Launcher UI scale (like Minecraft's GUI scale). A change must be confirmed within 8 seconds or it reverts. Written, not compiled. */
object UiScale {
    /** the preference key in use: one size for everything, or a separate size for portrait and for landscape */
    fun key(land: Boolean) = if (Store.b("uiScaleSep", false)) (if (land) "uiScaleL" else "uiScaleP") else "uiScale"
    fun pct(land: Boolean): Int { val k = key(land); return Store.i(k, Store.i("uiScale", 100)).coerceIn(70, 150) }
    fun value(land: Boolean) = pct(land) / 100f
    @Composable
    fun Provide(content: @Composable () -> Unit) {
        val d = LocalDensity.current
        val land = androidx.compose.ui.platform.LocalConfiguration.current.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
        val k = value(land)
        CompositionLocalProvider(LocalDensity provides Density(d.density * k, d.fontScale)) { content() }
    }
}

@Composable
fun UiScalePanel() {
    var pending by remember { mutableStateOf<Int?>(null) }
    val land = androidx.compose.ui.platform.LocalConfiguration.current.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
    val sep = Store.b("uiScaleSep", false); val key = UiScale.key(land); val cur = UiScale.pct(land)
    var prev by remember { mutableIntStateOf(100) }
    H("Interface size")
    Text("Makes the whole launcher bigger or smaller (not the game picture). After a change you have 8 seconds to keep it; if the screen becomes unreadable just wait and it goes back by itself.", color = Color(0xCCFFFFFF), fontSize = 12.sp)
    SToggle("Separate size for portrait and landscape", "uiScaleSep", false, "ON: the size below belongs only to the way you hold the phone now; turn the phone to set the other one. OFF: one size for both.")
    Text("Now setting: " + (if (!sep) "both positions" else if (land) "LANDSCAPE" else "PORTRAIT") + " · current size $cur%" + (if (sep) " · other position: ${UiScale.pct(!land)}%" else ""), color = Color.White, fontSize = 13.sp)
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf(70, 80, 90, 100, 110, 120, 135, 150).forEach { v -> Btn("$v%", selected = cur == v) { if (v != cur) { prev = cur; Store.setI(key, v); pending = prev; com.sonicforge.audio.Sfx.play("click"); com.sonicforge.input.Haptics.ui() } } }
    }
    Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Btn("－ 5%") { if (cur > 70) { prev = cur; Store.setI(key, cur - 5); pending = prev } }
        Btn("＋ 5%") { if (cur < 150) { prev = cur; Store.setI(key, cur + 5); pending = prev } }
        Btn("RESET TO 100%", color = Color(0xFFE53935)) { Store.setI("uiScale", 100); Store.setI("uiScaleL", 100); Store.setI("uiScaleP", 100); pending = null }
    }
    pending?.let { old ->
        var left by remember { mutableIntStateOf(8) }
        LaunchedEffect(Unit) { while (left > 0) { delay(1000); left-- }; Store.setI(key, old); pending = null }
        AlertDialog(onDismissRequest = { }, containerColor = Color(0xFF0D0D14), titleContentColor = Color.White, textContentColor = Color.White,
            title = { Text("Keep this size?") }, text = { Text("Going back to ${old}% in $left s.") },
            confirmButton = { TextButton({ pending = null }) { Text("KEEP") } },
            dismissButton = { TextButton({ Store.setI(key, old); pending = null }) { Text("GO BACK") } })
    }
}

/** per-category cache clearing + free space on the device (SETTINGS ▸ DATA & PRIVACY) */
@Composable
fun StorageTools() {
    StorageMap()
    val ctx = LocalContext.current; var tick by remember { mutableIntStateOf(0) }; @Suppress("UNUSED_VARIABLE") val t = tick
    fun size(f: File): Long = if (f.isFile) f.length() else (f.listFiles()?.sumOf { size(it) } ?: 0L)
    fun mb(b: Long) = if (b < 1024 * 1024) "${b / 1024} KB" else "%.1f MB".format(b / 1048576.0)
    val free = try { ctx.filesDir.usableSpace } catch (_: Exception) { 0L }; val total = try { ctx.filesDir.totalSpace } catch (_: Exception) { 0L }
    H("Space and caches")
    Text("Device: ${mb(free)} free of ${mb(total)}.", color = Color.White, fontSize = 13.sp)
    val cats = listOf(
        Triple("Temporary files (cache)", ctx.cacheDir, "Safe to clear: rebuilt when needed."),
        Triple("Save states", File(ctx.filesDir, "saves"), "Erases your save states and battery saves. Not recoverable."),
        Triple("Pictures (covers, backgrounds)", com.sonicforge.data.Library.art, "Your own pictures; games fall back to the built-in look."),
        Triple("Media (comics, notes, video, recordings)", Media.root, "Everything you added in the MEDIA tab."))
    var ask by remember { mutableStateOf<Triple<String, File, String>?>(null) }
    val maxB = cats.maxOf { size(it.second) }.coerceAtLeast(1L)
    cats.forEach { c ->
        val b = size(c.second)
        Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
            Row(Modifier.fillMaxWidth()) { Text(c.first + ": " + mb(b), color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f)); Btn("CLEAR", color = Color(0xFFE53935)) { ask = c } }
            Box(Modifier.fillMaxWidth(b.toFloat() / maxB).height(6.dp).background(Color(0xFF4FC3F7), androidx.compose.foundation.shape.RoundedCornerShape(3.dp)))
        }
    }
    ask?.let { c -> ConfirmDialog("Clear ${c.first}?", c.third, "Your game files (ROMs) are not touched.", onYes = {
        try { c.second.listFiles()?.forEach { it.deleteRecursively() }; Logger.notice("Cleared ${c.first}") } catch (e: Exception) { Logger.notice("Could not clear: ${e.message}", false) }
        ask = null; tick++ }, onNo = { ask = null }) }
}

/**
 * STORAGE MAP: one bar for the whole device (SonicForge / other things / free) and one bar for what SonicForge itself keeps, every part with its size.
 * Files the launcher only READS in place (a linked game folder, a linked music folder) are not inside the launcher: a switch decides whether they are counted.
 */
@Composable
fun StorageMap() {
    val ctx = LocalContext.current
    var count by remember { mutableStateOf(Store.b("storeCountExt", false)) }
    var parts by remember { mutableStateOf<List<Triple<String, Long, Color>>?>(null) }
    var ext by remember { mutableStateOf<List<Pair<String, Long>>>(emptyList()) }
    var devTotal by remember { mutableStateOf(0L) }; var devFree by remember { mutableStateOf(0L) }
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(tick) {
        withContext(Dispatchers.IO) {
            fun size(f: File?): Long = if (f == null) 0L else if (f.isFile) f.length() else (f.listFiles()?.sumOf { size(it) } ?: 0L)
            fun docSize(u: String, exts: Set<String>): Long = try {
                val root = DocumentFile.fromTreeUri(ctx, android.net.Uri.parse(u)); var sum = 0L
                fun walk(d: DocumentFile, depth: Int) { d.listFiles().forEach { if (it.isDirectory) { if (depth < 3) walk(it, depth + 1) } else if ((it.name ?: "").substringAfterLast('.', "").lowercase() in exts) sum += it.length() } }
                if (root != null) walk(root, 0); sum } catch (_: Exception) { 0L }
            val fd = ctx.filesDir; val ex = ctx.getExternalFilesDir(null)
            val apk = size(File(ctx.applicationInfo.sourceDir)) + (ctx.applicationInfo.splitSourceDirs?.sumOf { size(File(it)) } ?: 0L)
            val games = size(File(fd, "roms")); val sys = size(File(fd, "system")); val saves = size(File(fd, "saves")); val art = size(File(fd, "art"))
            val music = size(File(fd, "music")) + size(ctx.getExternalFilesDir("music"))
            val video = size(File(Media.root, "video")); val media = size(Media.root) - video
            val cache = size(ctx.cacheDir) + size(ctx.externalCacheDir)
            val counted = games + sys + saves + art + size(File(fd, "music")) + size(Media.root)
            val other = (size(fd) - counted).coerceAtLeast(0L) + (size(ex) - size(ctx.getExternalFilesDir("music")) - (if (Media.root.path.startsWith(ex?.path ?: "\u0000")) size(Media.root) else 0L)).coerceAtLeast(0L)
            devTotal = try { fd.totalSpace } catch (_: Exception) { 0L }; devFree = try { fd.usableSpace } catch (_: Exception) { 0L }
            parts = listOf(Triple("App itself (APK)", apk, Color(0xFF9575CD)), Triple("Game copies (ROMs, disc images)", games, Color(0xFF4FC3F7)), Triple("Music in the app folders", music, Color(0xFF81C784)),
                Triple("Video", video, Color(0xFFFF8A65)), Triple("Other media (pictures, comics, notes, recordings)", media, Color(0xFFFFD54F)), Triple("Save states and battery saves", saves, Color(0xFFBA68C8)),
                Triple("Covers and backgrounds", art, Color(0xFF4DB6AC)), Triple("BIOS and system files", sys, Color(0xFFA1887F)), Triple("Temporary files (cache)", cache, Color(0xFF90A4AE)), Triple("Settings, logs, other", other, Color(0xFFE0E0E0)))
            val l = ArrayList<Pair<String, Long>>()
            val rf = Store.s("romFolder"); if (rf.isNotEmpty()) l.add("Linked game folder (originals stay there)" to docSize(rf, Archives.romExts + Archives.archiveExts + Archives.cdExts))
            val mf = Store.s("musicFolder"); if (mf.isNotEmpty()) l.add("Linked music folder (played from there)" to docSize(mf, setOf("mp3", "ogg", "wav", "flac", "m4a", "opus", "aac", "mid", "midi")))
            ext = l
        }
    }
    fun mb(b: Long) = if (b < 1024 * 1024) "${b / 1024} KB" else if (b < 1024L * 1024 * 1024) "%.1f MB".format(b / 1048576.0) else "%.2f GB".format(b / 1073741824.0)
    H("Storage map")
    val p = parts
    if (p == null) { Text("Measuring…", color = Color(0xCCFFFFFF), fontSize = 12.sp); return }
    val mine = p.sumOf { it.second }; val extSum = if (count) ext.sumOf { it.second } else 0L
    val total = devTotal.coerceAtLeast(1L); val freeB = devFree; val others = (total - freeB - mine).coerceAtLeast(0L)
    @Composable fun bar(segs: List<Pair<Long, Color>>, h: Int) { Row(Modifier.fillMaxWidth().height(h.dp).clip(RoundedCornerShape(6.dp)).background(Color.White.copy(.08f))) { segs.forEach { (b, c) -> if (b > 0) Box(Modifier.weight(b.toFloat().coerceAtLeast(1f)).fillMaxHeight().background(c)) } } }
    Text("The whole device: ${mb(total)}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    bar(listOf(mine to Color(0xFF29B6F6), others to Color(0xFF616161), freeB to Color(0xFF2E7D32)), 18)
    Text("■ SonicForge ${mb(mine)} (${"%.1f".format(mine * 100.0 / total)}%)    ■ everything else ${mb(others)}    ■ free ${mb(freeB)}", color = Color(0xCCFFFFFF), fontSize = 10.sp, modifier = Modifier.padding(top = 3.dp, bottom = 10.dp))
    Text("What SonicForge keeps: ${mb(mine)}" + if (count && extSum > 0) "  (+ ${mb(extSum)} outside, see below)" else "", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    bar(p.map { it.second to it.third } + (if (count) ext.map { it.second to Color(0xFFFF5252) } else emptyList()), 22)
    p.filter { it.second > 0 }.sortedByDescending { it.second }.forEach { (n, b, c) ->
        Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(10.dp).clip(RoundedCornerShape(3.dp)).background(c)); Text("  $n", color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f)); Text(mb(b) + "  ·  " + (if (mine > 0) b * 100 / mine else 0) + "%", color = Color(0xCCFFFFFF), fontSize = 11.sp) } }
    if (count) ext.forEach { (n, b) -> Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).clip(RoundedCornerShape(3.dp)).background(Color(0xFFFF5252))); Text("  $n", color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f)); Text(mb(b), color = Color(0xCCFFFFFF), fontSize = 11.sp) } }
    SToggle("Also count files the launcher only reads in place (linked folders)", "storeCountExt", false, "OFF: only what sits inside the launcher. ON: adds the size of a linked game folder / music folder as a red part. Those files are NOT copied and are not part of the launcher's own size; deleting the launcher leaves them alone.")
    if (ext.isEmpty()) Text("No folder is linked right now, so nothing stays outside.", color = Color(0x99FFFFFF), fontSize = 10.sp)
    Btn("MEASURE AGAIN", Modifier.padding(top = 6.dp)) { tick++ }
    H("What happens to your files")
    Text("• GAMES: when you add a game (a file, a .zip / .rar / .7z, or a whole folder with 📁 LINK FOLDER / SCAN FOLDER) the launcher makes its OWN COPY inside its private folder, unpacking archives on the way. After that it never opens your original again: you may delete or move the original and the game still starts. So every game takes its size once more on the phone. Linking a folder is only a way to find new games; what it finds is copied too.", color = Color(0xDDFFFFFF), fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
    Text("• MUSIC: files you add are copied into the music folder of the app (also reachable from the file manager under Android/data). A linked music folder is different: its songs are played from where they are and are not copied.", color = Color(0xDDFFFFFF), fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
    Text("• VIDEO, PICTURES, COMICS, NOTES, RECORDINGS: copied into the app as well (a 2-hour video is gigabytes). Delete them from the MEDIA tab when you are done.", color = Color(0xDDFFFFFF), fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
    Text("• SAVES: save states and battery saves live in the app and are part of a backup. CACHE: temporary files that can always be cleared. Uninstalling the app deletes everything in the app's own folders (not the linked ones).", color = Color(0xDDFFFFFF), fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
}
