package com.sonicforge.ui

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.os.Build
import android.widget.VideoView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.sonicforge.data.Store
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

private val thumbCache = HashMap<String, ImageBitmap>()

/**
 * a small picture taken from the video itself (a frame about a tenth into the movie), cached while the app runs.
 * The picture belongs to the file (path + size): when the list changes, or a file is still being copied, it is looked up again at once.
 */
@Composable
fun VideoThumb(f: File, modifier: Modifier) {
    val len = f.length(); val ck = f.path + "|" + len
    var bmp by remember(ck) { mutableStateOf(thumbCache[ck]) }
    LaunchedEffect(ck) {
        if (bmp == null && len > 0) bmp = withContext(Dispatchers.IO) {
            try {
                val r = MediaMetadataRetriever(); r.setDataSource(f.path)
                val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                val b = r.getFrameAtTime((d * 100L).coerceIn(0L, 5_000_000L), MediaMetadataRetriever.OPTION_CLOSEST_SYNC); r.release()
                if (b == null) null else { val s = Bitmap.createScaledBitmap(b, 240, (240f * b.height / b.width.coerceAtLeast(1)).toInt().coerceAtLeast(1), true); val x = s.asImageBitmap(); thumbCache[ck] = x; x }
            } catch (_: Throwable) { null }
        }
    }
    val b = bmp
    if (b != null) Image(b, null, modifier, contentScale = ContentScale.Crop) else Box(modifier.background(Color.White.copy(.08f)), Alignment.Center) { Text("▶", color = Color.White.copy(.6f), fontSize = 18.sp) }
}

private fun fmt(ms: Int): String { val s = (ms / 1000).coerceAtLeast(0); return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, s / 60 % 60, s % 60) else "%d:%02d".format(s / 60, s % 60) }
private fun spd(s: Float) = (if (s == s.toInt().toFloat()) s.toInt().toString() else s.toString()) + "×"

@Composable
private fun IBtn(t: String, sel: Boolean = false, onClick: () -> Unit) =
    Text(t, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(if (sel) Color(0xFF1E88E5) else Color.White.copy(.14f)).clickable(onClick = onClick).padding(horizontal = 11.dp, vertical = 7.dp))

/**
 * Full-screen video player. Tap = show / hide the controls, double tap on the left / right half = 10 s back / forward, pinch = zoom (drag to move the zoomed picture),
 * seek bar, previous / next, speed 0.25x..3x with an optional "keep the voice pitch", frame by frame, volume, loop, resume where you stopped.
 * The small bar at the bottom holds only the main buttons; everything else is in the ⚙ panel, which sits at the side in landscape so the picture stays visible.
 * Written, not compiled, never run on a device.
 */
@Composable
fun VideoPlayerDialog(files: List<File>, start: Int, onClose: () -> Unit) {
    var idx by remember { mutableIntStateOf(start.coerceIn(0, (files.size - 1).coerceAtLeast(0))) }
    val f = files.getOrNull(idx)
    if (f == null) { LaunchedEffect(Unit) { onClose() }; return }
    var vv by remember { mutableStateOf<VideoView?>(null) }
    var mp by remember { mutableStateOf<MediaPlayer?>(null) }
    var playing by remember { mutableStateOf(true) }
    var pos by remember { mutableIntStateOf(0) }; var dur by remember { mutableIntStateOf(0) }
    var speed by remember { mutableFloatStateOf(Store.s("vidSpeed", "1").toFloatOrNull() ?: 1f) }
    var keepTone by remember { mutableStateOf(Store.b("vidTone", true)) }
    var vol by remember { mutableFloatStateOf(Store.i("vidVol", 100) / 100f) }
    var muted by remember { mutableStateOf(false) }
    var loop by remember { mutableStateOf(Store.b("vidLoop", false)) }
    var fps by remember { mutableIntStateOf(Store.i("vidFps", 30)) }
    var hideBars by remember { mutableStateOf(Store.b("vidBars", true)) }
    var more by remember { mutableStateOf(false) }
    var show by remember { mutableStateOf(true) }; var lastTouch by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var seeking by remember { mutableStateOf(false) }; var seekVal by remember { mutableFloatStateOf(0f) }
    var msg by remember { mutableStateOf("") }; var note by remember { mutableStateOf("") }
    var zoom by remember { mutableFloatStateOf(1f) }; var panX by remember { mutableFloatStateOf(0f) }; var panY by remember { mutableFloatStateOf(0f) }
    var boxW by remember { mutableIntStateOf(1) }; var boxH by remember { mutableIntStateOf(1) }
    var vw by remember { mutableIntStateOf(0) }; var vh by remember { mutableIntStateOf(0) }
    fun touched() { lastTouch = System.currentTimeMillis(); show = true }
    fun setZoom(z: Float) { zoom = z.coerceIn(1f, 6f); val mx = boxW * (zoom - 1) / 2; val my = boxH * (zoom - 1) / 2; panX = panX.coerceIn(-mx, mx); panY = panY.coerceIn(-my, my); if (zoom <= 1.01f) { panX = 0f; panY = 0f } }
    /** the zoom at which the picture just fills the screen (the bars of the letterbox are cropped) */
    fun fillZoom(): Float { if (vw <= 0 || vh <= 0) return 1f; val ar = vw.toFloat() / vh; val sa = boxW.toFloat() / boxH; return if (sa > ar) sa / ar else ar / sa }
    fun applyParams() {
        val m = mp ?: return
        try {
            val v = if (muted) 0f else vol; m.setVolume(v, v); m.isLooping = loop
            if (Build.VERSION.SDK_INT >= 23) {
                val s = speed.coerceIn(.1f, 4f)
                // AUDIO_FALLBACK_MODE_MUTE: when the phone's audio path can't stretch to this speed the picture still runs (silently) instead of the change being refused
                try { m.playbackParams = PlaybackParams().setSpeed(s).setPitch(if (keepTone) 1f else s).setAudioFallbackMode(PlaybackParams.AUDIO_FALLBACK_MODE_MUTE) }
                catch (_: Exception) { try { m.playbackParams = PlaybackParams().setSpeed(s).setAudioFallbackMode(PlaybackParams.AUDIO_FALLBACK_MODE_MUTE) } catch (e2: Exception) { note = "This phone cannot play at ${spd(s)} (${e2.javaClass.simpleName})." } }
                val got = try { m.playbackParams.speed } catch (_: Exception) { s }
                if (kotlin.math.abs(got - s) > .05f) note = "This phone plays at most ${spd(got)}."
                if (!playing) m.pause()
            }
        } catch (_: Exception) {}
    }
    fun seekMs(t: Int) {
        val v = vv ?: return; val to = t.coerceIn(0, (v.duration - 1).coerceAtLeast(0))
        try { if (Build.VERSION.SDK_INT >= 26 && mp != null) mp?.seekTo(to.toLong(), MediaPlayer.SEEK_CLOSEST) else v.seekTo(to) } catch (_: Exception) { v.seekTo(to) }
        pos = to
    }
    fun togglePlay() { val v = vv ?: return; if (v.isPlaying) { v.pause(); playing = false } else { v.start(); playing = true; applyParams() } }
    fun step(dir: Int) { val v = vv ?: return; if (v.isPlaying) { v.pause(); playing = false }; seekMs(v.currentPosition + dir * (1000 / fps.coerceAtLeast(1))) }
    fun savePos() { vv?.let { v -> val p = v.currentPosition; Store.set("vidPos_" + f.name, if (p > v.duration - 3000) "0" else p.toString()) } }
    val view = LocalView.current
    SideEffect {   // the system bars (clock, battery, gesture bar) hide while a video plays; the switch is in the ⚙ panel
        val w = (view.parent as? DialogWindowProvider)?.window
        if (w != null) { WindowCompat.setDecorFitsSystemWindows(w, false); val c = WindowInsetsControllerCompat(w, view)
            if (hideBars) { c.hide(WindowInsetsCompat.Type.systemBars()); c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE } else c.show(WindowInsetsCompat.Type.systemBars()) }
    }
    LaunchedEffect(vv, idx) {
        var n = 0
        while (true) {
            vv?.let { v -> try { if (!seeking) { pos = v.currentPosition; dur = v.duration.coerceAtLeast(0); playing = v.isPlaying } } catch (_: Exception) {} }
            if (show && playing && !more && System.currentTimeMillis() - lastTouch > 3500) show = false
            if (++n % 20 == 0) savePos()
            delay(250)
        }
    }
    LaunchedEffect(note) { if (note.isNotEmpty()) { delay(4000); note = "" } }
    LaunchedEffect(speed, keepTone, vol, muted, loop, mp) { applyParams(); Store.set("vidSpeed", speed.toString()); Store.setB("vidTone", keepTone); Store.set("vidVol", (vol * 100).toInt().toString()); Store.setB("vidLoop", loop) }
    LaunchedEffect(hideBars) { Store.setB("vidBars", hideBars) }
    Dialog(onDismissRequest = { savePos(); onClose() }, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black).onSizeChanged { boxW = it.width.coerceAtLeast(1); boxH = it.height.coerceAtLeast(1) }) {
            key(idx) {
                AndroidView(factory = { c ->
                    VideoView(c).also { v ->
                        vv = v; v.keepScreenOn = true
                        v.setOnPreparedListener { m ->
                            mp = m; dur = v.duration; vw = m.videoWidth; vh = m.videoHeight; val p = Store.i("vidPos_" + f.name, 0); if (p > 2000 && p < v.duration - 3000) v.seekTo(p)
                            m.setOnVideoSizeChangedListener { _, w, h -> vw = w; vh = h }
                            v.start(); playing = true; applyParams()
                        }
                        v.setOnCompletionListener { if (!loop) { if (idx < files.size - 1) idx++ else { playing = false; show = true } } }
                        v.setOnErrorListener { _, w, e -> msg = "This phone cannot play this file ($w/$e)."; true }
                        v.setVideoPath(f.path)
                    }
                }, modifier = Modifier.fillMaxSize().align(Alignment.Center).graphicsLayer(scaleX = zoom, scaleY = zoom, translationX = panX, translationY = panY), onRelease = { try { it.stopPlayback() } catch (_: Throwable) {} })
            }
            Box(Modifier.fillMaxSize()
                .pointerInput(Unit) { detectTransformGestures { _, pan, g, _ -> if (g != 1f || zoom > 1.01f) { zoom = (zoom * g).coerceIn(1f, 6f); val mx = boxW * (zoom - 1) / 2; val my = boxH * (zoom - 1) / 2; panX = (panX + pan.x).coerceIn(-mx, mx); panY = (panY + pan.y).coerceIn(-my, my); if (zoom <= 1.01f) { panX = 0f; panY = 0f }; touched() } } }
                .pointerInput(Unit) { detectTapGestures(onTap = { if (more) more = false else if (show) show = false else touched() }, onDoubleTap = { o -> touched(); val v = vv; if (v != null) seekMs(v.currentPosition + (if (o.x < size.width / 2) -10000 else 10000)) }) })
            if (msg.isNotEmpty()) Text(msg, color = Color(0xFFFFAB91), modifier = Modifier.align(Alignment.Center).padding(24.dp))
            if (note.isNotEmpty()) Text(note, color = Color.White, fontSize = 12.sp, modifier = Modifier.align(Alignment.TopCenter).padding(top = 56.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xCC000000)).padding(horizontal = 12.dp, vertical = 6.dp))
            if (zoom > 1.01f && !show) Text("🔍 " + String.format("%.1f", zoom) + "×", color = Color.White, fontSize = 11.sp, modifier = Modifier.align(Alignment.TopEnd).padding(10.dp).clip(RoundedCornerShape(8.dp)).background(Color(0x88000000)).padding(horizontal = 8.dp, vertical = 3.dp))
            if (show) {
                Row(Modifier.align(Alignment.TopStart).fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(f.name + "  (${idx + 1}/${files.size})", color = Color.White, fontSize = 12.sp, maxLines = 1, modifier = Modifier.weight(1f, false).clip(RoundedCornerShape(12.dp)).background(Color(0x99000000)).padding(horizontal = 10.dp, vertical = 6.dp))
                    Spacer(Modifier.weight(1f))
                    IBtn("🔍 " + if (zoom > 1.01f) String.format("%.1f", zoom) + "×" else "FIT", zoom > 1.01f) { touched(); if (zoom > 1.01f) setZoom(1f) else setZoom(fillZoom()) }
                    IBtn("⚙", more) { touched(); more = !more }
                    IBtn("✕") { savePos(); onClose() }
                }
                Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)).background(Color(0xB3000000)).padding(horizontal = 12.dp, vertical = 6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(fmt(if (seeking) seekVal.toInt() else pos), color = Color.White, fontSize = 11.sp)
                        Slider(value = (if (seeking) seekVal else pos.toFloat()).coerceIn(0f, dur.coerceAtLeast(1).toFloat()), onValueChange = { seeking = true; seekVal = it; touched() },
                            onValueChangeFinished = { seekMs(seekVal.toInt()); seeking = false }, valueRange = 0f..dur.coerceAtLeast(1).toFloat(), modifier = Modifier.weight(1f).padding(horizontal = 8.dp))
                        Text(fmt(dur), color = Color.White, fontSize = 11.sp)
                    }
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        IBtn("⏮") { if (idx > 0) idx-- }; IBtn("⏪10") { touched(); seekMs(pos - 10000) }; IBtn("◂|") { touched(); step(-1) }
                        IBtn(if (playing) "⏸" else "▶", true) { touched(); togglePlay() }
                        IBtn("|▸") { touched(); step(1) }; IBtn("10⏩") { touched(); seekMs(pos + 10000) }; IBtn("⏭") { if (idx < files.size - 1) idx++ }
                        IBtn("🔁", loop) { touched(); loop = !loop }
                        IBtn(if (muted) "🔇" else "🔊", muted) { touched(); muted = !muted }
                        IBtn(spd(speed) + if (!keepTone && speed != 1f) " ♪" else "", speed != 1f) { touched(); more = !more }
                    }
                }
            }
            if (more) {
                val land = boxW > boxH
                Column((if (land) Modifier.align(Alignment.CenterEnd).padding(end = 10.dp).width(280.dp).heightIn(max = (boxH / 2.6f).dp.coerceAtLeast(240.dp)) else Modifier.align(Alignment.BottomCenter).padding(bottom = 110.dp, start = 10.dp, end = 10.dp).fillMaxWidth())
                    .clip(RoundedCornerShape(16.dp)).background(Color(0xE60E1017)).verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("SPEED", color = Color(0xAAFFFFFF), fontSize = 10.sp)
                    listOf(listOf(.25f, .5f, .75f, 1f), listOf(1.25f, 1.5f, 2f, 3f)).forEach { row -> Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { row.forEach { s -> IBtn(spd(s), speed == s) { touched(); speed = s } } } }
                    IBtn(if (keepTone) "♪ KEEP VOICE PITCH: ON" else "♪ KEEP VOICE PITCH: OFF", keepTone) { touched(); keepTone = !keepTone }
                    Text("ON: faster speed keeps the voices and music at the normal pitch. OFF: like a tape, higher when faster. If your phone cannot stretch the sound that far the picture still runs, silently.", color = Color(0x99FFFFFF), fontSize = 9.sp)
                    Text("ZOOM  (pinch the picture, drag to move it)", color = Color(0xAAFFFFFF), fontSize = 10.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { IBtn("FIT", zoom <= 1.01f) { touched(); setZoom(1f) }; IBtn("FILL") { touched(); setZoom(fillZoom()) }; IBtn("2×") { touched(); setZoom(2f) }; IBtn("3×") { touched(); setZoom(3f) } }
                    Text("FRAME STEP (frames per second)", color = Color(0xAAFFFFFF), fontSize = 10.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf(24, 25, 30, 50, 60).forEach { n -> IBtn("$n", fps == n) { touched(); fps = n; Store.set("vidFps", n.toString()) } } }
                    Text("VOLUME ${(vol * 100).toInt()}%", color = Color(0xAAFFFFFF), fontSize = 10.sp)
                    Slider(value = vol, onValueChange = { vol = it; muted = false; touched() }, valueRange = 0f..1f)
                    IBtn(if (hideBars) "HIDE PHONE BARS: ON" else "HIDE PHONE BARS: OFF", hideBars) { touched(); hideBars = !hideBars }
                    Text("Tap: show / hide · double tap left / right: 10 s back / forward · ◂| |▸ one frame (video pauses) · the position is remembered", color = Color(0x88FFFFFF), fontSize = 9.sp)
                }
            }
        }
    }
}
