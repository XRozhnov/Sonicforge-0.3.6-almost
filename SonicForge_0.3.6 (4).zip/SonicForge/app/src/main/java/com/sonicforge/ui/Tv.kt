package com.sonicforge.ui

import android.app.UiModeManager
import android.content.Context
import android.content.res.Configuration
import com.sonicforge.data.Store

/** Android TV / Fire TV / set-top boxes: the first time the app starts on one, switch to a remote-friendly setup. Everything stays changeable in SETTINGS. */
object Tv {
    fun isTv(ctx: Context): Boolean = try { (ctx.getSystemService(Context.UI_MODE_SERVICE) as UiModeManager).currentModeType == Configuration.UI_MODE_TYPE_TELEVISION || ctx.packageManager.hasSystemFeature("android.software.leanback") } catch (_: Throwable) { false }
    fun init(ctx: Context) {
        if (!isTv(ctx) || Store.b("tvInit", false)) return
        Store.setB("tvInit", true)
        Store.setI("uiScale", 125)              // bigger text and buttons for a couch distance
        Store.setB("padNav", true)              // remote D-pad / gamepad moves a focus ring through the launcher
        Store.setB("hideTouch", true)            // no on-screen buttons: there is no touch screen
        Store.set("orientGame", "landscape")
        Store.setB("tvMode", true)
    }
}
