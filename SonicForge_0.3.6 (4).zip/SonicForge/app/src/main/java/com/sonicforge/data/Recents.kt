package com.sonicforge.data

import com.sonicforge.core.Systems

/**
 * The real "recently played" history: every game of every console (Mega Drive, NES, SNES, GBA, DS, Flash ...) is written here when it starts.
 * Before this the "Recent games" row was only the last game plus the library order, which is why it looked like Mega Drive only.
 * A game or a whole console can be kept out of the history ("recentHide_<id>", "recentShow_<console>"); entries can be removed by hand and come back the next time the game is played.
 */
object Recents {
    private const val KEY = "recentIds"
    fun ids(): List<String> = Store.s(KEY).split('\n').filter { it.isNotEmpty() }
    private fun save(l: List<String>) = Store.set(KEY, l.take(40).joinToString("\n"))
    fun catHidden(r: Rom): Boolean = !Store.b("recentShow_" + Systems.tabOf(r.sys), true)
    fun gameHidden(r: Rom): Boolean = Store.b("recentHide_" + r.id, false)
    fun isHidden(r: Rom): Boolean = gameHidden(r) || catHidden(r)
    /** called whenever a game is started */
    fun note(r: Rom) { if (isHidden(r)) return; save(listOf(r.id) + ids().filter { it != r.id }) }
    fun remove(id: String) = save(ids().filter { it != id })
    fun clear() = Store.set(KEY, "")
    fun setGameHidden(r: Rom, hide: Boolean) { Store.setB("recentHide_" + r.id, hide); if (hide) remove(r.id) }
    fun list(all: List<Rom>): List<Rom> = ids().mapNotNull { id -> all.firstOrNull { it.id == id } }.filter { !isHidden(it) }
}
