package com.sonicforge.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** What a system needs besides the game itself. Written from memory of the emulators' documentation: check the emulator's own page if a file is refused. */
data class Need(val level: String, val file: String, val looks: String, val where: String)   // level: REQUIRED / OPTIONAL
data class SysNeeds(val summary: String, val items: List<Need>, val gameFormat: String)

object NeedsInfo {
    val all: Map<String, SysNeeds> = mapOf(
        "scd" to SysNeeds("Needs a Sega CD BIOS.", listOf(
            Need("REQUIRED", "bios_CD_U.bin (USA) · bios_CD_E.bin (Europe) · bios_CD_J.bin (Japan)", "a raw dump, one file per region, 128 KB (131,072 bytes) each; a .zip is fine", "LOCATIONS tab ▸ Sega CD BIOS (the app renames it by the region it finds inside)"),
            Need("OPTIONAL", "backup RAM (.brm)", "made by the core; SEGA CD TOOLS can delete it if a game says the memory is full or damaged", "automatic")),
            "a .cue + .bin pair (plus any audio .wav/.mp3 tracks), or .chd, or .iso; a zip/rar/7z of them also works"),
        "gba" to SysNeeds("No BIOS needed (a built-in one is used).", listOf(Need("OPTIONAL", "gba_bios.bin", "16 KB (16,384 bytes), from your own console", "the app's system folder (LOCATIONS)")), ".gba (or zipped)"),
        "gb" to SysNeeds("No BIOS needed.", listOf(Need("OPTIONAL", "gb_bios.bin · gbc_bios.bin", "256 bytes and 2,304 bytes: the start-up logo screens", "the app's system folder (LOCATIONS)")), ".gb or .gbc"),
        "nes" to SysNeeds("No BIOS for normal cartridges.", listOf(Need("OPTIONAL", "disksys.rom", "8 KB; only for Famicom Disk System (.fds) games", "the app's system folder (LOCATIONS)")), ".nes (or zipped)"),
        "snes" to SysNeeds("Nothing extra for normal games.", emptyList(), ".sfc or .smc (or zipped)"),
        "nds" to SysNeeds("Works with built-in replacement firmware.", listOf(Need("OPTIONAL", "bios7.bin · bios9.bin · firmware.bin", "16 KB, 4 KB and 128 to 512 KB dumps from your own DS; give better compatibility and the real start menu", "the app's system folder (LOCATIONS)")), ".nds (or zipped)"),
        "psp" to SysNeeds("No BIOS needed.", emptyList(), ".iso, .cso, .pbp or .chd"),
        "wii" to SysNeeds("No BIOS needed for games.", listOf(Need("OPTIONAL", "Wii NAND dump and keys", "only for the Wii menu and online channels; not needed for discs", "inside Dolphin")), ".wbfs, .rvz, .iso, .gcz or a WAD"),
        "gc" to SysNeeds("No BIOS needed for games.", listOf(Need("OPTIONAL", "GameCube IPL (IPL.bin)", "about 2 MB, from your own console; only for the start-up animation", "inside Dolphin")), ".iso, .gcm, .rvz, .gcz or .ciso"),
        "dc" to SysNeeds("Works without BIOS (a replacement is built in).", listOf(Need("OPTIONAL", "dc_boot.bin + dc_flash.bin", "2 MB boot ROM and 128 KB flash, from your own console; some games run better", "inside Flycast's data folder")), ".cdi, .gdi or .chd (not a bare .bin)"),
        "sat" to SysNeeds("Works with a built-in replacement.", listOf(Need("OPTIONAL", "a Saturn BIOS", "about 512 KB (for example the 'sega_101' or 'mpr-17933' dumps), from your own console; improves compatibility", "inside Yaba Sanshiro 2 (Settings ▸ BIOS)")), ".cue + .bin, .chd, .iso or .mdf"),
        "3ds" to SysNeeds("No BIOS, but encrypted dumps need keys.", listOf(
            Need("OPTIONAL", "aes_keys.txt", "a plain text list of key lines from your own console; needed for encrypted .3ds/.cia files, not for decrypted ones", "inside the emulator (Lime3DS / Azahar: its user folder, sysdata)"),
            Need("OPTIONAL", "seeddb.bin · system files", "only some digital games and system apps need them", "inside the emulator")), ".3ds / .cci, .cia, .cxi or .3dsx"),
        "ps2" to SysNeeds("REQUIRES a PS2 BIOS.", listOf(
            Need("REQUIRED", "a PS2 BIOS such as scph70012.bin", "a 4 MB (4,194,304 bytes) dump, usually with its small .rom1/.rom2/.erom/.nvm companions, from your own console", "choose the folder that holds them in the emulator (Settings ▸ BIOS)")), ".iso or .chd (large files)"),
    )
    fun has(sys: String) = all.containsKey(sys)
}

@Composable
fun NeedsCard(sys: String, modifier: Modifier = Modifier) {
    val n = NeedsInfo.all[sys] ?: return
    val req = n.items.any { it.level == "REQUIRED" }
    Column(modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(10.dp)).background(Color.Black.copy(.35f)).padding(10.dp)) {
        Text((if (req) "⚠ " + I18n.tr("REQUIRED FILES") else "ℹ " + I18n.tr("EXTRA FILES")) + " · " + I18n.tr(n.summary), color = if (req) Color(0xFFFFCC80) else Color(0xFF80D8FF), fontWeight = FontWeight.Bold, fontSize = 12.sp)
        n.items.forEach { it ->
            Text((if (it.level == "REQUIRED") "● " + I18n.tr("REQUIRED") + "  " else "○ " + I18n.tr("optional") + "  ") + it.file, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 5.dp))
            Text(I18n.tr("looks like:") + " " + I18n.tr(it.looks), color = Color(0xDDFFFFFF), fontSize = 11.sp)
            Text(I18n.tr("put it:") + " " + I18n.tr(it.where), color = Color(0xDDFFFFFF), fontSize = 11.sp)
        }
        Text(I18n.tr("Game file:") + " " + I18n.tr(n.gameFormat), color = Color(0xFF9BFF9B), fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
        Text("BIOS and key files are not included and must come from your own console.", color = Color(0x99FFFFFF), fontSize = 10.sp)
    }
}
