package com.sonicforge.input

import android.content.Context
import android.hardware.input.InputManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.InputDevice
import android.view.KeyEvent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.sonicforge.data.Store

enum class Act(val label: String, val def: Int, val kbDef: Int) {
    UP("D-pad Up", KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_UP), DOWN("D-pad Down", KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_DOWN),
    LEFT("D-pad Left", KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_LEFT), RIGHT("D-pad Right", KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_DPAD_RIGHT),
    A("Button A", KeyEvent.KEYCODE_BUTTON_X, KeyEvent.KEYCODE_Z), B("Button B (jump)", KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_X), C("Button C", KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_C),
    X("Button X (6-button)", KeyEvent.KEYCODE_BUTTON_Y, KeyEvent.KEYCODE_A), Y("Button Y (6-button)", KeyEvent.KEYCODE_BUTTON_L2, KeyEvent.KEYCODE_S), Z("Button Z (6-button)", KeyEvent.KEYCODE_BUTTON_R2, KeyEvent.KEYCODE_D),
    L("Shoulder L (GBA)", KeyEvent.KEYCODE_BUTTON_L2, KeyEvent.KEYCODE_Q), R("Shoulder R (GBA)", KeyEvent.KEYCODE_BUTTON_R2, KeyEvent.KEYCODE_W),
    START("Start", KeyEvent.KEYCODE_BUTTON_START, KeyEvent.KEYCODE_ENTER), MODE("Mode / Select", KeyEvent.KEYCODE_BUTTON_SELECT, KeyEvent.KEYCODE_TAB),
    SAVE("Quick save", KeyEvent.KEYCODE_BUTTON_THUMBL, KeyEvent.KEYCODE_F5), LOAD("Quick load", KeyEvent.KEYCODE_BUTTON_THUMBR, KeyEvent.KEYCODE_F7),
    MENU("Pause menu", KeyEvent.KEYCODE_BUTTON_MODE, KeyEvent.KEYCODE_ESCAPE), TURBO("Fast-forward (hold)", KeyEvent.KEYCODE_BUTTON_R1, KeyEvent.KEYCODE_SPACE), REWIND("Rewind (hold)", KeyEvent.KEYCODE_BUTTON_L1, KeyEvent.KEYCODE_R),
    UPRIGHT("Diagonal ↗ (up + right)", 0, 0), UPLEFT("Diagonal ↖ (up + left)", 0, 0), DOWNRIGHT("Diagonal ↘ (down + right)", 0, 0), DOWNLEFT("Diagonal ↙ (down + left)", 0, 0),
    SLOTNEXT("Next save slot", 0, 0), SLOTPREV("Previous save slot", 0, 0), UITOGGLE("Show / hide on-screen buttons", 0, 0), VIBTOGGLE("Vibration on / off", 0, 0)
}

data class PadInfo(val id: Int, val name: String, val vendor: Int, val product: Int, val rumble: Boolean, val style: PadStyle = PadStyle.GENERIC, val amplitude: Boolean = false, val motors: Int = 0)

object Pads {
    val devices = mutableStateListOf<PadInfo>()
    var lastKey by mutableStateOf("")
    /** when non-null, the next key press is delivered here instead of the game (used by the rebind UI) */
    var capture: ((Int) -> Unit)? = null
    /** raw capture for the mapping editor: receives the whole key event (code, device, scan code) */
    var captureEv: ((KeyEvent) -> Unit)? = null
    /** buttons currently held on any controller/keyboard (for the live highlight in the editor) */
    val held = mutableStateListOf<Int>()
    /** live stick / trigger positions of the last controller that moved (for the visual test): lx ly rx ry lt rt, each -1..1 (triggers 0..1) */
    var axes by mutableStateOf(floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f))
    fun feedAxes(e: android.view.MotionEvent) {
        if ((e.source and InputDevice.SOURCE_JOYSTICK) == 0) return
        val x = e.getAxisValue(android.view.MotionEvent.AXIS_X); val y = e.getAxisValue(android.view.MotionEvent.AXIS_Y)
        val z = e.getAxisValue(android.view.MotionEvent.AXIS_Z); val rz = e.getAxisValue(android.view.MotionEvent.AXIS_RZ)
        val lt = maxOf(e.getAxisValue(android.view.MotionEvent.AXIS_LTRIGGER), e.getAxisValue(android.view.MotionEvent.AXIS_BRAKE))
        val rt = maxOf(e.getAxisValue(android.view.MotionEvent.AXIS_RTRIGGER), e.getAxisValue(android.view.MotionEvent.AXIS_GAS))
        axes = floatArrayOf(x, y, z, rz, lt, rt)
    }
    /** called first by every activity; true = the event was consumed by the capture or by the held tracker rules */
    fun intercept(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN) { if (!held.contains(e.keyCode)) held.add(e.keyCode) } else if (e.action == KeyEvent.ACTION_UP) held.remove(e.keyCode)
        val c = captureEv ?: return false
        if (e.keyCode == KeyEvent.KEYCODE_BACK || e.keyCode == KeyEvent.KEYCODE_UNKNOWN && e.scanCode == 0) return false
        if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) c(e)
        return true
    }
    private fun chain() = Profiles.activeChain()
    fun key(a: Act) = Profiles.code(a, false, chain())
    fun kbKey(a: Act) = Profiles.code(a, true, chain())
    /** every action bound to this key (a key may drive several actions), diagonals split into two directions, plus combo partners */
    fun actsFor(code: Int, kb: Boolean): List<Act> {
        if (code == 0) return emptyList()
        val ch = chain(); val out = ArrayList<Act>()
        for (a in Act.values()) {
            if (Profiles.code(a, kb, ch) != code) continue
            out.addAll(Profiles.expand(a)); Profiles.comboOf(a, ch)?.let { out.addAll(Profiles.expand(it)) }
        }
        return out
    }
    fun combo(a: Act) = Profiles.comboOf(a, chain())?.name ?: ""
    fun keyName(code: Int) = KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_")

    fun refresh() {
        devices.clear()
        for (id in InputDevice.getDeviceIds()) {
            val d = InputDevice.getDevice(id) ?: continue
            val s = d.sources
            if (!d.isVirtual && ((s and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD || (s and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK))
                {
                var has = false; var amp = false; var n = 0
                try {
                    if (Build.VERSION.SDK_INT >= 31) { val vm = d.vibratorManager; n = vm.vibratorIds.size; has = n > 0; amp = n > 0 && vm.defaultVibrator.hasAmplitudeControl() }
                    else { @Suppress("DEPRECATION") val v = d.vibrator; has = v.hasVibrator(); amp = has && v.hasAmplitudeControl(); n = if (has) 1 else 0 }
                } catch (_: Throwable) {}
                devices.add(PadInfo(id, d.name, d.vendorId, d.productId, has, PadStyle.detect(d.name, d.vendorId, d.productId), amp, n))
            }
        }
    }
    fun init(ctx: Context) {
        val im = ctx.getSystemService(Context.INPUT_SERVICE) as InputManager
        im.registerInputDeviceListener(object : InputManager.InputDeviceListener {
            override fun onInputDeviceAdded(id: Int) = refresh()
            override fun onInputDeviceRemoved(id: Int) = refresh()
            override fun onInputDeviceChanged(id: Int) = refresh()
        }, Handler(Looper.getMainLooper()))
        refresh()
    }
}
