package com.sonicforge.core

import com.sonicforge.data.Store

/**
 * Vibration driven by the game's SOUND, so every game on every console gets some haptics without a memory map.
 * A sudden loud sound is an "event": a deep boom (low pitch) = hit/explosion, a bright blip (high pitch) = pickup/coin/ring, anything else = action.
 * It is a heuristic: it cannot know WHAT happened, only that something loud and sudden did. Written, not compiled, never tried on a device.
 */
class AudioHaptics(private val assist: Boolean = false, private val recentRam: () -> Boolean = { false }, private val emit: (String) -> Unit) {
    private var avg = 0f; private var prev = 0f; private var cool = 0
    private val sens = Store.i("audioHapSens", 5).coerceIn(1, 10)
    /** [n] = number of shorts in [buf] (interleaved stereo) */
    fun feed(buf: ShortArray, n: Int) {
        if (n < 64) return
        var sum = 0.0; var zc = 0; var last = 0
        var i = 0
        while (i < n) { val v = (buf[i].toInt() + buf[i + 1 - (if (i + 1 < n) 0 else 1)].toInt()) / 2; sum += v.toDouble() * v; if ((v >= 0) != (last >= 0)) zc++; last = v; i += 2 }
        val cnt = (n / 2).coerceAtLeast(1)
        val e = (Math.sqrt(sum / cnt) / 32768.0).toFloat()
        val zcr = zc.toFloat() / cnt
        avg = avg * .96f + e * .04f
        if (cool > 0) cool--
        val gate = 0.14f - sens * 0.011f          // sensitivity 1..10 -> gate 0.13 .. 0.03
        val onset = e > gate && e > avg * 1.8f && e - prev > gate * .5f
        prev = e
        if (assist) {   // games with their own memory map: only add what the map cannot see, a loud thump that no memory event explains (monitor / enemy / boss explosion)
            if (onset && cool == 0 && e > gate * 2f && !recentRam()) { emit("boom"); cool = 20 }
            return
        }
        if (onset && cool == 0) {
            when { zcr < 0.05f -> { emit("hurt"); cool = 14 }
                   zcr > 0.20f -> { emit("ring"); cool = 5 }
                   else -> { emit("jump"); cool = 8 } }
        }
    }
    companion object {
        /** "off" | "auto" (only games without their own memory profile) | "always" */
        fun mode() = Store.s("audioHap", "auto")
    }
}
