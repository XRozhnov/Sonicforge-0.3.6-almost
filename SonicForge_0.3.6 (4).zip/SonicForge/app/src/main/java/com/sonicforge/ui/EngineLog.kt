package com.sonicforge.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonicforge.data.Logger
import com.sonicforge.data.Store
import kotlinx.coroutines.delay

object EngineLog { var defaultOn = false; fun on() = Store.b("engineLog", defaultOn) }

/**
 * ENGINE LOG: a live strip that tells what the launcher and the emulators are doing (loading core, starting game, Flash page steps ...).
 *  - touch it three times quickly: it folds into a small "LOG" pill (touch the pill to unfold it again)
 *  - long press: closes it completely. Bring it back with the ENGINE LOG switch (SETTINGS ▸ ABOUT APP, the game's settings page, or the SUPER tab)
 *  - the ▲ / ▼ button makes it taller or shorter
 */
@Composable
fun EngineLogStrip(modifier: Modifier = Modifier, tags: List<String> = listOf("/Super:", "/Emu:", "/core:", "/Import:", "/App:", "/Game", "/Flash:", "/Pad", "/Audio")) {
    var closed by remember { mutableStateOf(false) }   // the Store is not observable, so closing is also remembered here: the strip disappears at once and cannot flash back
    if (!EngineLog.on() || closed) return
    var lines by remember { mutableStateOf(listOf<String>()) }
    var big by remember { mutableStateOf(false) }
    var mini by remember { mutableStateOf(Store.b("engineLogMini", false)) }
    var taps by remember { mutableIntStateOf(0) }; var lastTap by remember { mutableLongStateOf(0L) }
    LaunchedEffect(big, mini) { while (!mini) { lines = Logger.text().lines().filter { l -> tags.any { l.contains(it) } }.takeLast(if (big) 40 else 5); delay(400) } }
    if (mini) {
        Text("⌁ LOG", color = Color(0xFF80D8FF), fontSize = 10.sp, fontWeight = FontWeight.Bold,
            modifier = modifier.padding(4.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xCC000000)).pointerInput(Unit) { detectTapGestures(onTap = { mini = false; Store.setB("engineLogMini", false) }, onLongPress = { closed = true; Store.setB("engineLog", false) }) }.padding(horizontal = 8.dp, vertical = 3.dp))
        return
    }
    Column(modifier.fillMaxWidth().background(Color(0xDD000000)).pointerInput(Unit) {
        detectTapGestures(
            onTap = { val n = System.currentTimeMillis(); taps = if (n - lastTap < 700) taps + 1 else 1; lastTap = n; if (taps >= 3) { taps = 0; mini = true; Store.setB("engineLogMini", true) } },
            onLongPress = { closed = true; Store.setB("engineLog", false) })
    }.padding(horizontal = 8.dp, vertical = 4.dp)) {
        Row {
            Text("▁ FOLD", color = Color(0xFF80D8FF), fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.pointerInput(Unit) { detectTapGestures { mini = true; Store.setB("engineLogMini", true) } }.padding(end = 10.dp))
            Text("✕ CLOSE", color = Color(0xFFFF8A80), fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.pointerInput(Unit) { detectTapGestures { closed = true; Store.setB("engineLog", false) } }.padding(end = 10.dp))
            Text("ENGINE LOG · 3 taps: fold · long press: close", color = Color(0xFF80D8FF), fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            val clip = androidx.compose.ui.platform.LocalClipboardManager.current
            Text("COPY", color = Color(0xFFFFD54F), fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.pointerInput(Unit) { detectTapGestures { clip.setText(androidx.compose.ui.text.AnnotatedString(Logger.text().lines().filter { l -> tags.any { l.contains(it) } }.takeLast(400).joinToString("\n"))); Logger.i("App", "engine log copied to the clipboard") } }.padding(horizontal = 8.dp))
            Text(if (big) "▼" else "▲", color = Color.White, fontSize = 12.sp, modifier = Modifier.pointerInput(Unit) { detectTapGestures { big = !big } }.padding(horizontal = 8.dp))
        }
        Column(if (big) Modifier.heightIn(max = 260.dp).verticalScroll(rememberScrollState(), reverseScrolling = true) else Modifier) {
            if (lines.isEmpty()) Text("(nothing yet)", color = Color(0x99FFFFFF), fontSize = 10.sp)
            lines.forEach { Text(it, color = if (it.contains(" E/") || it.contains(" W/")) Color(0xFFFFAB91) else Color(0xFF9BFF9B), fontFamily = FontFamily.Monospace, fontSize = 10.sp, maxLines = 2) }
        }
    }
}
