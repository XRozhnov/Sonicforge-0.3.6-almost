package com.sonicforge.core

import com.sonicforge.data.Store

/** Vibration debug: remembers what made the phone buzz (RAM rule / sound / touch / preset) so the debug panel can show the cause. Switch: Store "hapDebug". Written, not compiled. */
object HapDebug {
    private val q = ArrayDeque<String>()
    @Volatile var header = ""
    @Volatile var stamp = 0L
    val counts = java.util.concurrent.ConcurrentHashMap<String, Int>()
    fun on() = Store.b("hapDebug", false)
    fun add(src: String, ev: String, why: String = "") {
        counts.merge(src, 1) { a, b -> a + b }
        if (!on()) return
        val t = (System.currentTimeMillis() / 1000) % 1000
        synchronized(q) { q.addLast("${t}s  [$src] $ev" + (if (why.isNotEmpty()) "  ← $why" else "")); while (q.size > 40) q.removeFirst() }
        stamp++
    }
    fun lines(n: Int = 10): List<String> = synchronized(q) { q.toList().takeLast(n).reversed() }
    fun reset() { synchronized(q) { q.clear() }; counts.clear(); stamp++ }
}
