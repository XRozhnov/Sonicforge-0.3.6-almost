package com.sonicforge.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Switch
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonicforge.data.Store

/** Global switch for the guide overlay. First launch opens it once; after that only when the user asks (SETTINGS > ABOUT APP > OPEN GUIDE). */
object Guide { var show by mutableStateOf(false) }

private data class Page(val emoji: String, val title: String, val lines: List<String>, val c1: Color, val c2: Color, val goto: String? = null, val gotoLabel: String = "", val picker: String = "")

private val pages = listOf(
    Page("👋", "Welcome to SonicForge", listOf(
        "Hi! I'm Tails, and I'll walk you through the launcher. SonicForge is an offline hub for retro Sonic games: an emulator front end, a music player, mini-games, a drawing tab and a lot of customisation.",
        "🧪 This is a BETA (0.3.6 beta). Most things work, but some parts are still being finished and a few may misbehave. If something breaks, the app's logs page keeps crash notes you can send to the developer.",
        "🔒 SonicForge contains no games and has no internet permission at all. Everything stays on your phone.",
        "Tabs at the top: GAMES, MINI-GAMES, MUSIC, DRAW, CUSTOMIZE, LOCATIONS, SETTINGS, HELP. The ◐ button next to the title changes the look of the launcher.",
        "📍 Reopen this tour any time: HELP ▸ Quick start, or SETTINGS ▸ ABOUT APP ▸ OPEN GUIDE. Swipe or tap NEXT. If you skip it, I'll ask you to confirm."), Color(0xFFEF6C00), Color(0xFFFFCA28)),
    Page("🌍", "Your language and your look", listOf(
        "Choose your language now; this tour and the HELP pages change at once. You can change it later in SETTINGS.",
        "Then choose a look for the launcher. NORMAL is the classic one. MANIA is inspired by the Sonic Mania menus. TILES is inspired by Steam's Big Picture mode. They only restyle the launcher, never the games.",
        "Switch any time with the ◐ button in the top bar. You can hide that button, rename the looks and read more in SETTINGS ▸ SCREEN & LOOK ▸ Interface style."), Color(0xFF283593), Color(0xFF7C4DFF), picker = "lang"),
    Page("🎮", "Games: bring your own", listOf(
        "GAMES ▸ + ADD GAME. Use your own original game files (.zip, .rar (RAR4), .7z or the ROM itself). 📁 LINK FOLDER scans a folder.",
        "Mega Drive, Master System and Game Gear are fully supported; Sega CD (needs your BIOS), 32X and Game Boy Advance are experimental; OpenBOR opens in its own app.",
        "Give games versions (Original, French translation, Hack) and re-order them. Every game page has tips and cheats."), Color(0xFF2E7D32), Color(0xFF76FF03), "games", "Open GAMES"),
    Page("🕹", "Controllers, done properly", listOf(
        "Plug in or pair a gamepad and open SETTINGS ▸ CONTROLS. The app recognises Xbox, DualShock 4, DualSense, Switch Pro and Steam pads and draws yours with its real button names.",
        "To change a button: press REBIND, press the button you want, check what the app recognised, then CONFIRM. Nothing is saved before you confirm. You can also tap a button on the picture.",
        "There are three layers: a GAME layer overrides the EMULATOR layer, which overrides the GLOBAL layer. Each layer only stores what you changed and every row shows where it comes from, so layers never overwrite each other. RESET LAYER and RESTORE FACTORY undo things safely.",
        "Buttons can also do Save, Load, previous or next save slot, diagonals, show or hide the on-screen buttons and vibration on or off. While a pad is used, the on-screen buttons light up when you press the real ones.",
        "Android cannot give apps the touchpad, gyro, light bar or adaptive triggers of ordinary gamepads, and two buttons pressed together as one trigger are not supported yet."), Color(0xFF1B5E20), Color(0xFF00E676), "settings", "Open SETTINGS"),
    Page("⚠️", "Good to know before you play", listOf(
        "Some things depend on your Android device, not on the launcher. It is better to know this in advance, especially if you play on a TV.",
        "• The touchpad and motion sensors of a gamepad are NOT passed on by the launcher. Android gives apps buttons and sticks only. If the touchpad of your pad does nothing on your phone or TV, the launcher cannot add that.",
        "• If your Android turns a touchpad, a mouse or an air-mouse remote into a mouse cursor, a click / tap inside the lower Nintendo DS screen works as the stylus (the app treats a mouse click like a finger). This is not tested with every device.",
        "• A TV or TV box has no touch screen: Nintendo DS games that need the lower screen (menus, 'touch to continue') need such a mouse or touchpad. Many TV boxes cannot provide one, so on those the touch part of a DS game cannot be used.",
        "• Motion controls (tilt, gyro) of GBA / DS games are not supported either.",
        "• Rewind needs the emulator core to be able to save its state; if a core cannot, the screen says so while you hold REW. Vibration on a TV or pad depends on what Android and the pad allow."), Color(0xFF6A1B9A), Color(0xFFE040FB)),
    Page("✨", "What makes this launcher different", listOf(
        "• Vibration that reacts to the game: rings, hits, jumps, spin dash, springs, shields, drowning and even a ring-stealing bite. It reads the game's memory, so it works with many ROM hacks too, and a Ring Finder lets you teach it any game.",
        "• Rewind, fast-forward, previous-save protection, two-step pause menu, tilt (glitch) mode.",
        "• 20+ shaders, 18 skins, effects behind the game, six ready-made and six custom control layouts.",
        "• No internet permission at all, and one-file backups."), Color(0xFF00695C), Color(0xFF1DE9B6)),
    Page("📳", "Vibration: phone, controller or both", listOf(
        "SETTINGS ▸ VIBRATION ▸ Where it vibrates: Phone, Controller, Both or Off. Menus and games have separate choices, and a single game can override its own.",
        "TEST DEVICES buzzes your phone and every controller one by one and shows what Android reports about each. Tell the app whether you felt it, so you know which device really vibrates.",
        "Some Bluetooth pads and some phones never pass rumble through. If a pad is listed as not supported, the app cannot force it."), Color(0xFFBF360C), Color(0xFFFF9100), "settings", "Open SETTINGS"),
    Page("🔍", "Why does my phone buzz? (vibration explained)", listOf(
        "Buzzes come from four different sources. Knowing them tells you which one to switch off:",
        "1) ON-SCREEN BUTTONS: a short tick whenever you press a touch button (SETTINGS ▸ VIBRATION ▸ Touch buttons). This is the most common 'random' buzz.",
        "2) THE GAME'S MEMORY: for games the app knows (Sonic 1 / 2 / 3&K, Mario and a few more) it reads rings, lives, hits, springs, shields and water, so these buzzes are exact. Rings are now a crisp double tick, stronger than before and different from a button press.",
        "3) THE GAME'S SOUND: for games without a profile, a loud sudden sound makes a buzz (deep = hit or explosion, bright = pickup). In games WITH a profile the sound only adds explosions (monitors, enemies, bosses). Music peaks can sometimes trigger it: lower the sensitivity or switch it off per game.",
        "4) FOOTSTEPS (experimental) and other small events such as water splashes and bubbles. Footsteps are off in the ready-made presets.",
        "To see the cause of every buzz: GAME MENU ▸ FPS counters ▸ VIBRATION DEBUG. Each buzz appears as a line (source, event).",
        "To quiet a single game: in the mini menu (VIBRATION) the 'Vibration profile' box shows where this game's buzzes come from and lists ONLY the switches this game can produce. Preset 1 = rings and buttons only."), Color(0xFFBF360C), Color(0xFFFFAB40), "settings", "Open SETTINGS"),
    Page("🎛", "CUSTOMIZE vs THEMES (TILES, Mania ...)", listOf(
        "CUSTOMIZE builds YOUR STYLE: skin colours, frame, particles, shaders, touch layouts and your own pictures. A THEME (Normal, Mania, Tiles, Game Jolt, itch, Neon Coast ...) is a ready-made launcher look chosen with the ◐ button.",
        "NORMAL shows your style exactly. Every other theme paints its OWN colours, borders and corners on top, so these CUSTOMIZE settings do NOT show while such a theme is active: skin colours, accent colour, frame style / width / roundness, particles. Switch back to NORMAL to see them.",
        "What keeps working in every theme: your launcher background picture (new in 0.3.6: before it only showed in NORMAL; there is a switch in the theme picker), your own style pictures (layers), shaders and touch layouts inside games, and all game settings.",
        "TILES / Game Jolt / itch also change the GAMES tab into big cards; the ⋯ menu of a card has EDIT, PATCH, MOVE, REMOVE and the per-game VIBRATION button.",
        "Inside games the look follows the theme only if 'Use the theme inside games and emulators' (theme picker) is on; the game screen itself keeps your skin."), Color(0xFFAD1457), Color(0xFFFF80AB), "custom", "Open CUSTOMIZE"),
    Page("📁", "Where your files go", listOf(
        "Games are COPIED into the app (unpacked if zipped), so the original file is not needed afterwards. A linked folder is only used to scan for new games and to copy them in.",
        "Music you add is copied too; music in a linked music folder is played in place. Pictures, videos, comics and recordings live in the media folder; BIOS files in the system folder; saves in the saves folder.",
        "The STORAGE MAP (SETTINGS ▸ DATA & PRIVACY, storage section) draws how much space each part uses and which games point to outside files. OPEN WITH… sends a folder to another file app without copying anything.",
        "If the phone is full, copying stops with a 'No space left' line in the log: free some space and add the files again."), Color(0xFF00695C), Color(0xFF69F0AE), "settings", "Open SETTINGS"),
    Page("🆕", "What is new in 0.3.6", listOf(
        "• Recent games for every console, hide or remove a game from the list. • One speed button: rewind and fast-forward on/off. • 4-button layout for DS / SNES.",
        "• DS: your own gap between the screens, touch test, and a switch to turn the touch screen off (DS TOUCH in the mini menu).",
        "• Video player: zoom, speed up to 3× (keep the voice pitch), hide system bars. • Shader quick button with a number in the top-right plate of a game.",
        "• Flash: engines, an info strip, on-screen keys with a CUSTOM layout. • Vibration profile per game in the mini menu. • The log says when the app was updated."), Color(0xFF1565C0), Color(0xFF40C4FF)),
    Page("🧑‍🤝‍🧑", "Meet the helpers", listOf(
        "Each helper knows one area, and they point you to each other:",
        "• Tails (me): the launcher and every setting, in simple, technical or developer depth.",
        "• Sonic: how the games play, their stories, abilities and famous glitches.   • Amy: customisation and other games to try.",
        "• Knuckles: hidden things and keeping your data safe.   • Dr. Eggman: music.   • Metal Sonic: comics, TV and films.",
        "• Motobug: official facts.   • Buzz Bomber: fan creations.   • Shadow: advanced tricks, consoles and what's next.",
        "They work offline and can be wrong or out of date: for anything important check manuals and fan wikis."), Color(0xFF1565C0), Color(0xFF00B0FF), "help", "Open HELP"),
    Page("🎨", "Make it yours", listOf(
        "CUSTOMIZE: skins, frame and shaders, the touch-control editor with presets, backgrounds. A game's ✎ EDIT can have its own shader, skin, controls, music and cheats.",
        "SETTINGS ▸ VIDEO: screen margins for notches and rounded corners (there is a preview), aspect ratio, classic mode, FPS counters.",
        "The ◐ button switches between NORMAL, MANIA and TILES looks; hide it in SETTINGS ▸ SCREEN & LOOK.",
        "Amy can tell you more about looks and extras."), Color(0xFFAD1457), Color(0xFFFF4081), "custom", "Open CUSTOMIZE"),
    Page("🎵", "Music, files & safety", listOf(
        "MUSIC: playlists, sorting, covers, equalizers, background play with a notification and headphone buttons (1 press play/pause, 2 next, 3 back).",
        "LOCATIONS shows every folder the app uses. SETTINGS ▸ DATA & PRIVACY: LIGHT or FULL backups, named by you. Updating is simply installing the new APK over the old one.",
        "Classic mode hides advanced settings; Pro mode shows them (SETTINGS ▸ GENERAL). Classic is the default so nothing important gets changed by accident."), Color(0xFF6A1B9A), Color(0xFFE040FB), "music", "Open MUSIC"),
    Page("🛟", "Questions? Ask a helper", listOf(
        "HELP ▸ ASK A HELPER: pick questions from a list, type your own, or both.",
        "That's the whole tour, and you can replay it from the settings. Thank you for testing the beta, and have fun!"), Color(0xFF37474F), Color(0xFF90A4AE), "help", "Ask a helper"),
)

@Composable
fun GuideOverlay(onGoto: (String) -> Unit) {
    if (!Guide.show) return
    val skin = Skins.current()
    var page by remember { mutableIntStateOf(0) }; var again by remember { mutableStateOf(false) }; var drag by remember { mutableFloatStateOf(0f) }
    var askSkip by remember { mutableStateOf(false) }
    val close = { Store.setB("guideSeen", !again); Guide.show = false }
    if (askSkip) ConfirmDialog("Skip the tutorial?", "close the tour", "delete anything; you can replay it from SETTINGS ▸ ABOUT APP ▸ OPEN GUIDE", yes = "YES, SKIP", force = true, onYes = { askSkip = false; close() }, onNo = { askSkip = false })
    Box(Modifier.fillMaxSize().background(Color(0xE6000000)).clickable(enabled = true) {}.systemBarsPadding()) {
        Column(Modifier.align(Alignment.Center).fillMaxWidth(.94f).widthIn(max = 560.dp).fillMaxHeight(.94f).clip(RoundedCornerShape(24.dp)).background(Color(0xFF15151C))) {
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(I18n.tr("GUIDE") + "  ${page + 1}/${pages.size}", color = skin.accent, fontWeight = FontWeight.Black, letterSpacing = 2.sp, modifier = Modifier.weight(1f))
                Text("✕", color = Color.White, fontSize = 22.sp, modifier = Modifier.clip(CircleShape).clickable { askSkip = true }.padding(horizontal = 12.dp, vertical = 4.dp))
            }
            val p = pages[page]
            // our own swipe handling (no experimental Pager API)
            Column(Modifier.weight(1f).padding(horizontal = 14.dp).clip(RoundedCornerShape(20.dp)).background(Brush.verticalGradient(listOf(p.c1, p.c2.copy(alpha = .75f))))
                .pointerInput(page) { detectHorizontalDragGestures(onDragStart = { drag = 0f }, onDragEnd = { if (drag < -80f && page < pages.size - 1) page++ else if (drag > 80f && page > 0) page-- }, onHorizontalDrag = { _, d -> drag += d }) }
                .verticalScroll(rememberScrollState()).padding(20.dp)) {
                Text(p.emoji, fontSize = 64.sp)
                Text(p.title, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(vertical = 8.dp))
                p.lines.forEach { Text(it, color = Color.White, fontSize = 15.sp, modifier = Modifier.padding(vertical = 5.dp)) }
                if (p.picker == "lang") LangStyleChooser()
                if (p.goto != null) { Spacer(Modifier.height(12.dp)); Btn("▶ " + I18n.tr(p.gotoLabel), color = Color.White) { Guide.show = false; Store.setB("guideSeen", !again); onGoto(p.goto) } }
            }
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                    pages.indices.forEach { i -> Box(Modifier.size(if (i == page) 12.dp else 8.dp).clip(CircleShape).background(if (i == page) skin.accent else Color(0x55FFFFFF)).clickable { page = i }) }
                }
                if (page > 0) { Btn("◀") { page-- }; Spacer(Modifier.width(6.dp)) }
                if (page < pages.size - 1) { Btn("SKIP") { askSkip = true }; Spacer(Modifier.width(8.dp)); Btn("NEXT", selected = true) { page++ } }
                else Btn("DONE", selected = true) { close() }
            }
            Row(Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Show this guide again next launch", color = Color(0xE6FFFFFF), fontSize = 11.sp, modifier = Modifier.weight(1f))
                Switch(again, { again = it })
            }
        }
    }
}

/** language + interface style chooser shown inside the tour */
@Composable
private fun LangStyleChooser() {
    val cur = Store.s("lang", "auto")
    Column(Modifier.padding(top = 10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        I18n.languages.chunked(3).forEach { row -> Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { row.forEach { (k, n) -> Btn(n, selected = cur == k, color = Color.White) { Store.set("lang", k) } } } }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { UiMode.ids.forEach { id -> Btn(UiMode.name(id), selected = UiMode.id() == id, color = Color.White) { Store.set("uiMode", id) } } }
    }
}
