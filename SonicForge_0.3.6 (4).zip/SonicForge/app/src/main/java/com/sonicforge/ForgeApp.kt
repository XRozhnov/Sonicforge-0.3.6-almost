package com.sonicforge

import android.app.Application
import com.sonicforge.audio.Music
import com.sonicforge.audio.Sfx
import com.sonicforge.data.*
import com.sonicforge.input.Haptics
import com.sonicforge.input.Pads
import kotlinx.coroutines.launch

class ForgeApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        // pause the music when the headphones are unplugged or disconnect (dead battery, Bluetooth off)
        try {
            val r = object : android.content.BroadcastReceiver() { override fun onReceive(c: android.content.Context?, i: android.content.Intent?) { try { if (com.sonicforge.audio.Music.playing) com.sonicforge.audio.Music.toggle() } catch (_: Throwable) {} } }
            val f = android.content.IntentFilter(android.media.AudioManager.ACTION_AUDIO_BECOMING_NOISY)
            if (android.os.Build.VERSION.SDK_INT >= 33) registerReceiver(r, f, android.content.Context.RECEIVER_NOT_EXPORTED) else registerReceiver(r, f)
        } catch (_: Throwable) {}
        Logger.init(this)
        Library.init(this)
        PadLayouts.init()
        Sfx.init(this)
        Haptics.init(this)
        Pads.init(this)
        Music.init(this)
        Logger.startWatchdog()
        Logger.reportLastExit(this)
        Logger.reportVersion(this)
        // every pop-up text is also kept in the log, in full
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Default + kotlinx.coroutines.SupervisorJob()).launch { Store.events.collect { Logger.notice(it.label, it.ok) } }
    }
}
