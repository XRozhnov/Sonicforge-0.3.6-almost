# MASTER PROGRESS, BY VERSION (done AND not done, in the order the user asked for things)
Legend: ✅ done (compiled and confirmed by the user) · 🧪 compiled at some point, known bugs · ✍ written, never compiled/confirmed · 🆕 newest batch (pre5), written, NOT compiled · ⬜ requested, not done · 🔒 impossible or deferred on purpose.
Rule: next to a DONE item stands the version where it was ADDED; next to a NOT-DONE item stands the version where it was FIRST REQUESTED. An item requested early and still open stays in its early chapter, so you can see how long it has waited.
Sources: `11_CHECKLIST_UP_TO_0.3.5.md`, `08_CHECKLIST_0.3.6.md`, `12_MASTER_BACKLOG…`, `02_USER_REQUESTS_FULL_LOG.md`. Early dates are approximate: the old chats were summarised, not re-read item by item.

## Chapter 1 · v0.1.0 "Customisation n' Blue" (the first launcher; compiled once, "works well")
Done:
* ✅ (0.1.0) Genesis Plus GX libretro host, touch controls, Mega Drive / Genesis games. ✅ (0.1.0) Skins, frames, shaders, background effects. ✅ (0.1.0) Mini-games, music player, controller support, vibration, backups. ✅ (0.1.0) Short version name + hidden version display; first-run guide.
Not done (requested in this chapter):
* ⬜ (0.1.0) Music search, share-to-launcher import of games/music/comics. ⬜ (0.1.0) Several retro player faces. 🔒 (0.1.0) RAR5 archives (library limit).

## Chapter 2 · v0.2.0 "Archives n' Cheats" (did NOT compile; pager API removed later)
Done:
* ✍ (0.2.0) ZIP/7z/RAR4 import. 🧪 (0.2.0) IPS/BPS patching. 🧪 (0.2.0) Cheats (Game Genie/Action Replay). 🧪 (0.2.0) Two-step pause menu, save states, rewind, fast-forward.
Not done:
* ⬜ (0.2.0) Explain the patch buttons with a real example. ⬜ (0.2.0) 12 control layouts: 7 factory exist, the 6 + 6 split is approximate.

## Chapter 3 · v0.3.0–0.3.3 "Emerald Everything Plus" (0.3.3 compiled, tested)
Done:
* 🧪 (0.3.0) Vibration with ~18 events, templates, presets, per-game profile (S1, S2, S3K), Ring Finder. 🧪 (0.3.1) Nine helper characters, ~110 answers, tutorial with Tails. 🧪 (0.3.2) UI labels in 12 languages (long texts English only). 🧪 (0.3.3) Music: playlists, favourites, equalizers, notification service. 🧪 (0.3.3) Logs and crash notes.
Not done:
* ⬜ (0.3.0) Vibration for monitors, bosses, badniks, footsteps, shields, explosions (events never fired for the user). ⬜ (0.3.1) More helper answers, characters that look like themselves. ⬜ (0.3.2) Translate ALL long texts (tutorial, What's new, help, manuals).

## Chapter 4 · v0.3.4 "Rock Solid Rings"
Done:
* ✅ (0.3.4) Import bug fixed, mini-game crash fixed, scene no longer plays sounds by itself, music loads details in the background, instant sound packs.
Not done:
* ⬜ (0.3.4) Flash (Ruffle) that really works in the app (it worked for the user only in the official Ruffle app). ⬜ (0.3.4) Real Sega CD module. ⬜ (0.3.4) Comics / Photos / Video tabs.

## Chapter 5 · v0.3.5 "Tilt & Queue" (did NOT compile: DrawUi Int vs Float, fixed afterwards)
Done:
* ✍ (0.3.5) DRAW tab. ✍ (0.3.5) Tilt modes 1–6. ✍ (0.3.5) Look-for-games global vs per game. ✍ (0.3.5) Storage page.
Not done:
* ⬜ (0.3.5) Scene creator with the user's sprites. ⬜ (0.3.5) Holiday themes (now partly done in 0.3.6_pre2). ⬜ (0.3.5) PNG-mask frames, per-tab presets, per-game custom UI. ⬜ (0.3.5) Widgets for the home screen. ⬜ (0.3.5) Karaoke + timestamps, multitrack editor. ⬜ (0.3.5) Real-time spectrum equalizer. ⬜ (0.3.5) Cheat macros (timed sequences). ⬜ (0.3.5) Tilt: glitch-visuals-only switch, gentle mode.

## Chapter 6 · v0.3.6 pre-releases (the current line)
### pre1 / `0.3.6_pre` (code 10)
* ✍ (pre1) Music player fixes (queue sheet, favourites, mini player, peek list). ✍ (pre1) Themes Mania, Tiles, Game Jolt, itch, Neon Coast + quick-switch ◐ button. ✍ (pre1) Own PNG layers per theme. ✍ (pre1) Startup intro (off by default). ✍ (pre1) Three new mini-games. ✍ (pre1) Controller picture per family, vibration route phone/controller. ✍ (pre1) Game-card toggles, launcher focus ring for controllers.
### pre2 (code 11)
* ✍ (pre2) NES and SNES. ✍ (pre2) Themes Blue Blur, Dark Rival, Meadow Day. ✍ (pre2) Seasonal overlay (snow, confetti...), off by default. ✍ (pre2) 24h clock, music notification cover + seek.
### pre3 (code 12) — REAL build log: 3 errors, fixed in pre4
* ✍ (pre3) BY BUTTON list in controller setup. ✍ (pre3) CONSOLE MANUALS (9 consoles, English). ✍ (pre3) Flash fix attempt #1.
### pre4 (code 13)
* ✍ (pre4) MEDIA tab (pictures, comics, video, notes, files, recorder). ✍ (pre4) Open with / Share to SonicForge. ✍ (pre4) Flash keyboard symbols. ✍ (pre4) BUILD_REPORT.txt next to the APKs. ✍ (pre4) TV launcher icon. ✍ (pre4) Preflight script.
### pre5 (code 14) — 🆕 everything below is NEW, written, NOT compiled
* 🆕 (pre5) Sega CD TOOLS (BIOS check, disc check, region override, backup RAM reset). Honest limit: it diagnoses and lets you force the region; it cannot promise a fan CD boots.
* 🆕 (pre5) Layers behind the interface by default, optional in front with a warning; fit / crop / size / position / offset; APPLY TO ALL; UNDO STEP; GIF animation (Android 9+).
* 🆕 (pre5) Comics: zoom, tap-edge page turn, manga/scroll mode with width zoom, page reorder/delete, comic reorder, counting names, replace warning.
* 🆕 (pre5) Pictures: zoom, rotate, flip, crop, copy, share, delete. Text files open directly in the editor from FILES.
* 🆕 (pre5) Recorder level display (bar + waveform). 🆕 (pre5) Vibration rules for any game on any console. 🆕 (pre5) Nintendo DS (experimental): 3 arrangements + AUTO + TABLET + touch. 🆕 (pre5) Theme art for Game Jolt, itch, Neon Coast, Dark Rival, Meadow Day. 🆕 (pre5) TILES bottom bar fix. 🆕 (pre5) Flash autoplay + status line.
### Still open in the 0.3.6 line
* ⬜ (pre1) Full translations of every long text and the new texts (do LAST). ⬜ (pre1) In-game pause menu in Mania/Tiles styles. ⬜ (pre2) Console guide BOOKS with pictures in 12 languages. ⬜ (pre3) Vibration sets for Mario family, Sonic Advance rumble, Sonic monsters/explosions/footsteps from RAM. ⬜ (pre3) A/B swap for GB, rewind-seconds hint, tutorial last-slide intro offer. ⬜ (pre3) Flash FPS lock, haptics for Flash. ⬜ (pre4) Android TV: full remote pass + real TV test (deferred: costly to keep correct with every update). ⬜ (pre4) x86 / x86_64 builds. ⬜ (pre4) "Read in place" media mode, CBZ import. ⬜ (pre5) Zoom inside manga scroll mode (only width zoom exists), crop with a drag frame, GIF editing, comic search. ⬜ (pre5) DS: screen swap button, per-game layout, microphone, real tablet layouts for the whole app. 🔒 3DS / Saturn / Dreamcast / PSP / GC / Wii / PS2 (not feasible in this design).

## Chapter 7 · planned: v0.3.6 final → 1.0
* ⬜ Three editions (FULL, LITE, TV/x86). ⬜ Real compilation on every batch (needs a toolchain with network). ⬜ Verify EVERY 🆕 item on a phone and report back: nothing in pre5 has ever run.
