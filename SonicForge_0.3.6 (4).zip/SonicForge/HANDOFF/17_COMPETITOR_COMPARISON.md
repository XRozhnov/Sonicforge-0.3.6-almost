# SonicForge vs existing Android retro launchers (2026-11-21)
Sources (read 2026-11-21): [Held Games, best frontends 2026](https://heldgames.com/guides/best-emulation-frontends) · [RetroSensei frontends](https://retrosensei.com/best-android-retro-gaming-frontends/) · [Lemuroid on GitHub](https://github.com/swordfish90/lemuroid) · [Daijisho](https://github.com/TapiocaFox/Daijishou) · [Emulation General Wiki, frontends](https://emulation.gametechwiki.com/index.php/Frontends).
SonicForge column comes from our own code, which is written but NOT yet compiled or verified on a phone. Competitor cells say "not stated" where the sources did not say.

## Two kinds of competitor
1. **Frontends that only launch other emulators:** ES-DE (150+ systems, scraper, theme engine; Android version paid), Daijisho (free, can replace the home screen, no full theme engine), Beacon (simple, paid), iiSU (visual, alpha), Cocoon, RetroHrai!.
2. **All-in-one emulator apps with libretro cores:** Lemuroid (GPL-3.0; 23 systems incl. N64, DS, 3DS, PSX, PSP; auto save/restore, touch controls, tilt, local multiplayer, cloud save sync, Android TV, LCD/CRT simulation, HD mode) and RetroArch (cores, own menu; the article calls it "not pretty").
SonicForge belongs to group 2, plus extras nobody else bundles.

## Feature matrix
| | SonicForge (ours) | Lemuroid | RetroArch | ES-DE | Daijisho | iiSU |
|---|---|---|---|---|---|---|
| Runs games itself | yes (libretro bridge) | yes | yes | no | no | no |
| Systems | ~10 (MD, SMS, GG, Sega CD, 32X, GB/GBC/GBA, NES, SNES, DS exp., Flash, OpenBOR) | 23 | very many | 150+ via other apps | via other apps | via other apps |
| Save states / rewind / fast-forward | yes (rewind memory-capped) | save states yes; rewind not stated | yes | n/a | n/a | n/a |
| Touch layout editor, many presets | yes, 7 factory + 6 slots, symbol transparency | custom size/position | yes | n/a | n/a | n/a |
| Cheats, IPS/BPS patching | yes | not stated | cheats yes | n/a | n/a | n/a |
| Cover art scraper | NO (manual backgrounds/logos) | not stated | thumbnails | yes, strong | yes | yes |
| Themes / skins | 18+ skins, 8 full UI modes, shaders (22) | LCD/CRT | shaders | theme engine | wallpapers | animated |
| Built-in music player, recorder, comics, video, notes | YES (unique) | no | no | no | no | no |
| Per-game vibration (Sonic events, RAM rules, audio-driven) | YES (unique) | not stated | rumble | n/a | n/a | n/a |
| Helper characters, tutorial, manuals | YES (unique) | no | no | manuals support | no | no |
| Android TV / dual-screen / foldables | NOT yet (TV pass deferred) | TV yes | yes | companion app | single-screen | dual-screen work |
| RetroAchievements | no | not stated | yes | n/a | n/a | yes |
| Cloud save sync | no (local backups) | yes | via other tools | n/a | n/a | n/a |
| Languages | 12 UI (long texts English) | not stated | many | many | many | not stated |
| Maturity, years of fixes | pre-release, unverified | mature | very mature | mature | mature | alpha |
| Price | free (own project) | free, open source | free | paid on Android | free | free |

## Where we are strong
- One app that is launcher + emulator + media suite + fun layer; no competitor listed does music/recorder/comics/video/notes together.
- Sonic-aware features: vibration profiles, ring finder, helper characters; any-game sound-driven haptics.
- Deep touch-control customisation and many visual modes.

## Where we are behind (honest)
1. **Stability and trust:** mature apps have years of edge-case fixes; ours is unbuilt since pre5.
2. **No scraper:** every competitor in group 1 fetches art and metadata; our library needs manual art. Offline-first rule means scraping must be optional and user-triggered, and the sandbox cannot reach those sites, so this needs on-device testing.
3. **Fewer systems:** 10 vs Lemuroid's 23 (PSX, PSP, N64, 3DS, Atari, PC Engine, Neo Geo Pocket, WonderSwan are absent).
4. **No TV/dual-screen/foldable support, no cloud sync, no RetroAchievements.**
5. **Settings sprawl:** many chips and rows; competitors lean toward simple setup (Beacon, Lemuroid).

## What to take from the comparison (feeds 0.3.7)
- Add to the plan: optional **box-art scraper** (user-started, cached offline), **search + recent/last-played shelf** (pre8 has search), **simple setup mode** hiding Pro settings by default (already partly there), **Android TV pass** moved up if the phone gate is green, **foldable/dual-screen layout** for DS (our TABLET mode is a start), **cloud backup via the system share/Drive file picker** (no account code in-app).
- Do not chase 150 systems; stay a focused, polished "Sega-first, plus extras" app. Add PSX/PC Engine only if the core fetch and BIOS story is solved.
- Position: "Lemuroid-style simplicity with a lot more personality," not an ES-DE rival.

## Net health, re-read with this context
The earlier 42% was internal (checklist, builds, verification). Compared with the market, the gap is mainly maturity and breadth, not ideas: our unique feature set is wide, our reliability is unproven. Priority stays: compile, test, polish.
