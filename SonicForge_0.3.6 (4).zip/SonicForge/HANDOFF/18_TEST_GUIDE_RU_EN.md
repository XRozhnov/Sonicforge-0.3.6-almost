# Как собрать лог для DS / Sonic CD / Flash (RU) · How to capture a log (EN)

## RU
1. Включите ENGINE LOG: Настройки → «О приложении» → кнопка «ENGINE LOG: OFF» (или переключатель на вкладке SUPER, или в настройках игры).
2. Запустите проблемную игру (DS, Sonic CD, Flash) и подождите 10–15 секунд.
3. Нажмите на полосе ENGINE LOG кнопку COPY (жёлтая) и вставьте текст в сообщение мне. Либо Настройки → Логи → экспорт файла.
4. Что я ищу в логе:
   - `option available: …` — настоящие названия настроек ядра (для исправления региона/RAM Sega CD и раскладки экранов DS);
   - `HARDWARE rendering … refused` — ядро хочет OpenGL, а у нас только программная отрисовка (так ведут себя PSP/Dreamcast/Wii);
   - `frame …: ALL SAMPLED PIXELS ARE THE SAME` — картинка пустая (белый/чёрный экран);
   - `retro_load_game returned FALSE` — ядро отказалось от файла (формат, BIOS, повреждён).
5. Полоса: 3 быстрых касания — свернуть, долгое нажатие — закрыть; вернуть — Настройки → «О приложении».
6. Sonic CD: в игре на странице игры нажмите «SEGA CD TOOLS» → ⚡ AUTO-FIX, затем запустите и пришлите лог (там будет видно, какой BIOS загружен и какой регион).

## EN
1. Turn on ENGINE LOG (SETTINGS ▸ ABOUT ▸ ENGINE LOG button, or the SUPER tab switch, or the game's settings).
2. Start the problem game and wait 10 to 15 seconds.
3. Tap COPY on the strip and paste the text to me, or SETTINGS ▸ LOGS ▸ export.
4. Look for: `option available`, `HARDWARE rendering … refused`, `ALL SAMPLED PIXELS ARE THE SAME`, `retro_load_game returned FALSE`.
