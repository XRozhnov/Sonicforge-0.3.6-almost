import sys,re
for p in sys.argv[1:]:
    s=open(p).read()
    # strip strings/comments roughly
    t=re.sub(r'"""[\s\S]*?"""','',s)
    t=re.sub(r'//[^\n]*','',t)
    t=re.sub(r'"(\\.|[^"\\\n])*"','""',t)
    t=re.sub(r"'(\\.|[^'\\\n])'","''",t)
    c={k:t.count(k) for k in '(){}[]'}
    ok=c['(']==c[')'] and c['{']==c['}'] and c['[']==c[']']
    print(('OK  ' if ok else 'BAD ')+p, c if not ok else '')
