# SonicForge — БОЛЬШОЙ ЧЕЙНДЖЛОГ И ПРОГРЕСС (0.1.0 → 0.3.6)

_Документ собран из внутреннего списка «Что нового» самого приложения (SETTINGS ▸ ABOUT), поэтому он совпадает с тем, что показывает приложение. Все записи ниже — на английском (так их видит пользователь в приложении), заголовки и итоги — на русском. Перевод на 12 языков делается последним._

## Как читать статусы

| Метка | Значение |
|---|---|
| 🛠 FIXED | исправлено (причина найдена, правка внесена) |
| ✨ NEW | новая функция |
| 🛠 CHANGED | изменено поведение |
| ❌ NOT DONE | не сделано или не проверено на устройстве |
| 🧪 | версия написана, но **не компилировалась и не запускалась** на телефоне — всё считается непроверенным, пока вы не подтвердите |

> Честно: большинство pre-релизов 0.3.6 собирались на GitHub Actions по моему коду, который я не мог скомпилировать и запустить. Поэтому «исправлено» = «причина найдена по исходникам/логам, правка написана», а не «проверено на Nothing A069».

## Итог на сегодня (0.3.6)

**Сделано в этом релизе**
- Зазор между экранами DS (TOP / BOTTOM + REAL GAP): ядра игнорировали свою опцию зазора, теперь зазор рисует само приложение между двумя половинами картинки; ползунок работает сразу, в том числе во время игры; касание пересчитывается под зазор.
- Недавние игры: раньше это был «последний запуск + порядок библиотеки», поэтому виднелись только Mega Drive. Теперь настоящая история для всех систем; удаление записи, «никогда не показывать» для игры (значок 🙈), отключение целых консолей и очистка списка в SETTINGS.
- Кнопка скорости в мини-меню: оба режима → только перемотка → только ускорение → выкл. Два независимых переключателя (rewind / fast-forward) в настройках и меню; выключенная функция убирает свою кнопку с экрана. Кнопка BUTTONS (мастер) стоит после REWIND и CLASSIC.
- Мини-меню: кнопка повтора музыки (все → этот трек → выкл) с подписью режима.
- Перемотка: на экране подпись «⏪ REWIND, осталось N с» или причина, почему перемотка невозможна; в логе пишется отказ ядра сохранять состояние.
- Туториал: страница «Good to know» про тачпад/датчики геймпада, ТВ и нижний экран DS.
- Flash: страница переписана по образцу Flash Forge; по умолчанию старый Ruffle; строка диагностики; табличку «NO PICTURE?» можно скрыть ✕ и вернуть переключателем в меню.
- DS касание: найдена причина (в DeSmuME нужна опция `desmume_pointer_mouse=enabled`, приложение её не отправляло); добавлен метод MOUSE и тест касания.
- Мастер-переключатель экранных кнопок (обычный / classic режимы).

**Не подтверждено на устройстве (нужна ваша проверка)**
1. Рисует ли Flash картинку (если нет — скриншот строки диагностики внизу экрана).
2. Работает ли касание DS и зазор между экранами.
3. Перемотка: причина неизвестна; новая подпись покажет, что мешает.
4. Вибрация Sonic Advance 2 / 3, Sonic Battle, Sonic Rush: адреса для USA-версий; совпали с публичными кодами только жизни SA3 и здоровье Battle; адреса колец неподтверждены; возможно, ядро не публикует нужный диапазон памяти (теперь это пишется в лог и в панель VIBRATION DEBUG).
5. Белый экран DS на melonDS; тачпад геймпада нативно недоступен (ограничение Android).

**Планы:** Super (тяжёлые консоли), Hyper; перевод на 12 языков — в самом конце.

---

## Полная история версий

### 0.3.6 — Release 0.3.6 (beta): Flash keys, shader button, vibration profile, DS touch switch (Nov 2026)

- 🛠 FIXED · Logs window: it no longer overflows. Buttons wrap into rows, the whole window scrolls, and it is wider in landscape (the 'ПОЛН' button was squeezed and some buttons were cut off).
- 🛠 FIXED · Nintendo DS: SIDE BY SIDE is now drawn by the app itself (the cores ignored the layout option), so it works with every DS core. New SWAP SCREENS (⇅): a chip on the top bar, a button in the mini menu and a switch in the DS screens window; the stylus follows the swapped screens.
- 🛠 FIXED · Flash: the harmless missing /favicon.ico no longer fills the notices.
- 🛠 FIXED · Mini menu: the launcher music row (SHUFFLE / REPEAT) no longer overflows; it is split into two rows with text buttons.
- 🛠 FIXED · Recordings equalizer froze or closed while sound kept playing: it now redraws on every frame and has modes REAL / SIMULATED / OFF; use SIMULATED if the real one stutters on your phone.
- 🛠 FIXED · Ring vibration was as faint as a button tick (strength 25 against 35): rings are now a crisp double tick at strength 70, and an old stored 25 is raised once. Unverified on a phone.
- 🛠 FIXED · Your launcher background picture was drawn only in the NORMAL theme; now it shows on every theme (switch in the theme picker).
- 🛠 FIXED · Music and menu-sound volume now exist TWICE: one for the launcher and one for while a game is open (SETTINGS ▸ AUDIO and the game's mini menu). Before, a low value set in a game stayed everywhere. Each slider says which is in use and what it changes to when you enter / leave a game; two buttons copy one value to the other. The old single value moved to the game slot and the launcher went back to 100% (one time).
- 🛠 FIXED · Flash: arrows were sent only as Android DPAD keys, which WebView can swallow as focus navigation (probably why only jump worked). Arrows are now also sent as plain DOM key events. Unverified on a phone.
- 🛠 FIXED · Recordings equalizer: the real analyzer needs the microphone permission, which this tab never asked for, so it only showed a fake pattern. It asks now, and says when it is real and when it is a pattern.
- ✨ NEW · Comics: a book page with cover and title, START / CONTINUE READING and INCOGNITO buttons and the page list below (cover, buttons and list can each be hidden). Bigger tap zones for turning pages, with an optional flash that shows where you tapped. Note: a comic here is a folder of pictures, so its 'chapters' are really pages.
- ✨ NEW · GIF: pictures now animate; tap to start or stop, a small GIF badge sits on top; options to turn animation off and to lower GIF quality (smaller resolution) for weak phones. Needs Android 9+.
- ✨ NEW · Flash pauses when the screen locks or the app goes to background (switch in the Flash menu, ON by default).
- ✨ NEW · Screen rotation for every game, Flash and settings: Auto / lock / flipped and a new ASK mode (a ⟳ ROTATE button appears and the screen turns only after you tap it). The launcher itself is not covered yet.
- ✨ NEW · Interface size now has 70-150%, ±5% steps, a RESET TO 100% button and a switch for a SEPARATE size in portrait and in landscape (SETTINGS ▸ SCREEN & LOOK).
- ✨ NEW · Controls editor (CUSTOMIZE ▸ CONTROLS): SELECT SEVERAL mode, ready groups (D-pad / all face buttons / save-load-fast-rewind / L+R / START+MD / MENU), select all, clear selection, remove one control from the selection, drag the whole selection together, nudge arrows, size and show/hide for the selection, and 3 own group slots (G1-G3). Layouts are saved as before.
- ✨ NEW · Rotation prompt: with a locked orientation a ⟳ ROTATE button pops up in the right corner when you hold the phone the other way (switch ON by default; position top / middle / bottom). It hides after 8 seconds by default; you can pick 3, 5, 15 s or never. It is drawn above everything but is small and sits in the corner.
- ✨ NEW · Rewind: when its history runs out the game freezes until you release the button (switch in settings) instead of running frame by frame.
- ✨ NEW · Controller setup: live view of both sticks with the real dead-zone circle, L2/R2 bars and a list of held buttons with their actions, and a 'Saved: … (was …)' message after each binding.
- ✨ NEW · DS touch screen switch: SETTINGS of DS SCREENS and the in-game mini menu (✋ DS TOUCH) turn the stylus touch on or off at once. Whether DS touch itself works on your phone is still unconfirmed: use the touch test.
- ✨ NEW · Tutorial: pages 'Why does my phone buzz?', 'CUSTOMIZE vs THEMES', 'Where your files go' and 'What is new in 0.3.6'.
- ✨ NEW · Vibration profile in the mini menu now has a live check (memory / sound / button events since the game started) with a plain verdict, and a ▶ FEEL button for each switch to try the buzz by hand.
- ✨ NEW · Search box (by name) in PICTURES, VIDEO and RECORDINGS lists. Comics are not filtered yet.
- ✨ NEW · Translation: about 1100 more interface texts (buttons, hints, tutorial pages) translated into all 12 languages. Machine-quality, not checked by native speakers; strings with inserted numbers/names and the changelog stay English.
- ✨ NEW · Quick shader button in the small top-right plate of the game: shows '🎨 number/total name' and a tap switches to the next shader (it follows 'Shader applies to'). The shader list in the game menu is numbered the same way.
- ✨ NEW · Flash on-screen keys: new CUSTOM layout (direction keys arrows / WASD / none + 4 action buttons with any key, key size). Reachable in SETTINGS ▸ CONTROLS ▸ FLASH KEYS and inside the Flash menu.
- ✨ NEW · The log now says 'App UPDATED/DOWNGRADED: old (build N) -> new (build M)' at the first start after a version change.
- ✨ NEW · Vibration profile in the mini menu: shows where this game's buzzes come from (auto / own rules / preset / memory map / sound only), lets you choose another source or a preset for the console, and lists ONLY the switches this game can really produce (no rings for Mario, no water shields for Sonic Rush). Every event can be switched off per game.
- ✨ NEW · Video player: zoom, speed up to 3× with a keep-pitch button, hide system bars, nicer menu that does not cover landscape video; fresh thumbnails; big imports no longer freeze the app.
- ✨ NEW · 4-button layout (A B X Y + L R) for DS / SNES, in the layout list; REW/FF and show-buttons also in classic mode; SCREEN POSITION is its own settings tab; storage map with file handling explained; OPEN WITH… for paths; Flash info strip choice (off / 8 / 16 / 30 s / always).
- 🧪 BETA, written but not compiled or tried on a phone yet.
- ℹ From your log: the 'ran out of memory' crashes and the long freeze while copying a video came from OLD builds (rewind history now has a memory cap and videos are copied in the background). 'Missing BIOS ... Using FreeBIOS' is normal without DS firmware.
- ⬜ NOT DONE · Rewind in Nintendo DS: the code allows it but the cause of 'no rewind' is unknown, I need a log from your phone. Right stick, L2 and R2 are shown in the live view but still cannot be bound to actions. New texts of this batch are not translated yet.
- ⬜ NOT DONE · Vibration was NOT checked game by game: the original games are not available to me and I cannot run an emulator. Profiles exist only for Sonic 1/2/3&K (memory map), Mario NES/SNES/GBA, Yoshi's Island, Sonic Advance 1-3 and Battle (addresses unverified); Sonic CD, Game Gear Sonics, Rush and hacks rely on sound only.
- ⬜ NOT DONE · Other items of the 0.3.6 plan (GG rewind colours, D-pad lights, T indicator, opacity split, picture presets, tempo, comics search) are still open; 0.3.6 keeps getting features.
- ⬜ NOT DONE · Springs, monitors, shields, boss hits for Sonic Advance / Rush and Super / Hyper forms: no verified memory addresses, so only the sound-based 'explosions' work there. Do not expect exact events.
- ⬜ NOT DONE · Flash: save/load state, rewind and fast-forward are not possible (Ruffle has no savestates, the movie speed is fixed by the file).
- ⬜ NOT DONE · Flash keyboard choice (Android / internal) left unchanged on purpose until explained.

### 0.3.6_pre15 — DS gap, real Recent list, speed button (pre-release 15) (Nov 2026)

- 🛠 FIXED · Flash: the page is rebuilt the way Flash Forge does it (Ruffle picks its own renderer, a sized holder, low quality, exact fit, metadata listener); the older Ruffle build (the one Flash Forge uses) is the default engine; an on-screen diagnostics line prints the player / canvas size and Ruffle version, so a black picture can be photographed and diagnosed.
- 🛠 FIXED · The NO PICTURE? ▶ NEXT ENGINE plaque: its ✕ hides it for good, and the Flash menu (top and PICTURE section) has a switch that shows it again.
- 🛠 FIXED · DS touch: the DeSmuME core only reads the stylus when 'pointer mouse' is enabled, and the app never sent that option, so the touch screen could not work. It is sent now. New TOUCH METHOD choice (POINTER or MOUSE-style) and a touch test (a dot and numbers where the touch goes).
- 🛠 FIXED · DS gap between the screens did nothing: the cores ignored their gap option on the device. Now the APP draws the gap itself between the two halves of the picture (TOP / BOTTOM + REAL GAP), so the slider works at once, also during a game; touch is re-mapped to match.
- 🛠 FIXED · Recent games: it was only the last game plus the library order, so only Mega Drive showed. Now every game of every console (NES, SNES, GBA, DS, Flash, OpenBOR ...) is written into a real history when it starts.
- ✨ NEW · On-screen buttons master switch with two dependent switches (normal mode, classic mode) in SETTINGS, the in-game menu and a BUTTONS button.
- ✨ NEW · Recent: remove a game from the list (⋯ ▸ REMOVE FROM RECENT, it returns when you play it again), never show a game (⋯ menu or the in-game menu; a 🙈 marks hidden games), keep whole consoles out (SETTINGS ▸ Recent games), CLEAR THE LIST.
- ✨ NEW · One speed button in the in-game menu: both on → rewind only → fast-forward only → both off. Two real switches (rewind, fast-forward) in SETTINGS and in the menus; a switched-off ⏪ / ⏩ button disappears from the on-screen buttons. The BUTTONS (master) button sits after REWIND and CLASSIC.
- ✨ NEW · Mini menu music: REPEAT button that cycles ALL → THIS TRACK → OFF and says which one is active.
- ✨ NEW · Rewind says what happens: while REW is held a small label shows the seconds of history left, or why rewind cannot work (core cannot save states, memory budget, no history yet); the log records a core that refuses to save its state. Some cores only report their state size after the first frames: this is now re-read.
- ✨ NEW · Tutorial page 'Good to know before you play': gamepad touchpad and sensors are not passed on by Android, what that means for TV boxes and the Nintendo DS lower screen; a mouse or touchpad that Android turns into a cursor works as the stylus.
- 🛠 CHANGED · Vibration rules: when a game's memory cannot be read (the core does not publish that address range) the log and the VIBRATION DEBUG panel now say so, instead of staying silent.
- ❌ NOT DONE · Rewind not proven on a device: the cause is unknown, the new label will tell what blocks it. No vibration yet for Sonic Advance 2 / 3 / Sonic Battle / Sonic Rush on the phone: the built-in addresses are for USA versions, only Sonic Advance 3 lives and Sonic Battle health match public cheat codes (rings addresses are unconfirmed). Gamepad touchpad is not read natively. Flash and DS touch from pre-release 15 still await your test. Translations come last.
- 🧪 BETA, written but not compiled or tried on a phone yet.

### 0.3.6_pre14 — Flash engines, DS side by side, mini menu (pre-release 14) (Nov 2026)

- 🛠 FIXED · Flash black picture: the app forced the WebGL renderer, so the movie ran (sound) but the picture stayed black; Flash Forge lets Ruffle choose its own renderer and draws correctly. Engine 1 now does the same. Five engine combinations (newest / older Ruffle, own choice / canvas / WebGL); the app switches by itself when a movie does not start, and a NO PICTURE? ▶ NEXT ENGINE button is shown for 40 s and in the Flash menu. The older Ruffle is 12 releases back (like Flash Forge's fallback). The player gets an exact pixel size, and key taps are held at least 70 ms (Flash reads keys once per frame).
- 🛠 FIXED · DS side by side: the picture is now really narrower (default 68% of the width) so the buttons sit in the side bands instead of over the screens. New: picture width slider, RESET button, switch 'buttons over the picture' (optional overlap), also in the in-game mini menu.
- 🛠 FIXED · DS gap: TOP / BOTTOM has no gap; only TOP / BOTTOM + REAL GAP (and TABLET in portrait) uses the gap slider.
- ✨ NEW · Touch test (DS SCREENS): a red dot and numbers show where the stylus touch is sent, to check that touch reaches the game.
- ✨ NEW · The in-game mini menu now has DS SCREENS, SEGA CD, BIOS FILES and ALL SETTINGS buttons, picture size, and in the music block: shuffle and a LIST button that opens the queue over the menu (close it with its button, open it again with LIST).
- ❌ NOT DONE · Cannot see the picture on your phone: the Flash fix is based on the difference to Flash Forge, not on a test. If every engine stays black, send the ENGINE LOG. Input lag of Flash Forge was not copied (this app already sends real key events). Translations come last.
- 🧪 BETA, written but not compiled or tried on a phone yet.

### 0.3.6_pre13 — Shaders, BIOS files, RAM finder (pre-release 13) (Nov 2026)

- 🛠 FIXED · Shaders: the chips in the game menu wrote the per-game value while the picture read the global one, so nothing changed. They now write both.
- 🛠 FIXED · DS gap: the screens touch by default; the slider now sets the gap in every stacked arrangement (applies when the game starts).
- ✨ NEW · SYSTEM FILES (BIOS): a button on every game page and tile menu, and a section in LOCATIONS. Pick all your files at once (a .zip is fine): the app recognises DS bios7 / bios9 / firmware, GBA BIOS (BIOSGBA.ROM), GB / GBC boot ROMs, FDS disksys and Sega CD BIOS by size and name. Nothing is downloaded.
- ✨ NEW · RAM Finder rewritten (GAME MENU ▸ cheats area): 8 / 16-bit, works on any console, filters CHANGED / UNCHANGED / INCREASED / DECREASED / +1, COPY LIST, and USE buttons that make a vibration rule (pickup, hit, life lost, extra life, smash, any change) for that game. This is how to teach a game that has no built-in rules (Sonic Advance, Sonic Battle, Yoshi, block breaking in Mario...).
- ✨ NEW · VIBRATION DEBUG panel (switch in the game menu, FPS counters): shows the game, where its vibration comes from (RAM map / rules / sound / touch), a count per source and the cause of every buzz.
- ✨ NEW · Rewind memory setting (SETTINGS) and a 40 s length; big states (Sega CD, DS) are saved every 6th frame so the history reaches much further back.
- ✨ NEW · Vibration rules for Sonic Advance 1, 2, 3, Sonic Battle, Super Mario Advance 1 and 2 (Mario World) and Yoshi's Island (lives), with addresses taken from public GameShark / CodeBreaker tables and Data Crystal RAM maps (USA versions). The native bridge now reads the core's memory map, so GBA IWRAM is visible to the rules and to the RAM Finder.
- ✨ NEW · DS emulator choice: AUTO (DeSmuME 2015 first), DeSmuME, melonDS DS (new), melonDS (old). Cores that are not in the build are skipped. Flash: a second, older Ruffle release can be chosen if the newest misbehaves.
- 🛠 CHANGED · Sega CD now uses PicoDrive by default (Genesis Plus GX is still a choice per game in SEGA CD TOOLS).
- 🛠 CHANGED · Disc systems (Sega CD, Saturn, Dreamcast, PS2, PSP): sound-driven vibration is off by default, because the CD music caused random buzzing. It can be switched on per game.
- 🛠 CHANGED · The DS message 'Missing bios/firmware ... Using FreeBIOS' is information now, not a problem.
- ❌ NOT DONE · The GBA rules are untested and for USA ROMs only (a wrong region would buzz at wrong moments: delete them in the RAM Finder). No RAM map found for Super Mario Advance 4 (SMB3), Yoshi's stars, or the Sonic Advance 2 rest. DS white screen and Flash picture are still unconfirmed. 3DS is not part of this build. Translations come last.
- 🧪 BETA, written but not compiled or tried on a phone yet.

### 0.3.6_pre12 — DS, Flash, video, logs (pre-release 12) (Nov 2026)

- 🛠 FIXED (probably) · DS white screen: your log showed the picture stays pure white even after 600 frames. The melonDS JIT is now off by default (the switch is in DS SCREENS). Not confirmed: if it stays white, the translated ROM or FreeBIOS may be the cause; try another DS game. A real bios7.bin / bios9.bin / firmware.bin from your own DS is optional, add it in LOCATIONS.
- 🛠 FIXED (probably) · Flash black screen: in your log the page froze right after the player started (not even the 9 s check ran). The player now tries the WebGL renderer first, and builds a fresh player with the plain canvas renderer if nothing starts within 10 s (choose in the controls menu: Flash renderer). Not confirmed on a phone.
- 🛠 FIXED · the app may use a larger memory heap (the DS ran out of memory in older logs).
- 🧪 BETA, written but not compiled or tried on a phone yet.
- 🆕 NEW · LOGS: SAVE RECENT (48 h) and COPY RECENT (48 h). The app now keeps everything it did in the last 48 hours in a file (errors, pop-ups, emulator lines), whatever the recording mode is.
- 🆕 NEW · Nintendo DS: natural gap between the two screens in portrait and stacked landscape (switch + slider); landscape buttons move beside the picture so they do not cover the screens (also available for every console: GAME MENU ▸ screen); touches on the lower screen are read before the button layer, so the touch screen works under it; JIT switch (default OFF).
- 🆕 NEW · Sega CD: choose the emulator core per game (AUTO / Genesis Plus GX / PicoDrive). Sonic Neon is a Mode 1 Mega CD hack; AUTO uses PicoDrive for it. Needs the PicoDrive core in the build.
- 🆕 NEW · Vibration for Super Mario Bros. 3 (NES) and more for Super Mario World (SNES: death, Yoshi, star power), written from public RAM maps (Data Crystal). The preset names now make sense outside Sonic, and the game's vibration page lists what the game can buzz for.
- 🆕 NEW · TILES game menu now has EDIT, PATCH, MOVE and REMOVE, like the classic game page.
- 🆕 NEW · Media: videos show a preview picture; a new video player with speed 0.25x to 3x, frame by frame, loop, volume / mute, seek bar, 10 s skip (double tap), previous / next and resume.
- ⚠ NOT DONE · Sonic Advance 1-3, Sonic Battle, Yoshi's Island and Super Mario Advance memory rules: no public RAM addresses I could verify, and the GBA cores may not expose that memory. These games vibrate from their SOUND only (touch buttons always).
- ⚠ NOT DONE · Sonic CD 'RAM cartridge is not initialized' is not confirmed fixed; try PicoDrive for this game (SEGA CD TOOLS ▸ Core). Video preview for pictures/comics exists already; 12-language translation of the new texts comes last.

### 0.3.6_pre11 — Vibration for every game (pre-release 11) (Nov 2026)

- 🛠 FIXED · Sega CD: the option name for the backup RAM was wrong (it never reached the core); now genesis_plus_gx_system_bram / cart_bram, with a new 'RAM cartridge' switch. Empty (all-zero) backup RAM files are moved aside before each start (for 'RAM cartridge is not initialized' in Sonic CD). SEGA CD TOOLS is reachable from the TILES menu.
- 🛠 FIXED · the build error in Haptics.kt (operator precedence) that stopped the previous upload from compiling.
- 🛠 FIXED · ENGINE LOG: FOLD and CLOSE buttons (closing no longer flashes back); the in-game top bar's ▸ can no longer be undone by the same tap.
- 🛠 FIXED · Nintendo DS: plain picture frame (no rounded corners / border, switchable), in landscape the screens stay stacked so buttons do not cover them (switchable).
- 🛠 FIXED · Flash: if the movie does not start the screen now offers OPEN IN THE RUFFLE APP (your phone plays these files there).
- 🧪 BETA, written but not compiled or tried on a phone yet.
- 🆕 NEW · VIBRATION per game: a 📳 VIBRATION button on every game page and in the TILES menu (⋯ on a tile, always available) chooses a preset for that game only and shows where its buzzes come from (touch buttons, memory map, sound). The ENGINE LOG now prints one line per game: which source is active.
- 🆕 NEW · more vibration: explosions of monitors / enemies (from the game's sound, on top of the memory map), water splash in and out, air bubble. Sonic 3 / S&K / Heroes now use the advanced map by default (shields, fire / lightning / bubble); Mario NES / SNES use suggested memory rules automatically. Sound haptics give every other game (Advance, SNES, GB...) buzzes: SETTINGS ▸ VIBRATION.
- 🆕 NEW · LOCATIONS ▸ Nintendo DS files: + ADD DS FILES installs bios7.bin / bios9.bin / firmware.bin (recognised by name). Optional: DS games start without them.
- ⚠ NOT DONE / UNCONFIRMED · DS white screen and the Flash black screen: the true cause is still unknown. Your last log came from a build without the new bridge lines, so install this one and send the ENGINE LOG again.

### 0.3.6_pre10 — Core diagnostics (pre-release 10) (Nov 2026)

- 🛠 FIXED · SUPER tab scrolls as one page (buttons at the bottom were cut off); INSIDE shows messages when it cannot start.
- 🧪 BETA, written but not compiled or tried on a phone yet.
- 🆕 NEW · ENGINE LOG has a COPY button; the emulator bridge now writes what the core does: every option name the core offers, refused hardware rendering, video size, and whether the picture is blank (white/black). This is for the DS white screen and the Sega CD problem.
- NOT DONE · DS white screen and Sonic CD RAM problem: not fixed, only made visible. Send the ENGINE LOG after trying them.

### 0.3.6_pre9 — Engine log, Flash diagnostics, TV and x86 (pre-release 9) (Nov 2026)

- 🛠 FIXED (not verified) · Flash page is served like a real site and each step goes to the engine log: ruffle.js, wasm, WebView version, movie start.
- 🧪 BETA, written but not compiled or tried on a phone yet.
- 🆕 NEW · ENGINE LOG strip over the launcher, games and Flash: 3 taps fold it, a long press closes it, SETTINGS ▸ ABOUT or the logs window bring it back (off by default).
- 🆕 NEW · Required-files cards (BIOS, keys, game format) on the game page for Sega CD, GBA, GB, NES and DS.
- 🆕 NEW · x86_64 and x86 APKs (Chromebooks, PC emulators); Android TV first-start setup (bigger UI, remote navigation, no touch buttons).
- 🆕 NEW · Manuals and new texts translated into all 12 languages.
- NOT DONE · Sonic CD RAM error (send the engine log), Flash still unconfirmed.

### 0.3.6_pre8 — Manuals with a console (pre-release 8) (Nov 2026)

- 🧪 BETA, written but not compiled or tried on a phone yet.
- 🆕 NEW · Manuals redesigned: each console is drawn in the app with numbered callouts and a legend, a SPECS box, coloured section bars with icons.
- 🆕 NEW · Nintendo DS manual added.
- 🆕 NEW · Game library: ALL CONSOLES tab and a search box (also in portrait).
- 🆕 NEW · Music: search by title or artist, sort by length.
- 🆕 NEW · Game settings: colours for the EMU and SCREEN counters, with an explanation.
- 🆕 NEW · Symbol transparency: letters and arrows can follow the button transparency (linked, default) or have their own slider.
- NOT DONE · Rest of the 0.3.6 checklist (Game Gear rewind colours, D-pad lights, T indicator, transparency split, picture presets, vibration presets, tempo) is still open.

### 0.3.6_pre7 — Controllers & Looks (pre-release 7) (Nov 2026)

- 🧪 BETA, written but not compiled or tried on a phone yet.
- FIXED · The pre5 build did not compile (a missing import in UiModes). Fixed.
- FIXED · Nintendo DS crashed with 'out of memory': the rewind history kept 6.5 MB per step. Rewind now uses at most 64 MB and switches itself off for DS.
- FIXED · The music notification stayed on 'pause' when the song was already paused (the app replaced the notification's update hook). Now it follows play and pause.
- NEW · 📳 Vibration from the game's SOUND for every game on every console (SETTINGS ▸ HAPTICS): deep boom = hit, bright blip = pickup, other loud blips = action. AUTO is on for games that have no memory profile.
- NEW · 💿 Sega CD: ⚡ AUTO-FIX reads the disc's region, sets it, and clears the backup RAM; the region is also taken from the disc automatically at start.
- NEW · 🎚 Real-time equalizer in the music player (follows the real sound, switchable, needs the microphone permission) and a preview equalizer when you play a recording.
- NEW · ★ MEDIA: favourites, sorting (name, newest, oldest, biggest, favourites first, favourites only) and a small date line under every item.
- NEW · 📐 Game screen: swap sides (4:3 ↔ 3:4), more ratios (16:10, 8:5, 5:3, 3:2, 5:4, 21:9, 7:3, 32:9), system bars switch, optional PAUSE button, shader for this game / console / all.
- NEW · 🔠 Interface size 80 to 135 % with an 8-second 'keep it?' countdown; per-category cache clearing and free space (SETTINGS ▸ DATA).
- STILL UNCONFIRMED · Flash showing a black screen: the log held no page error. Test this build, and if it is still black send the log again; the page now prints its own status line.
- NOT DONE YET · TV remote pass, x86, translations, exact Sonic RAM events, console guide books.

### 0.3.6_pre6 — Controllers & Looks (pre-release 6) (Nov 2026)

- 🧪 BETA, written but not compiled or tried on a phone yet. Small batch on top of pre5.
- FIXED · The rewind hint said 4 seconds while about 12 were kept. Now the length is a choice: 4, 8, 12 or 20 seconds.
- NEW · Swap A and B for Nintendo-style consoles (GB, GBA, NES, SNES, DS), SETTINGS ▸ VIDEO.
- NOT DONE YET · TV remote pass, x86, translations, Flash FPS lock, Sonic vibration events from memory.

### 0.3.6_pre5 — Controllers & Looks (pre-release 5) (Nov 2026)

- 🧪 BETA, written but not compiled or tried on a phone yet.
- NEW · 💿 SEGA CD TOOLS (game page): checks the BIOS files, reads the disc image (cue, track files, boot tag, region), forces the region, and resets the backup RAM. It cannot promise that every fan CD boots.
- NEW · 🖼 Picture layers sit BEHIND the interface on every tab by default (in front is optional, with a warning); fit, crop, size, position and offset; APPLY TO ALL; UNDO STEP; GIF animation on Android 9+.
- NEW · 📚 Comics: pinch and double-tap zoom, tap the left or right edge to turn the page, manga/scroll mode with width zoom, reorder or delete pages, reorder comics, names count up (Comic 1, 2 ...) and a name clash asks before replacing.
- NEW · 🖼 Pictures: zoom, rotate, flip, crop (free or by ratio), save a copy or replace, share, delete. Text files open in the editor from FILES.
- NEW · 🎙 Recorder level display: level bar and a scrolling waveform (switchable).
- NEW · 📳 Vibration RULES for any game on any console (SETTINGS ▸ HAPTICS): you pick a memory address and a trigger. Starter rules for NES and SNES Mario are included, unverified.
- NEW · 🖥 Nintendo DS (experimental, optional core): side by side, top / bottom, top / bottom with the real gap, AUTO and TABLET arrangements; the lower screen is a touch screen.
- NEW · 🎨 Themes: Game Jolt, itch, Neon Coast and Dark Rival get their own backgrounds and button shapes; Meadow Day gets bricks, pipes, hills with eyes, plants, ? blocks and coins.
- FIXED (unverified) · The TILES bottom bar no longer wraps BACK letter by letter; BACK is tappable; the A / B circles show only with a gamepad.
- FIXED (unverified) · Flash starts without waiting for a click and shows its own status line; the recorder now asks for the microphone.
- NOT DONE YET · full Android TV remote pass, x86 builds, translations of the new texts, vibration events read from Sonic's memory, tablet-specific layouts for the rest of the app.

### 0.3.6_pre4 — Controllers & Looks (pre-release 4) (Nov 2026)

- 🧪 BETA, written but not compiled or tried on a phone yet.
- FIXED · The build errors of pre3 (an experimental layout API in games and a missing import in the mini-games).
- NEW · 🗂 MEDIA tab: pictures, comics (pages, scroll or manga mode), video, notes (text editor), files (the app's own folder) and a voice recorder with a backing track. Files are copied into the app.
- NEW · ↗ Open with / Share to SonicForge: pictures, video, audio and text ask where they should go.
- NEW · ⌨ Flash keyboard: backspace and a ?123 page with symbols, F-keys, Home / End.
- NEW · 📺 The app icon shows on Android TV (remote navigation is partly done; a real TV test is still to do).
- NOT DONE YET · new vibration sets, Flash FPS lock, translations of the new texts, x86 build.

### 0.3.6_pre3 — Controllers & Looks (pre-release 3) (Nov 2026)

- 🧪 BETA, written but not compiled or tried on a phone yet.
- FIXED (unverified) · Flash: the game's file name is now URL-encoded (spaces and special characters used to break loading), the page shows its own error text instead of a silent black screen, and the quick menu has OPEN IN RUFFLE APP for the official app.
- NEW · 🎮 SETTINGS ▸ CONTROLS ▸ BY BUTTON: every controller button listed with the function it does; tap to choose another (for example R3 → Mode Select).
- NEW · 📖 HELP ▸ CONSOLE MANUALS: illustrated booklets for Mega Drive, Master System, Game Gear, Sega CD, 32X, Game Boy, GBA, NES and SNES (English only for now).
- NOT DONE YET · media tabs, recorder/karaoke, new vibration sets, FPS lock for Flash, keyboard symbols page, translations, the rest of the 0.3.6 checklist.

### 0.3.6_pre2 — Controllers & Looks (pre-release 2) (Nov 2026)

- 🧪 BETA, written but not compiled or tried on a phone yet.
- NEW · 👾 NES and SNES (experimental, cores are optional downloads at build time).
- NEW · 🎨 Themes Blue Blur, Dark Rival and Meadow Day (original palettes, no logos or characters). Neon Coast, Game Jolt and itch stay.
- NEW · 🖼 More picture layers: background, background objects (palms), ground, character, foreground. SETTINGS ▸ SCREEN & LOOK.
- NEW · ❄ Optional seasonal decoration (snow, confetti, lights, leaves), OFF by default.
- NEW · 🕐 24-hour clock option; music notification with cover, seek bar and play/pause state.
- IMPROVED · Changing a theme no longer shows a 'saved' notice.
- NOT DONE YET · per-button mapping list, console manuals, media tabs (comics, video, notes, files), recorder/karaoke, new vibration sets, extra translations.

### 0.3.6 pre-release — Controllers & Looks (pre-release) (Nov 2026)

- 🧪 BETA: this is the first build with everything below, and none of it has been tried on a real phone yet. Please tell the developer what breaks. The final 0.3.6 will be this app after your feedback and the rest of the checklist.
- NEW · 🕹 Classic mode can now show the on-screen controls over the clean picture (SETTINGS ▸ SCREEN, and the in-game menu). They are see-through; set the opacity yourself.
- NEW · 🔆 Controller highlight: a white frame shows which item the gamepad is on in the launcher. SETTINGS ▸ CONTROLS ▸ 'Launcher with a controller' turns the frame off, and lets A / ✕ press and B / ○ go back.
- NEW · 📳 Vibration strength: Low / Normal / High / Max separately for the phone and for the controller, with fine tuning (multiplier, weakest buzz, longer buzz). A controller's Normal is stronger than before. Not tested on real pads yet.
- NEW · 🎨 Two more launcher looks, Game Jolt and itch (original colour palettes, game-card grid), besides Normal, Mania and Tiles. Your own PNG background / foreground / character with opacity and blur for every look (CUSTOMIZE and SETTINGS ▸ SCREEN).
- NEW · 🌅 Neon Coast theme (original sunset / neon poster look). Themes now also change the menus, buttons and background inside games and emulators; switch 'Use the theme inside games and emulators' off to keep your normal style there. The Help topic 'Styles and themes' explains the difference.
- NEW · 🎬 Startup intro (experimental, off by default): your own picture or video, optional music, fade from / to a colour, tap to skip. A theme's built-in backdrop is replaced when you add your own background picture.
- IMPROVED · Help: ASK A HELPER is now second. MUSIC: switch to hide the small player bar inside the music tab; opening MUSIC always brings a hidden player back.
- NEW · 🃏 Game cards: show or hide the title, the system label and the logo. In the card looks a tap opens a small game menu (or starts the game at once, your choice).
- NEW · 🎮 Three more mini-games with their own rules: Endless Hills (endless platformer), Sky Spring (vertical bouncer: drag, buttons, D-pad or optional tilt) and Lane Sprint (run into the screen). They work with a gamepad or TV remote.
- FIXED · 🎵 The hidden-player ♪ chip now floats above every screen and can be tapped. The 'next songs' strip no longer repeats a song, and the ▲ ▼ reorder arrows follow what you see, also with Reverse order on.
- FIXED · 📱 In a game the picture no longer slides under the status bar until you switch apps. Mania is roomier in landscape, the game list is no longer covered by the add buttons, and small text is brighter and larger.
- NOT DONE YET (still on the checklist): startup splash, music / video / comics / photos tabs, voice recorder, Flash fix, new equalizers, 'open with' for files, per-button function dropdown and the emulator's own button labels.
- NEW · 🎮 Controller setup (SETTINGS ▸ CONTROLS, also in the pause menu ▸ CONTROLS ▸ CONTROLLER MAPPING): detects Xbox, DualShock 4, DualSense, Switch Pro and Steam pads (or pick the family yourself) and draws the pad with real button names and your layout. The button you press lights up. Tap a button on the picture to change it.
- NEW · 🔁 Step-by-step re-binding: choose the action, press the button, read what was recognised, then CONFIRM. Nothing is saved before you confirm. Warns when a button is already used. Optional 'also press together with' second action.
- NEW · 🧩 Control profiles in three layers: GAME → EMULATOR → GLOBAL → factory. Each layer stores only what you changed, so they never overwrite each other, and each row shows which layer it comes from. Built-in profiles and your own (save, copy, rename, apply, delete). RESET THIS LAYER and RESTORE FACTORY.
- NEW · ⌨ New actions for any button: four D-pad diagonals, next / previous save slot, show / hide on-screen buttons, vibration on / off (besides Save, Load, Menu, Fast-forward, Rewind).
- NEW · 📳 Vibration goes to the Phone, the Controller, Both or Off (menus and game separately, a game can override, controller strength). TEST DEVICES buzzes each device and shows what Android reports, so you can see which one really vibrates.
- NEW · 🕹 While a controller hides the touch buttons, the on-screen buttons stay drawn and light up when you press the real ones (not in Classic mode; can be switched off).
- NEW · 🖼 Two extra interface styles besides NORMAL: MANIA (like the Sonic Mania menus) and TILES (like Steam's Big Picture). Switch with the ◐ button in the top bar, rename them, or hide the button: SETTINGS ▸ SCREEN & LOOK ▸ Interface style.
- NEW · 👋 A longer tour with a language and look chooser on the second page, and new HELP pages: Control layers & profiles, Interface styles, About this beta.
- IMPROVED · 🌍 The whole tour and every HELP page are now translated into all 12 languages (helper answers are still English only).
- FIXED · 🔧 The colour-picker bar that stopped the 0.3.5 build from compiling; a missing comma in the tour source.
- FIXED · ♥ Favourites update at once (list, counter and the heart on the song).
- FIXED · 🎵 The queue stays open when you pick a song; the mini player takes no space when hidden and can be closed; music pauses when headphones disconnect.
- FIXED · 🕹 Master System: the Pause button (ST) and buttons 1 / 2 are labelled correctly; A and C both act as button 2.
- FIXED · 🎨 Default text colour follows the skin (the storage page was black); LOCATIONS buttons scroll sideways.

### 0.3.5 — Tilt & Queue (Nov 2026)

- 🧊 Tilt (cartridge glitch): six modes (Loose, Hot, Dying, Overheating, Meltdown, Total chaos), a crash-safe switch, SET / RESTORE SAFE POINT, no forced shader, and a coloured ● T badge in the top bar. Warning: tilting can damage saves made during or after it
- 🎮 Game screen: the top bar explained (menu, lock, awake, α, UI, tilt, hide), UI can be hidden but still touchable, RESET GAME in the menu, the picture stays below the status bar in portrait, one small menu button in classic mode (can be hidden; Back opens the menu)
- 💾 Save slots show ○ empty / ● saved / ■ latest with date and time; LOAD PREVIOUS SAVE
- 🎨 Look for games: choose MY OWN SET (default, every game looks the same) or EACH GAME'S OWN SET; shaders no longer come bundled with skins; anime outline is now thin
- 🎵 Player: BACK now goes to the previous song in the list (history only while shuffling), NOW n/total and JUMP, REORDER with a hint, COPY TO / MOVE TO playlist, mini player with swipe, peek list and scrolling titles, 2 more equalizers, queue as a bottom sheet
- 🌸 Effects: smoother motion, a sakura-petal effect, a low-power switch; the scene under a game no longer skips rings during a spin-dash
- 🗂 LOCATIONS: Sega CD BIOS library (choose which file acts as USA / Europe / Japan), OPEN IN APP for every folder; SETTINGS: storage used by SonicForge with a clear-cache button; text and picture files are never imported as games
- 🧾 Logs: EMU tab with two optional switches (record emulator activity, only while tilting); Flash now reports page errors and missing files in the log
- 📖 HELP: Sega CD guide (BIOS, regions, the 'RAM cartridge is not initialized' message)

### 0.3.4 — Rock Solid Rings (Nov 2026)

- 🎨 DRAW tab (new): pixel-art canvas with layers (show/hide, opacity, CLIP to the layer below), pencil / eraser / fill / eyedropper, zoom and pan, add a picture onto a layer or as a new layer, resize the canvas, undo, export PNG. Your drawing is saved and reopens next time
- 🔊 Menu sounds: they only play when you tap something (the little scene under a game used to make them by itself); a new sound pack applies at once, no preview needed; sounds are prepared in the background
- 🔧 GAMES RUN AGAIN: importing a ROM, ZIP, RAR or 7z really saves the game now (the save step was switched off by mistake in 0.3.3, so the core 'rejected' every ROM). A game whose file is missing is flagged and is repaired by importing it again
- 💽 Sega CD BIOS: any BIOS dump works whatever its file name; you can pick a whole zip of them. The app reads the region from the file itself and installs it under the name the core needs
- 🕹 Mini-games no longer crash (an endless loop in the hero colour code). The little scene under a game no longer makes sounds by itself
- 🎵 Music: the screen can't freeze or crash any more (song details load in the background, the list changes safely), 600+ songs are fine; shuffle plays every song once per round and BACK returns to the songs you really heard; QUEUE panel (what played, what is next); favourites ♥ and built-in lists (Recent, Imported, Built-in, Linked folder); MOVE mode; adding music while a playlist is open puts it into that playlist; a hide-able mini player on every tab; the current song and the list can no longer get out of step after an import
- 🧾 Logs: every pop-up is also kept in full (NOTICES tab), COPY / SAVE FILE / SHARE for the whole log, one entry, or only errors; the app now records freezes ('not responding') and why the last run ended
- 🕹 Flash (experimental): Ruffle is now downloaded in two ways at build time; full see-through keyboard over the game (⌨), a key for every gamepad button, left stick/D-pad as arrows, WASD or mouse, touchpad mouse mode
- 🎛 Sliders: ↺ back to default and tap the number to type an exact value; moving a screen margin shows the real picture area on your screen; vibration test tells you what it did and has RESET ALL
- 🧭 Settings re-organised: SCREEN & LOOK, SOUND & MUSIC, ABOUT & UPDATES hold everything of their kind; LOCATIONS can BROWSE every app folder; the 'show game UI again' button moved to SETTINGS ▸ GENERAL
- 📲 Quick Settings tiles: Launcher, Music play/pause, Last game, Ask a character (pull down the shade, tap the pencil, drag a tile in)
- 🌐 The language switch always shows an English 'Languages' under it (so you can find it in any language); welcome title translated into every language; darker 'Are you sure?' pop-ups; MD/SMS/GG explained
- 🧰 Build: 7z and RAR4 archives are read; build.yml updated (copy it from SETTINGS ▸ ABOUT & UPDATES) so Ruffle is really included; three APKs per build

### 0.3.3 — Emerald Everything Plus (Nov 2026)

- 🛠 Build stability: no experimental Compose API any more (own swipe pages); one build now makes THREE APKs: Universal, arm64-v8a, armeabi-v7a
- 📺 Android TV / remote basics (same APK), minimum Android 8.0 stated; ABI and Android info in ABOUT APP
- 🎮 Systems: Mega Drive, Master System, Game Gear, Sega CD (BIOS needed), optional 32X and Game Boy Advance cores, OpenBOR via its own app with a CPU-match report, Flash games through Ruffle (experimental)
- 🕹 Flash: touch mouse or touchpad mode (tap, two-finger right-click and scroll, hold buttons), gamepad sticks as arrows/WASD/mouse, on-screen key sets, quality/scale/resolution
- ⏯ Two-step pause menu that freezes the game; mini music player, vibration, cheats, screen, controls and tools inside it
- 🕹 Controls: 7 ready-made layouts (close 6-button, GBA) + 6 of your own, gamepad/keyboard maps with APPLY/CANCEL/RESET, combos, controller visualisation, opacity per orientation, Pocket Lock, Stay Awake, quick opacity, UI rescue button
- 📳 Vibration: 18 events (rings, hits, jump, spin dash, springs, Tails flying, drowning, ring bite and drain, extra life, shields, speed shoes, footsteps), templates, presets, per-game switches, Ring Finder for any game
- 🎚 Volumes up to 200% with snap, -1/+1 and reset; music in game never restarts your song; 3 menu sound packs
- 🎵 Music: playlists (merge/ungroup/reorder), multi-select, sorting, covers, equalizers, ±10/30 s, scratch disc, details toggles, failed-import list with reasons, background notification + headphone multi-click, 2-minute test track
- 🧩 11 mini-games with pause, mute, best, rules, 3-2-1-GO; Speed Cafe uses real menu names; the scene under each game really collects rings; 28 colour palettes
- 🎨 22 shaders (incl. a lighter bloom), 18 skins, effects behind the game, screen margins/corners/classic mode with a preview, FPS counters (emulated vs screen)
- 🧑‍🤝‍🧑 9 helpers with 110+ answers (Tails in three depths), character-led tutorial with skip confirmation, Classic/Pro mode, confirmations with delay
- 🗂 LOCATIONS tab, LIGHT/FULL named backups, logs and crash reports with explanations in two languages (hidden near the version), 13 languages incl. Brazilian Portuguese, Korean, Hindi, Turkish

### 0.2.0 — Archives n' Cheats (Oct 2026)

- 📦 Import ROMs from .zip, .rar and .7z; link a ROM folder; IPS/BPS patches
- 🔑 Per-game cheats
- ⏪ Rewind, fast-forward, 6-button option, screenshots
- 🎨 RGB colour pickers, per-game shader/skin/layout/music
- 🕹 Tails Flyer and Zone Trivia
- 🌍 10 languages, guide, version history

### 0.1.0 — Customisation n' Blue (Oct 2026)

- First release: launcher with per-game art, mini-scenes
- Genesis Plus GX emulation with saves, save states, FPS control
- 9 shaders, 10 skins, touch-control editor with 6 presets, controller remapping
- Retro music player, custom launcher sounds, independent volumes, vibration, no INTERNET permission

---
_Сгенерировано из AboutUi.kt; число версий: 21._
