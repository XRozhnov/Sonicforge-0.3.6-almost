# Progress and health, ALL versions (2026-11-21, 0.3.6_pre8)
Open 16_PROGRESS_REPORT.html for charts. Approximate counts from the checklists.
| Version | Delivered | Open | Build |
|---|---|---|---|
| 0.1.0 | 9 | 3 | compiled, works |
| 0.2.0 | 4 | 2 | did not compile |
| 0.3.0-0.3.3 | 12 | 3 | 0.3.3 compiled, tested |
| 0.3.4 | 5 | 3 | compiled |
| 0.3.5 | 4 | 10 | did not compile |
| 0.3.6 pre2-8 | 60 | 47 | pre3 had 3 errors, pre5 1; pre6-8 never built |

Total delivered 94, still open about 85.
Completion 53%, verified on a phone 28%, compile-first-try 44%. Net health 42% (red under 45).
