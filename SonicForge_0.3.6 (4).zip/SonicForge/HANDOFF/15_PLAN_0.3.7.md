# SonicForge 0.3.7: "Polish" plan (draft, 2026-11-21)
Theme: stop adding surfaces, make every existing one feel finished. Written, not compiled, like everything before it; the first gate is a real build on the phone.

## 0. Gate before any new feature (blocking). Market comparison: see 17_COMPETITOR_COMPARISON.md (adds: optional art scraper, simple-setup mode, TV and dual-screen passes)
1. Compile pre8 on GitHub Actions; fix errors. Send BUILD_REPORT.
2. Phone smoke test (15 minutes, checklist in section 6): launch, play MD, Sega CD, DS, Flash, music with notification, recorder, manuals.
3. Collect one log after a normal session. No new feature batch until 1 to 3 are green.

## 1. UX principles for 0.3.7
- Every setting says what it does in one line, and what changes is visible at once (live preview where possible).
- Every destructive action asks once, and has UNDO or a copy where cheap.
- No dead ends: each screen has a visible BACK, and controller focus reaches everything.
- Same words everywhere (one glossary: SAVE, APPLY, RESET, DEFAULT).
- Fewer buttons per row; long rows become a labelled sheet.
- Fast: nothing blocks the main thread (scan, thumbnails, metadata).

## 2. Workstreams
### A. First-run and discoverability (high value)
- First-launch tour of 5 cards (add games, play, controls, music, help), skippable, re-openable.
- "Tip of the day" strip in Library (off switch).
- Empty states with one clear action (no games, no music, no comics).
- Settings search box (type "vibration" and jump there). Pro mode list (D5) shown as badges.
### B. Library and game page
- Library pages per console family with coloured tag and search (done in pre8, extend to sorting: recent, most played, A-Z, favourites).
- Play-time and last-played per game; "continue" shelf with a resume-state thumbnail.
- Game page: one-tap SAVE STATE slots with screenshots.
### C. In-game screen
- Remaining items: Game Gear rewind colours (A11), D-pad lights only pressed direction, T indicator hollow square + hide, mini-menu hide option, auto-rotate confirm icon, dead-zone map always visible, tilt options, Classic mini-panel switches.
- One "Quick panel" instead of many chips: 6 big toggles (rewind, FF, shader, ratio, pause, haptics).
### D. Controls
- Layout editor undo/redo, snap grid, mirror left/right, per-game layout memory.
- Controller pictures per model (bumpers/triggers). 6-button layout fixes (D6).
- Presets: 9 slots per category with names and thumbnails.
### E. Music and media
- Tempo/speed, same-name import confirm, play original files in place, custom-image equalizer, hide-cover.
- Search in video, comics, pictures (the box exists already; wire it).
- Media: batch select, share multiple, slideshow.
### F. Look and feel
- Skins: leaves, Horror Hills, Angel Island; effect FPS + presets; particles fade.
- Consistent motion: 150 to 250 ms transitions, reduced-motion switch.
- Accessibility pass: minimum 48 dp touch targets, contrast check for each theme, font-size follows UI scale, TalkBack labels on icon-only buttons.
### G. Help and manuals
- Console guide books with 3 depth levels (F3/E4), Flash and OpenBOR manuals, manuals for controller diagrams with pointer lines.
- IPS/BPS patch explanation with an example (D10).
- "What's new" grouped Added / Fixed / Improved.
### H. Vibration
- S3&K fixes, footsteps, vibration log, 6 preset slots + 5 more event sets.
### I. Stability
- Crash report screen on next launch (last log, share button).
- Memory guard (rewind caps exist), storage tools, scan on background thread with progress.
- Unit tests for parsers (archives, ROM header, Sega CD region), a CI step running them.

## 3. Not in 0.3.7 (decided)
Translations (done once, at the end of 0.3.7 after text freeze), x86/x86_64, 3DS/N64, Android TV pass (revisit if phone gate is green).

## 4. Milestones
| Build | Content | Exit test |
|---|---|---|
| pre9 | Gate + all compile fixes + in-game remaining items (C) | phone smoke test green |
| pre10 | A first-run tour + settings search + library sort/play-time | new-user walkthrough without help |
| pre11 | D controls + E music/media | layout edit/undo, music search |
| pre12 | F look + G manuals/books | contrast + TalkBack pass |
| rc1 | H vibration + I stability, text freeze | 30 min soak test |
| rc2/final | translations (12 languages), release notes | all languages open every screen |

## 5. Risks
- Nothing since pre4 has been verified on hardware. Mitigation: the gate above.
- Core option names for Sega CD and DS come from memory and may be wrong. Mitigation: log the options each core asks for (GET_VARIABLE) and show them in the log.
- Big Compose screens (UiModes, GameActivity) are slow to edit safely. Mitigation: split files before adding more.

## 6. Smoke-test checklist (phone)
Launch and library; play a MD game 2 minutes; rewind; save/load state; Sega CD with BIOS; DS two screens + touch; Flash page loads; music play/pause from notification; recorder; each manual opens; settings open without crash; rotate 3 times.
