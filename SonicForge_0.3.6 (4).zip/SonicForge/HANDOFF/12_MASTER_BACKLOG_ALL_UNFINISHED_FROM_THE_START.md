# MASTER BACKLOG: every feature the user ever asked for that is NOT finished (from the very first messages until today)
Why this file exists: `08_CHECKLIST_0.3.6.md` only lists what was requested for the 0.3.6 batch, and some older asks (like the voice recorder) were voiced earlier and never made it into that list. This file is the complete memory. When something here is finished, tick it here AND in `08`. Phases: **P1** first messages · **P2** early waves (0.1–0.2) · **P3** 0.3.x waves · **P4** latest batch (0.3.5–0.3.6).
Legend: ⬜ not started · 🟡 partly (details in brackets) · 🔒 impossible/deferred (reason). Anything fully done is NOT listed (see `11_CHECKLIST_UP_TO_0.3.5.md`).

## 1. Media and files
* 🆕🟡 **COMICS tab** (P2; basic reader written in pre4: images only, no CBZ/Kotatsu import, no zoom %): a reader like Kotatsu (modes, zoom, bookmarks, long images), import of image folders/CBZ and Kotatsu comics.
* 🆕🟡 **PHOTOS / PICTURES tab** (P2; grid + viewer written in pre4, no filters/editor): a gallery with format tags, filters, a simple editor (crop with grid + rotation ruler).
* 🆕🟡 **VIDEO tab and video player** (P2/P3; plain player with system controls written in pre4): YouTube-like controls (hide/show on tap), a library of videos, custom covers, playlists, subtitles/lyrics.
* 🆕🟡 **File explorer** (P3; browser of the own media folder only, written in pre4): like X-plore/ZArchiver: multi-select, copy/move/rename/delete/extract, format groups, hidden/system folders toggle with a warning. 🟡 (a read-only folder browser for the app's own folders exists)
* 🆕🟡 **Simple text editor** (P3; NOTES tab written in pre4): for code/notes next to the file manager. 🟡 (choose an external file manager/editor exists)
* ⬜ **Private (hidden) folders** for music/comics/photos (P2). ⬜ **Mods folder option** (P3).
* ⬜ **Search** for games, video, comics, pictures (P4); 🟡 music search planned.
* ⬜ **Share-to-launcher** (Android share sheet) importing games/music/comics/pictures/video with per-type tabs (P4). ⬜ Import music "in place" without copying + choose copy format (same / Opus) (P4).
* ⬜ **GIF** support for covers/thumbnails and click-to-play GIF on buttons (P4). ⬜ Recommended image sizes + a crop editor that keeps no spare copies (P3).
## 2. Voice, karaoke, audio extras
* ⬜ **Voice recorder page** (P3): listening and recording on separate pages; background recording with a notification (pause/stop); auto-name with order number + date/time; catalogue with date/size; multi-delete; rename; recolour labels; zoomed live timeline for timestamps; speed change with "keep tone"; skip silence; never lose a recording (Pro).
* ⬜ **Karaoke + timestamps/chapters** (P3), lyrics/subtitles with or without timecodes, multitrack editor, effects, keyframe volume, export (wav/ogg/mp3) (P3). If impossible: a voice "zoo" mini-game.
* ⬜ **Real-time spectrum equalizer** using the audio session (P4) (needs the audio permission). ⬜ Equalizer over the cover + more styles + tempo (P4).
* ⬜ Several retro player faces with covers/composer (P3); music colours/contour customisation (P3); blur backgrounds (P3); notification widget/cover/seek bar (P3–P4).
* ⬜ Mute buttons in the volume menus ("music / game / both") (P3); device-volume display (P4).
## 3. Emulation, consoles and controls
* ⬜ **Extra consoles** (P2/P4): NES, SNES, N64 (via libretro cores); Nintendo DS skipped; 🔒 3DS/Saturn/Dreamcast/PSP/GC/Wii/PS2 (hardware rendering/too big). ⬜ SRB2 as a separate engine tab (P2). ⬜ Console preview carousel with sample images (P2).
* ⬜ **Sega CD module** (P4): launch the Sega CD itself with disc controls and a tutorial to fix the RAM message; choose the BIOS to boot with; per-region ROM switching.
* ⬜ **Flash fixes** (P2/P4): works for the user only in the official Ruffle app; add "open in installed Ruffle", FPS lock, haptics, full keyboard extras, keyboard languages.
* ⬜ **Cheat macros** (P4): timed button sequences (e.g. Sonic 3 level select needs exact timing).
* ⬜ Game Gear rewind bug (P4); per-save-point rewind history (P4); combos reset circle (P4); keyboard+mouse control settings like Controllers (P3).
* ✅ (written, uncompiled, batch "controls UX") controller picture per family (Xbox / DualShock 4 / DualSense / Switch Pro / Steam / generic, auto-detected + manual override) with real button names; controller vibration on/off via route Phone/Controller/Both/Off; detects several controllers and lists each with its rumble support; three-layer profiles (game → emulator → global); step-by-step re-binding with confirm; diagonals; extra actions (slot next/prev, UI toggle, vibration toggle). 🟡 not done: real photos/exact models (the picture is a generic drawing re-labelled), button chords of two physical buttons.
* 🔒 Adaptive triggers (not exposed by Android for generic pads).
## 4. Vibration and tilt
* 🟡 Vibration for monitors, bosses, badniks, steps, Sonic 3 shields, explosions, bricks/walls, cutscene events, special-stage entry, wind, debris, icicles; Hellfire Saga profile; 12+ popular MD games and racers; Sonic on Game Boy (P2–P4). ⬜ Supported-games catalogue (collapsible, searchable). ⬜ 5 more sets + 6 presets (hollow circle = save, rounded square = load) + reset + a Classic default preset (P4). ⬜ Optional readable vibration log (P4).
* ⬜ Tilt: "glitch visuals only" switch, vibration-ignore switch, per-console methods, gentle mode (P3/P4).
## 5. Look, customisation, effects
* ⬜ **Holiday themes** (New Year, Halloween, Easter, birthdays) and anniversary mode (P2/P3). ⬜ Gradient + image backgrounds with fit/crop/position (P3); foreground image layer (P4); animated backgrounds beyond particles (P3).
* ⬜ PNG-mask / shaped frames and frame contour variations (P3); per-tab customisation presets (P2); per-game custom UI (experimental) (P4); a customisation editor starting from a preset with "+" (P4).
* ⬜ Picture preset slots (9 per category with +) (P4); effect FPS settings and presets (P4); particles appear/disappear off-screen (P4); UI scale with an 8-second confirm (P4).
* ✅ (written, uncompiled) two extra launcher styles MANIA and TILES (+ NORMAL kept), quick-switch ◐ button that can be hidden, renamable. ⬜ polish: in-game pause menu in these styles, controller-driven focus tuning for TILES.
* ⬜ Shader choice inside the in-game menu (this console / all) (P4); more shaders (P2/P4); synthwave with custom colours (experimental) (P4); overlay on/off (P4).
## 6. Game screen quality of life
* ⬜ Portrait layout under the status bar, UI scale, auto-rotate with confirmation, resolution swap and extra ratios (P4); optional PAUSE button (P4); mini panel minimise/off with confirmation (P4); D-pad shows only pressed directions (P4); alpha for symbols (P4); TV remote support in all APK types (P3/P4).
* ⬜ Widgets for the home screen (music, mini-games, quick launch, character) (P3). 🟡 Quick Settings tiles exist.
* ⬜ Universal TV APK, universal phone APK, x86 (P3/P4).
## 7. Helpers, help, content
* ⬜ More answers for every character (P2–P4): franchise history (games order, plots, popularity, Sonic 4 episodes, canon), films (including Wreck-It Ralph cameos, the Angry Birds Movie 3 cameo to verify), series (Sonic X, Boom, Prime, Knuckles) with synopses and dates, fan works (Sonic Paradox, Hazo animation, flash games: Snowboard, Cannonball, Scene/Character Creator), first appearances of Silver/Shadow/Amy and why they came back, collabs (McLaren, Minecraft, DC, LEGO), Sonic Racing CrossWorlds, other Sega IPs (NiGHTS, Super Monkey Ball, Jet Set Radio, Persona…), indie recommendations, genre guide, multiplayer/co-op list, birthdays, voice actors, model/design history, one fun fact per language.
* ⬜ Characters look like themselves + zone backdrops (palms, loops), decorations not looking like a bug (P3); a background image layer for the helper screen with transparency (P4); ASK A HELPER second after QUICK START (P4).
* ⬜ **Console guide BOOKS** for every console/emulator (P2/P4), swipeable, manual-like with pictures, history, competitors, sales, cables, regions, usage; also Flash and OpenBOR; in all 12 languages.
* ⬜ More tutorial slides (new features, Pro mode list, language chooser at the start) (P3/P4); What's new split Added/Fixed/Improved (P4).
* ⬜ **Translations**: all long texts (tutorial, What's new, help, helper answers, books, logs commentary) into 12 languages (P3/P4).
* ⬜ Explain the patch buttons (IPS/BPS) with a real example (P4); explain Pro mode contents (P4).
## 8. Data, storage, system
* ⬜ Per-category cache clearing; free device space; storage charts (Pro) (P4). ⬜ "Reset the console/emulator (reinstall cores)" option or instructions (P3).
* ⬜ Add-game category confirmation sheet (experimental) with automatic-sorting advice (P4); supported-games lists per console (P4).
* ⬜ Scene creator with the user's own sprites/assets (Pro, experimental) (P3/P4); level-maker mini-game with picture export (P3); more mini-game polish and Among-Us-style idea (P2).
## 9. Big future project
* ⬜ Three editions: FULL, LITE (simple, translated, player, themes, explorer + text editor, NES/SNES/GB, wide Android support) and TV/x86 (remote + gamepad, economical). See `10_NEW_CHAT_START_HERE.md` §6.

## Added after pre3 (new emoji 🆕 = newest)
* 🆕⬜ **Android TV pass**: leanback launcher entry exists; needs a TV layout check, remote-friendly focus everywhere, an APK tested on a real TV box (the user meant "TV", not "you").
* 🆕⬜ **x86 / x86_64 builds**: libretro cores exist for those ABIs but the build is kept arm-only for stability; enable with a build switch later.
* 🆕⬜ **Preflight check** (`HANDOFF/tools/preflight.py`) must be run before every zip. Add real compilation as soon as a Kotlin/Android toolchain with network is available.

## See also
`13_MASTER_PROGRESS_BY_VERSION.md` is the chronological chapter list with DONE and NOT-DONE items and the version next to each.
