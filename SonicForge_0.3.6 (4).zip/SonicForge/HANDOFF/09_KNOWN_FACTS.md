# Known facts, gotchas, environment

## People and environment
* User writes Russian (sometimes English). Phone: Android with a gesture bar. Builds on GitHub Actions with the zip method; private repo; sends screenshots + Actions `e:` error lines. Never assume he can run adb/Android Studio.
* My sandbox (the AI): no internet from bash, no Gradle/Kotlin, so NOTHING is compiled by me. The sandbox can be RESET between messages: the only source of truth is `/mnt/user-data/outputs/SonicForge.zip` (unzip it into /home/claude first thing).

## Build history facts
* 0.1.0 compiled and worked. 0.3.3 compiled and was tested (ROM import was broken, mini-games crashed, sounds from nowhere, music froze). 0.3.4 failed: JVM clash `Draw.color` property + `fun setColor` (fixed by renaming to `chooseColor`). 0.3.5 failed: `DrawUi.kt:420:86 Type mismatch Int vs Float` in `HueBar`: inside the Canvas lambda `size` resolves to the local `IntSize` state (shadowing DrawScope.size), so `Size(6f, size.height)` needs `.toFloat()` (fixed).
* Kotlin gotchas hit so far: a code comment swallowed a statement (`// ... ; File(...).use(write)` on one line); a function calling itself (`else -> heroCol()`); property named like a setter; shadowed `size`; missing imports (`Brush`, `horizontalScroll`). Run the checks: bracket balance, unterminated quotes, import scan (`/tmp/check_imports.py` is not persistent; rewrite it if needed).
* Opt-in flags for experimental Compose/foundation APIs are enabled in `app/build.gradle.kts` (so `basicMarquee` etc. are fine).
* Warning in the Actions log "extractNativeLibs should not be specified in AndroidManifest" is harmless (remove the attribute later and keep `jniLibs.useLegacyPackaging = true`).

## Emulation facts
* Genesis Plus GX (libretro) handles MD, Master System, Game Gear, Sega CD. For SMS the two buttons are RetroPad B (button 1) and RetroPad A (button 2); the SMS "Pause" button is mapped to Start (it pauses, it does NOT start games; most SMS games start with button 1/2). Game Gear has a real Start button. In `Systems.bit` "1"/"B" → Bits.B, "2"/"C"/"A" → Bits.A, "START" → Bits.START.
* Sega CD needs a BIOS of the right region; any file name works (content detection); BIOS library lives in `files/system/bios_library`; "RAM cartridge is not initialized" is the game asking for a formatted memory (needs the BIOS/CD menu to format; the launcher cannot yet open the Sega CD menu without a disc or eject/load a disc).
* Game Gear rewind bug (user report): pressing REWIND turns the picture into a solid colour; RESET afterwards shows solid colours cycling. Likely the rewind state buffer / video size for the small GG screen. NOT fixed.
* Rewind buffer: 240 snapshots, one every 3 frames (about 12 s). User wants rewind history stored per save point.
* Ruffle: assets are downloaded at build time by `fetch_extras.sh` (GitHub release "web-selfhosted" zip, then npm package). It plays local .swf OFFLINE; the app has no INTERNET permission (games that need the network fail quietly). Flash is still reported "virtually broken" by the user (black screen); diagnostics now log console errors and missing files; cause not confirmed. The official Ruffle Android app works on the user's phone (screenshots show it running Flash Sonic games with a keyboard overlay). Option wanted: launch the .swf in the installed Ruffle app if it supports being given a file (not verified).
* Headset buttons: Android delivers headset/Bluetooth media keys through MediaSession; the app already handles play/pause/next/previous and multi-click. Each headset maps its own gestures (e.g. long press of volume +/- to skip). The app can only support what the headset sends.

## App facts
* Package com.sonicforge, minSdk 26. Three APKs per build (universal, arm64-v8a, armeabi-v7a). TV APK and x86 are wanted, not done.
* Settings storage: flat JSON `files/data/settings.json` via `Store`. Playlists: `files/data/playlists.json`; a user playlist or ★ Favorites is a name → list of absolute file paths.
* i18n: `Text` wrapper (package `ui`) translates exact English strings through `RAW` rows `English::es|fr|de|pt|ru|uk|ja|zh|it` and `RAW2` (`ko|hi|tr`); empty columns fall back to English. Long texts (What's new, guide, help, helpers) are mostly English only: translating them is a standing task.
* Screens the user showed (Nov 11): storage page works (3.3 GB total: games 977 MB, music 2.3 GB); Locations page buttons overflow; text on the storage page was black (default text colour bug); mini player takes an empty strip when hidden and covers other tabs; queue sheet works but closed itself after picking a song; favourites hearts did not update (Playlists state not observable).
