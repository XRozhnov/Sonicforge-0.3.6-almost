# pre11 / Super exp4 — что проверить (RU)

Всё написано, но НЕ скомпилировано и не проверено на телефоне.

1. Вибрация: страница игры → «📳 VIBRATION» (в режиме TILES: «⋯» на плитке или тап по плитке). Выберите пресет для этой игры; внизу видно, откуда идут вибрации (кнопки / карта памяти / звук). Включите ENGINE LOG: каждая вибрация пишется строкой (rule / audio / ring…).
2. Sega CD: SEGA CD TOOLS есть и в меню плитки. Для «RAM cartridge is not initialized»: AUTO-FIX, затем «RAM cartridge → SEPARATE PER GAME». В логе ищите «Sega CD: … moved aside».
3. DS: DS SCREENS → «Plain picture frame» и «Side by side in landscape» (по умолчанию выключено — экраны стопкой, кнопки по бокам).
4. Flash: если фильм не стартовал — появится кнопка OPEN IN THE RUFFLE APP. Пришлите ENGINE LOG после попытки (строки Flash:).
5. Super: PLAY пробует 4 способа открыть файл в эмуляторе. INSIDE для больших образов и .gdi отключён с сообщением.
6. Пришлите свежий лог (ENGINE LOG → COPY): в нём должны быть строки [bridge], без них причину белого экрана DS не найти.
