# CHECKLIST: everything up to and including 0.3.5 (archive; the CURRENT list is `08_CHECKLIST_0.3.6.md`)
Legend: ✅ done and confirmed working by the user · 🧪 written, compiled at some point but with known bugs · ✍ written in code, never confirmed (0.3.5 never compiled) · ⬜ requested, never done · 🔒 impossible/deferred.
How to use: when you are unsure whether something exists, search the code first; this file says what was intended and what the user saw.

## Version history (with build status)
| Version | Build status | Notes |
|---|---|---|
| 0.1.0 "Customisation n' Blue" | compiled once, user: "works well" | first launcher: Genesis Plus GX host, skins, shaders, mini-games, music, controllers, vibration, backups |
| 0.2.0 "Archives n' Cheats" | FAILED to compile | an experimental pager API broke the build; the pager was removed later |
| 0.3.0–0.3.2 | never compiled | intermediate code states |
| 0.3.3 "Emerald Everything Plus" | compiled, tested by the user | serious bugs: ROMs "rejected" (import never saved files), mini-games crashed, sounds from nowhere, music freeze |
| 0.3.4 "Rock Solid Rings" | first attempt failed (JVM clash `setColor`), later attempts tested partly | many fixes; Flash still not working |
| 0.3.5 "Tilt & Queue" | FAILED to compile (`DrawUi.kt:420` Int vs Float) | fixed in source; code is the base of 0.3.6 |

## 0.1.0 (the first launcher)
* ✅ Libretro host for Mega Drive/Genesis with touch controls (the core idea of the app). ✅ Skins (colours, frame), shaders, background effects. ✅ Mini-games (ring runner, etc.). ✅ Music player with the user's own folder. ✅ UI sounds, volumes, vibration (launcher/game), controllers, key mapping. ✅ FPS counter, orientation, save indicator, backups. ✅ No internet permission. ✅ Presets of touch layouts.
## 0.2.0–0.3.3 (big feature waves)
* ✍/🧪 Archives: ZIP/7z/RAR4 import (RAR5 impossible with the library used). 🧪 IPS/BPS patching (works in code; needs a clearer explanation for users). 🧪 Cheats (Game Genie/Action Replay codes + known S3K codes). 🧪 Sega CD import with BIOS. 🧪 32X and GBA via optional cores. 🧪 OpenBOR via an external app (the user's OpenBOR build is 32-bit only).
* 🧪 Two-step pause menu (quick pop-up + full menu), save states with previous-save copy, rewind, fast-forward, speed up to unlimited, screen margins/corners/classic mode, FPS counters. 🧪 Touch layouts: 7 factory (11–17) + 6 user slots, gamepad/keyboard maps, combos, controller visualisation text.
* 🧪 Vibration: ~18 events, templates, presets, per-game profile (S1, S2, S3K basic/advanced), Ring Finder. Many events never fired for the user (footsteps, monitors, bosses, badniks, shields in S3) → still open.
* 🧪 Helpers: 9 characters, ~110 answers, tutorial with Tails, Help topics. 🧪 Languages: UI labels in 12 languages; long texts English only.
* 🧪 Music: playlists, favourites, equalizers, covers, notification service, headset buttons. 🧪 Logs: problems, crash notes, console capture.
## 0.3.4–0.3.5 (stabilisation + new modules)
* ✅ Import bug fixed (write call was inside a comment), mini-game crash fixed (self-calling function), scene no longer plays sounds by itself, music loads song details in the background, instant sound packs.
* ✍ DRAW tab (layers, clip, paste image, resize, export, colour picker with palettes/wheel/hex, favourites). ✍ Tilt modes 1–6, crash-safe, safe point, EMU log. ✍ Look-for-games global vs per-game. ✍ Storage page, BIOS library, "open in app", text-file import guard. ✍ Queue as a bottom sheet, mini player with swipe/peek, equalizers (9 styles + 2), sakura effect, low-power switch. ✍ Flash: diagnostics, full keyboard overlay, gamepad bindings, touchpad mode.
* 🔒 Known limits: RAR5; PlayStation touchpad; embedding DS/3DS/Saturn/Dreamcast/PSP/GC/Wii/PS2; Arabic UI (right-to-left).

## Items requested up to 0.3.5 and never finished (carried into 0.3.6; see 08 for the live status)
* ⬜ Comics/Photos/Video tabs · scene creator · recorder + karaoke · lyrics/timestamps · widgets · holiday themes · gradient/image backgrounds with crop · PNG-mask frames · per-tab presets · hack-specific vibration profiles · Flash fixes · SRB2 · universal TV APK/x86 · full translation of long texts · controller pictures · cheat macros (timed sequences) · supported-games lists for vibration/tilt · add-game category sheet.
