# 0.3.6 STATUS, RECONCILED (2026-11-21, build line `0.3.6_pre7`, code 16)
Honest note: ✅ below means CODE WRITTEN. Nothing from pre2 to pre7 has been compiled by me, and the user has run no pre5+ build yet (the pre5 build failed on a missing import, fixed in pre7). Only 0.3.3/0.3.4/0.3.5-era features were ever confirmed on a phone. 🟡 = partly. ⬜ = not done. 🔒 = out of reach.

## DONE (code written)
Fixes: A1 A3 A4 A5 A8 A9 D1 D4 · DS rewind out-of-memory · music notification stuck on pause · pre3 build errors · pre5 build error (nativeCanvas).
Game screen: Classic "show controls" · UI scale with 8 s confirm · swap sides + 8 ratios + system-bars switch · optional PAUSE button · shader for game/console/all · A/B swap (Nintendo) · rewind length 4-20 s + memory cap.
Music: ♥ favourites, queue stays open, mini-player rules (A6), headphone-unplug pause, notification with cover/seek/state, REAL-TIME equalizer, hide player bar in tab.
Look: themes Mania, Tiles, Game Jolt, itch, Neon Coast, Blue Blur, Dark Rival, Meadow Day (all with art + button shapes) · layers behind the interface by default, fit/size/position, APPLY TO ALL, UNDO · GIF in layers/backgrounds (Android 9+) · seasonal overlay · intro splash · 24 h clock.
Controls: controller setup, BY BUTTON list, layered profiles, vibration route/strength, pad lights on-screen buttons, controller focus ring (launcher).
Consoles: NES, SNES, Nintendo DS (experimental: 3 arrangements + AUTO + TABLET + touch).
Media: pictures (zoom, rotate, crop, copy), comics (zoom, tap edges, manga/scroll, reorder, counting names, replace warning), video, notes, files, recorder (level display, backing track, live preview), favourites, sorting, dates, share-to-launcher.
Vibration: sound-driven haptics for any game · RAM rules for any game · Sega CD auto-fix · cache clearing + free space.
Help: manuals (9 consoles, English), helper answers, tutorial + HELP in 12 languages, HELP order (F5/G2).

## PARTIAL
A2 (⌖ jump icon in queue) · A7 (English "Languages" line to check) · A10 (SMS/GG layout vs real pad) · A12 Flash (open-in-Ruffle, keyboard, status line done; FPS lock + haptics options + hide language key not; black screen still unconfirmed) · D2 · D11 · D13 (no N64) · E2/E4 (helper answers and console handbook not translated/illustrated) · F2 · What's new split (labels only) · media READ-IN-PLACE · scene creator/karaoke · storage charts.

## NOT DONE
Game screen: A11 Game Gear rewind colour bug · D-pad lights only pressed directions · T indicator hollow square + hide setting · separate alpha for controls and symbols · EMU/SCREEN counter colours · dead-zone map always show · auto-rotate with confirm icon · hide-mini-menu option · tilt options (glitch-only, ignore vibration, per-console) · rewind per save point · Classic mini-panel switches.
Music: search bar · sort by length · ⌖ jump icon · tempo/speed · use original files in place · same-name import confirm · custom-image equalizer.
Look: more varied skins (leaves, Horror Hills, Angel Island...) · picture preset slots (9 per category) · effect FPS + presets · particles fade · controller pictures per model with bumpers/triggers · helper background picture (F4) · click-to-play GIF on buttons.
Content: console guide BOOKS (F3/E4) with 3 depth levels · Flash/OpenBOR manuals · Pro-mode list (D5) · 6-button layout fixes (D6) · IPS/BPS explanation with example (D10) · search in games/video/comics/pictures (D9) · library pages GB/GBC/GBA + ALL CONSOLES (D12) · add-game category sheet · more guide slides.
Vibration: S3&K fixes + footsteps + optional vibration log (D7) · 6 preset slots + 5 more event sets (F6) · exact cutscene/hazard events.
Everything else: translations of all new texts (do last) · D8 re-check LOCATIONS in portrait · D3/G3 translate helper answers + HELP.
🔒 / deferred on purpose: Android TV remote pass + real TV test · x86/x86_64 builds · Nintendo 3DS, N64 · touchpad/gyro/lightbar/adaptive triggers.

## Suggested order for the next batches
1) Verify pre7 on a phone (compile, Flash, DS, Sega CD). 2) Cheap UI items: D12 library pages, What's new grouping, D-pad lights, T indicator, alpha split, counters, search bars, sort by length. 3) Presets (F6 vibration slots, picture slots). 4) Big: console books, controller pictures, READ IN PLACE. 5) Translations. 6) TV / x86.

## Update 0.3.6_pre16 / Super_0.1_exp9
See 08_CHECKLIST_0.3.6.md sections Q–T. Everything written, NOT compiled. Open: vibration events for Advance/Rush/Super forms (no verified addresses), Guide text about files, DS touch + gap on device, Flash on device.

## U. 0.3.6 release name (versionCode 26; Super_0.1_exp10 = code 10)
- ✅ DS touch screen ON/OFF (settings + mini menu). 🟡 DS touch itself unconfirmed on device (use touch test).
- ✅ Ring vibration: distinct double tick, default 70 (old 25 migrated). 🟡 unverified. Spurious buzzes explained in the tutorial (touch ticks, memory map, sound, footsteps) + VIBRATION DEBUG.
- ✅ Launcher background picture now on every theme (was NORMAL only). Tutorial pages: vibration sources, CUSTOMIZE vs THEMES, where files go, what is new.
- ⬜ Still open from the 0.3.6 plan: GG rewind colours, D-pad lights, T indicator, opacity split, picture presets, tempo, search in video/comics/pictures; Advance/Rush/Super-form vibration; Flash keyboard choice; Flash on-device checks.

## V. 0.3.6 build 2
- ✅ Vibration profile: live check + verdict + ▶ FEEL per event. ✅ Search by name in pictures / video / recordings (comics ⬜).
- ⬜ Vibration NOT verified per game (no ROMs available to Claude, no emulator): Sonic CD, GG Sonics, Rush, hacks = sound only until addresses are verified on a device with the RAM finder.

## W. Volume split (0.3.6)
- ✅ Music + menu sounds: separate LAUNCHER / IN-GAME volumes (keys volMusic/volMusicG, volUi/volUiG, migration flag volSplit), "in use now" lines, SET buttons. Game audio (volGame) stays single. Written, not compiled.
- ⬜ TRANSLATION of this version: 1097 new English strings extracted to /tmp/trl; part A done for all 12 languages, part B only zh; sub-agents hit the rate limit. Next: finish part B, merge into assets/i18n_long.json (key = English text).

## X. Translation of 0.3.6 — DONE (written, not compiled)
- ✅ 1097 new UI strings translated into all 12 languages (es fr de pt ru uk ja zh it ko hi tr) and merged into assets/i18n_long.json (key = English text, row = 12 values in that order). Placeholders checked, no empty entries. Quality NOT reviewed by a native speaker.
- Not covered: strings built with $ templates, AboutUi changelog, CrashKB/Assistant data (as before).

## Y. Batch of Nov 27 (written, NOT compiled, nothing tried on device)
- Comics: detail page (cover/title/buttons/list, each hideable), START/CONTINUE/INCOGNITO, big tap zones + tap flash. "Chapters" are really pages. Status filters (unread/reading/finished) still open.
- GIF animated (ImageDecoder, Android 9+), tap start/stop, badge, off switch, quality (downscale).
- Flash pauses on screen lock (flashPauseLock, default on).
- Rotation: Auto/lock/flip + "ask" (⟳ ROTATE overlay, Orient.installAsk) for games+Flash+settings; launcher (MainActivity) NOT wired.
- Rewind freeze when ring empty (rewindFreeze). DS rewind cause unknown: need device log.
- Controller setup: PadLive (sticks + real dead zone, L2/R2, held buttons). Right stick/L2/R2 not bindable.
- Mini menu music row split (REPEAT overflow fixed). Recordings equalizer: REAL/SIM/OFF, frame ticker.
- TODO: translate new English strings of this batch into 12 languages; zip names SonicForge_<ver>[_PreN].zip / SonicForgeSuper_<ver>[_N].zip.

## Z. Batch of Nov 27 (2) (written, NOT compiled)
- Logs dialog: FlowRow + scroll + wide dialog. UiScale per orientation (uiScaleSep/uiScaleL/uiScaleP, RESET). DS side-by-side + swap drawn in GlView (core always top/bottom; Ds.touchUV maps the stylus). Controls editor: multi-select, groups, G1-G3 (ctrlGrp1..3). Flash favicon notice hidden.
- Open: DS rewind cause; translation of new strings; comics status filters; R-stick/L2/R2 bindings; launcher rotation prompt.
