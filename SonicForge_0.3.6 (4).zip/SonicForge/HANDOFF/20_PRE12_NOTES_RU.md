# 20 — pre12 / exp5 (написано, не скомпилировано)
Из лога 23.11 (classic, 10:26): Flash — страница замирает после "Loading SWF" (таймер 9 с не сработал → поток страницы завис, вероятно wgpu-webgl); DS — кадр чисто белый на 600-м кадре (FreeBIOS + JIT); Sonic CD — BIOS и диск (.chd) грузятся, регион AUTO; core option RAM CART пути нет.
Сделано: Logger.recent (48 ч), DS gap/JIT/inset/stylus (Initial pass), Flash renderer chain+watchdog+новый WebView, SegaCd.useAltCore (PicoDrive), правила Mario SMB3/SMW, TileMenu = classic, VideoPlayer.kt + VideoThumb.
Не сделано: RAM-карты Sonic Advance/Battle/Yoshi's Island (нет проверенных адресов; mGBA system RAM может быть EWRAM), BIOS-ссылки (не даём).
