package com.sonicforge.ui

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.PackageManager
import android.os.Process
import android.view.KeyEvent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonicforge.audio.Music
import com.sonicforge.audio.MusicService
import com.sonicforge.audio.Sfx
import com.sonicforge.data.Library
import com.sonicforge.data.SaveEvent
import com.sonicforge.data.Store
import com.sonicforge.input.Act
import com.sonicforge.input.Pads
import java.io.File

val ORIENT_OPTS = listOf("auto" to "Auto", "landscape" to "Landscape", "landscape_rev" to "Landscape ⟲", "portrait" to "Portrait", "portrait_rev" to "Portrait ⟲")
val IMM_OPTS = listOf("full" to "Hide all", "status" to "Hide status bar", "nav" to "Hide nav bar", "off" to "Off")
private fun Context.findActivity(): Activity? { var c: Context = this; while (c is ContextWrapper) { if (c is Activity) return c; c = c.baseContext }; return null }

@Composable
fun SettingsScreen() {
    var tab by remember { mutableStateOf("general") }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("general" to "GENERAL", "screen" to "SCREEN & LOOK", "position" to "SCREEN POSITION", "sound" to "SOUND & MUSIC", "haptics" to "VIBRATION", "controls" to "CONTROLS", "data" to "DATA & PRIVACY", "about" to "ABOUT & UPDATES")
                .forEach { (k, n) -> Btn(n, selected = tab == k) { tab = k } }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 14.dp)) {
            when (tab) {
                "general" -> GeneralTab()
                "screen" -> { UiModePicker(); UiScalePanel(); Spacer(Modifier.height(16.dp)); SplashSettings(); Spacer(Modifier.height(16.dp)); VideoTab(); Spacer(Modifier.height(16.dp)); H("Look of the launcher, app icon and skins"); AppearanceTab() }
                "position" -> PositionTab()
                "sound" -> { AudioTab(); Spacer(Modifier.height(16.dp)); H("Menu sounds"); SoundTab() }
                "haptics" -> { HapticsPanel(false); AudioHapticsPanel(); VibRulesEditor() }
                "controls" -> ControlsTab()
                "data" -> { DataTab(); StorageTools() }
                else -> { SToggle("ENGINE LOG strip (what the launcher and emulators are doing)", "engineLog", EngineLog.defaultOn, "Shown over the launcher and over games. 3 quick taps fold it, a long press closes it; this switch brings it back."); AboutTab(); Spacer(Modifier.height(16.dp)); UpdatesTab() }
            }
            Spacer(Modifier.height(40.dp))
        }
    }
}

@Composable private fun GeneralTab() {
    val ctx = LocalContext.current; val confirm = rememberConfirm(); var pick by remember { mutableStateOf<String?>(null) }
    H("🌐 " + I18n.tr("Language"))
    androidx.compose.material3.Text("Languages", color = Color(0xE6FFFFFF), fontSize = 11.sp)   // always English, so the language switch can be found in any language
    SChips("🌐", "lang", "auto", I18n.languages)
    Text("Buttons, tabs and settings are translated; long help texts, tips and helper dialogues are English for now. Translations may be inaccurate, and for languages with very different word lengths or scripts the layout can look different or slightly cramped.", color = Color(0xE6FFFFFF), fontSize = 11.sp)
    H("Bring the game screen back")
    Text("If you hid the touch buttons/frame inside a game (UI HIDDEN, Classic mode) and can't find them again, press this. It affects the game screens, not the launcher.", color = Color(0xCCFFFFFF), fontSize = 12.sp)
    Btn("SHOW GAME CONTROLS AND UI AGAIN") { Store.setB("hideTouch", false); Store.set("classic", "0"); Store.events.tryEmit(com.sonicforge.data.SaveEvent("Game controls and frame will be visible again the next time a game opens", true)) }
    H("Mode: Classic or Pro")
    SToggle("Pro mode", "proMode", false, "Classic (default) hides advanced tools so nothing important is changed by accident. Pro shows them.")
    Text("HIDDEN in Classic: screen margins/corners/position, background effects, rewind & fast-forward options, controller combos/visual/opacity modes, experimental-features switch, glitch tool and Ring Finder in the game menu. WHY: these are powerful and rarely needed; they exist for experienced players and for odd phones (notches, rounded corners) or special games. Nothing is removed: switch Pro on any time.", color = Color(0xCCFFFFFF), fontSize = 11.sp)
    H("Confirmations")
    Text("Important actions ask “Are you sure?”, underline what will and won't happen, and unlock their button after a short delay.", color = Color(0xE6FFFFFF), fontSize = 11.sp)
    SChips("Ask before important changes", "confirmMode", "3", listOf("3" to "Yes, 3 s delay", "5" to "Yes, 5 s delay", "off" to "No"))
    H("External apps")
    Text("Use apps you already have instead of the built-in ones where SonicForge opens folders or text files.", color = Color(0xE6FFFFFF), fontSize = 11.sp)
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { Btn("FILE MANAGER: " + ExternalApps.label(ctx, "extFm")) { pick = "extFm" }; Btn("TEXT EDITOR: " + ExternalApps.label(ctx, "extEdit")) { pick = "extEdit" } }
    pick?.let { k -> AppPicker(k) { pick = null } }
    H("Help")
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { Btn("OPEN GUIDE") { Guide.show = true }; Btn("SHOW CONTROLS & UI AGAIN") { Store.setB("hideTouch", false); Store.setB("uiHidden", false); Store.set("classic", "0") } }
    if (Store.b("proMode", false)) H("Experimental features")
    if (Store.b("proMode", false)) SToggle("Allow experimental features", "experiments", true, "Sega CD, 32X, GBA, tilt/glitch mode, footstep and advanced vibration events, OpenBOR link, app icon switching. Switch off if something misbehaves: those features are then hidden or disabled.")
    H("Close")
    Text("Closing the app normally leaves music playing if the notification is on. This button stops everything (music, notification, background work) and exits.", color = Color(0xE6FFFFFF), fontSize = 11.sp)
    Btn("CLOSE APP COMPLETELY", color = Color(0xFFE53935)) { confirm.ask("Close the app completely?", "stop the music, the notification and everything running in the background, then exit", "delete any of your data or settings", true) { Music.stop(); MusicService.stop(ctx); ctx.findActivity()?.finishAffinity(); Process.killProcess(Process.myPid()) } }
    confirm.Host()
}

@Composable private fun VideoTab() {
    val pro = Store.b("proMode", false)
    H("Look for games")
    SChips("Which look do games use?", "lookMode", "global", listOf("global" to "My own set (default)", "perGame" to "Each game's own set"))
    Text("My own set: the shader, skin, border and background effect you choose in CUSTOMIZE stay the same in every game, all day. Each game's own set: a game that has its own shader or skin uses it (you can still change it per game). You can switch whenever you like; nothing is lost.", color = Color(0xCCFFFFFF), fontSize = 12.sp)
    H("Speed (how fast the GAME runs)")
    SChips("Emulation speed (FPS target)", "fps", "0", listOf("0" to "Native", "30" to "30", "45" to "45", "50" to "50", "60" to "60", "75" to "75", "90" to "90", "120" to "120", "144" to "144", "-1" to "Unlimited"))
    Text("This changes game speed (30 = slow motion, 120 = double speed). It does NOT change how smooth your display is: the picture is always redrawn at your screen's refresh rate.", color = Color(0xE6FFFFFF), fontSize = 11.sp)
    H("FPS counters")
    Text("EMU = frames per second the emulated game produced (NTSC consoles aim for 60, PAL for 50; lower means the game is lagging). SCREEN = how often your phone redrew the picture (follows your display: 60/90/120 Hz). They are different numbers on purpose.", color = Color(0xCCFFFFFF), fontSize = 11.sp)
    SToggle("Show EMU counter", "fpsEmu", true); Swatch("fpsEmuCol", 0xFF9BFF9B)
    SToggle("Show SCREEN counter", "fpsScr", false); Swatch("fpsScrCol", 0xFF80D8FF)
    H("Screen")
    SChips("Aspect", "aspect", "fit", listOf("fit" to "Original", "4:3" to "4:3", "16:9" to "16:9", "1:1" to "1:1", "stretch" to "Stretch"))
    SToggle("Classic mode (just the picture, no controls or frame)", "classic", false, "Like a console on a TV. Works with a gamepad or keyboard; tap the corner ≡ for the menu.")
    SToggle("On-screen buttons (master switch)", "padShow", true, "OFF hides the touch buttons in every mode; the two switches below only count while this one is ON.")
    SToggle("   • normal mode: show the on-screen buttons", "normalControls", true); 
    SToggle("   • classic mode: show the on-screen buttons", "classicControls", false, "Keeps the clean full picture but draws the touch buttons over it, see-through. Handy on a phone without a gamepad.")
    SSlider("Classic mode: controls opacity", "classicCtlAlpha", 45, 100)
    SChips("Classic mode size", "classicFrame", "full", listOf("small" to "Small frame", "full" to "Full height"))
    SChips("Scaling", "smooth", "0", listOf("0" to "Pixel-perfect", "1" to "Smooth (blur)"))
    if (pro) {
    H("Gameplay")
    SToggle("Rewind (hold REW)", "rewind", true, "Keeps the last few seconds of play (length below). Longer = more memory. When it is off the ⏪ button disappears from the on-screen buttons.")
    SToggle("Fast-forward (hold FF)", "ffOn", true, "When it is off the ⏩ button disappears from the on-screen buttons. The in-game menu has one button that cycles: both / rewind only / fast-forward only / both off.")
    SChips("Rewind length", "rewindSec", "12", listOf("4" to "4 s", "8" to "8 s", "12" to "12 s", "20" to "20 s", "40" to "40 s"))
    SChips("Rewind memory (big games such as Sega CD / DS keep fewer seconds in a small budget)", "rewindMb", "128", listOf("64" to "64 MB", "128" to "128 MB", "256" to "256 MB", "384" to "384 MB"))
    SToggle("Swap A and B (Nintendo-style consoles)", "abSwap", false, "For GB, GBA, NES, SNES, DS: the on-screen and pad A / B buttons trade places.")
    SChips("Fast-forward speed", "ffMult", "2", listOf("2" to "2×", "3" to "3×", "4" to "4×"))
    SToggle("6-button pad (X/Y/Z)", "sixButton", false, "Applies next time you start a game.")
    }
    H("Orientation & system bars")
    SChips("Launcher orientation", "orientLauncher", "auto", ORIENT_OPTS); SChips("Game orientation", "orientGame", "auto", ORIENT_OPTS)
    SChips("Immersive mode: game", "immGame", "full", IMM_OPTS); SChips("Immersive mode: launcher", "immLauncher", "off", IMM_OPTS)
    if (pro) {
    H("Background effects (behind the game)")
    SToggle("Low-power mode for effects (fewer, simpler particles)", "fxLite", false)
    SChips("Effect", "bgfx", "off", FX_KINDS)
    val ctx = LocalContext.current
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { Btn("MY PNG…") { Picker.pick(arrayOf("image/*")) { u -> u.firstOrNull()?.let { uri -> val f = File(Library.art, "fx-${System.currentTimeMillis()}.img"); try { ctx.contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { i.copyTo(it) } }; Store.set("bgfxPng", f.path); Store.set("bgfx", "custom") } catch (_: Exception) {} } } }
        Btn("EFFECT OVER THE GAME", selected = Store.b("bgfxOver", false)) { Store.setB("bgfxOver", !Store.b("bgfxOver", false)) } }
    Text("PNG tip: a transparent PNG about 128×128 px works best. It is drawn small, spinning and falling behind the picture.", color = Color(0xE6FFFFFF), fontSize = 11.sp)
    }
}

@Composable private fun MarginPreview() {
    androidx.compose.foundation.Canvas(Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF263238))) {
        val ph = Size(size.height * .5f, size.height * .92f); val o = Offset((size.width - ph.width) / 2, size.height * .04f)
        drawRoundRect(Color(0xFF455A64), o, ph, androidx.compose.ui.geometry.CornerRadius(Store.i("scrRadius", 0).toFloat().coerceAtLeast(14f)))
        val k = ph.width / 360f; val l = Store.i("scrLeft", 0) * k; val t = Store.i("scrTop", 0) * k; val r = Store.i("scrRight", 0) * k; val b = Store.i("scrBottom", 0) * k
        drawRoundRect(Color(0xFF9BFF9B).copy(.55f), Offset(o.x + l, o.y + t), Size((ph.width - l - r).coerceAtLeast(4f), (ph.height - t - b).coerceAtLeast(4f)), androidx.compose.ui.geometry.CornerRadius(Store.i("scrRadius", 0).toFloat()))
        drawContext.canvas.nativeCanvas.drawText("usable picture area", o.x + 12f, o.y + ph.height / 2, android.graphics.Paint().apply { color = android.graphics.Color.WHITE; textSize = 22f })
    }
}

@Composable private fun Swatch(key: String, def: Long) {
    val cur = Store.s(key).toIntOrNull() ?: def.toInt()
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(bottom = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Skins.accents.forEach { c -> val col = Color(c.toInt()); Box(Modifier.size(26.dp).clip(CircleShape).background(col).border(if (cur == c.toInt()) 3.dp else 1.dp, Color.White, CircleShape).forgeClick { Store.setI(key, c.toInt()) }) } }
}

@Composable private fun PositionTab() {
    H("Screen position")
    Text("Where the game picture sits on the screen: margins for notches and rounded corners, size and position. Applies to every game.", color = Color(0xCCFFFFFF), fontSize = 11.sp)
    Text("Adjust for notches and rounded corners (0 = none). The preview shows where the picture will sit:", color = Color.White, modifier = Modifier.padding(top = 6.dp))
    MarginPreview()
    SSlider("Top margin", "scrTop", 0, 120, " dp"); SSlider("Bottom margin", "scrBottom", 0, 120, " dp"); SSlider("Left margin", "scrLeft", 0, 120, " dp"); SSlider("Right margin", "scrRight", 0, 120, " dp")
    SSlider("Corner roundness", "scrRadius", 0, 60, " dp"); SSlider("Size", "scrScale", 100, 100, "%"); SSlider("Horizontal position (50 = centre)", "scrOffX", 50, 100, ""); SSlider("Vertical position (50 = centre)", "scrOffY", 50, 100, "")
    Btn("RESET SCREEN ADJUSTMENTS") { listOf("scrTop", "scrBottom", "scrLeft", "scrRight", "scrRadius", "scrScale", "scrOffX", "scrOffY").forEach { Store.set(it, "") } }
}

@Composable private fun AudioTab() {
    LaunchedEffect(Store.i("volMusic", 100), Store.i("volMusicG", 100)) { Music.applyVolume() }
    H("Volumes (independent, default 100%)")
    VolPair("Music", "volMusic", "volMusicG", onChange = { Music.applyVolume() }); VolSlider("Game audio (emulator sound)", "volGame"); VolPair("Menu sounds", "volUi", "volUiG", max = 100)
    Text("Music and menu sounds have two values: one used in the launcher, one used while a game is open. Changing one never changes the other, unless you press a SET button. Above 100% uses Android's loudness enhancer and can distort. The in-game menu shows the same sliders; 'Music' there is the launcher's music player.", color = Color(0xE6FFFFFF), fontSize = 11.sp)
    H("Music in game")
    SChips("When a game starts", "musicInGame", "pause", listOf("pause" to "Pause, resume after", "keep" to "Keep playing", "play" to "Play my playlist"))
    H("Background playback")
    SToggle("Music notification & background playback", "musicNotif", true, "Keeps music playing with other apps, shows controls, and lets headphone buttons work (1 press play/pause, 2 next, 3 restart/previous). Android 13+ asks for notification permission.")
    SToggle("Album picture in the notification", "notifCover", true, "Shows the cover behind / beside the title in the notification and lock screen. Off = no picture (the controls and the seek bar stay).")
}

@Composable private fun SoundTab() {
    val ctx = LocalContext.current
    H("Sound pack")
    SChips("Menu sounds", "sfxPack", "chip", Sfx.packs.map { it.first to it.second })
    Text("A new pack works immediately, no confirmation needed. Tap to hear it:", color = Color(0xE6FFFFFF), fontSize = 11.sp)
    Btn("▶ HEAR THIS PACK") { Sfx.play("confirm") }
    H("Your own sounds")
    Text("Each event can use any short audio file instead of the pack.", color = Color(0xE6FFFFFF), fontSize = 11.sp)
    Sfx.events.forEach { ev ->
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Column(Modifier.weight(1f)) { Text(ev.uppercase(), color = Color.White, fontWeight = FontWeight.Bold); Text(if (Store.s("sfx_$ev").isEmpty()) "from the pack" else "custom", color = Color(0xE6FFFFFF), fontSize = 11.sp) }
            Btn("▶") { Sfx.play(ev) }; Btn("CHOOSE") { Picker.pick(arrayOf("audio/*")) { u -> u.firstOrNull()?.let { Sfx.setCustom(ctx, ev, it) } } }; Btn("RESET") { Sfx.reset(ev) }
        }
    }
}

private val ICONS = listOf("IconDefault" to "SonicForge (emerald)", "IconCalc" to "Calculator", "IconNotes" to "Notes", "IconRing" to "Gold ring", "IconLauncher" to "Launcher", "IconCollection" to "Collection", "IconMusic" to "Music", "IconPad" to "Gamepad", "IconClock" to "Clock")
@Composable private fun AppearanceTab() {
    val ctx = LocalContext.current
    H("App icon & name (experimental)")
    Text("Changes the launcher icon and name. No restart of the phone is needed; some home screens take a few seconds, and a few need the app closed. Needs Android 8.0+ (same as the app). Your data is not affected.", color = Color(0xCCFFFFFF), fontSize = 12.sp)
    if (!Store.b("experiments", true)) { Text("Turn on experimental features in GENERAL to use this.", color = Color(0xFFFFB74D)); return }
    val cur = Store.s("appIcon", "IconDefault")
    ICONS.forEach { (n, label) -> Btn(label + if (cur == n) "  ✓" else "", Modifier.fillMaxWidth().padding(vertical = 2.dp), selected = cur == n) {
        try { val pm = ctx.packageManager
            ICONS.forEach { (a, _) -> pm.setComponentEnabledSetting(ComponentName(ctx.packageName, "com.sonicforge.$a"), if (a == n) PackageManager.COMPONENT_ENABLED_STATE_ENABLED else PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP) }
            Store.set("appIcon", n) } catch (e: Exception) { Store.events.tryEmit(SaveEvent("Could not switch the icon", false)) } } }
}

@Composable private fun DataTab() {
    H("Storage used by SonicForge")
    StorageBreakdown()
    val ctx = LocalContext.current
    val net = remember { try { ctx.packageManager.getPackageInfo(ctx.packageName, PackageManager.GET_PERMISSIONS).requestedPermissions?.contains("android.permission.INTERNET") == true } catch (_: Exception) { false } }
    H("Recent games")
    Text("Every game you start (Mega Drive, NES, SNES, GBA, DS, Flash ...) is added to the Recent list. Switch a console off to keep it out of the list; hide a single game with ⋯ ▸ NEVER SHOW THIS GAME IN RECENT (a 🙈 marks hidden games), or in the game's own menu.", color = Color(0xCCFFFFFF), fontSize = 11.sp)
    listOf("md" to "Mega Drive / Master System / Game Gear", "scd" to "Sega CD", "x32" to "32X", "gba" to "Game Boy / GBA", "nes" to "NES", "snes" to "SNES", "nds" to "Nintendo DS", "bor" to "OpenBOR", "flash" to "Flash").forEach { (k, n) -> SToggle("Show $n games in Recent", "recentShow_$k", true) }
    Btn("CLEAR THE RECENT LIST") { com.sonicforge.data.Recents.clear() }
    H("Privacy")
    Text(if (!net) "✓ This app does NOT declare the INTERNET permission. It cannot go online." else "✗ INTERNET permission present!", color = if (!net) Color(0xFF69F0AE) else Color(0xFFFF5252), fontWeight = FontWeight.Bold)
    BackupSection()
    H("Storage")
    Text("Games: ${Library.roms.size}   ·   save files: ${File(ctx.filesDir, "saves").listFiles()?.size ?: 0}. All folders are listed in the LOCATIONS tab.", color = Color.White, fontSize = 12.sp)
    Btn("RUN STORAGE SELF-TEST", Modifier.padding(top = 8.dp)) { Store.events.tryEmit(SaveEvent("Storage self-test", Store.writeVerified("selftest.json", "{\"t\":${System.currentTimeMillis()}}"))) }
}

// ---------------- controls ----------------
@Composable private fun ControlsTab() {
    var sub by remember { mutableStateOf("setup") }
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("setup" to "CONTROLLER & KEYS", "flash" to "FLASH KEYS", "opacity" to "TOUCH OPACITY").filter { Store.b("proMode", false) || it.first == "setup" || it.first == "flash" }.forEach { (k, n) -> Btn(n, selected = sub == k) { sub = k } } }
    if (sub == "setup") ControllerSetup() else if (sub == "flash") FlashKeySetup() else OpacityEditor()
}

@Composable private fun OpacityEditor() {
    H("Touch button opacity")
    SToggle("Symbols follow the buttons (linked)", "symLink", true, "On: letters and arrows get the same transparency as the buttons. Off: they have their own slider.")
    if (!Store.b("symLink", true)) SSlider("Symbol opacity (letters, arrows, stick)", "symAlpha", 100)
    SChips("Apply opacity to", "opMode", "layout", listOf("layout" to "Each layout's own", "all" to "All orientations together", "pairs" to "Portrait pair / landscape pair"))
    when (Store.s("opMode", "layout")) {
        "all" -> SSlider("All orientations", "opAll", 75)
        "pairs" -> { SSlider("Portrait and upside-down portrait", "opPortPair", 75); SSlider("Landscape and upside-down landscape", "opLandPair", 75) }
        else -> Text("Each layout uses its own opacity (set in CUSTOMIZE ▸ CONTROLS).", color = Color(0xE6FFFFFF), fontSize = 11.sp)
    }
}

/** where the phone's storage goes: games, music, saves, logs, caches... (counted in the background) */
@Composable private fun StorageBreakdown() {
    val ctx = LocalContext.current; var rows by remember { mutableStateOf<List<Triple<String, Long, String>>>(emptyList()) }; var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(tick) {
        rows = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            fun size(f: java.io.File?): Long = if (f == null || !f.exists()) 0L else f.walkTopDown().filter { it.isFile }.sumOf { it.length() }
            val fd = ctx.filesDir
            listOf(Triple("Games (ROMs, discs, flash)", size(java.io.File(fd, "roms")), "the games you imported"),
                Triple("Saves and save states", size(java.io.File(fd, "saves")), "game saves, states and the previous-save copies"),
                Triple("Music", size(java.io.File(fd, "music")) + size(ctx.getExternalFilesDir(null)?.let { java.io.File(it, "music") }), "imported songs and the built-in test tunes"),
                Triple("Pictures", size(java.io.File(fd, "art")), "covers, logos and backgrounds"),
                Triple("Drawings", size(java.io.File(fd, "draw")), "your drawing layers"),
                Triple("BIOS and system files", size(java.io.File(fd, "system")), "Sega CD BIOS and the BIOS library"),
                Triple("Settings and presets", size(java.io.File(fd, "data")), "settings, layouts, vibration presets, playlists"),
                Triple("Logs", size(java.io.File(fd, "logs")), "problems, notices and emulator logs"),
                Triple("Menu sounds", size(java.io.File(fd, "sounds")), "generated and custom menu sounds"),
                Triple("Temporary cache", size(ctx.cacheDir), "safe to clear; it is rebuilt when needed"))
        }
    }
    fun fmt(b: Long) = if (b < 1048576) "${b / 1024} KB" else "%.1f MB".format(b / 1048576.0)
    Column(Modifier.fillMaxWidth()) {
        if (rows.isEmpty()) Text("Counting…", fontSize = 12.sp)
        val total = rows.sumOf { it.second }
        if (rows.isNotEmpty()) Text("Total: ${fmt(total)}", fontWeight = FontWeight.Bold, color = Skins.current().accent)
        rows.forEach { (n, b, d) -> Column(Modifier.padding(vertical = 3.dp)) { Row { Text(n, fontSize = 13.sp, modifier = Modifier.weight(1f)); Text(fmt(b), fontSize = 13.sp, fontWeight = FontWeight.Bold) }; Text(d, fontSize = 11.sp, color = Color(0xDDFFFFFF)) } }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 4.dp)) {
            Btn("RECOUNT") { tick++ }
            Btn("CLEAR CACHE") { ctx.cacheDir.listFiles()?.forEach { it.deleteRecursively() }; com.sonicforge.data.Logger.notice("Temporary cache cleared"); tick++ }
        }
    }
}
