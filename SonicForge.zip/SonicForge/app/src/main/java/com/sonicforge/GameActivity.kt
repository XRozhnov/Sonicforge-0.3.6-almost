package com.sonicforge

import android.os.Build
import android.os.Bundle
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.sonicforge.audio.Music
import com.sonicforge.core.*
import com.sonicforge.data.*
import com.sonicforge.input.Act
import com.sonicforge.input.Haptics
import com.sonicforge.input.Pads
import com.sonicforge.input.Profiles
import com.sonicforge.ui.*
import kotlinx.coroutines.delay

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
class GameActivity : ComponentActivity() {
    private var session: EmuSession? = null
    private var glRef by mutableStateOf<EmuGlView?>(null)
    private val keys = mutableSetOf<Act>()
    private var axisMask = 0
    private var touchMask = 0
    private var menu by mutableIntStateOf(0)          // 0 closed, 1 quick pop-up, 2 full menu
    private var tilt by mutableIntStateOf(0)
    private var touchLock by mutableStateOf(false)
    private var awake by mutableStateOf(true)
    private var uiState by mutableIntStateOf(0)   // 0 visible, 1 hidden, 2 hidden but still touchable
    private var barHidden by mutableStateOf(false)
    private var opQuick by mutableIntStateOf(0)
    private var padVisIds by mutableStateOf(setOf<String>())     // physical-controller presses mirrored on the screen buttons
    private var padVisDirs by mutableIntStateOf(0)

    private fun bit(a: Act): Int = Systems.bit(PadSys.current, when (a) { Act.UP, Act.DOWN, Act.LEFT, Act.RIGHT -> "-"; else -> a.name }).let { b ->
        if (b != 0) b else when (a) { Act.UP -> Bits.UP; Act.DOWN -> Bits.DOWN; Act.LEFT -> Bits.LEFT; Act.RIGHT -> Bits.RIGHT; else -> 0 } }
    private fun push() {
        var m = 0; keys.forEach { m = m or bit(it) }; session?.inputMask = m or axisMask or touchMask
        val ids = HashSet<String>(); var d = axisMask and (Bits.UP or Bits.DOWN or Bits.LEFT or Bits.RIGHT)
        keys.forEach { a -> when (a) { Act.UP -> d = d or Bits.UP; Act.DOWN -> d = d or Bits.DOWN; Act.LEFT -> d = d or Bits.LEFT; Act.RIGHT -> d = d or Bits.RIGHT; else -> ids.add(a.name) } }
        session?.let { if (it.turbo) ids.add("FF"); if (it.rewinding) ids.add("REW") }
        if (ids != padVisIds) padVisIds = ids; if (d != padVisDirs) padVisDirs = d
    }
    private fun openMenu(level: Int) { menu = level; session?.paused = level != 0; if (level != 0) Haptics.ui() }
    private fun slot() = Store.i("quickSlot", 1)
    private fun applyBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        when (Store.s("immGame", "full")) { "full" -> c.hide(WindowInsetsCompat.Type.systemBars()); "status" -> { c.hide(WindowInsetsCompat.Type.statusBars()); c.show(WindowInsetsCompat.Type.navigationBars()) }
            "nav" -> { c.hide(WindowInsetsCompat.Type.navigationBars()); c.show(WindowInsetsCompat.Type.statusBars()) }; else -> c.show(WindowInsetsCompat.Type.systemBars()) }
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        applyBars()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) window.attributes.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        requestedOrientation = Orient.flag(Store.s("orientGame", "auto"))
        val rom = Library.roms.firstOrNull { it.id == intent.getStringExtra("rom") }
        if (rom == null) { finish(); return }
        UiMode.inGame = true; PadSys.current = rom.sys; Haptics.currentGame = rom.id; Profiles.emu = rom.sys; Profiles.game = rom.id
        val s = EmuSession(this, rom)
        if (!s.start()) { Toast.makeText(this, s.error, Toast.LENGTH_LONG).show(); finish(); return }
        session = s; s.onEvent = { Haptics.game(it) }
        if (rom.slot != 0) PadLayouts.loadSlot(rom.slot)
        Music.gameStart(rom.track)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) { override fun handleOnBackPressed() { openMenu(if (menu == 0) 1 else 0) } })
        setContent { val skin = Skins.current(); ForgeTheme(skin) { GameScreen(s) } }
    }

    private fun rotation(): Int = @Suppress("DEPRECATION") windowManager.defaultDisplay.rotation   // 0 portrait, 1 landscape, 2 portrait flipped, 3 landscape flipped

    @Composable
    private fun GameScreen(s: EmuSession) {
        val rom = Library.roms.firstOrNull { it.id == s.rom.id } ?: s.rom
        val perGame = Store.s("lookMode", "global") == "perGame"   // global (default): my own set for every game
        val base = (if (perGame) rom.skin else "").takeIf { it.isNotEmpty() }?.let { id -> Skins.all.firstOrNull { it.id == id } } ?: Skins.current()
        val shaderId = if (perGame) rom.shader.ifEmpty { Store.s("shader", "none") } else Store.s("shader", "none")   // tilting never forces a shader
        val skin = base.copy(shader = shaderId)
        val cfg = LocalConfiguration.current; val land = cfg.screenWidthDp > cfg.screenHeightDp
        var fps by remember { mutableIntStateOf(0) }; var sfps by remember { mutableIntStateOf(0) }
        LaunchedEffect(Unit) { while (true) { fps = s.measuredFps; sfps = glRef?.renderFps() ?: 0; delay(400) } }
        LaunchedEffect(Store.s("fps", "0")) { s.targetFps = Store.i("fps", 0).toDouble() }
        LaunchedEffect(Store.i("volGame", 100), Store.i("volMusic", 100)) { s.applyVolume(); Music.applyVolume() }
        LaunchedEffect(shaderId, glRef) { glRef?.setShader(shaderId) }
        LaunchedEffect(tilt) { s.tilt = tilt }
        LaunchedEffect(Store.s("cheats_${rom.id}", "1"), rom.cheats) { s.applyCheats() }
        LaunchedEffect(awake) { if (awake) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
        val smooth = Store.b("smooth", false)
        LaunchedEffect(smooth, glRef) { glRef?.setSmooth(smooth) }
        val padBg = rememberBitmap(Store.s("padBg").ifEmpty { null }); val fxPng = rememberBitmap(Store.s("bgfxPng").ifEmpty { null })
        val hideTouch = (Pads.devices.isNotEmpty() && Store.b("hideTouch", true)) || uiState == 1
        val classic = Store.b("classic", false)
        val classicCtl = classic && Store.b("classicControls", false)   // classic picture + on-screen controls drawn over it
        val showTouchUi = !classic || classicCtl
        val aspectMode = Store.s("aspect", "fit")
        val ar0 = aspectMode.split(":").let { p -> val a = p.getOrNull(0)?.toFloatOrNull(); val b = p.getOrNull(1)?.toFloatOrNull(); if (a != null && b != null && b > 0f) a / b else s.aspect }
        val ar = if (Store.b("aspectSwap", false)) 1f / ar0 else ar0
        val immNow = Store.s("immGame", "full"); LaunchedEffect(immNow) { applyBars() }
        var pausedUi by remember { mutableStateOf(false) }; var moreRatios by remember { mutableStateOf(false) }
        val layout = if ((rom.sys == "gba" || rom.sys == "gb" || rom.sys == "nes") && rom.slot == 0) Factory.build(17) else PadLayouts.active
        val alpha = when (opQuick) { 1 -> 1f; 2 -> .75f; 3 -> .4f; 4 -> .2f; else -> PadLayouts.opacityFor(rotation(), layout.opacity) }
        val fx = Store.s("bgfx", "off"); val fxOver = Store.b("bgfxOver", false)

        Box(Modifier.fillMaxSize().skinBg(skin)) {
            if (padBg != null && !classic) { Image(padBg, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop); Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = Store.i("padDim", 40) / 100f))) }
            if (classic) Box(Modifier.fillMaxSize().background(Color.Black)) else { if (padBg == null && UiMode.id() != "normal") { ThemeBackdrop(UiMode.id()); StyleLayer("bg", UiMode.id(), false) }; Particles(skin.deco); if (!fxOver) FxLayer(fx, fxPng) }
            val ins = Modifier.fillMaxSize().then(if (!land && Store.b("belowStatus", true)) Modifier.windowInsetsPadding(WindowInsets.statusBarsIgnoringVisibility) else Modifier).padding(start = Store.i("scrLeft", 0).dp, top = Store.i("scrTop", 0).dp, end = Store.i("scrRight", 0).dp, bottom = Store.i("scrBottom", 0).dp)
            Box(ins) {
                val sc = (Store.i("scrScale", 100) / 100f).coerceIn(.5f, 1f)
                val ox = ((Store.i("scrOffX", 50) - 50) / 50f * 60).dp; val oy = ((Store.i("scrOffY", 50) - 50) / 50f * 60).dp
                val gm = when {
                    aspectMode == "stretch" -> Modifier.fillMaxSize(sc)
                    classic && Store.s("classicFrame", "full") == "full" -> Modifier.align(Alignment.Center).fillMaxHeight(sc).aspectRatio(ar)
                    land -> Modifier.align(Alignment.Center).fillMaxHeight(.96f * sc).aspectRatio(ar)
                    else -> Modifier.align(Alignment.TopCenter).fillMaxWidth(sc).aspectRatio(ar)
                }
                val frameMod = if (classic) Modifier else Modifier.padding(8.dp).clip(RoundedCornerShape(skin.radius.dp)).skinBorder(skin)
                Box(gm.offset(ox, oy).then(frameMod)) {
                    AndroidView(factory = { c -> EmuGlView(c).also { glRef = it } }, modifier = Modifier.fillMaxSize())
                    if (rom.sys == "nds" && menu == 0) DsTouchPad()
                    if (fxOver) FxLayer(fx, fxPng)
                }
            }
            val rad = Store.i("scrRadius", 0)
            if (rad > 0) androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {   // paints the screen corners in the skin colour so the picture follows a rounded phone display
                val r = rad.dp.toPx(); val p = Path().apply { fillType = PathFillType.EvenOdd; addRect(androidx.compose.ui.geometry.Rect(0f, 0f, size.width, size.height)); addRoundRect(androidx.compose.ui.geometry.RoundRect(0f, 0f, size.width, size.height, CornerRadius(r))) }
                drawPath(p, Brush.verticalGradient(listOf(skin.bgTop, skin.bgBot))) }
            if (showTouchUi && !hideTouch && menu == 0) ControlsOverlay(layout, land, onMask = { touchMask = it; push() },
                onAction = { when (it) { "SAVE" -> s.saveState(slot()); "LOAD" -> s.loadState(slot()); "MENU" -> openMenu(1) } },
                onHeld = { s.turbo = "FF" in it; s.rewinding = "REW" in it }, opacity = if (uiState == 2) .02f else if (classicCtl) Store.i("classicCtlAlpha", 45) / 100f else alpha,
                extPressed = padVisIds, extDirs = padVisDirs)
            else if (showTouchUi && uiState == 0 && menu == 0 && Pads.devices.isNotEmpty() && Store.b("padFeedback", true)) {
                // a controller hides the touch buttons: keep them drawn (not touchable) so pressed buttons visibly light up
                val busy = padVisIds.isNotEmpty() || padVisDirs != 0
                val fa = if (busy) alpha.coerceAtLeast(.6f) else if (Store.b("padFeedbackIdle", true)) alpha * .45f else 0f
                if (fa > 0f) ControlsOverlay(layout, land, opacity = fa, extPressed = padVisIds, extDirs = padVisDirs, interactive = false)
            }
            if (touchLock) Box(Modifier.fillMaxSize().pointerInput(Unit) { awaitPointerEventScope { while (true) awaitPointerEvent().changes.forEach { it.consume() } } })
            // small always-reachable bar (what each button does: pause menu ▸ GAME, and HELP)
            val edge = Modifier.then(if (!land) Modifier.windowInsetsPadding(WindowInsets.statusBarsIgnoringVisibility) else Modifier).padding(top = Store.i("scrTop", 0).dp, end = Store.i("scrRight", 0).dp)
            val chipBg = Modifier.background(Color(0x66000000), RoundedCornerShape(20.dp))
            if (classic) { if (!Store.b("hideMenuBtn", false)) Chip("≡", true, Modifier.align(Alignment.TopEnd).then(edge).padding(6.dp).then(chipBg)) { openMenu(1) } }
            else if (barHidden) Chip("◂", true, Modifier.align(Alignment.TopEnd).then(edge).padding(6.dp).then(chipBg)) { barHidden = false }
            else Row(Modifier.align(Alignment.TopEnd).then(edge).padding(6.dp).then(chipBg).padding(horizontal = 4.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                Chip("≡", true) { openMenu(1) }
                if (Store.b("pauseBtn", false)) Chip(if (pausedUi) "▶" else "⏸", pausedUi) { pausedUi = !pausedUi; s.paused = pausedUi }
                Chip(if (touchLock) "🔒 LOCKED" else "🔓 LOCK", touchLock) { touchLock = !touchLock }
                Chip(if (awake) "☀ AWAKE" else "☾ AUTO", awake) { awake = !awake }
                Chip("α " + listOf("SAVED", "100", "75", "40", "20")[opQuick], opQuick != 0) { opQuick = (opQuick + 1) % 5 }
                Chip(listOf("UI", "UI HIDDEN", "UI GHOST")[uiState], uiState == 0) { uiState = (uiState + 1) % 3 }
                if (tilt > 0) Chip("● T$tilt", true, Modifier.background(Color(TILT_COLORS[tilt]), RoundedCornerShape(10.dp))) { openMenu(2) }
                Chip("▸", true) { barHidden = true }
            }
            Column(Modifier.align(Alignment.TopStart).padding(8.dp)) {
                if (Store.b("fpsEmu", true) && Store.b("fpsEmuShow", Store.b("fpsEmu", true))) Text("EMU $fps", color = Color(Store.s("fpsEmuCol").toIntOrNull() ?: 0xFF9BFF9B.toInt()), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.background(Color(0x99000000), RoundedCornerShape(6.dp)).padding(horizontal = 6.dp, vertical = 2.dp))
                if (Store.b("fpsScr", false)) Text("SCREEN $sfps", color = Color(Store.s("fpsScrCol").toIntOrNull() ?: 0xFF80D8FF.toInt()), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp).background(Color(0x99000000), RoundedCornerShape(6.dp)).padding(horizontal = 6.dp, vertical = 2.dp))
            }
            SaveIndicator(Modifier.align(Alignment.TopCenter).padding(10.dp))
            EngineLogStrip(Modifier.align(Alignment.BottomCenter).windowInsetsPadding(WindowInsets.navigationBars))
            if (menu == 1) QuickMenu(s, rom)
            if (menu == 2) FullMenu(s, rom, skin)
        }
    }

    @Composable private fun Chip(t: String, on: Boolean, m: Modifier = Modifier, f: () -> Unit) =
        Text(t, color = if (on) Color(0xFF9BFF9B) else Color(0xFFFFCDD2), fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = m.clip(RoundedCornerShape(14.dp)).clickable { Haptics.ui(); f() }.padding(horizontal = 7.dp, vertical = 5.dp))

    @Composable
    private fun QuickMenu(s: EmuSession, rom: Rom) {
        val skin = Skins.current()
        Box(Modifier.fillMaxSize().background(Color(0xAA000000)).clickable(enabled = false) {}, Alignment.Center) {
            Column(Modifier.widthIn(max = 420.dp).fillMaxWidth(.9f).clip(RoundedCornerShape(18.dp)).background(Color(0xF015151C)).skinBorder(skin).verticalScroll(rememberScrollState()).padding(14.dp)) {
                Text("PAUSED — ${rom.title}", color = skin.accent, fontWeight = FontWeight.Black)
                Text("The game is frozen. START is a normal game button; this menu is separate.", color = Color(0x99FFFFFF), fontSize = 10.sp)
                Row(Modifier.padding(top = 8.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Btn("▶ RESUME", selected = true) { openMenu(0) }; Btn("SAVE ${slot()}") { s.saveState(slot()) }; Btn("LOAD ${slot()}") { s.loadState(slot()); openMenu(0) }; Btn("RESET") { s.reset(); openMenu(0) } }
                Row(Modifier.padding(top = 6.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Btn("📸") { glRef?.takeShot { Shots.save(this@GameActivity, it) } }; Btn("REWIND: " + if (Store.b("rewind", true)) "ON" else "OFF", selected = Store.b("rewind", true)) { Store.setB("rewind", !Store.b("rewind", true)) }
                    Btn("CLASSIC: " + if (Store.b("classic", false)) "ON" else "OFF", selected = Store.b("classic", false)) { Store.setB("classic", !Store.b("classic", false)) } }
                H("Launcher music")
                MiniMusic()
                Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) { Btn("FULL MENU ▸", selected = true) { menu = 2 }; Btn("QUIT", color = Color(0xFFE53935)) { finish() } }
            }
        }
    }

    @Composable private fun MiniMusic() {
        val t = Music.tracks.getOrNull(Music.current)
        Text(t?.title ?: "Nothing loaded", color = Color.White, maxLines = 1, fontSize = 13.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { Btn("⏮") { Music.prev() }; Btn(if (Music.playing) "⏸" else "▶") { Music.toggle() }; Btn("⏭") { Music.next() } }
        SChips("When games start", "musicInGame", "pause", listOf("pause" to "Pause", "keep" to "Keep", "play" to "Playlist"))
    }

    @Composable
    private fun FullMenu(s: EmuSession, rom: Rom, skin: Skin) {
        var tab by remember { mutableStateOf("game") }
        var padEdit by remember { mutableStateOf(false) }
        val confirm = rememberConfirm()
        Box(Modifier.fillMaxSize().background(Color(0xDD000000)).clickable(enabled = false) {}, Alignment.Center) {
            Column(Modifier.fillMaxHeight(.95f).widthIn(max = 600.dp).fillMaxWidth(.95f).clip(RoundedCornerShape(16.dp)).background(Color(0xF015151C)).skinBorder(skin).padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) { Text(rom.title, color = skin.accent, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f), maxLines = 1); Btn("◀ BACK") { menu = 1 }; Spacer(Modifier.width(4.dp)); Btn("▶ RESUME", selected = true) { openMenu(0) } }
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    listOf("game" to "GAME", "screen" to "SCREEN", "audio" to "AUDIO", "controls" to "CONTROLS", "vib" to "VIBRATION", "cheats" to "CHEATS", "tools" to "TOOLS").filter { it.first != "tools" || Store.b("proMode", false) }.forEach { (k, n) -> Btn(n, selected = tab == k) { tab = k } } }
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                    when (tab) {
                        "game" -> {
                            H("Top-right buttons")
                            Text("≡ opens this menu · 🔒 LOCK blocks every touch (phone in a pocket); the lock stays touchable · ☀ AWAKE keeps the screen on, ☾ AUTO lets Android switch it off · α changes how see-through the on-screen buttons are (SAVED = the layout's own value, then 100/75/40/20 %) · UI cycles visible → hidden → ghost (hidden but still works) · ● T3 means Tilt is on (number = mode, colour = how severe; tap it to open this menu) · ▸ hides the bar, ◂ brings it back.", color = Color(0xCCFFFFFF), fontSize = 11.sp)
                            Btn("↻ RESET / RESTART THE EMULATOR (CONSOLE)", Modifier.padding(vertical = 6.dp), color = Color(0xFFE53935)) { confirm.ask("Reset the game?", "restart the game from the beginning", "touch your saves or save states", true) { s.reset(); openMenu(0) } }
                            H("Save states (game saves are automatic)")
                            Text("○ empty · ● has a save · ■ the most recent save", color = Color(0xAAFFFFFF), fontSize = 11.sp)
                            var tick by remember { mutableIntStateOf(0) }; @Suppress("UNUSED_VARIABLE") val tk = tick
                            for (n in 1..4) Row(Modifier.padding(vertical = 2.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                val latest = (1..4).filter { s.hasState(it) }.maxByOrNull { s.stateTime(it) }
                                Text((if (!s.hasState(n)) "○" else if (n == latest) "■" else "●") + " Slot $n" + (if (s.hasState(n)) "\n" + java.text.SimpleDateFormat("dd.MM HH:mm", java.util.Locale.getDefault()).format(java.util.Date(s.stateTime(n))) else ""), color = Color.White, fontSize = 12.sp, modifier = Modifier.width(110.dp))
                                Btn("SAVE", selected = slot() == n) { Store.setI("quickSlot", n); s.saveState(n); tick++ }; Btn("LOAD") { Store.setI("quickSlot", n); s.loadState(n); openMenu(0) }
                                if (s.hasPrev(n)) Btn("LOAD PREVIOUS SAVE") { s.restorePrevious(n) } }
                            Text("Saving over a slot keeps the previous save of that slot, so a bad save can be undone.", color = Color(0xAAFFFFFF), fontSize = 11.sp)
                            H("Speed"); SChips("Game speed (FPS target)", "fps", "0", listOf("0" to "Native", "30" to "30", "60" to "60", "90" to "90", "120" to "120", "144" to "144", "-1" to "Unlimited"))
                            SToggle("Rewind (hold REW / L1)", "rewind", true); SChips("Fast-forward", "ffMult", "2", listOf("2" to "2×", "3" to "3×", "4" to "4×"))
                            Btn("FLIP SCREEN (upside-down)", Modifier.padding(top = 6.dp)) { val cur = Store.s("orientGame", "auto"); val l = resources.configuration.screenWidthDp > resources.configuration.screenHeightDp
                                val n = Orient.flipped(if (cur == "auto") (if (l) "landscape" else "portrait") else cur); Store.set("orientGame", n); requestedOrientation = Orient.flag(n) }
                        }
                        "screen" -> {
                            SChips("Look for games", "lookMode", "global", listOf("global" to "My own set (default)", "perGame" to "Each game's own set"))
                            Text("My own set: the shader, skin and effects you chose in CUSTOMIZE stay the same in every game, all day. Each game's own set: games that have their own shader/skin use them. You can switch any time.", color = Color(0xAAFFFFFF), fontSize = 11.sp)
                            SToggle("Keep the picture below the status bar (portrait)", "belowStatus", true); SToggle("Hide the small menu button in classic mode (Back opens the menu)", "hideMenuBtn", false)
                            SChips("Aspect", "aspect", "fit", listOf("fit" to "Original", "4:3" to "4:3", "16:9" to "16:9", "1:1" to "1:1", "stretch" to "Stretch"))
                            SToggle("Swap the sides (4:3 ↔ 3:4, 16:9 ↔ 9:16 ...)", "aspectSwap", false, "Turns the ratio on its side: a wide picture becomes a tall one. Useful when you play with the phone upright.")
                            Btn(if (moreRatios) "FEWER RATIOS" else "SHOW MORE RATIOS") { moreRatios = !moreRatios }
                            if (moreRatios) SChips("More ratios", "aspect", "fit", listOf("16:10" to "16:10", "8:5" to "8:5", "5:3" to "5:3", "3:2" to "3:2", "5:4" to "5:4", "21:9" to "21:9", "7:3" to "7:3 (UWQHD 3440×1440)", "32:9" to "32:9"))
                            SChips("System bars (status / navigation)", "immGame", "full", listOf("full" to "Hide both", "status" to "Hide status bar", "nav" to "Hide navigation bar", "off" to "Show both"))
                            SToggle("Show a PAUSE button in the top bar", "pauseBtn", false, "A quick ⏸ that freezes the game without opening the menu.")
                            SToggle("Classic mode (picture only)", "classic", false); SToggle("Classic mode: show the on-screen controls", "classicControls", false); SChips("Scaling", "smooth", "0", listOf("0" to "Pixel-perfect", "1" to "Smooth"))
                            Text("Shader (see \"Shader applies to\" below)", color = Color.White, modifier = Modifier.padding(top = 6.dp))
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) { Shaders.list.forEach { sh -> Btn(sh.name, selected = skin.shader == sh.id && tilt < 2) {
                                val scope = Store.s("shaderScope", "game")
                                Library.roms.filter { r -> r.id == rom.id || (scope == "console" && r.sys == rom.sys) || scope == "all" }.forEach { r -> Library.update(r.copy(shader = sh.id)) } } } }
                            SChips("Shader applies to", "shaderScope", "game", listOf("game" to "THIS GAME", "console" to "THIS CONSOLE", "all" to "ALL CONSOLES"))
                            H("Engine log"); SToggle("ENGINE LOG strip (what the emulator is doing)", "engineLog", EngineLog.defaultOn, "3 quick taps fold it, a long press closes it; this switch brings it back."); H("FPS counters"); SToggle("EMU counter (game frames per second)", "fpsEmu", true); SToggle("SCREEN counter (display redraws per second)", "fpsScr", false)
                            Text("EMU = how many frames the game itself makes each second (60 is full speed). SCREEN = how many times your display is redrawn; if SCREEN is lower than EMU the phone is the bottleneck.", color = Color(0xCCFFFFFF), fontSize = 11.sp)
                            SChips("EMU counter colour", "fpsEmuCol", "", listOf("" to "Default", "-1" to "White", "-65536" to "Red", "-256" to "Yellow", "-16711936" to "Green", "-16711681" to "Cyan", "-65281" to "Pink"))
                            SChips("SCREEN counter colour", "fpsScrCol", "", listOf("" to "Default", "-1" to "White", "-65536" to "Red", "-256" to "Yellow", "-16711936" to "Green", "-16711681" to "Cyan", "-65281" to "Pink"))
                            H("Margins & corners"); SSlider("Top", "scrTop", 0, 120, " dp"); SSlider("Bottom", "scrBottom", 0, 120, " dp"); SSlider("Left", "scrLeft", 0, 120, " dp"); SSlider("Right", "scrRight", 0, 120, " dp"); SSlider("Corner roundness", "scrRadius", 0, 60, " dp")
                            SChips("Background effect", "bgfx", "off", FX_KINDS)
                        }
                        "audio" -> { VolSlider("Game audio", "volGame"); VolSlider("Music (the launcher's music player)", "volMusic"); MiniMusic() }
                        "controls" -> {
                            Text("Touch layout presets", color = Color.White)
                            Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                (11..17).forEach { n -> Btn("${Factory.names[n]}", selected = PadLayouts.activeSlot == n, color = PadLayouts.colorOf(n)) { PadLayouts.loadSlot(n) } } }
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) { (1..6).forEach { n -> Btn("Mine $n", selected = PadLayouts.activeSlot == n, color = PadLayouts.colorOf(n)) { PadLayouts.loadSlot(n) } } }
                            SToggle("Symbols follow the buttons' transparency (linked)", "symLink", true, "On: changing the button opacity changes the letters and arrows too. Off: set them separately below.")
                            if (!Store.b("symLink", true)) SSlider("Symbol opacity (letters, arrows, stick)", "symAlpha", 100)
                            SChips("Touch opacity (quick)", "opMode", "layout", listOf("layout" to "Layout's own", "all" to "All together", "pairs" to "Portrait/landscape pairs"))
                            SToggle("Hide touch controls while a gamepad is connected", "hideTouch", true); SToggle("Gamepad enabled", "padOn", true); SToggle("Keyboard enabled", "kbOn", true)
                            Text("Layout editor for the touch buttons: CUSTOMIZE ▸ CONTROLS.", color = Color(0xAAFFFFFF), fontSize = 11.sp)
                            Text("Controller layers for this game now: " + Profiles.chainFor(rom.sys, rom.id).joinToString(" → ") { Profiles.layerLabel(it) } + " → Factory", color = Skins.current().accent, fontSize = 11.sp)
                            Btn(if (padEdit) "HIDE CONTROLLER MAPPING" else "CONTROLLER MAPPING (this game)", selected = padEdit) { padEdit = !padEdit }
                            if (padEdit) ControllerSetup(rom)
                        }
                        "vib" -> HapticsPanel(true)
                        "cheats" -> {
                            var txt by remember { mutableStateOf(rom.cheats) }
                            H("Cheat codes")
                            Text("One cheat per line:  NAME=CODE.  Game Genie: XXXX-XXXX  (for example AWXT-CA4C).  Action Replay: XXXXXX:XXXX  (for example FFFFE0:0101). A line starting with # is a comment or a disabled cheat. Cheats are optional and only work for the matching original game.", color = Color(0xCCFFFFFF), fontSize = 12.sp)
                            OutlinedTextField(txt, { txt = it }, minLines = 4, modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp), label = { Text("Cheats") })
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { Btn("APPLY", selected = true) { Library.update(rom.copy(cheats = txt)) }
                                if (CheatDb.forRom(rom).isNotEmpty()) Btn("＋ ADD KNOWN") { txt = (txt + "\n" + CheatDb.asLines(CheatDb.forRom(rom))).trim() } }
                            SToggle("Cheats ON for this game", "cheats_${rom.id}", true)
                        }
                        else -> {
                            H("Screenshot"); Btn("📸 TAKE SCREENSHOT") { glRef?.takeShot { Shots.save(this@GameActivity, it) } }
                            H("Cartridge Tilt (glitch tool)")
                            Text("Imitates 'cartridge tilting': a real console glitches when a cartridge is loose, because the CPU reads wrong data. This tool scrambles bytes of the game's memory while it runs. You never need it to play.", color = Color(0xCCFFFFFF), fontSize = 12.sp)
                            Text("⚠ DATA WARNING: tilting changes the game's memory. Saves and save states made while tilting, or after it, can keep the damage even when tilt is off. Keep progress you care about in a separate slot first (use SET SAFE POINT, or another save slot).", color = Color(0xFFFFB74D), fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.padding(vertical = 4.dp))
                            Text("⚠ PHOTOSENSITIVITY WARNING: glitches can flash quickly and may trigger seizures.", color = Color(0xFFFF8A65), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("Mode: " + TILT_NAMES[tilt] + (if (tilt > 0) "   (shown as ● T$tilt in the top bar)" else ""), color = skin.accent, modifier = Modifier.padding(top = 6.dp))
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                TILT_NAMES.forEachIndexed { lv, n -> Btn(if (lv == 0) "OFF" else "$lv · $n", selected = tilt == lv, color = if (lv > 0) Color(TILT_COLORS[lv]) else null) {
                                    if (lv == 0) tilt = 0 else confirm.ask("Turn on “$n”?", "scramble the game's memory while this mode is on; flashing glitches may appear", "undo the damage when you turn it off; the game may freeze or reset. Please do not use it if you are sensitive to flashing lights.", true) { tilt = lv } } } }
                            SToggle("Crash-safe: try not to reset the cartridge", "tiltSafe", true, "Keeps away from the memory that holds the game's stack and system variables. The last mode ignores this on purpose.")
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { Btn("SET SAFE POINT NOW") { s.markSafe() }; Btn("RESTORE SAFE POINT") { s.restoreSafe() } }
                            Text("A safe point is also stored automatically when you switch a Tilt mode on. Glitch log options: SETTINGS ▸ ABOUT & UPDATES ▸ tap the version 5 times ▸ LOGS.", color = Color(0xAAFFFFFF), fontSize = 11.sp)
                            RingFinder(s, rom)
                        }
                    }
                }
            }
        }
        confirm.Host()
    }

    /** Teach the vibration system any game: find the memory address of a counter (rings, coins, health...) by changing it in game and narrowing down matches. */
    @Composable
    private fun RingFinder(s: EmuSession, rom: Rom) {
        var value by remember { mutableStateOf("") }; var cands by remember { mutableStateOf<List<Int>?>(null) }
        fun word(a: ByteArray, addr: Int) = ((a[addr xor 1].toInt() and 255) shl 8) or (a[(addr + 1) xor 1].toInt() and 255)
        H("Ring Finder (vibration for any game)")
        Text("1) Look at your ring / coin / health counter, type its number, press SCAN.  2) Resume, change the counter in the game (collect one), come back, type the new number, press NARROW.  3) When only a few addresses are left, press USE on the first. The launcher will then vibrate when that counter goes up, drops, or drains. Works with games and ROM hacks where the addresses are unknown. Mega Drive family only.", color = Color(0xCCFFFFFF), fontSize = 12.sp)
        OutlinedTextField(value, { value = it.filter { c -> c.isDigit() }.take(5) }, singleLine = true, label = { Text("Current number") })
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(vertical = 4.dp)) {
            Btn("SCAN") { val v = value.toIntOrNull(); val ram = Emu.readRam(0, 0x10000); if (v != null && ram != null) cands = (0 until 0xFFFF step 2).filter { word(ram, it) == v } }
            Btn("NARROW") { val v = value.toIntOrNull(); val ram = Emu.readRam(0, 0x10000); val c = cands; if (v != null && ram != null && c != null) cands = c.filter { word(ram, it) == v } }
            Btn("CLEAR") { cands = null } }
        cands?.let { c -> Text("${c.size} match(es)" + if (c.size > 8) ". Keep narrowing." else "", color = Skins.current().accent)
            c.take(8).forEach { a -> Row(verticalAlignment = Alignment.CenterVertically) { Text("$" + (0xFF0000 + a).toString(16).uppercase(), color = Color.White, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                Btn("USE") { Library.update(rom.copy(rings = a, lives = -1, profile = "generic")); Store.events.tryEmit(SaveEvent("Vibration counter set for this game (restart the game to apply)", true)) } } } }
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN) Pads.lastKey = Pads.keyName(e.keyCode)
        if (Pads.intercept(e)) return true     // the mapping editor (in-game menu) is waiting for a button
        if (e.keyCode == KeyEvent.KEYCODE_BACK) return super.dispatchKeyEvent(e)
        val gp = (e.source and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD || (e.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
        if (gp && !Store.b("padOn", true)) return super.dispatchKeyEvent(e)
        if (!gp && !Store.b("kbOn", true)) return super.dispatchKeyEvent(e)
        val acts = Pads.actsFor(e.keyCode, !gp); if (acts.isEmpty()) return super.dispatchKeyEvent(e)
        val down = e.action == KeyEvent.ACTION_DOWN
        if (down && e.repeatCount > 0) return true
        val s = session ?: return true
        for (a in acts) when (a) {
            Act.SAVE -> if (down) s.saveState(slot()); Act.LOAD -> if (down) s.loadState(slot())
            Act.MENU -> if (down) openMenu(if (menu == 0) 1 else 0)
            Act.SLOTNEXT -> if (down) { val n = (slot() % 9) + 1; Store.setI("quickSlot", n); Toast.makeText(this, "Save slot $n", Toast.LENGTH_SHORT).show() }
            Act.SLOTPREV -> if (down) { val n = if (slot() <= 1) 9 else slot() - 1; Store.setI("quickSlot", n); Toast.makeText(this, "Save slot $n", Toast.LENGTH_SHORT).show() }
            Act.UITOGGLE -> if (down) uiState = if (uiState == 0) 1 else 0
            Act.VIBTOGGLE -> if (down) { Store.setB("hapGameOn", !Store.b("hapGameOn", true)); Toast.makeText(this, if (Store.b("hapGameOn", true)) "Vibration on" else "Vibration off", Toast.LENGTH_SHORT).show() }
            Act.TURBO -> s.turbo = down; Act.REWIND -> s.rewinding = down
            else -> if (down) keys.add(a) else keys.remove(a)
        }
        push(); return true
    }

    override fun onGenericMotionEvent(e: MotionEvent): Boolean {
        if ((e.source and InputDevice.SOURCE_JOYSTICK) != 0 && e.action == MotionEvent.ACTION_MOVE && Store.b("padOn", true)) {
            val dz = Store.i("padDead", 35) / 100f
            val x = e.getAxisValue(MotionEvent.AXIS_X) + e.getAxisValue(MotionEvent.AXIS_HAT_X); val y = e.getAxisValue(MotionEvent.AXIS_Y) + e.getAxisValue(MotionEvent.AXIS_HAT_Y)
            var m = 0
            if (x < -dz) m = m or Bits.LEFT; if (x > dz) m = m or Bits.RIGHT; if (y < -dz) m = m or Bits.UP; if (y > dz) m = m or Bits.DOWN
            axisMask = m; push(); return true
        }
        return super.onGenericMotionEvent(e)
    }

    override fun onPause() { super.onPause(); session?.paused = true; session?.saveSram() }
    override fun onWindowFocusChanged(hasFocus: Boolean) { super.onWindowFocusChanged(hasFocus); if (hasFocus) { applyBars(); window.decorView.requestApplyInsets() } }
    override fun onResume() { super.onResume(); applyBars(); if (menu == 0) session?.paused = false }
    override fun onDestroy() { super.onDestroy(); session?.stop(); Haptics.stopAll(); UiMode.inGame = false; Haptics.currentGame = ""; Profiles.emu = ""; Profiles.game = ""; PadSys.current = "md"; Music.gameEnd() }
}

private val TILT_NAMES = listOf("Off", "Loose cartridge", "Hot cartridge", "Dying console", "Overheating", "Meltdown", "Total chaos")
private val TILT_COLORS = intArrayOf(0, 0xFF66BB6A.toInt(), 0xFFFFEE58.toInt(), 0xFFFFA726.toInt(), 0xFFEF5350.toInt(), 0xFFAB47BC.toInt(), 0xFFFFFFFF.toInt())
