package com.sonicforge.ui

import android.content.Context
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.dp
import com.sonicforge.core.Emu
import com.sonicforge.data.Store
import com.sonicforge.data.Logger

/**
 * Nintendo DS (experimental). The core draws both screens into ONE picture; we only choose how they are arranged and forward touches on the lower screen.
 * Layouts: side by side, top/bottom, top/bottom with the real gap between the screens, and AUTO (picks by orientation / tablet). Written, not compiled, never run on a device.
 */
object Ds {
    /** the DS cores that are in this build, in the order AUTO tries them. DeSmuME 2015 first: the melonDS core drew a white picture on some phones. */
    val cores = listOf("desmume2015" to "libdesmume.so", "desmume" to "libdesmume_full.so", "melondsds" to "libmelondsds.so", "melonds" to "libmelonds.so")
    fun pickCore(ctx: Context): java.io.File? {
        val dir = ctx.applicationInfo.nativeLibraryDir; val want = Store.s("dsCore", "auto")
        if (want != "auto") cores.firstOrNull { it.first == want }?.let { val f = java.io.File(dir, it.second); if (f.exists()) return f }
        return cores.map { java.io.File(dir, it.second) }.firstOrNull { it.exists() }
    }
    @Volatile var lastSide = false; @Volatile var lastGap = 0
    fun mouseMode() = Store.s("dsTouchMode", "pointer") == "mouse"
    /** MOUSE touch method: the finger position becomes a DS pixel of the lower screen; the cursor is first pushed into the corner (clamped by the core) and then moved there, because a mouse only gives steps */
    private var mx = 0; private var my = 0; private var mDown = false
    fun mouseTo(fx: Float, fy: Float, press: Boolean) {
        val tx: Int; val ty: Int
        if (lastSide) { tx = (fx * 512f - 256f).toInt().coerceIn(0, 255); ty = (fy * 192f).toInt().coerceIn(0, 191) }
        else { tx = (fx * 256f).toInt().coerceIn(0, 255); ty = (fy * (384f + lastGap) - (192f + lastGap)).toInt().coerceIn(0, 191) }
        if (press || !mDown) { Emu.setMouse(-400, -400, false); Emu.setMouse(tx, ty, true); mDown = true }
        else Emu.setMouse(tx - mx, ty - my, true)
        mx = tx; my = ty
    }
    fun mouseUp() { Emu.setMouse(0, 0, false); mDown = false }
    /** the core option names differ between melonDS and DeSmuME, both are sent; a core ignores the names it does not know */
    /** the arrangement really used: "lr" side by side, "tb" top / bottom touching, "tbgap" top / bottom with a gap */
    fun layoutMode(ctx: Context): String {
        val land = ctx.resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
        val wideDp = ctx.resources.configuration.smallestScreenWidthDp
        var mode = Store.s("dsLayout", "auto")
        if (mode == "auto") mode = if (land) (if (wideDp >= 600 || Store.b("dsLandSide", false)) "lr" else "tb") else "tb"
        if (mode == "tablet") mode = if (land) "lr" else "tbgap"
        return mode
    }
    /** gap between the two screens in DS pixels. The APP draws it between the two halves of the picture: the cores' own gap options did nothing on the device, this always works and changes at once */
    fun gapUnits(ctx: Context): Int = if (layoutMode(ctx) == "tbgap") Store.i("dsGap", 46).coerceIn(0, 200) else 0
    fun coreOptions(ctx: Context): Map<String, String> {
        val mode = layoutMode(ctx)
        val gap = 0   // the core always gets gap 0 (the app adds the gap itself)   // TOP / BOTTOM = the screens touch; only TOP / BOTTOM + REAL GAP (and TABLET in portrait) uses the slider
        val m = LinkedHashMap<String, String>()
        val side = mode == "lr"; lastSide = side; lastGap = if (side) 0 else gapUnits(ctx)
        m["melonds_screen_layout"] = if (side) "Left/Right" else "Top/Bottom"
        m["desmume_screens_layout"] = if (side) "left/right" else "top/bottom"
        m["melonds_jit_enable"] = if (Store.b("dsJit", false)) "enabled" else "disabled"   // the JIT needs executable memory: off is slower but draws on phones where the JIT leaves a white picture
        m["desmume_cpu_mode"] = "interpreter"; m["desmume_pointer_type"] = if (mouseMode()) "mouse" else "touch"; m["desmume_pointer_mouse"] = "enabled"; m["desmume_mouse_speed"] = "1.0"; m["desmume_frameskip"] = "0"   // DeSmuME: no JIT on phones; the lower screen is a touch screen
        if (!side) { m["melonds_screen_gap"] = gap.toString(); m["desmume_screens_gap"] = gap.toString() }
        return m
    }
}

/** landscape: the buttons are squeezed into the two side bands next to the picture (widthFrac = share of the screen width the picture takes), so nothing lies over the picture or the touch screen */
fun dsSideLayout(l: com.sonicforge.data.PadLayout, widthFrac: Float): com.sonicforge.data.PadLayout {
    val k = (1f - widthFrac).coerceIn(.2f, 1f)
    return l.copy(land = l.land.map { e -> e.copy(x = if (e.x < .5f) e.x * k else 1f - (1f - e.x) * k) })
}

/**
 * Stylus input for the lower screen. It listens in the INITIAL pass of the parent, so the full-screen button layer on top cannot swallow it
 * (a layer drawn above hides everything below it from touch): a finger that starts inside the picture and not on a button becomes the stylus.
 */
fun Modifier.dsStylus(active: Boolean, rect: () -> androidx.compose.ui.geometry.Rect?, onControl: (androidx.compose.ui.geometry.Offset) -> Boolean): Modifier =
    if (!active) this else this.pointerInput(Unit) {
        awaitPointerEventScope {
            var id: androidx.compose.ui.input.pointer.PointerId? = null
            fun send(p: androidx.compose.ui.geometry.Offset, r: androidx.compose.ui.geometry.Rect) {
                TouchDbg.hit(p.x, p.y, ((p.x - r.left) / r.width.coerceAtLeast(1f)).coerceIn(0f, 1f), ((p.y - r.top) / r.height.coerceAtLeast(1f)).coerceIn(0f, 1f))
                val fx = ((p.x - r.left) / r.width.coerceAtLeast(1f)).coerceIn(0f, 1f); val fy = ((p.y - r.top) / r.height.coerceAtLeast(1f)).coerceIn(0f, 1f)
                if (!TouchDbg.logged) { TouchDbg.logged = true; Logger.i("DS", "first stylus touch sent: " + (fx * 100).toInt() + "% / " + (fy * 100).toInt() + "% of the picture, method " + (if (Ds.mouseMode()) "mouse" else "pointer")) }
                if (Ds.mouseMode()) Ds.mouseTo(fx, fy, id != null && TouchDbg.fresh) else { val fyc = if (!Ds.lastSide && Ds.lastGap > 0) { val tot = 384f + Ds.lastGap; (192f + (fy * tot - (192f + Ds.lastGap)).coerceIn(0f, 191f)) / 384f } else fy; Emu.setPointer((fx * 65534f - 32767f).toInt(), (fyc * 65534f - 32767f).toInt(), true) }
                TouchDbg.fresh = false
            }
            while (true) {
                val ev = awaitPointerEvent(androidx.compose.ui.input.pointer.PointerEventPass.Initial)
                val r = rect() ?: continue
                val cur = id
                if (cur == null) {
                    val d = ev.changes.firstOrNull { it.pressed && !it.previousPressed && r.contains(it.position) && !onControl(it.position) }
                    if (d != null) { id = d.id; TouchDbg.fresh = true; send(d.position, r) }
                } else {
                    val c = ev.changes.firstOrNull { it.id == cur }
                    if (c == null || !c.pressed) { if (Ds.mouseMode()) Ds.mouseUp() else Emu.setPointer(0, 0, false); TouchDbg.up(); id = null } else send(c.position, r)
                }
            }
        }
    }

/** transparent layer over the picture: a finger on it becomes a stylus touch (the core reads the lower screen only) */
@Composable
fun DsTouchPad() {
    Box(Modifier.fillMaxSize().pointerInput(Unit) {
        awaitEachGesture {
            val w = size.width.coerceAtLeast(1); val h = size.height.coerceAtLeast(1)
            fun send(x: Float, y: Float, down: Boolean) { Emu.setPointer(((x / w).coerceIn(0f, 1f) * 65534f - 32767f).toInt(), ((y / h).coerceIn(0f, 1f) * 65534f - 32767f).toInt(), down) }
            val d = awaitFirstDown(requireUnconsumed = false)
            send(d.position.x, d.position.y, true)
            do {
                val ev = awaitPointerEvent()
                val c = ev.changes.firstOrNull() ?: break
                send(c.position.x, c.position.y, c.pressed)
                c.consume()
            } while (ev.changes.any { it.pressed })
            Emu.setPointer(0, 0, false)
        }
    })
}

@Composable
fun DsScreensDialog(onClose: () -> Unit) {
    AlertDialog(onDismissRequest = onClose, containerColor = Color(0xFF0D0D14), titleContentColor = Color.White, textContentColor = Color.White,
        confirmButton = { TextButton(onClose) { Text("CLOSE") } }, title = { Text("DS SCREENS (experimental)") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("Takes effect the next time the game starts. The picture keeps the DS proportions, so turn the phone to match: SIDE BY SIDE is for landscape, TOP / BOTTOM for portrait.", fontSize = 12.sp, color = Color(0xDDFFFFFF))
                SChips("DS emulator core (restart the game)", "dsCore", "auto", listOf("auto" to "AUTO", "desmume2015" to "DeSmuME 2015", "desmume" to "DeSmuME", "melondsds" to "melonDS DS (new)", "melonds" to "melonDS (old)"))
                Text("If the picture stays WHITE or the game crashes, try another core: they are different programs. A core that is not in this build is skipped. AUTO = the first one that is installed (DeSmuME 2015).", fontSize = 11.sp, color = Color(0xCCFFFFFF))
                SChips("Arrangement", "dsLayout", "auto", listOf("auto" to "AUTO", "lr" to "SIDE BY SIDE", "tb" to "TOP / BOTTOM", "tbgap" to "TOP / BOTTOM + REAL GAP", "tablet" to "TABLET"))
                Text("AUTO: landscape = side by side, portrait = top / bottom. TABLET: landscape = side by side, portrait = top / bottom with the real gap, which fills a tall tablet screen better.", fontSize = 11.sp, color = Color(0xCCFFFFFF))
                SSlider("Gap for “TOP / BOTTOM + REAL GAP”", "dsGap", 46, 126, " px")
                Text("TOP / BOTTOM has no gap at all. This slider only sets the gap of “TOP / BOTTOM + REAL GAP” (and TABLET in portrait); a real DS has about 46 pixels. The app draws the gap itself, so it changes at once, also during a game.", fontSize = 11.sp, color = Color(0xCCFFFFFF))
                SToggle("Side by side in landscape on phones (AUTO)", "dsLandSide", false, "OFF (recommended): in landscape the two screens stay stacked in the middle and the buttons sit at the sides, so nothing covers the picture. ON: wide picture, the buttons lie over it.")
                SSlider("Side by side: picture size (% of the screen width)", "dsSideSize", 68, 100, " %")
                Btn("RESET SIZE AND BUTTONS TO DEFAULT") { Store.set("dsSideSize", "68"); Store.setB("dsInset", true); Store.set("scrScale", "100") }
                SToggle("Touch screen ON (finger / mouse / touchpad acts as the stylus)", "dsTouchOn", true, "Switch OFF if touches on the lower screen cause stray taps (for example when you play with the on-screen buttons only, or a gamepad). Works at once, also inside a game.")
                SChips("Touch method (restart the game)", "dsTouchMode", "pointer", listOf("pointer" to "DIRECT (pointer)", "mouse" to "MOUSE (cursor jumps to the finger)"))
                Text("If touching the lower screen does nothing, switch to MOUSE (and/or pick another core above), then turn on the Touch test below to see whether your touches reach the game.", fontSize = 11.sp, color = Color(0xCCFFFFFF))
                SToggle("Touch test (shows a dot where the stylus is sent)", "touchTest", false, "A dot and the numbers appear over the picture while you touch the lower screen. Use it to check that touch reaches the game, then switch it off.")
                SToggle("Landscape: buttons beside the picture (OFF = buttons lie over the picture)", "dsInset", true, "The on-screen buttons move into the two side bands, so they never cover the screens or the touch screen. Other consoles can use this too (SETTINGS ▸ CONTROLS).")
                SToggle("JIT recompiler (faster, may leave the picture WHITE)", "dsJit", false, "OFF (default) is slower but draws correctly on more phones. If your phone is fast enough, try ON. Takes effect when the game starts.")
                SToggle("Plain picture frame (no rounded corners, no border)", "dsPlain", true, "Like the classic mode: sharp edges, no margin. Takes effect when the game starts.")
                H("Touch")
                Text("Touch the lower screen with a finger: it acts as the stylus. The on-screen pad gives the D-pad and A B X Y L R START SELECT.", fontSize = 12.sp, color = Color(0xFFFFE082))
            }
        })
}

fun Modifier.androidx_onSize(f: (androidx.compose.ui.unit.IntSize) -> Unit): Modifier = this.onSizeChanged(f)
fun Modifier.androidx_onPos(f: (androidx.compose.ui.geometry.Rect) -> Unit): Modifier = this.onGloballyPositioned { f(it.boundsInRoot()) }


/** touch test: where the last stylus touch was sent (SETTINGS of DS SCREENS ▸ Touch test). Written, not compiled. */
object TouchDbg {
    @Volatile var logged = false; @Volatile var fresh = false
    @Volatile var x = -1f; @Volatile var y = -1f; @Volatile var fx = 0f; @Volatile var fy = 0f; @Volatile var down = false; @Volatile var count = 0
    fun hit(px: Float, py: Float, fx: Float, fy: Float) { if (!Store.b("touchTest", false)) return; x = px; y = py; this.fx = fx; this.fy = fy; down = true; count++ }
    fun up() { down = false }
}

@Composable
fun TouchTestOverlay() {
    if (!Store.b("touchTest", false)) return
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { tick++; kotlinx.coroutines.delay(60) } }
    @Suppress("UNUSED_VARIABLE") val tk = tick
    Box(Modifier.fillMaxSize()) {
        androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) { if (TouchDbg.x >= 0f) drawCircle(if (TouchDbg.down) Color(0xCCFF5252) else Color(0x66FFFFFF), 22f, androidx.compose.ui.geometry.Offset(TouchDbg.x, TouchDbg.y)) }
        Text("TOUCH TEST: " + (if (TouchDbg.count == 0) "no touch has reached the game yet" else (if (TouchDbg.down) "DOWN " else "up ") + "x=" + (TouchDbg.fx * 100).toInt() + "% y=" + (TouchDbg.fy * 100).toInt() + "% of the picture, sent " + TouchDbg.count + " times"),
            color = Color(0xFFFFEB3B), fontSize = 11.sp, modifier = Modifier.align(Alignment.BottomStart).padding(8.dp).background(Color(0xAA000000)))
    }
}
