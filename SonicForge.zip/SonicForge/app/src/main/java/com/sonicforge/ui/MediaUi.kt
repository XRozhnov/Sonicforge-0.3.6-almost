package com.sonicforge.ui

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.widget.MediaController
import android.widget.VideoView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import com.sonicforge.data.Store
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider
import com.sonicforge.data.Library
import com.sonicforge.data.Logger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * MEDIA tab: pictures, comics, video, notes (text editor), files and a voice recorder with a backing track ("karaoke").
 * Everything lives in the app's own private folder (media/). Files you pick are COPIED in. Written, not compiled, not tested on a device.
 */
object Media {
    val root: File get() = File(Library.art.parentFile, "media").apply { mkdirs() }
    fun dir(n: String) = File(root, n).apply { mkdirs() }
    var tick by mutableIntStateOf(0)
    var sub by mutableStateOf("pictures")
    /** a file another app sent to us ("Open with SonicForge" / Share) waiting for the user to say where it goes */
    var incoming by mutableStateOf<Uri?>(null)
    var incomingMime by mutableStateOf("")
    var incomingText by mutableStateOf("")
    /** a text file the FILES tab wants opened straight in the editor (ready to type, no separate "edit" step) */
    var openNote by mutableStateOf<File?>(null)

    fun kind(n: String): String = when (n.substringAfterLast('.', "").lowercase()) {
        "jpg", "jpeg", "png", "webp", "gif", "bmp" -> "img"; "mp4", "mkv", "webm", "3gp", "mov" -> "vid"
        "txt", "md", "log", "json", "csv" -> "txt"; "m4a", "mp3", "ogg", "wav", "aac", "flac" -> "aud"; else -> "other" }
    fun mimeKind(m: String): String = when { m.startsWith("image/") -> "img"; m.startsWith("video/") -> "vid"; m.startsWith("text/") -> "txt"; m.startsWith("audio/") -> "aud"; else -> "other" }

    fun nameOf(ctx: Context, u: Uri): String {
        var n = ""
        try { ctx.contentResolver.query(u, null, null, null, null)?.use { c -> if (c.moveToFirst()) { val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (i >= 0) n = c.getString(i) ?: "" } } } catch (_: Exception) {}
        if (n.isBlank()) n = u.lastPathSegment?.substringAfterLast('/') ?: "file"
        return n.replace(Regex("[\\\\/:*?\"<>|]"), "_")
    }
    fun unique(d: File, name: String): File {
        var f = File(d, name); var i = 1; val b = name.substringBeforeLast('.', name); val e = name.substringAfterLast('.', "").let { if (it.isEmpty()) "" else ".$it" }
        while (f.exists()) { f = File(d, "$b ($i)$e"); i++ }; return f
    }
    fun copyIn(ctx: Context, u: Uri, d: File, name: String = nameOf(ctx, u)): File? = try {
        d.mkdirs(); val f = unique(d, name)
        ctx.contentResolver.openInputStream(u)!!.use { i -> f.outputStream().use { i.copyTo(it) } }; tick++; f
    } catch (e: Exception) { Logger.e("Media", "could not copy $name", e); null }

    /** progress text of a running import ("" = none); shown above the lists */
    var importMsg by mutableStateOf("")
    /** copies the picked files on a background thread (a 2 hour video is gigabytes: doing it on the main thread froze the app and Android showed "not responding"). Each file is written as name.part and renamed when finished, so half-copied files never show up. */
    fun copyInAsync(ctx: Context, us: List<Uri>, d: File) {
        if (us.isEmpty()) return
        kotlin.concurrent.thread {
            var done = 0
            for (u in us) {
                val name = nameOf(ctx, u)
                try {
                    d.mkdirs(); val f = unique(d, name); val part = File(d, f.name + ".part")
                    val total = try { ctx.contentResolver.openAssetFileDescriptor(u, "r")?.use { it.length } ?: -1L } catch (_: Exception) { -1L }
                    ctx.contentResolver.openInputStream(u)!!.use { i -> part.outputStream().use { o ->
                        val buf = ByteArray(1 shl 20); var n = 0L; var last = 0L
                        while (true) { val r = i.read(buf); if (r < 0) break; o.write(buf, 0, r); n += r
                            val now = System.currentTimeMillis(); if (now - last > 400) { last = now; importMsg = "Copying ${done + 1}/${us.size}: $name  ${n / 1048576} MB" + (if (total > 0) " of ${total / 1048576} MB" else "") } } } }
                    part.renameTo(f)
                } catch (e: Exception) { Logger.e("Media", "could not copy $name", e); try { File(d, "$name.part").delete() } catch (_: Exception) {} }
                done++
            }
            importMsg = ""; tick++; Logger.notice("Copied $done file(s) into the app")
        }
    }

    fun favs(): Set<String> = Store.s("mediaFav", "").split("\n").filter { it.isNotEmpty() }.toSet()
    fun isFav(f: File) = f.path in favs()
    fun toggleFav(f: File) { val s = favs().toMutableSet(); if (!s.add(f.path)) s.remove(f.path); Store.set("mediaFav", s.joinToString("\n")); tick++ }
    /** the file's date (last change: for files copied into the app that is the day they were added) */
    fun dateOf(f: File): String = java.text.SimpleDateFormat("dd.MM.yyyy HH:mm", java.util.Locale.getDefault()).format(java.util.Date(f.lastModified()))
    /** favourites filter + sort order chosen in the bar above the lists; "name" keeps the order the caller gave (natural name order or a hand-made order) */
    fun view(files: List<File>): List<File> {
        val q = Store.s("mediaQuery").trim().lowercase()
        val l0 = if (q.isEmpty()) files else files.filter { it.name.lowercase().contains(q) }
        val l = if (Store.b("mediaFavOnly", false)) { val fv = favs(); l0.filter { it.path in fv } } else l0
        return when (Store.s("mediaSort", "name")) {
            "new" -> l.sortedByDescending { it.lastModified() }; "old" -> l.sortedBy { it.lastModified() }
            "big" -> l.sortedByDescending { if (it.isFile) it.length() else (it.listFiles()?.size ?: 0).toLong() }
            "fav" -> { val fv = favs(); l.sortedBy { if (it.path in fv) 0 else 1 } }
            else -> l }
    }
    fun natCmp(a: String, b: String): Int {
        val re = Regex("\\d+|\\D+"); val ra = re.findAll(a.lowercase()).map { it.value }.toList(); val rb = re.findAll(b.lowercase()).map { it.value }.toList()
        for (i in 0 until minOf(ra.size, rb.size)) { val x = ra[i]; val y = rb[i]
            val c = if (x[0].isDigit() && y[0].isDigit()) x.toBigInteger().compareTo(y.toBigInteger()) else x.compareTo(y); if (c != 0) return c }
        return ra.size - rb.size
    }
    fun list(d: File, k: String? = null): List<File> = (d.listFiles()?.toList() ?: emptyList()).filter { it.isFile && (k == null || kind(it.name) == k) }.sortedWith { x, y -> natCmp(x.name, y.name) }
    fun decode(f: File, px: Int): ImageBitmap? = try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }; BitmapFactory.decodeFile(f.path, o)
        var s = 1; while (o.outWidth / (s * 2) >= px && o.outHeight / (s * 2) >= px) s *= 2
        BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })?.asImageBitmap()
    } catch (_: Throwable) { null }
    fun share(ctx: Context, f: File) {
        try {
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
            val mime = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
            ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Send / open with"))
        } catch (e: Exception) { Logger.notice("Could not share ${f.name}: ${e.message}", true) }
    }
}

@Composable
fun Thumb(f: File, px: Int, modifier: Modifier, fit: ContentScale = ContentScale.Crop, minH: Int = 0) {
    val bmp by produceState<ImageBitmap?>(null, f.path, px) { value = withContext(Dispatchers.IO) { Media.decode(f, px) } }
    val b = bmp
    if (b != null) Image(b, null, modifier, contentScale = fit) else Box(modifier.heightIn(min = minH.dp).background(Color.White.copy(.08f)))
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ImageViewer(files: List<File>, start: Int, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var edit by remember { mutableStateOf<File?>(null) }; var askDel by remember { mutableStateOf<File?>(null) }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            val ps = rememberPagerState(start.coerceIn(0, (files.size - 1).coerceAtLeast(0))) { files.size }
            HorizontalPager(ps, Modifier.fillMaxSize()) { i -> ZoomBox(Modifier.fillMaxSize(), resetKey = ps.currentPage) { AnyPicture(files[i].path, Modifier.fillMaxSize(), ContentScale.Fit) } }
            Text("${ps.currentPage + 1} / ${files.size}  ·  ${files.getOrNull(ps.currentPage)?.name ?: ""}  ·  ${files.getOrNull(ps.currentPage)?.let { Media.dateOf(it) } ?: ""}", color = Color.White, fontSize = 12.sp, modifier = Modifier.align(Alignment.TopStart).padding(12.dp).background(Color(0x88000000), RoundedCornerShape(8.dp)).padding(6.dp))
            Btn("✕ CLOSE", Modifier.align(Alignment.TopEnd).padding(12.dp)) { onClose() }
            Row(Modifier.align(Alignment.BottomCenter).horizontalScroll(rememberScrollState()).padding(10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                files.getOrNull(ps.currentPage)?.let { cur ->
                    Btn(if (Media.isFav(cur)) "★ FAVOURITE" else "☆ FAVOURITE", selected = Media.isFav(cur)) { Media.toggleFav(cur) }
                    Btn("✂ EDIT / CROP / ROTATE") { edit = cur }
                    Btn("SHARE") { Media.share(ctx, cur) }
                    Btn("COPY") { val t = Media.unique(cur.parentFile ?: Media.root, cur.nameWithoutExtension + "_copy." + cur.extension); try { cur.copyTo(t); Media.tick++; com.sonicforge.data.Logger.notice("Saved a copy: ${t.name}") } catch (e: Exception) { com.sonicforge.data.Logger.notice("Could not copy: ${e.message}", false) } }
                    Btn("🗑", color = Color(0xFFE53935)) { askDel = cur }
                }
            }
            Text("Pinch or double-tap to zoom", color = Color(0x99FFFFFF), fontSize = 10.sp, modifier = Modifier.align(Alignment.TopCenter).padding(top = 52.dp))
        }
    }
    edit?.let { f -> ImageEditDialog(f) { edit = null; onClose() } }
    askDel?.let { f -> ConfirmDialog("Delete ${f.name}?", "Deletes this picture from the app's media folder.", "Your original on the phone is not touched.", onYes = { f.delete(); askDel = null; Media.tick++; onClose() }, onNo = { askDel = null }) }
}

@Composable
fun SortBar() {
    val cur = Store.s("mediaSort", "name")
    if (Media.importMsg.isNotEmpty()) Text("⏳ " + Media.importMsg + "  (you can keep using the app)", color = Color(0xFFFFD54F), fontSize = 11.sp, modifier = Modifier.padding(vertical = 2.dp))
    androidx.compose.material3.OutlinedTextField(Store.s("mediaQuery"), { Store.set("mediaQuery", it); Media.tick++ }, singleLine = true, label = { Text("Search by name (pictures, video, recordings)") }, modifier = Modifier.fillMaxWidth())
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("Sort:", color = Color(0xCCFFFFFF), fontSize = 11.sp)
        listOf("name" to "NAME", "new" to "NEWEST", "old" to "OLDEST", "big" to "BIGGEST", "fav" to "★ FIRST").forEach { (k, n) -> Btn(n, selected = cur == k) { Store.set("mediaSort", k); Media.tick++ } }
        Btn(if (Store.b("mediaFavOnly", false)) "★ ONLY: ON" else "★ ONLY", selected = Store.b("mediaFavOnly", false)) { Store.setB("mediaFavOnly", !Store.b("mediaFavOnly", false)); Media.tick++ }
    }
}

@Composable
fun MediaScreen() {
    @Suppress("UNUSED_VARIABLE") val t = Media.tick
    val subs = listOf("pictures" to "🖼 PICTURES", "comics" to "📚 COMICS", "video" to "🎞 VIDEO", "notes" to "📝 NOTES", "files" to "📁 FILES", "rec" to "🎙 RECORDER")
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            subs.forEach { (k, n) -> Btn(n, selected = Media.sub == k) { Media.sub = k } }
        }
        Box(Modifier.weight(1f).padding(horizontal = 10.dp)) {
            when (Media.sub) { "pictures" -> PicturesTab(); "comics" -> ComicsTab(); "video" -> VideoTab2(); "notes" -> NotesTab(); "files" -> FilesTab(); else -> RecorderTab() }
        }
    }
}

@Composable
private fun PicturesTab() {
    val ctx = LocalContext.current; @Suppress("UNUSED_VARIABLE") val t = Media.tick
    val d = Media.dir("pictures"); val files = Media.view(Media.list(d, "img")); var open by remember { mutableIntStateOf(-1) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { us -> Media.copyInAsync(ctx, us, d) }
    Column {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { Btn("＋ ADD PICTURES") { pick.launch("image/*") }; Text("${files.size} pictures · copied into the app", color = Color(0xCCFFFFFF), fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterVertically)) }
        SortBar()
        if (files.isEmpty()) Text("No pictures yet. Tap ADD PICTURES, or open an image with SonicForge from another app.", color = Color.White, modifier = Modifier.padding(top = 12.dp))
        LazyVerticalGrid(GridCells.Adaptive(104.dp), Modifier.fillMaxSize().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(files.size) { i -> Box { Thumb(files[i], 256, Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(8.dp)).forgeClick { open = i }); if (Media.isFav(files[i])) Text("★", color = Color(0xFFFFD54F), modifier = Modifier.align(Alignment.TopEnd).padding(4.dp)) } }
        }
    }
    if (open >= 0) ImageViewer(files, open) { open = -1 }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ComicsTab() {
    val ctx = LocalContext.current; @Suppress("UNUSED_VARIABLE") val t = Media.tick
    val root = Media.dir("comics")
    val ord = Store.s("comicOrder", "").split("|").filter { it.isNotEmpty() }
    val comics = (root.listFiles()?.filter { it.isDirectory } ?: emptyList()).sortedWith(compareBy<File>({ ord.indexOf(it.name).let { i -> if (i < 0) Int.MAX_VALUE else i } }).thenComparator { a, b -> Media.natCmp(a.name, b.name) }).let { Media.view(it) }
    var reading by remember { mutableStateOf<File?>(null) }; var naming by remember { mutableStateOf<List<Uri>>(emptyList()) }; var newName by remember { mutableStateOf("") }
    var clash by remember { mutableStateOf<File?>(null) }; var askDel by remember { mutableStateOf<File?>(null) }; var editPages by remember { mutableStateOf<File?>(null) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { us -> if (us.isNotEmpty()) { naming = us; newName = "Comic " + (Store.i("comicSeq", 0) + 1) } }
    fun createFrom(d: File, replace: Boolean) {
        if (replace) d.deleteRecursively()
        val fresh = !d.exists(); d.mkdirs()
        val start = Media.list(d, "img").size
        naming.forEachIndexed { i, u -> val n = Media.nameOf(ctx, u); Media.copyIn(ctx, u, d, if (start == 0) n else "%04d_%s".format(start + i + 1, n)) }
        if (fresh) Store.setI("comicSeq", Store.i("comicSeq", 0) + 1)
        naming = emptyList(); clash = null; Media.tick++
    }
    fun moveComic(c: File, dir: Int) {
        val names = comics.map { it.name }.toMutableList(); val i = names.indexOf(c.name); val j = i + dir
        if (i < 0 || j !in names.indices) return
        names[i] = names[j].also { names[j] = names[i] }; Store.set("comicOrder", names.joinToString("|")); Media.tick++
    }
    val r = reading
    if (r == null) Column {
        Btn("＋ NEW COMIC FROM PICTURES") { pick.launch("image/*") }
        Text("Select all the page images of a comic. Pages are sorted by name with natural numbering (2 before 10); fix the order afterwards with PAGES. The suggested names count up (Comic 1, Comic 2 ...) and never repeat, even after you delete one. A name that already exists asks before anything is replaced.", color = Color(0xCCFFFFFF), fontSize = 11.sp, modifier = Modifier.padding(vertical = 6.dp))
        SortBar()
        if (comics.isEmpty()) Text("No comics yet.", color = Color.White)
        LazyColumn { items(comics) { c ->
            val pages = Media.list(c, "img")
            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(10.dp)).background(Color.Black.copy(.35f)).forgeClick { reading = c }.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                pages.firstOrNull()?.let { Thumb(it, 160, Modifier.size(56.dp, 76.dp).clip(RoundedCornerShape(6.dp))) }
                Column(Modifier.padding(start = 10.dp).weight(1f)) { Text(c.name, color = Color.White, fontWeight = FontWeight.Bold); Text("${pages.size} pages · page ${Store.i("cm_" + c.name, 0) + 1} · ${Media.dateOf(c)}", color = Color(0xCCFFFFFF), fontSize = 10.sp) }
                Text(if (Media.isFav(c)) "★" else "☆", color = Color(0xFFFFD54F), modifier = Modifier.forgeClick { Media.toggleFav(c) }.padding(8.dp))
                Text("▲", color = Color.White, modifier = Modifier.forgeClick { moveComic(c, -1) }.padding(8.dp))
                Text("▼", color = Color.White, modifier = Modifier.forgeClick { moveComic(c, 1) }.padding(8.dp))
                Text("✕", color = Color(0xFFFFCDD2), modifier = Modifier.forgeClick { askDel = c }.padding(8.dp))
            }
        } }
    } else {
        val pages = Media.list(r, "img"); val rtl = Store.b("cmRtl", false); val vertical = Store.b("cmVertical", false); val tapNav = Store.b("cmTap", true)
        val scope = rememberCoroutineScope(); var wide by remember { mutableFloatStateOf(1f) }
        Column {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Btn("◀ COMICS") { reading = null }
                Btn(if (vertical) "MODE: MANGA / SCROLL" else "MODE: PAGES", selected = true) { Store.setB("cmVertical", !vertical) }
                if (!vertical) Btn(if (rtl) "READ: RIGHT→LEFT" else "READ: LEFT→RIGHT") { Store.setB("cmRtl", !rtl) }
                if (!vertical) Btn(if (tapNav) "TAP EDGES: ON" else "TAP EDGES: OFF") { Store.setB("cmTap", !tapNav) }
                if (vertical) { Btn("－") { wide = (wide - 0.25f).coerceAtLeast(1f) }; Btn("WIDTH ${(wide * 100).toInt()}%") { wide = 1f }; Btn("＋") { wide = (wide + 0.25f).coerceAtMost(3f) } }
                Btn("PAGES / ORDER") { editPages = r }
            }
            if (pages.isEmpty()) Text("This comic has no pages.", color = Color.White)
            else if (vertical) { val ls = androidx.compose.foundation.lazy.rememberLazyListState(Store.i("cm_" + r.name, 0).coerceIn(0, pages.size - 1))
                LaunchedEffect(ls.firstVisibleItemIndex) { Store.set("cm_" + r.name, ls.firstVisibleItemIndex.toString()) }
                val sw = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp.dp
                Box(Modifier.fillMaxSize().horizontalScroll(rememberScrollState())) {
                    LazyColumn(Modifier.width(sw * wide).fillMaxHeight(), state = ls) { items(pages.size) { i -> Thumb(pages[i], 1400, Modifier.fillMaxWidth(), ContentScale.FillWidth, 240) } }
                } }
            else { val ps = rememberPagerState(Store.i("cm_" + r.name, 0).coerceIn(0, pages.size - 1)) { pages.size }
                LaunchedEffect(ps.currentPage) { Store.set("cm_" + r.name, ps.currentPage.toString()) }
                Box(Modifier.fillMaxSize()) {
                    HorizontalPager(ps, Modifier.fillMaxSize(), reverseLayout = rtl) { i ->
                        ZoomBox(Modifier.fillMaxSize(), resetKey = ps.currentPage, onTap = { p, sz ->
                            if (tapNav) { val f = p.x / sz.width.coerceAtLeast(1)
                                val dir = if (f < 0.28f) -1 else if (f > 0.72f) 1 else 0
                                val step = if (rtl) -dir else dir
                                if (step != 0) scope.launch { ps.animateScrollToPage((ps.currentPage + step).coerceIn(0, pages.size - 1)) } }
                        }) { Thumb(pages[i], 2048, Modifier.fillMaxSize(), ContentScale.Fit) }
                    }
                    Text("${ps.currentPage + 1} / ${pages.size}", color = Color.White, fontSize = 12.sp, modifier = Modifier.align(Alignment.BottomCenter).padding(6.dp).background(Color(0x88000000), RoundedCornerShape(8.dp)).padding(horizontal = 8.dp, vertical = 3.dp))
                } }
        }
    }
    if (naming.isNotEmpty()) Dialog(onDismissRequest = { naming = emptyList() }) {
        Column(Modifier.clip(RoundedCornerShape(14.dp)).background(Color(0xFF1B1B22)).padding(14.dp)) {
            Text("Comic name (${naming.size} pages)", color = Color.White, fontWeight = FontWeight.Bold)
            BasicTextField(newName, { newName = it }, singleLine = true, textStyle = TextStyle(color = Color.White, fontSize = 16.sp), cursorBrush = SolidColor(Color.White), modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp).background(Color.White.copy(.1f), RoundedCornerShape(8.dp)).padding(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Btn("ADD", selected = true) { val d = File(root, newName.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "Comic " + (Store.i("comicSeq", 0) + 1) }); if (d.exists()) clash = d else createFrom(d, false) }
                Btn("CANCEL") { naming = emptyList() }
            }
        }
    }
    clash?.let { d -> AlertDialog(onDismissRequest = { clash = null }, containerColor = Color(0xFF0D0D14), titleContentColor = Color.White, textContentColor = Color.White,
        title = { Text("A comic named “${d.name}” already exists") },
        text = { Text("Choose what to do. REPLACE deletes the existing comic first. ADD PAGES keeps it and appends the new pages at the end.") },
        confirmButton = { TextButton({ createFrom(d, true) }) { Text("REPLACE IT", color = Color(0xFFFF8A80)) } },
        dismissButton = { Row { TextButton({ createFrom(d, false) }) { Text("ADD PAGES") }; TextButton({ clash = null }) { Text("BACK") } } }) }
    askDel?.let { c -> ConfirmDialog("Delete the comic “${c.name}”?", "Deletes all its pages from the app's media folder.", "Your originals on the phone are not touched.", onYes = { c.deleteRecursively(); askDel = null; Media.tick++ }, onNo = { askDel = null }) }
    editPages?.let { d -> ComicPagesDialog(d) { editPages = null } }
}

@Composable
private fun VideoTab2() {
    val ctx = LocalContext.current; @Suppress("UNUSED_VARIABLE") val t = Media.tick
    val d = Media.dir("video"); val files = Media.view(Media.list(d, "vid")); var play by remember { mutableStateOf<File?>(null) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { us -> Media.copyInAsync(ctx, us, d) }
    Column {
        Btn("＋ ADD VIDEOS") { pick.launch("video/*") }
        SortBar()
        Text("Videos are copied into the app (big files take space; delete them here when done).", color = Color(0xCCFFFFFF), fontSize = 11.sp, modifier = Modifier.padding(vertical = 6.dp))
        LazyColumn { items(files) { f ->
            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(10.dp)).background(Color.Black.copy(.35f)).forgeClick { play = f }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                VideoThumb(f, Modifier.width(96.dp).height(54.dp).clip(RoundedCornerShape(6.dp))); Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) { Text("▶ " + f.name, color = Color.White); Text(Media.dateOf(f), color = Color(0xAAFFFFFF), fontSize = 10.sp) }; Text("${f.length() / 1024 / 1024} MB", color = Color(0xCCFFFFFF), fontSize = 11.sp)
                Text(if (Media.isFav(f)) "★" else "☆", color = Color(0xFFFFD54F), modifier = Modifier.forgeClick { Media.toggleFav(f) }.padding(8.dp))
                Text("✕", color = Color(0xFFFFCDD2), modifier = Modifier.forgeClick { f.delete(); Media.tick++ }.padding(10.dp))
            } } }
    }
    play?.let { f -> VideoPlayerDialog(files, files.indexOf(f).coerceAtLeast(0)) { play = null } }
}

@Composable
private fun NotesTab() {
    val ctx = LocalContext.current; @Suppress("UNUSED_VARIABLE") val t = Media.tick
    val d = Media.dir("notes"); val files = Media.list(d).filter { Media.kind(it.name) == "txt" }
    var cur by remember { mutableStateOf<File?>(null) }; var text by remember { mutableStateOf("") }; var title by remember { mutableStateOf("") }; var saved by remember { mutableStateOf("") }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { us -> Media.copyInAsync(ctx, us, d) }
    fun save() { val c = cur ?: return; try { var f = c; val want = title.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "Note" }.let { if (it.contains('.')) it else "$it.txt" }
        if (want != c.name) { val n = Media.unique(c.parentFile ?: d, want); if (c.exists()) c.renameTo(n); f = n }
        f.writeText(text); cur = f; saved = text; Media.tick++ } catch (e: Exception) { Logger.notice("Could not save the note: ${e.message}", true) } }
    LaunchedEffect(Media.openNote) { Media.openNote?.let { f -> cur = f; title = f.name; text = try { f.readText() } catch (_: Exception) { "" }; saved = text; Media.openNote = null } }
    val c = cur
    if (c == null) Column {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { Btn("＋ NEW NOTE", selected = true) { val f = Media.unique(d, "Note.txt"); f.writeText(""); Media.tick++; cur = f; title = f.name; text = ""; saved = "" }; Btn("IMPORT .TXT") { pick.launch("text/*") } }
        if (files.isEmpty()) Text("No notes yet. Notes are plain .txt files in the app's media folder; open a text file with SonicForge from another app to import it.", color = Color.White, modifier = Modifier.padding(top = 10.dp))
        LazyColumn(Modifier.padding(top = 8.dp)) { items(files) { f ->
            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(10.dp)).background(Color.Black.copy(.35f)).forgeClick { cur = f; title = f.name; text = try { f.readText() } catch (_: Exception) { "" }; saved = text }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text(f.name, color = Color.White, fontWeight = FontWeight.Bold); Text(try { f.useLines { it.firstOrNull() ?: "" }.take(60) } catch (_: Exception) { "" }, color = Color(0xCCFFFFFF), fontSize = 11.sp, maxLines = 1) }
                Text("✕", color = Color(0xFFFFCDD2), modifier = Modifier.forgeClick { f.delete(); Media.tick++ }.padding(10.dp))
            } } }
    } else Column(Modifier.fillMaxSize()) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Btn(if (text == saved) "◀ NOTES" else "◀ NOTES (unsaved!)") { cur = null }; Btn(if (text == saved) "SAVED ✓" else "SAVE", selected = text != saved) { save() }
            Btn("SHARE") { save(); cur?.let { Media.share(ctx, it) } }
        }
        BasicTextField(title, { title = it }, singleLine = true, textStyle = TextStyle(color = Color(0xFFFFD54F), fontSize = 14.sp, fontWeight = FontWeight.Bold), cursorBrush = SolidColor(Color.White), modifier = Modifier.fillMaxWidth().padding(top = 8.dp).background(Color.White.copy(.08f), RoundedCornerShape(8.dp)).padding(8.dp))
        BasicTextField(text, { text = it }, textStyle = TextStyle(color = Color.White, fontSize = 15.sp), cursorBrush = SolidColor(Color.White), modifier = Modifier.fillMaxWidth().weight(1f).padding(top = 6.dp).background(Color.White.copy(.06f), RoundedCornerShape(8.dp)).verticalScroll(rememberScrollState()).padding(10.dp))
    }
}

@Composable
private fun FilesTab() {
    val ctx = LocalContext.current; @Suppress("UNUSED_VARIABLE") val t = Media.tick
    var dir by remember { mutableStateOf(Media.root) }; var sel by remember { mutableStateOf<File?>(null) }; var rename by remember { mutableStateOf("") }; var mk by remember { mutableStateOf("") }
    val kids = (dir.listFiles()?.toList() ?: emptyList()).sortedWith(compareBy<File>({ !it.isDirectory }).thenComparator { a, b -> Media.natCmp(a.name, b.name) })
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { us -> Media.copyInAsync(ctx, us, dir) }
    val rel = dir.path.removePrefix(Media.root.path).ifEmpty { "/" }
    Column {
        Text("📁 $rel   (only SonicForge's own media folder; it cannot see the rest of the phone)", color = Color(0xCCFFFFFF), fontSize = 11.sp)
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            if (dir != Media.root) Btn("◀ UP") { dir = dir.parentFile ?: Media.root }
            Btn("＋ ADD FILES") { pick.launch("*/*") }
        }
        Row(Modifier.padding(bottom = 4.dp)) {
            BasicTextField(mk, { mk = it }, singleLine = true, textStyle = TextStyle(color = Color.White, fontSize = 13.sp), cursorBrush = SolidColor(Color.White), modifier = Modifier.weight(1f).background(Color.White.copy(.08f), RoundedCornerShape(8.dp)).padding(8.dp))
            Btn("NEW FOLDER") { if (mk.isNotBlank()) { File(dir, mk.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_")).mkdirs(); mk = ""; Media.tick++ } }
        }
        LazyColumn { items(kids) { f ->
            Row(Modifier.fillMaxWidth().padding(vertical = 2.dp).clip(RoundedCornerShape(8.dp)).background(Color.Black.copy(.3f)).forgeClick { if (f.isDirectory) dir = f else { sel = f; rename = f.name } }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text((if (f.isDirectory) "📁 " else when (Media.kind(f.name)) { "img" -> "🖼 "; "vid" -> "🎞 "; "txt" -> "📝 "; "aud" -> "🎵 "; else -> "📄 " }) + f.name, color = Color.White, modifier = Modifier.weight(1f), maxLines = 1)
                Text(Media.dateOf(f), color = Color(0xAAFFFFFF), fontSize = 9.sp, modifier = Modifier.padding(end = 8.dp))
                Text(if (f.isDirectory) "${f.listFiles()?.size ?: 0}" else "${(f.length() / 1024).coerceAtLeast(1)} KB", color = Color(0xCCFFFFFF), fontSize = 11.sp)
            } } }
    }
    sel?.let { f -> Dialog(onDismissRequest = { sel = null }) {
        Column(Modifier.clip(RoundedCornerShape(14.dp)).background(Color(0xFF1B1B22)).padding(14.dp)) {
            Text(f.name, color = Color.White, fontWeight = FontWeight.Bold)
            BasicTextField(rename, { rename = it }, singleLine = true, textStyle = TextStyle(color = Color.White, fontSize = 14.sp), cursorBrush = SolidColor(Color.White), modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp).background(Color.White.copy(.1f), RoundedCornerShape(8.dp)).padding(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Btn("RENAME", selected = true) { if (rename.isNotBlank() && rename != f.name) f.renameTo(Media.unique(f.parentFile ?: dir, rename.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_"))); sel = null; Media.tick++ }
                if (Media.kind(f.name) == "txt") Btn("✎ OPEN IN EDITOR") { Media.openNote = f; Media.sub = "notes"; sel = null }
                Btn("SHARE / OPEN WITH") { Media.share(ctx, f) }
                Btn("DELETE", color = Color(0xFFE53935)) { f.delete(); sel = null; Media.tick++ }
            }
        } } }
}

@Composable
private fun RecorderTab() {
    val ctx = LocalContext.current; @Suppress("UNUSED_VARIABLE") val t = Media.tick
    val d = Media.dir("recordings"); val files = Media.view(Media.list(d, "aud").filter { !it.name.startsWith("backing-") })
    var rec by remember { mutableStateOf<MediaRecorder?>(null) }; var backing by remember { mutableStateOf<MediaPlayer?>(null) }; var track by remember { mutableStateOf<Uri?>(null) }; var trackName by remember { mutableStateOf("") }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }; var playing by remember { mutableStateOf("") }; var msg by remember { mutableStateOf("") }
    fun stopRec() { try { rec?.stop() } catch (_: Exception) {}; try { rec?.release() } catch (_: Exception) {}; rec = null; try { backing?.stop() } catch (_: Exception) {}; try { backing?.release() } catch (_: Exception) {}; backing = null; Media.tick++ }
    DisposableEffect(Unit) { onDispose { stopRec(); try { player?.release() } catch (_: Exception) {} } }
    fun startRec() {
        try {
            val f = Media.unique(d, "rec-" + java.text.SimpleDateFormat("yyyyMMdd-HHmmss", java.util.Locale.US).format(java.util.Date()) + ".m4a")
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else @Suppress("DEPRECATION") MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC); r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4); r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC); r.setAudioEncodingBitRate(128000); r.setAudioSamplingRate(44100)
            r.setOutputFile(f.path); r.prepare()
            track?.let { u -> try { backing = MediaPlayer.create(ctx, u)?.also { it.start() } } catch (e: Exception) { msg = "Backing track failed: ${e.message}" } }
            r.start(); rec = r; msg = "Recording… (use headphones with a backing track, or the mic will hear it)"
        } catch (e: Exception) { msg = "Could not start recording: ${e.message}"; Logger.e("Recorder", "start failed", e); rec = null }
    }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) startRec() else msg = "Microphone permission was refused. The recorder needs it; nothing is sent anywhere (the app has no internet access)." }
    val permEq = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) com.sonicforge.data.Store.setB("recLive", true) else msg = "The real equalizer needs the microphone permission (Android treats listening to the output sound as capturing audio). Without it the bars only dance to a pattern." }
    val pickTrack = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u -> if (u != null) { track = u; trackName = Media.nameOf(ctx, u) } }
    Column(Modifier.verticalScroll(rememberScrollState())) {
        Text("Voice recorder with a backing track (karaoke style). Pick a song, press RECORD: the song plays while your voice is recorded. Your voice and the song are NOT mixed into one file in this version; the recording holds your voice only. Lyrics display is not done yet.", color = Color(0xCCFFFFFF), fontSize = 11.sp)
        Row(Modifier.padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Btn("🎵 BACKING TRACK" + if (trackName.isNotEmpty()) ": $trackName" else "") { pickTrack.launch("audio/*") }
            if (track != null) Btn("✕") { track = null; trackName = "" }
        }
        Btn(if (rec == null) "● RECORD" else "■ STOP", selected = rec != null, color = Color(0xFFE53935)) {
            if (rec != null) stopRec() else if (ctx.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) startRec() else perm.launch(android.Manifest.permission.RECORD_AUDIO) }
        val viz = com.sonicforge.data.Store.s("recViz", "both")
        val hist = remember { mutableStateListOf<Float>() }; var lvl by remember { mutableFloatStateOf(0f) }
        LaunchedEffect(rec) {
            hist.clear()
            while (rec != null) { kotlinx.coroutines.delay(60); val a = try { rec?.maxAmplitude ?: 0 } catch (_: Exception) { 0 }; lvl = (a / 32767f).coerceIn(0f, 1f); hist.add(lvl); if (hist.size > 160) hist.removeAt(0) }
            lvl = 0f
        }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Level display:", color = Color(0xCCFFFFFF), fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterVertically))
            listOf("both" to "Bar + wave", "bar" to "Level bar", "wave" to "Waveform", "off" to "Off").forEach { (k, n) -> Btn(n, selected = viz == k) { com.sonicforge.data.Store.set("recViz", k) } }
        }
        if (viz != "off") Row(Modifier.fillMaxWidth().padding(vertical = 8.dp).height(120.dp).clip(RoundedCornerShape(10.dp)).background(Color.Black.copy(.4f)).padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (viz == "both" || viz == "bar") androidx.compose.foundation.Canvas(Modifier.width(26.dp).fillMaxHeight()) {   // vertical level bar: green, yellow, red
                drawRect(Color.White.copy(.08f), androidx.compose.ui.geometry.Offset(0f, 0f), androidx.compose.ui.geometry.Size(size.width, size.height))
                val hgt = size.height * lvl
                drawRect(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color(0xFFE53935), Color(0xFFFFD54F), Color(0xFF43A047)), 0f, size.height), androidx.compose.ui.geometry.Offset(0f, size.height - hgt), androidx.compose.ui.geometry.Size(size.width, hgt))
            }
            if (viz == "both" || viz == "wave") androidx.compose.foundation.Canvas(Modifier.weight(1f).fillMaxHeight()) {   // scrolling waveform, newest on the right
                val n = 160; val bw = size.width / n; val mid = size.height / 2f
                for (i in 0 until hist.size) { val h = (hist[i] * size.height).coerceAtLeast(2f); val x = size.width - (hist.size - i) * bw
                    drawRect(Color(0xFF8C82FF), androidx.compose.ui.geometry.Offset(x, mid - h / 2f), androidx.compose.ui.geometry.Size((bw * .7f).coerceAtLeast(1f), h)) }
                drawLine(Color.White.copy(.25f), androidx.compose.ui.geometry.Offset(0f, mid), androidx.compose.ui.geometry.Offset(size.width, mid), 1f)
            }
        }
        if (msg.isNotEmpty()) Text(msg, color = Color(0xFFFFE082), fontSize = 12.sp, modifier = Modifier.padding(vertical = 4.dp))
        H("Recordings")
        SortBar()
        val liveOn = com.sonicforge.data.Store.b("recLive", true) && ctx.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED
        val spec = rememberLiveSpectrum(liveOn && playing.isNotEmpty(), { try { player?.audioSessionId ?: 0 } catch (_: Exception) { 0 } }, playing)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            val hasPerm = ctx.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED
            Btn(if (liveOn) "PREVIEW EQUALIZER: ON" else "PREVIEW EQUALIZER: OFF", selected = liveOn) { if (liveOn) com.sonicforge.data.Store.setB("recLive", false) else if (hasPerm) com.sonicforge.data.Store.setB("recLive", true) else permEq.launch(android.Manifest.permission.RECORD_AUDIO) }
            Text(if (!hasPerm) "Needs the microphone permission — press the button to allow it." else if (playing.isNotEmpty() && spec == null) "Real analyzer unavailable on this phone/recording: showing a pattern, not the real sound." else "Press ▶ on a recording: bars follow the real sound.", color = Color(0xCCFFFFFF), fontSize = 11.sp)
        }
        if (liveOn && playing.isNotEmpty()) androidx.compose.foundation.Canvas(Modifier.fillMaxWidth().height(90.dp).padding(vertical = 6.dp).clip(RoundedCornerShape(10.dp)).background(Color.Black.copy(.4f))) {
            val n = 28; val w = size.width / n
            for (i in 0 until n) { val a = if (spec != null) spec[i].coerceIn(0.03f, 1f) else (0.1f + 0.5f * kotlin.math.abs(kotlin.math.sin(System.nanoTime() / 2.5e8f + i * .7f)))
                drawRect(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color(0xFFFF6E9C), Color(0xFF8C82FF)), size.height * (1 - a), size.height), androidx.compose.ui.geometry.Offset(i * w + 2f, size.height * (1 - a)), androidx.compose.ui.geometry.Size(w - 4f, size.height * a)) }
        }
        if (files.isEmpty()) Text("Nothing recorded yet.", color = Color.White)
        files.forEach { f ->
            Row(Modifier.fillMaxWidth().padding(vertical = 2.dp).clip(RoundedCornerShape(10.dp)).background(Color.Black.copy(.35f)).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text(f.name, color = Color.White, fontSize = 12.sp); Text(Media.dateOf(f) + " · " + (f.length() / 1024) + " KB", color = Color(0xAAFFFFFF), fontSize = 9.sp) }
                Text(if (Media.isFav(f)) "★" else "☆", color = Color(0xFFFFD54F), modifier = Modifier.forgeClick { Media.toggleFav(f) }.padding(8.dp))
                Text(if (playing == f.name) "■" else "▶", color = Color.White, modifier = Modifier.forgeClick {
                    try { player?.release() } catch (_: Exception) {}; player = null
                    if (playing == f.name) playing = "" else try { player = MediaPlayer().apply { setDataSource(f.path); prepare(); start(); setOnCompletionListener { playing = "" } }; playing = f.name } catch (e: Exception) { msg = "Could not play: ${e.message}" } }.padding(10.dp))
                Text("↗", color = Color.White, modifier = Modifier.forgeClick { Media.share(ctx, f) }.padding(10.dp))
                Text("✕", color = Color(0xFFFFCDD2), modifier = Modifier.forgeClick { f.delete(); Media.tick++ }.padding(10.dp))
            }
        }
    }
}

/** "Open with SonicForge" / Share target: asks where the incoming file should go. */
@Composable
fun IncomingDialog(onGoto: () -> Unit) {
    val u = Media.incoming; val text = Media.incomingText
    if (u == null && text.isEmpty()) return
    val ctx = LocalContext.current
    val k = if (u == null) "txt" else Media.mimeKind(Media.incomingMime.ifEmpty { ctx.contentResolver.getType(u) ?: "" }).let { if (it == "other") Media.kind(Media.nameOf(ctx, u)) else it }
    fun done(sub: String) { Media.sub = sub; Media.incoming = null; Media.incomingText = ""; Media.incomingMime = ""; onGoto() }
    fun toFiles(sub: String, d: File) { if (u != null) Media.copyIn(ctx, u, d) else Media.unique(d, "Shared text.txt").writeText(text); done(sub) }
    Dialog(onDismissRequest = { Media.incoming = null; Media.incomingText = "" }) {
        Column(Modifier.clip(RoundedCornerShape(14.dp)).background(Color(0xFF1B1B22)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Where should this go?", color = Color.White, fontWeight = FontWeight.Black, fontSize = 16.sp)
            Text(if (u != null) Media.nameOf(ctx, u) else "Shared text", color = Color(0xCCFFFFFF), fontSize = 12.sp)
            when (k) {
                "img" -> {
                    Btn("📚 COMICS (new comic)") { if (u != null) { val d = File(Media.dir("comics"), Media.nameOf(ctx, u).substringBeforeLast('.').ifBlank { "Comic" }); Media.copyIn(ctx, u, d) }; done("comics") }
                    (Media.dir("comics").listFiles()?.filter { it.isDirectory } ?: emptyList()).take(6).forEach { c -> Btn("📚 add to comic: ${c.name}") { if (u != null) Media.copyIn(ctx, u, c); done("comics") } }
                    Btn("🖼 PICTURES") { toFiles("pictures", Media.dir("pictures")) }
                }
                "vid" -> Btn("🎞 VIDEO") { toFiles("video", Media.dir("video")) }
                "txt" -> Btn("📝 NOTES (text editor)") { toFiles("notes", Media.dir("notes")) }
                "aud" -> Btn("🎙 RECORDER folder (backing tracks)") { toFiles("rec", Media.dir("recordings")) }
            }
            Btn("📁 FILES (just keep it)") { toFiles("files", Media.root) }
            Btn("CANCEL") { Media.incoming = null; Media.incomingText = "" }
        }
    }
}
