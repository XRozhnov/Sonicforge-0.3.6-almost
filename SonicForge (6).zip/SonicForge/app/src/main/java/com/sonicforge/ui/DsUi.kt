package com.sonicforge.ui

import android.content.Context
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.sp
import com.sonicforge.core.Emu
import com.sonicforge.data.Store

/**
 * Nintendo DS (experimental). The core draws both screens into ONE picture; we only choose how they are arranged and forward touches on the lower screen.
 * Layouts: side by side, top/bottom, top/bottom with the real gap between the screens, and AUTO (picks by orientation / tablet). Written, not compiled, never run on a device.
 */
object Ds {
    /** the core option names differ between melonDS and DeSmuME, both are sent; a core ignores the names it does not know */
    fun coreOptions(ctx: Context): Map<String, String> {
        val land = ctx.resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
        val wideDp = ctx.resources.configuration.smallestScreenWidthDp
        var mode = Store.s("dsLayout", "auto")
        if (mode == "auto") mode = if (land) (if (wideDp >= 600 || Store.b("dsLandSide", false)) "lr" else "tb") else "tb"
        if (mode == "tablet") mode = if (land) "lr" else "tbgap"
        val gap = when (mode) { "tbgap" -> Store.i("dsGap", 46); "lr" -> 0; else -> Store.i("dsGapPlain", 0) }
        val m = LinkedHashMap<String, String>()
        val side = mode == "lr"
        m["melonds_screen_layout"] = if (side) "Left/Right" else "Top/Bottom"
        m["desmume_screens_layout"] = if (side) "left/right" else "top/bottom"
        if (!side) { m["melonds_screen_gap"] = gap.toString(); m["desmume_screens_gap"] = ((gap + 2) / 5 * 5).toString() }
        return m
    }
}

/** transparent layer over the picture: a finger on it becomes a stylus touch (the core reads the lower screen only) */
@Composable
fun DsTouchPad() {
    Box(Modifier.fillMaxSize().pointerInput(Unit) {
        awaitEachGesture {
            val w = size.width.coerceAtLeast(1); val h = size.height.coerceAtLeast(1)
            fun send(x: Float, y: Float, down: Boolean) { Emu.setPointer(((x / w).coerceIn(0f, 1f) * 65534f - 32767f).toInt(), ((y / h).coerceIn(0f, 1f) * 65534f - 32767f).toInt(), down) }
            val d = awaitFirstDown(requireUnconsumed = false)
            send(d.position.x, d.position.y, true)
            do {
                val ev = awaitPointerEvent()
                val c = ev.changes.firstOrNull() ?: break
                send(c.position.x, c.position.y, c.pressed)
                c.consume()
            } while (ev.changes.any { it.pressed })
            Emu.setPointer(0, 0, false)
        }
    })
}

@Composable
fun DsScreensDialog(onClose: () -> Unit) {
    AlertDialog(onDismissRequest = onClose, containerColor = Color(0xFF0D0D14), titleContentColor = Color.White, textContentColor = Color.White,
        confirmButton = { TextButton(onClose) { Text("CLOSE") } }, title = { Text("DS SCREENS (experimental)") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("Takes effect the next time the game starts. The picture keeps the DS proportions, so turn the phone to match: SIDE BY SIDE is for landscape, TOP / BOTTOM for portrait.", fontSize = 12.sp, color = Color(0xDDFFFFFF))
                SChips("Arrangement", "dsLayout", "auto", listOf("auto" to "AUTO", "lr" to "SIDE BY SIDE", "tb" to "TOP / BOTTOM", "tbgap" to "TOP / BOTTOM + REAL GAP", "tablet" to "TABLET"))
                Text("AUTO: landscape = side by side, portrait = top / bottom. TABLET: landscape = side by side, portrait = top / bottom with the real gap, which fills a tall tablet screen better.", fontSize = 11.sp, color = Color(0xCCFFFFFF))
                SSlider("Gap between the screens", "dsGap", 46, 126, " px")
                Text("A real DS has about 46 pixels of hinge between the screens (default). Used by TOP / BOTTOM + REAL GAP and TABLET in portrait.", fontSize = 11.sp, color = Color(0xCCFFFFFF))
                SToggle("Side by side in landscape on phones (AUTO)", "dsLandSide", false, "OFF (recommended): in landscape the two screens stay stacked in the middle and the buttons sit at the sides, so nothing covers the picture. ON: wide picture, the buttons lie over it.")
                SToggle("Plain picture frame (no rounded corners, no border)", "dsPlain", true, "Like the classic mode: sharp edges, no margin. Takes effect when the game starts.")
                H("Touch")
                Text("Touch the lower screen with a finger: it acts as the stylus. The on-screen pad gives the D-pad and A B X Y L R START SELECT.", fontSize = 12.sp, color = Color(0xFFFFE082))
            }
        })
}
