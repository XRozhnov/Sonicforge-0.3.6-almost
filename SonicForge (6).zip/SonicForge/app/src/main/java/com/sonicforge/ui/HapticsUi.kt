package com.sonicforge.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.runtime.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import com.sonicforge.input.Pads
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonicforge.data.Library
import com.sonicforge.data.Store
import com.sonicforge.input.Haptics
import kotlin.math.roundToInt

/** The vibration settings. Used in SETTINGS ▸ VIBRATION (full) and in the in-game menu (compact = same controls, no long explanations). */
@Composable
fun HapticsPanel(compact: Boolean) {
    val game = Haptics.currentGame
    H("Master switches")
    SToggle("Vibration: APP (menus & buttons)", "hapAppOn", true, if (compact) null else "Launcher taps. Independent from the emulator.")
    SToggle("Vibration: EMULATOR (touch buttons & game events)", "hapGameOn", true, if (compact) null else "Your per-event settings are kept when this is off.")
    H("Where it vibrates")
    if (!compact) Text("Phone = the phone's own motor · Controller = rumble of the connected controllers · Both · Off. Menus and the game are set separately, and a single game can override its own.", color = Color(0xE6FFFFFF), fontSize = 11.sp)
    val routes = listOf("phone" to "Phone", "pad" to "Controller", "both" to "Both", "off" to "Off")
    SChips("Menus & buttons (app)", "hapRouteApp", "phone", routes)
    SChips("Game (touch buttons & events)", "hapRouteGame", "phone", routes)
    if (game.isNotEmpty()) SChips("This game only", "hapRG_$game", "", listOf("" to "Same as above") + routes)
    val r1 = Haptics.routeApp(); val r2 = Haptics.routeGame()
    if ((r1 == "pad" || r1 == "both" || r2 == "pad" || r2 == "both") && Pads.devices.none { it.rumble })
        Text("⚠ No connected controller reports rumble, so nothing will buzz there. Use TEST DEVICES below.", color = Color(0xFFFFAB91), fontSize = 11.sp)
    H("Strength")
    if (!compact) Text("Each device has its own strength. NORMAL is a good everyday level; MAX pushes the motor as hard as Android allows. A controller needs more than a phone to be felt, so its NORMAL is already stronger than before.", color = Color(0xE6FFFFFF), fontSize = 11.sp)
    val lv = listOf("low" to "Low", "normal" to "Normal", "high" to "High", "max" to "Max")
    SChips("Phone strength", "hapPhoneLevel", "normal", lv)
    SChips("Controller strength", "hapPadLevel", "normal", lv)
    var adv by remember { mutableStateOf(false) }
    Btn(if (adv) "HIDE FINE TUNING" else "FINE TUNING (controller & phone)", selected = adv) { adv = !adv }
    if (adv) {
        SSlider("Phone: multiplier", "hapPhoneScale", 100, 300)
        SSlider("Controller: multiplier", "hapPadScale", 100, 400)
        SSlider("Controller: weakest buzz (0 = automatic)", "hapPadMin", 0, 255, "")
        SSlider("Controller: longer buzz", "hapPadDur", 100, 300)
        Text("Multiplier scales every event. Weakest buzz lifts small events above the motor's dead zone. Longer buzz helps pads that only support on / off. Use TEST DEVICES to feel the result.", color = Color(0xE6FFFFFF), fontSize = 11.sp)
    }
    TestDevices()
    if (compact && game.isNotEmpty()) {
        Library.roms.firstOrNull { it.id == game }?.let { GameHapticsPicker(it) }
    } else if (!compact) {
        H("Apply to these games")
        Text("Switch vibration off for a game without losing your settings.", color = Color(0xE6FFFFFF), fontSize = 11.sp)
        Library.roms.forEach { r ->
            Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text(r.title, color = Color.White, maxLines = 1); Text(com.sonicforge.core.Systems.byId(r.sys).label + if (r.sys in setOf("md", "scd")) "" else " (touch buttons only)", color = Color(0xCCFFFFFF), fontSize = 11.sp) }
                Switch(Store.s("hapG_${r.id}", "1") != "0", { Store.set("hapG_${r.id}", if (it) "1" else "0") }) }
        }
    }
    H("Templates & presets")
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Btn("QUIET") { Haptics.template("quiet") }; Btn("MEDIUM") { Haptics.template("medium") }; Btn("MAX") { Haptics.template("max") } }
    Text("Built-in presets: 1 = rings + buttons only · 2 = classic set · 3 = everything. 4-9 are empty slots for you.", color = Color(0xE6FFFFFF), fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        for (n in 1..9) Btn(if (n <= 3) "$n" else if (Haptics.presetExists(n)) "$n" else "$n ∅", color = if (n <= 3) Color(0xFF26C6DA) else null) { Haptics.loadPreset(n) } }
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("SAVE CURRENT TO", color = Skins.current().accent, fontSize = 11.sp, fontWeight = FontWeight.Bold); for (n in 4..9) Btn("$n") { Haptics.savePreset(n) } }
    if (!compact) { SSlider("App vibration strength", "hapApp", 35); Btn("TEST APP VIBRATION") { Haptics.test("ui"); Store.events.tryEmit(com.sonicforge.data.SaveEvent("Test buzz sent at ${Store.i("hapApp", 35)}%. If you felt nothing: raise the strength, or check that vibration is on in your phone's settings.", true)) } }
    Btn("RESET ALL VIBRATION VALUES") { Store.set("hapApp", ""); Haptics.events.forEach { Store.set("hapE_${it.id}_amp", "") }; Store.events.tryEmit(com.sonicforge.data.SaveEvent("Vibration strengths reset to their defaults", true)) }
    H("Events (on/off + strength)")
    Haptics.events.forEach { e ->
        val amp = Haptics.evAmp(e.id)
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Switch(Haptics.evOn(e.id), { Store.setB("hapE_${e.id}_on", it) })
            Spacer(Modifier.width(6.dp))
            Column(Modifier.weight(1f)) { SSlider(e.label, "hapE_${e.id}_amp", Haptics.defAmp(e.id), 100, "%") }
            Btn("▶") { Haptics.test(e.id) }
        }
    }
    if (!compact) {
        SToggle("Footsteps (experimental)", "hapSteps", false, "A tick for each step; pace follows running speed (faster with speed shoes). Works on Sonic 1/2 profiles only.")
        SSlider("Footstep calibration (match the sprite's steps)", "hapStepCal", 100, 200, "%")
        H("What works where")
        Text("• Mega Drive: Sonic 1, 2 (full), 3 & Knuckles (rings/lives; advanced events are experimental), ROM hacks (best effort).\n• Sega CD, 32X, GBA, Master System, Game Gear: touch-button vibration only.\n• Ring bite/drain: any game whose ring counter drops in small steps (for example robotic piranhas that steal rings).\n• The app reads the game's memory, it can't know about events in unknown games. Wrong addresses can cause odd buzzing: switch the event off or the game's profile to Off in ✎ EDIT.", color = Color(0xCCFFFFFF), fontSize = 11.sp)
    }
}

/** Buzzes the phone and every controller one by one so you can see which of them really vibrates, and remembers your answer. */
@Composable
fun TestDevices() {
    val scope = rememberCoroutineScope(); var now by remember { mutableStateOf("") }
    H("Test devices")
    Text("TEST buzzes one device for about half a second. Then tell the app whether you felt it, so you know which device to choose above.", color = Color(0xE6FFFFFF), fontSize = 11.sp)
    val tg = Haptics.targets()
    tg.forEach { t ->
        val ans = Store.s("hapOk_" + t.label)
        Column(Modifier.fillMaxWidth().padding(vertical = 3.dp).background(Color.Black.copy(.3f)).padding(8.dp)) {
            Text(t.label + if (now == t.id) "   ◀ buzzing now" else "", color = Color.White, fontWeight = FontWeight.Bold)
            Text(if (!t.supported) "Not supported: " + t.note else "Android reports a motor" + (if (t.amplitude) " with adjustable strength" else " (on/off only, strength setting has no effect)"),
                color = if (t.supported) Color(0xFF69F0AE) else Color(0xFFFFAB91), fontSize = 11.sp)
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                if (t.supported) Btn("TEST") { Haptics.testTarget(t) }
                if (t.supported) { Btn("I FELT IT", selected = ans == "1") { Store.set("hapOk_" + t.label, "1") }; Btn("NOTHING", selected = ans == "0") { Store.set("hapOk_" + t.label, "0") } }
                if (ans == "0" && t.supported) Text("Android says it can, but you felt nothing: the phone or pad ignores the request.", color = Color(0xFFFFCC80), fontSize = 11.sp)
            }
        }
    }
    Btn("TEST ALL, ONE AFTER ANOTHER", Modifier.padding(top = 4.dp)) {
        scope.launch { for (t in Haptics.targets()) { if (!t.supported) continue; now = t.id; Haptics.testTarget(t); delay(1400) }; now = "" } }
}

/** SETTINGS ▸ VIBRATION ▸ rules for any game: ROM hacks, other Sega games, NES, SNES, Game Boy ... */
@Composable
fun VibRulesEditor() {
    var romId by remember { mutableStateOf(Library.roms.firstOrNull()?.id ?: "") }
    var tick by remember { mutableIntStateOf(0) }
    var name by remember { mutableStateOf("") }; var addr by remember { mutableStateOf("") }; var value by remember { mutableStateOf("0") }
    var size by remember { mutableStateOf(1) }; var trig by remember { mutableStateOf("up") }; var ev by remember { mutableStateOf("ring") }
    H("Vibration rules for any game")
    Text("For ROM hacks, other Sega games and other consoles (NES, SNES, Game Boy...): tell the app which number in the game's memory to watch (for example the ring, coin or life counter) and which vibration to play when it changes. Addresses are offsets in the console's work RAM (Mega Drive: \$FFxxxx = xxxx). Rules are saved per game.", color = Color(0xE6FFFFFF), fontSize = 11.sp)
    if (Library.roms.isEmpty()) { Text("Add a game first.", color = Color.White); return }
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Library.roms.filter { it.sys != "bor" && it.sys != "flash" }.forEach { r -> val n = com.sonicforge.core.VibRules.load(r.id).size; Btn(r.title + if (n > 0) " ($n)" else "", selected = romId == r.id) { romId = r.id } }
    }
    val rom = Library.roms.firstOrNull { it.id == romId } ?: return
    @Suppress("UNUSED_VARIABLE") val t = tick
    val rules = com.sonicforge.core.VibRules.load(romId)
    if (rules.isEmpty()) Text("No rules for ${rom.title} yet.", color = Color(0xCCFFFFFF), fontSize = 12.sp)
    rules.forEachIndexed { i, r ->
        Row(Modifier.fillMaxWidth().padding(vertical = 2.dp).background(Color.Black.copy(.3f), androidx.compose.foundation.shape.RoundedCornerShape(8.dp)).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("${r.label}: \$${r.addr.toString(16).uppercase()} (${r.size} byte) ${when (r.trig) { "up" -> "rises"; "down" -> "falls"; "change" -> "changes"; "eq" -> "becomes ${r.value}"; else -> "drops below ${r.value}" }} → ${Haptics.events.firstOrNull { it.id == r.event }?.label ?: r.event}", color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Text("TEST", color = Color(0xFF69F0AE), fontSize = 12.sp, modifier = Modifier.clickable { Haptics.test(r.event) }.padding(8.dp))
            Text("✕", color = Color(0xFFFFCDD2), modifier = Modifier.clickable { com.sonicforge.core.VibRules.save(romId, rules.filterIndexed { j, _ -> j != i }); tick++ }.padding(8.dp))
        }
    }
    val sug = com.sonicforge.core.VibRules.suggestions.filter { it.sys == rom.sys }
    if (sug.isNotEmpty()) {
        Text("Suggested starting points for this console (written from memory, not verified: test them):", color = Color(0xFFFFCC80), fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
        sug.forEach { s -> Btn("ADD: ${s.game}") { com.sonicforge.core.VibRules.save(romId, rules + s.rules); tick++ } }
    }
    H("New rule")
    Text("Name", color = Color.White, fontSize = 11.sp)
    androidx.compose.foundation.text.BasicTextField(name, { name = it }, singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 14.sp), cursorBrush = androidx.compose.ui.graphics.SolidColor(Color.White), modifier = Modifier.fillMaxWidth().background(Color.White.copy(.1f), androidx.compose.foundation.shape.RoundedCornerShape(8.dp)).padding(8.dp))
    Text("RAM address in hex (for example 075E)", color = Color.White, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
    androidx.compose.foundation.text.BasicTextField(addr, { addr = it.filter { c -> c.isLetterOrDigit() }.take(6) }, singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 14.sp), cursorBrush = androidx.compose.ui.graphics.SolidColor(Color.White), modifier = Modifier.fillMaxWidth().background(Color.White.copy(.1f), androidx.compose.foundation.shape.RoundedCornerShape(8.dp)).padding(8.dp))
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Btn("1 byte", selected = size == 1) { size = 1 }; Btn("2 bytes", selected = size == 2) { size = 2 }
        listOf("up" to "rises", "down" to "falls", "change" to "changes", "eq" to "becomes value", "below" to "drops below value").forEach { (k, n) -> Btn(n, selected = trig == k) { trig = k } }
    }
    if (trig == "eq" || trig == "below") { Text("Value (number)", color = Color.White, fontSize = 11.sp)
        androidx.compose.foundation.text.BasicTextField(value, { value = it.filter { c -> c.isDigit() }.take(6) }, singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 14.sp), cursorBrush = androidx.compose.ui.graphics.SolidColor(Color.White), modifier = Modifier.fillMaxWidth().background(Color.White.copy(.1f), androidx.compose.foundation.shape.RoundedCornerShape(8.dp)).padding(8.dp)) }
    Text("Vibration to play", color = Color.White, fontSize = 11.sp)
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Haptics.events.filter { it.id != "touch" }.forEach { e -> Btn(e.label, selected = ev == e.id) { ev = e.id } }
    }
    Btn("ADD RULE", selected = true) {
        val a = addr.toIntOrNull(16)
        if (a != null) { com.sonicforge.core.VibRules.save(romId, rules + com.sonicforge.core.VibRule(name.ifBlank { "Rule " + (rules.size + 1) }, a, size, trig, value.toIntOrNull() ?: 0, ev)); name = ""; addr = ""; tick++ }
    }
    Text("Tip: a rule only works when the game's memory really holds that number there. A ROM hack usually keeps the original layout; if nothing happens, check the address in a RAM-search tool.", color = Color(0x99FFFFFF), fontSize = 10.sp)
}

/** Where does THIS game's vibration come from, and which preset does it use? One place, reachable from the game page, the TILES menu and the in-game menu. Written, not compiled. */
@Composable
fun GameHapticsPicker(rom: com.sonicforge.data.Rom) {
    var tick by remember { mutableIntStateOf(0) }
    @Suppress("UNUSED_VARIABLE") val t = tick
    val cur = Haptics.gamePreset(rom.id); val gm = Store.s("hapAudio_${rom.id}", "")
    val ram = com.sonicforge.core.Watch.byId(rom.profile, rom.rings, rom.lives) != null; val rules = com.sonicforge.core.VibRules.effective(rom).size
    val glob = com.sonicforge.core.AudioHaptics.mode()
    val sound = when { rom.sys == "flash" || gm == "off" || glob == "off" && gm != "on" -> "off"; gm == "on" || glob == "always" -> "full"; ram || rules > 0 -> "assist"; else -> "full" }
    H("Vibration for this game")
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("Vibration for THIS game", color = Color.White, modifier = Modifier.weight(1f))
        Switch(Store.s("hapG_${rom.id}", "1") != "0", { Store.set("hapG_${rom.id}", if (it) "1" else "0"); tick++ }) }
    Text("Where the buzzes come from:", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    Text("• Touch buttons: always (if EMULATOR vibration is on).", color = Color(0xE6FFFFFF), fontSize = 11.sp)
    Text(if (ram) "• Game memory map (${rom.profile}): exact events such as rings, hits, jumps, springs, shields, water." else if (rules > 0) "• $rules memory rule(s) for this game." else "• No memory map for this game.", color = if (ram || rules > 0) Color(0xFFC5E1A5) else Color(0xCCFFFFFF), fontSize = 11.sp)
    Text(when (sound) { "full" -> "• The game's SOUND: a loud sudden sound makes a buzz (deep = hit, bright = pickup). This is where buzzes in games without a map come from."; "assist" -> "• The game's SOUND adds explosions only (monitors, enemies), on top of the memory map."; else -> "• Sound haptics: off." }, color = Color(0xE6FFFFFF), fontSize = 11.sp)
    Text("Preset for this game (the global settings stay untouched):", color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Btn("GLOBAL", selected = cur == 0) { Haptics.setGamePreset(rom.id, 0); tick++ }
        for (n in 1..9) if (Haptics.presetExists(n)) Btn(if (n == 1) "1 rings" else if (n == 2) "2 classic" else if (n == 3) "3 everything" else "$n", selected = cur == n) { Haptics.setGamePreset(rom.id, n); tick++ }
    }
    Text("Sound for this game:", color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Btn("DEFAULT", selected = gm == "") { Store.set("hapAudio_${rom.id}", ""); tick++ }; Btn("ALWAYS ON", selected = gm == "on") { Store.set("hapAudio_${rom.id}", "on"); tick++ }; Btn("OFF", selected = gm == "off") { Store.set("hapAudio_${rom.id}", "off"); tick++ }
    }
    if (rom.sys in setOf("md", "x32", "scd")) {
        Text("Memory map:", color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("auto" to "AUTO", "s1" to "Sonic 1", "s2" to "Sonic 2", "s3k" to "Sonic 3 / S&K", "off" to "NONE").forEach { (k, n) -> Btn(n, selected = rom.profile == k) { Library.update(rom.copy(profile = k)); tick++ } }
        }
    }
    Text("Tip: with the ENGINE LOG on, every buzz is written as a line (rule / audio / ring ...), so you can see what caused it.", color = Color(0x99FFFFFF), fontSize = 10.sp)
}

@Composable
fun GameHapticsDialog(rom: com.sonicforge.data.Rom, onClose: () -> Unit) {
    androidx.compose.material3.AlertDialog(onDismissRequest = onClose, containerColor = Color(0xFF0D0D14), titleContentColor = Color.White, textContentColor = Color.White,
        confirmButton = { androidx.compose.material3.TextButton(onClose) { Text("CLOSE") } }, title = { Text(rom.title, maxLines = 1) },
        text = { Column(Modifier.verticalScroll(rememberScrollState())) { GameHapticsPicker(rom) } })
}

@Composable
fun AudioHapticsPanel() {
    H("Vibration from the game's sound (every console)")
    SChips("Sound haptics", "audioHap", "auto", listOf("off" to "OFF", "auto" to "AUTO (games without their own profile)", "always" to "ALWAYS"))
    SSlider("Sensitivity", "audioHapSens", 5, 10, "")
    SToggle("Sound adds explosions to games with a memory map", "audioAssist", true, "Monitors, enemies and bosses popping: the memory map cannot see them, the sound can.")
    SToggle("Use suggested memory rules automatically (Mario NES / SNES)", "hapAutoRules", true, "Starting points written from memory, not verified: switch off if a game buzzes at the wrong moments.")
    SToggle("Sonic 3 & Knuckles: advanced map (shields, water)", "hapAdvS3k", true, "Experimental: reads more of the game's memory and can misfire.")
    Text("Games the app knows by memory (the first Sonic games and a few hacks) keep their exact events. Every other game, on any console, buzzes when something loud and sudden happens: a deep boom = a hit or explosion, a bright blip = a pickup, other sudden sounds = an action. It reacts to sound, so it cannot tell what really happened; lower the sensitivity if it buzzes too much. Takes effect when a game starts.", color = Color(0xCCFFFFFF), fontSize = 11.sp)
}
