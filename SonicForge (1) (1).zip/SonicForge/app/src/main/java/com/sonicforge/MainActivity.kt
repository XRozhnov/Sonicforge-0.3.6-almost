package com.sonicforge

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.sonicforge.audio.Music
import com.sonicforge.audio.MusicService
import com.sonicforge.data.Rom
import com.sonicforge.data.Store
import com.sonicforge.input.Pads
import com.sonicforge.ui.*

class MainActivity : ComponentActivity() {
    private var pendingDocs: ((List<Uri>) -> Unit)? = null
    private var pendingCreate: ((Uri) -> Unit)? = null
    private var pendingTree: ((Uri) -> Unit)? = null
    private var pendingText: ((Uri) -> Unit)? = null
    private var startTab by mutableStateOf("games")
    private val docs = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { u -> pendingDocs?.invoke(u); pendingDocs = null }
    private val create = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { u -> if (u != null) pendingCreate?.invoke(u); pendingCreate = null }
    private val createText = registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { u -> if (u != null) pendingText?.invoke(u); pendingText = null }
    private val tree = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u -> if (u != null) pendingTree?.invoke(u); pendingTree = null }
    private val notif = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        com.sonicforge.ui.Tv.init(this)
        Picker.launcher = { mime, cb -> pendingDocs = cb; docs.launch(mime) }
        Picker.creator = { name, cb -> pendingCreate = cb; create.launch(name) }
        Picker.tree = { cb -> pendingTree = cb; tree.launch(null) }
        Picker.textCreator = { name, cb -> pendingText = cb; createText.launch(name) }
        handleIntent(intent)
        if (Build.VERSION.SDK_INT >= 33 && Store.b("musicNotif", true) && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED && !Store.b("notifAsked", false)) { Store.setB("notifAsked", true); notif.launch(Manifest.permission.POST_NOTIFICATIONS) }
        if (Store.s("crashPending") == "1") { Store.setRaw("crashPending", ""); Toast.makeText(this, "The app closed unexpectedly last time. Details: SETTINGS ▸ ABOUT APP, tap the version 5 times.", Toast.LENGTH_LONG).show() }
        setContent {
            val skin = Skins.current()
            val o = Store.s("orientLauncher", "auto")
            LaunchedEffect(o) { requestedOrientation = Orient.flag(o) }
            val imm = Store.s("immLauncher", "off")
            LaunchedEffect(imm) { applyBars(imm) }
            ForgeTheme(skin) { UiScale.Provide { App(skin, startTab) { rom -> play(rom) } } }
        }
    }
    override fun onResume() { super.onResume(); Music.onChange = { if (Music.playing) MusicService.ensure(applicationContext); MusicService.live?.refresh() } }
    private fun applyBars(mode: String) {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        when (mode) { "full" -> c.hide(WindowInsetsCompat.Type.systemBars()); "status" -> { c.hide(WindowInsetsCompat.Type.statusBars()); c.show(WindowInsetsCompat.Type.navigationBars()) }
            "nav" -> { c.hide(WindowInsetsCompat.Type.navigationBars()); c.show(WindowInsetsCompat.Type.statusBars()) }; else -> c.show(WindowInsetsCompat.Type.systemBars()) }
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); handleIntent(intent) }
    /** the quick-settings tiles start the app with extras: "tab" opens a tab, "play" starts a game */
    private fun handleIntent(i: Intent?) {
        i ?: return
        if (i.action == Intent.ACTION_VIEW || i.action == Intent.ACTION_SEND) {   // "Open with SonicForge" / Share: ask where it goes
            val u: android.net.Uri? = if (i.action == Intent.ACTION_SEND) (if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_STREAM, android.net.Uri::class.java) else @Suppress("DEPRECATION") i.getParcelableExtra<android.net.Uri>(Intent.EXTRA_STREAM)) else i.data
            if (u != null) { com.sonicforge.ui.Media.incomingMime = i.type ?: ""; com.sonicforge.ui.Media.incoming = u }
            else i.getStringExtra(Intent.EXTRA_TEXT)?.let { com.sonicforge.ui.Media.incomingText = it }
            i.action = null
        }
        i.getStringExtra("tab")?.let { startTab = it; i.removeExtra("tab") }
        i.getStringExtra("play")?.let { id -> i.removeExtra("play"); com.sonicforge.data.Library.roms.firstOrNull { it.id == id }?.let { r -> window.decorView.post { play(r) } } }
    }
    private fun play(r: Rom) {
        Store.set("lastGame", r.id); com.sonicforge.data.Recents.note(r)
        if (r.sys == "bor") { OpenBor.launch(this, r); return }
        if (r.sys == "flash") { startActivity(Intent(this, FlashActivity::class.java).putExtra("rom", r.id)); return }
        startActivity(Intent(this, GameActivity::class.java).putExtra("rom", r.id))
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN) Pads.lastKey = Pads.keyName(e.keyCode)
        if (Pads.intercept(e)) return true
        val cap = Pads.capture
        if (cap != null && e.action == KeyEvent.ACTION_DOWN && e.keyCode != KeyEvent.KEYCODE_BACK) { cap(e.keyCode); return true }
        // controller navigation in the launcher: A / ✕ presses the highlighted item, B / ○ goes back
        if (Store.b("padNav", true) && Pads.captureEv == null && com.sonicforge.input.Profiles.isGamepad(e)) {
            val m = when (e.keyCode) { KeyEvent.KEYCODE_BUTTON_A -> KeyEvent.KEYCODE_DPAD_CENTER; KeyEvent.KEYCODE_BUTTON_B -> KeyEvent.KEYCODE_BACK; else -> 0 }
            if (m != 0) return super.dispatchKeyEvent(KeyEvent(e.action, m))
        }
        return super.dispatchKeyEvent(e)
    }
}

@Composable
private fun App(skin: Skin, startTab: String, onPlay: (Rom) -> Unit) {
    var tab by remember(startTab) { mutableStateOf(startTab) }
    val lbg = rememberBitmap(Store.s("launcherBg").ifEmpty { null })
    LaunchedEffect(Unit) { if (!Store.b("guideSeen", false)) Guide.show = true }
    BackHandler(enabled = Guide.show) { Guide.show = false }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val mode = UiMode.id()
    Box(Modifier.fillMaxSize().skinBg(skin)) {
        ThemeBackdrop(mode)
        if (lbg != null && mode == "normal") { AnyPicture(Store.s("launcherBg"), Modifier.fillMaxSize(), ContentScale.Crop); Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = Store.i("launcherDim", 45) / 100f))) }
        for (ly in listOf("bg", "bo", "gr", "ch", "fg")) StyleLayer(ly, mode, false)
        if (mode == "normal") Particles(skin.deco)
        Column(Modifier.fillMaxSize().systemBarsPadding()) {
            NavBar(mode, tab) { tab = it; if (it == "music") { MiniHide.hidden = false; MiniHide.closed = false } }   // opening MUSIC always brings the mini player back (second way to recover it)
            if (tab != "music") MiniPlayerBar(onOpen = { tab = "music" })
            // Mania: in landscape the frame is thinner and has no outer margin, so the game list gets all the room (the slanted shapes are only background)
            val landM = androidx.compose.ui.platform.LocalConfiguration.current.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
            val panel = if (mode == "mania") (if (landM) Modifier.padding(horizontal = 2.dp).background(Color(0xCC0A1F52)).border(1.dp, Color.Black) else Modifier.padding(horizontal = 10.dp, vertical = 6.dp).background(Color(0xEE0A1F52)).border(3.dp, Color.Black)) else Modifier
            Box(Modifier.weight(1f).then(panel)) {
                when (tab) {
                    "games" -> if (mode == "tiles" || mode == "jolt" || mode == "itch") TilesGames(onPlay) else LauncherScreen(onPlay)
                    "mini" -> MiniGamesScreen(); "media" -> MediaScreen(); "music" -> MusicScreen(); "draw" -> DrawScreen(); "custom" -> CustomizeScreen()
                    "locations" -> LocationsScreen(); "help" -> HelpScreen { tab = it }; else -> SettingsScreen()
                }
            }
            if (mode == "tiles") TilesHintBar { tab = it }
        }
        for (ly in listOf("bg", "bo", "gr", "ch", "fg")) StyleLayer(ly, mode, true)
        SaveIndicator(Modifier.align(Alignment.TopEnd).systemBarsPadding().padding(top = 52.dp, end = 8.dp))
        PreviewOverlay()
        MiniChip(Modifier.align(Alignment.BottomEnd).systemBarsPadding().padding(bottom = if (mode == "tiles") 64.dp else 12.dp, end = 12.dp))
        SeasonalOverlay()
        IncomingDialog { tab = "media" }
        GuideOverlay { tab = it }
        com.sonicforge.ui.EngineLogStrip(Modifier.align(Alignment.BottomCenter).systemBarsPadding())
        StartupSplash()
    }
}
