package com.sonicforge.ui

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.os.Build
import android.widget.VideoView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.sonicforge.data.Store
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

private val thumbCache = HashMap<String, ImageBitmap>()

/** a small picture taken from the video itself (a frame about a tenth into the movie), cached while the app runs. Written, not compiled. */
@Composable
fun VideoThumb(f: File, modifier: Modifier) {
    val bmp by produceState<ImageBitmap?>(thumbCache[f.path], f.path) {
        if (value == null) value = withContext(Dispatchers.IO) {
            try {
                val r = MediaMetadataRetriever(); r.setDataSource(f.path)
                val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                val b = r.getFrameAtTime((d * 100L).coerceIn(0L, 5_000_000L), MediaMetadataRetriever.OPTION_CLOSEST_SYNC); r.release()
                if (b == null) null else { val s = Bitmap.createScaledBitmap(b, 240, (240f * b.height / b.width.coerceAtLeast(1)).toInt().coerceAtLeast(1), true); val x = s.asImageBitmap(); thumbCache[f.path] = x; x }
            } catch (_: Throwable) { null }
        }
    }
    val b = bmp
    if (b != null) Image(b, null, modifier, contentScale = ContentScale.Crop) else Box(modifier.background(Color.White.copy(.08f)), Alignment.Center) { Text("▶", color = Color.White.copy(.6f), fontSize = 18.sp) }
}

private fun fmt(ms: Int): String { val s = (ms / 1000).coerceAtLeast(0); return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, s / 60 % 60, s % 60) else "%d:%02d".format(s / 60, s % 60) }

/**
 * Full-screen video player: tap = show/hide the controls, double tap on the left/right half = 10 s back/forward, seek bar, previous/next,
 * speed 0.25x..3x, frame-by-frame (while paused), volume and mute, loop, resume where you stopped. Written, not compiled, never run on a device.
 */
@Composable
fun VideoPlayerDialog(files: List<File>, start: Int, onClose: () -> Unit) {
    var idx by remember { mutableIntStateOf(start.coerceIn(0, (files.size - 1).coerceAtLeast(0))) }
    val f = files.getOrNull(idx)
    if (f == null) { LaunchedEffect(Unit) { onClose() }; return }
    var vv by remember { mutableStateOf<VideoView?>(null) }
    var mp by remember { mutableStateOf<MediaPlayer?>(null) }
    var playing by remember { mutableStateOf(true) }
    var pos by remember { mutableIntStateOf(0) }; var dur by remember { mutableIntStateOf(0) }
    var speed by remember { mutableFloatStateOf(Store.s("vidSpeed", "1").toFloatOrNull() ?: 1f) }
    var vol by remember { mutableFloatStateOf(Store.i("vidVol", 100) / 100f) }
    var muted by remember { mutableStateOf(false) }
    var loop by remember { mutableStateOf(Store.b("vidLoop", false)) }
    var fps by remember { mutableIntStateOf(Store.i("vidFps", 30)) }
    var show by remember { mutableStateOf(true) }; var lastTouch by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var seeking by remember { mutableStateOf(false) }; var seekVal by remember { mutableFloatStateOf(0f) }
    var msg by remember { mutableStateOf("") }
    fun touched() { lastTouch = System.currentTimeMillis(); show = true }
    fun applyParams() {
        val m = mp ?: return
        try {
            val v = if (muted) 0f else vol; m.setVolume(v, v); m.isLooping = loop
            if (Build.VERSION.SDK_INT >= 23) { m.playbackParams = m.playbackParams.setSpeed(speed.coerceIn(.1f, 4f)); if (!playing) m.pause() }
        } catch (_: Exception) {}
    }
    fun seekMs(t: Int) {
        val v = vv ?: return; val to = t.coerceIn(0, (v.duration - 1).coerceAtLeast(0))
        try { if (Build.VERSION.SDK_INT >= 26 && mp != null) mp?.seekTo(to.toLong(), MediaPlayer.SEEK_CLOSEST) else v.seekTo(to) } catch (_: Exception) { v.seekTo(to) }
        pos = to
    }
    fun togglePlay() { val v = vv ?: return; if (v.isPlaying) { v.pause(); playing = false } else { v.start(); playing = true; applyParams() } }
    fun step(dir: Int) { val v = vv ?: return; if (v.isPlaying) { v.pause(); playing = false }; seekMs(v.currentPosition + dir * (1000 / fps.coerceAtLeast(1))) }
    fun savePos() { vv?.let { v -> val p = v.currentPosition; Store.set("vidPos_" + f.name, if (p > v.duration - 3000) "0" else p.toString()) } }
    LaunchedEffect(vv, idx) {
        var n = 0
        while (true) {
            vv?.let { v -> try { if (!seeking) { pos = v.currentPosition; dur = v.duration.coerceAtLeast(0); playing = v.isPlaying } } catch (_: Exception) {} }
            if (show && playing && System.currentTimeMillis() - lastTouch > 3500) show = false
            if (++n % 20 == 0) savePos()
            delay(250)
        }
    }
    LaunchedEffect(speed, vol, muted, loop, mp) { applyParams(); Store.set("vidSpeed", speed.toString()); Store.set("vidVol", (vol * 100).toInt().toString()); Store.setB("vidLoop", loop) }
    Dialog(onDismissRequest = { savePos(); onClose() }, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            key(idx) {
                AndroidView(factory = { c ->
                    VideoView(c).also { v ->
                        vv = v; v.keepScreenOn = true
                        v.setOnPreparedListener { m ->
                            mp = m; dur = v.duration; val p = Store.i("vidPos_" + f.name, 0); if (p > 2000 && p < v.duration - 3000) v.seekTo(p)
                            v.start(); playing = true; applyParams()
                        }
                        v.setOnCompletionListener { if (!loop) { if (idx < files.size - 1) idx++ else { playing = false; show = true } } }
                        v.setOnErrorListener { _, w, e -> msg = "This phone cannot play this file ($w/$e)."; true }
                        v.setVideoPath(f.path)
                    }
                }, modifier = Modifier.fillMaxSize().align(Alignment.Center), onRelease = { try { it.stopPlayback() } catch (_: Throwable) {} })
            }
            Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures(onTap = { if (show) show = false else touched() }, onDoubleTap = { o -> touched(); val v = vv; if (v != null) seekMs(v.currentPosition + (if (o.x < size.width / 2) -10000 else 10000)) }) })
            if (msg.isNotEmpty()) Text(msg, color = Color(0xFFFFAB91), modifier = Modifier.align(Alignment.Center).padding(24.dp))
            if (show) {
                Row(Modifier.align(Alignment.TopStart).fillMaxWidth().background(Color(0x99000000)).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(f.name + "   (${idx + 1}/${files.size})", color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f), maxLines = 1)
                    Btn("✕ CLOSE") { savePos(); onClose() }
                }
                Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color(0xB3000000)).padding(horizontal = 10.dp, vertical = 6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(fmt(if (seeking) seekVal.toInt() else pos), color = Color.White, fontSize = 11.sp)
                        Slider(value = (if (seeking) seekVal else pos.toFloat()).coerceIn(0f, dur.coerceAtLeast(1).toFloat()), onValueChange = { seeking = true; seekVal = it; touched() },
                            onValueChangeFinished = { seekMs(seekVal.toInt()); seeking = false }, valueRange = 0f..dur.coerceAtLeast(1).toFloat(), modifier = Modifier.weight(1f).padding(horizontal = 8.dp))
                        Text(fmt(dur), color = Color.White, fontSize = 11.sp)
                    }
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                        Btn("⏮") { if (idx > 0) idx-- }; Btn("⏪ 10") { touched(); seekMs(pos - 10000) }; Btn("◂|") { touched(); step(-1) }
                        Btn(if (playing) "⏸ PAUSE" else "▶ PLAY", selected = true) { touched(); togglePlay() }
                        Btn("|▸") { touched(); step(1) }; Btn("10 ⏩") { touched(); seekMs(pos + 10000) }; Btn("⏭") { if (idx < files.size - 1) idx++ }
                        Btn(if (loop) "🔁 LOOP ON" else "🔁 LOOP", selected = loop) { touched(); loop = !loop }
                        Btn(if (muted) "🔇 MUTED" else "🔊", selected = muted) { touched(); muted = !muted }
                    }
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("SPEED", color = Color.White, fontSize = 10.sp)
                        listOf(.25f, .5f, .75f, 1f, 1.25f, 1.5f, 2f, 3f).forEach { s -> Btn((if (s == s.toInt().toFloat()) s.toInt().toString() else s.toString()) + "×", selected = speed == s) { touched(); speed = s } }
                        Text("FRAME STEP", color = Color.White, fontSize = 10.sp, modifier = Modifier.padding(start = 8.dp))
                        listOf(24, 25, 30, 50, 60).forEach { n -> Btn("$n", selected = fps == n) { touched(); fps = n; Store.set("vidFps", n.toString()) } }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("VOLUME ${(vol * 100).toInt()}%", color = Color.White, fontSize = 10.sp)
                        Slider(value = vol, onValueChange = { vol = it; muted = false; touched() }, valueRange = 0f..1f, modifier = Modifier.weight(1f).padding(horizontal = 8.dp))
                    }
                    Text("Tap: show / hide · double tap left / right: 10 s back / forward · ◂| |▸ step one frame (video pauses) · the position is remembered", color = Color(0x99FFFFFF), fontSize = 9.sp)
                }
            }
        }
    }
}
