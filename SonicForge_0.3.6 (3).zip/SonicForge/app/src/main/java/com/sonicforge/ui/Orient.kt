package com.sonicforge.ui

import android.content.pm.ActivityInfo
import android.view.Gravity
import android.view.OrientationEventListener
import android.view.Surface
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonicforge.data.Store

object Orient {
    fun flag(s: String) = when (s) {
        "landscape" -> ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        "landscape_rev" -> ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE
        "portrait" -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        "portrait_rev" -> ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT
        "ask" -> ActivityInfo.SCREEN_ORIENTATION_LOCKED   // stays as it is until you confirm the rotation with the ⟳ button
        else -> ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
    }
    fun flipped(s: String) = when (s) { "landscape" -> "landscape_rev"; "landscape_rev" -> "landscape"; "portrait" -> "portrait_rev"; "portrait_rev" -> "portrait"; else -> "landscape_rev" }

    private fun current(a: ComponentActivity): String = when (@Suppress("DEPRECATION") a.windowManager.defaultDisplay.rotation) {
        Surface.ROTATION_90 -> "landscape"; Surface.ROTATION_180 -> "portrait_rev"; Surface.ROTATION_270 -> "landscape_rev"; else -> "portrait" }

    /**
     * Rotation prompt. Mode "ask": the screen stays put and a ⟳ ROTATE button appears when the phone is turned; it rotates only after a tap.
     * Fixed modes (landscape / portrait / flipped): if the switch "rotHint" is ON (default) the same small button offers the turn when the phone is
     * held the other way, then hides itself after "rotHintSec" seconds (default 8, 0 = stays until the phone is turned back).
     * Drawn last = above everything, but small and in a corner so it covers nothing. Written, not compiled, not tried on a device.
     */
    fun installAsk(a: ComponentActivity, key: () -> String) {
        var sugg by mutableStateOf<String?>(null)
        var dismissed: String? = null
        fun active() = key().let { it == "ask" || (it != "auto" && Store.b("rotHint", true)) }
        val lis = object : OrientationEventListener(a) {
            override fun onOrientationChanged(deg: Int) {
                if (!active() || deg == ORIENTATION_UNKNOWN) { if (sugg != null) sugg = null; return }
                val want = when { deg >= 330 || deg < 30 -> "portrait"; deg in 60..120 -> "landscape_rev"; deg in 240..300 -> "landscape"; else -> return }
                if (want == current(a)) { sugg = null; dismissed = null; return }
                if (dismissed == want) return
                sugg = want
            }
        }
        if (lis.canDetectOrientation()) lis.enable()
        val v = ComposeView(a).apply { setContent {
            val s = sugg
            val v0 = androidx.compose.ui.platform.LocalView.current
            val pos = Store.s("rotHintPos", "top")
            val dens = a.resources.displayMetrics.density
            androidx.compose.runtime.SideEffect {
                (v0.layoutParams as? FrameLayout.LayoutParams)?.let {
                    val g = Gravity.END or (if (pos == "bottom") Gravity.BOTTOM else if (pos == "middle") Gravity.CENTER_VERTICAL else Gravity.TOP)
                    if (it.gravity != g) { it.gravity = g; v0.layoutParams = it }
                }
            }
            val sec = Store.i("rotHintSec", 8)
            androidx.compose.runtime.LaunchedEffect(s, sec) {
                if (s != null && sec > 0) { kotlinx.coroutines.delay(sec * 1000L); dismissed = s; sugg = null }
            }
            if (s != null && active()) Text("⟳ ROTATE", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                modifier = Modifier.background(Color(0xDD1565C0), RoundedCornerShape(24.dp)).forgeClick {
                    a.requestedOrientation = flag(s); sugg = null; dismissed = null
                    if (key() == "ask") { Store.set("orientGame", "ask"); a.window.decorView.postDelayed({ a.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LOCKED }, 900) }
                    else Store.set("orientGame", s)
                }.padding(horizontal = 14.dp, vertical = 12.dp))
        } }
        a.addContentView(v, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.END or Gravity.TOP).apply { marginEnd = (16 * a.resources.displayMetrics.density).toInt(); topMargin = (64 * a.resources.displayMetrics.density).toInt(); bottomMargin = (24 * a.resources.displayMetrics.density).toInt() })
        a.lifecycle.addObserver(object : androidx.lifecycle.DefaultLifecycleObserver { override fun onDestroy(owner: androidx.lifecycle.LifecycleOwner) { lis.disable() } })
    }
}
